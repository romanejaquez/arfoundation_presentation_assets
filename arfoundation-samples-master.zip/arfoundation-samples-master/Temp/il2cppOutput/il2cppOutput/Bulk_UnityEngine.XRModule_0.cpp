﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>
#include <stdint.h>

#include "il2cpp-class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "il2cpp-object-internals.h"

template <typename T1>
struct InterfaceActionInvoker1
{
	typedef void (*Action)(void*, T1, const RuntimeMethod*);

	static inline void Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj, T1 p1)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		((Action)invokeData.methodPtr)(obj, p1, invokeData.method);
	}
};

// System.Action`1<UnityEngine.Experimental.XR.FrameReceivedEventArgs>
struct Action_1_t2760547698;
// System.Action`1<UnityEngine.Experimental.XR.PlaneAddedEventArgs>
struct Action_1_t2722643320;
// System.Action`1<UnityEngine.Experimental.XR.PlaneRemovedEventArgs>
struct Action_1_t1739597377;
// System.Action`1<UnityEngine.Experimental.XR.PlaneUpdatedEventArgs>
struct Action_1_t521953446;
// System.Action`1<UnityEngine.Experimental.XR.PointCloudUpdatedEventArgs>
struct Action_1_t3609124943;
// System.Action`1<UnityEngine.Experimental.XR.ReferencePointUpdatedEventArgs>
struct Action_1_t2218980328;
// System.Action`1<UnityEngine.Experimental.XR.SessionTrackingStateChangedEventArgs>
struct Action_1_t2515503250;
// System.Action`1<UnityEngine.XR.XRNodeState>
struct Action_1_t3925070025;
// System.ArgumentException
struct ArgumentException_t132251570;
// System.ArgumentNullException
struct ArgumentNullException_t1615371798;
// System.AsyncCallback
struct AsyncCallback_t3962456242;
// System.Char[]
struct CharU5BU5D_t3528271667;
// System.Collections.Generic.List`1<System.Object>
struct List_1_t257213610;
// System.Collections.Generic.List`1<System.Single>
struct List_1_t2869341516;
// System.Collections.Generic.List`1<UnityEngine.Experimental.ISubsystemDescriptorImpl>
struct List_1_t60503245;
// System.Collections.Generic.List`1<UnityEngine.Experimental.Subsystem>
struct List_1_t1561798217;
// System.Collections.Generic.List`1<UnityEngine.Experimental.XR.BoundedPlane>
struct List_1_t2789567076;
// System.Collections.Generic.List`1<UnityEngine.Experimental.XR.XRRaycastHit>
struct List_1_t3842879816;
// System.Collections.Generic.List`1<UnityEngine.Vector3>
struct List_1_t899420910;
// System.Collections.Generic.List`1<UnityEngine.XR.XRNodeState>
struct List_1_t929709876;
// System.Collections.IDictionary
struct IDictionary_t1363984059;
// System.Delegate
struct Delegate_t1188392813;
// System.DelegateData
struct DelegateData_t1677132599;
// System.IAsyncResult
struct IAsyncResult_t767004451;
// System.IntPtr[]
struct IntPtrU5BU5D_t4013366056;
// System.Reflection.MethodInfo
struct MethodInfo_t;
// System.Single[]
struct SingleU5BU5D_t1444911251;
// System.String
struct String_t;
// System.Void
struct Void_t1185182177;
// UnityEngine.Camera
struct Camera_t4157153871;
// UnityEngine.Camera/CameraCallback
struct CameraCallback_t190067161;
// UnityEngine.Experimental.ISubsystemDescriptor
struct ISubsystemDescriptor_t515866703;
// UnityEngine.Experimental.ISubsystemDescriptorImpl
struct ISubsystemDescriptorImpl_t2883395799;
// UnityEngine.Experimental.ISubsystemDescriptorImpl[]
struct ISubsystemDescriptorImplU5BU5D_t2330535406;
// UnityEngine.Experimental.Subsystem
struct Subsystem_t89723475;
// UnityEngine.Experimental.SubsystemDescriptorBase
struct SubsystemDescriptorBase_t2374447182;
// UnityEngine.Experimental.Subsystem[]
struct SubsystemU5BU5D_t3923325698;
// UnityEngine.Experimental.XR.BoundedPlane[]
struct BoundedPlaneU5BU5D_t1105497115;
// UnityEngine.Experimental.XR.XRCameraSubsystem
struct XRCameraSubsystem_t4195795144;
// UnityEngine.Experimental.XR.XRDepthSubsystem
struct XRDepthSubsystem_t4084359858;
// UnityEngine.Experimental.XR.XRPlaneSubsystem
struct XRPlaneSubsystem_t2260142932;
// UnityEngine.Experimental.XR.XRRaycastHit[]
struct XRRaycastHitU5BU5D_t3736959271;
// UnityEngine.Experimental.XR.XRRaycastSubsystem
struct XRRaycastSubsystem_t2747560419;
// UnityEngine.Experimental.XR.XRReferencePointSubsystem
struct XRReferencePointSubsystem_t416875062;
// UnityEngine.Experimental.XR.XRSessionSubsystem
struct XRSessionSubsystem_t3616338244;
// UnityEngine.Material
struct Material_t340375123;
// UnityEngine.Vector3[]
struct Vector3U5BU5D_t1718750761;
// UnityEngine.XR.XRNodeState[]
struct XRNodeStateU5BU5D_t1311914507;

extern RuntimeClass* Action_1_t1739597377_il2cpp_TypeInfo_var;
extern RuntimeClass* Action_1_t2218980328_il2cpp_TypeInfo_var;
extern RuntimeClass* Action_1_t2515503250_il2cpp_TypeInfo_var;
extern RuntimeClass* Action_1_t2722643320_il2cpp_TypeInfo_var;
extern RuntimeClass* Action_1_t2760547698_il2cpp_TypeInfo_var;
extern RuntimeClass* Action_1_t3609124943_il2cpp_TypeInfo_var;
extern RuntimeClass* Action_1_t521953446_il2cpp_TypeInfo_var;
extern RuntimeClass* ArgumentException_t132251570_il2cpp_TypeInfo_var;
extern RuntimeClass* ArgumentNullException_t1615371798_il2cpp_TypeInfo_var;
extern RuntimeClass* ISubsystemDescriptorImpl_t2883395799_il2cpp_TypeInfo_var;
extern RuntimeClass* InputTracking_t2240286067_il2cpp_TypeInfo_var;
extern RuntimeClass* IntPtr_t_il2cpp_TypeInfo_var;
extern RuntimeClass* Internal_SubsystemDescriptors_t691162017_il2cpp_TypeInfo_var;
extern RuntimeClass* Internal_SubsystemInstances_t893566515_il2cpp_TypeInfo_var;
extern RuntimeClass* List_1_t1561798217_il2cpp_TypeInfo_var;
extern RuntimeClass* List_1_t60503245_il2cpp_TypeInfo_var;
extern RuntimeClass* Mathf_t3464937446_il2cpp_TypeInfo_var;
extern RuntimeClass* String_t_il2cpp_TypeInfo_var;
extern RuntimeClass* SubsystemManager_t1056502336_il2cpp_TypeInfo_var;
extern RuntimeClass* TrackableId_t1251031970_il2cpp_TypeInfo_var;
extern RuntimeClass* TrackingStateEventType_t4085253601_il2cpp_TypeInfo_var;
extern String_t* _stringLiteral1754079207;
extern String_t* _stringLiteral2047980736;
extern String_t* _stringLiteral2112669954;
extern String_t* _stringLiteral2268009268;
extern String_t* _stringLiteral3520200148;
extern String_t* _stringLiteral4273954858;
extern String_t* _stringLiteral450688759;
extern String_t* _stringLiteral56995845;
extern String_t* _stringLiteral772464777;
extern const RuntimeMethod* Action_1_Invoke_m1143137826_RuntimeMethod_var;
extern const RuntimeMethod* Action_1_Invoke_m1458665122_RuntimeMethod_var;
extern const RuntimeMethod* Action_1_Invoke_m2953615518_RuntimeMethod_var;
extern const RuntimeMethod* Action_1_Invoke_m3012248422_RuntimeMethod_var;
extern const RuntimeMethod* Action_1_Invoke_m316788244_RuntimeMethod_var;
extern const RuntimeMethod* Action_1_Invoke_m3662407658_RuntimeMethod_var;
extern const RuntimeMethod* Action_1_Invoke_m3768946330_RuntimeMethod_var;
extern const RuntimeMethod* Action_1_Invoke_m4140516850_RuntimeMethod_var;
extern const RuntimeMethod* BoundedPlane_TryGetBoundary_m3909741008_RuntimeMethod_var;
extern const RuntimeMethod* Enumerator_Dispose_m2979251017_RuntimeMethod_var;
extern const RuntimeMethod* Enumerator_Dispose_m4163083902_RuntimeMethod_var;
extern const RuntimeMethod* Enumerator_MoveNext_m2084212791_RuntimeMethod_var;
extern const RuntimeMethod* Enumerator_MoveNext_m3572286872_RuntimeMethod_var;
extern const RuntimeMethod* Enumerator_get_Current_m1367904766_RuntimeMethod_var;
extern const RuntimeMethod* Enumerator_get_Current_m4233439720_RuntimeMethod_var;
extern const RuntimeMethod* InputTracking_GetNodeStates_m713678237_RuntimeMethod_var;
extern const RuntimeMethod* InputTracking_InvokeTrackingEvent_m2819866424_RuntimeMethod_var;
extern const RuntimeMethod* List_1_Add_m2793820062_RuntimeMethod_var;
extern const RuntimeMethod* List_1_Add_m3860418725_RuntimeMethod_var;
extern const RuntimeMethod* List_1_Clear_m1794174222_RuntimeMethod_var;
extern const RuntimeMethod* List_1_Clear_m2449803944_RuntimeMethod_var;
extern const RuntimeMethod* List_1_Clear_m2804938920_RuntimeMethod_var;
extern const RuntimeMethod* List_1_GetEnumerator_m2059771147_RuntimeMethod_var;
extern const RuntimeMethod* List_1_GetEnumerator_m489737270_RuntimeMethod_var;
extern const RuntimeMethod* List_1_RemoveAt_m1171746181_RuntimeMethod_var;
extern const RuntimeMethod* List_1__ctor_m3747657077_RuntimeMethod_var;
extern const RuntimeMethod* List_1__ctor_m910085292_RuntimeMethod_var;
extern const RuntimeMethod* List_1_get_Count_m4144085239_RuntimeMethod_var;
extern const RuntimeMethod* List_1_get_Item_m4223061980_RuntimeMethod_var;
extern const RuntimeMethod* XRDepthSubsystem_GetConfidence_m621056309_RuntimeMethod_var;
extern const RuntimeMethod* XRDepthSubsystem_GetPoints_m2117729361_RuntimeMethod_var;
extern const RuntimeMethod* XRNodeState_TryGet_TisQuaternion_t2301928331_m1353060540_RuntimeMethod_var;
extern const RuntimeMethod* XRNodeState_TryGet_TisVector3_t3722313464_m270903620_RuntimeMethod_var;
extern const RuntimeMethod* XRPlaneSubsystem_GetAllPlanes_m1313721439_RuntimeMethod_var;
extern const RuntimeMethod* XRRaycastSubsystem_Raycast_m2841114376_RuntimeMethod_var;
extern const RuntimeMethod* XRRaycastSubsystem_Raycast_m4086064154_RuntimeMethod_var;
extern const uint32_t BoundedPlane_TryGetBoundary_m3909741008_MetadataUsageId;
extern const uint32_t InputTracking_GetNodeStates_m713678237_MetadataUsageId;
extern const uint32_t InputTracking_InvokeTrackingEvent_m2819866424_MetadataUsageId;
extern const uint32_t InputTracking__cctor_m3381564435_MetadataUsageId;
extern const uint32_t Internal_SubsystemDescriptors_Internal_ClearManagedDescriptors_m1351509011_MetadataUsageId;
extern const uint32_t Internal_SubsystemDescriptors_Internal_InitializeManagedDescriptor_m2393151601_MetadataUsageId;
extern const uint32_t Internal_SubsystemDescriptors__cctor_m2670682352_MetadataUsageId;
extern const uint32_t Internal_SubsystemInstances_Internal_ClearManagedInstances_m856038640_MetadataUsageId;
extern const uint32_t Internal_SubsystemInstances_Internal_GetInstanceByPtr_m1622708940_MetadataUsageId;
extern const uint32_t Internal_SubsystemInstances_Internal_InitializeManagedInstance_m317893559_MetadataUsageId;
extern const uint32_t Internal_SubsystemInstances_Internal_RemoveInstanceByPtr_m3992065214_MetadataUsageId;
extern const uint32_t Internal_SubsystemInstances__cctor_m482657293_MetadataUsageId;
extern const uint32_t SubsystemDescriptorBase_get_id_m893539935_MetadataUsageId;
extern const uint32_t Subsystem_Destroy_m328346957_MetadataUsageId;
extern const uint32_t TrackableId_Equals_m1354170007_MetadataUsageId;
extern const uint32_t TrackableId_ToString_m2456781735_MetadataUsageId;
extern const uint32_t TrackableId__cctor_m2923896333_MetadataUsageId;
extern const uint32_t TrackableId_get_InvalidId_m4062814271_MetadataUsageId;
extern const uint32_t XRCameraSubsystem_InvokeFrameReceivedEvent_m3350736905_MetadataUsageId;
extern const uint32_t XRCameraSubsystem_add_FrameReceived_m1573821284_MetadataUsageId;
extern const uint32_t XRCameraSubsystem_remove_FrameReceived_m700817009_MetadataUsageId;
extern const uint32_t XRDepthSubsystem_GetConfidence_m621056309_MetadataUsageId;
extern const uint32_t XRDepthSubsystem_GetPoints_m2117729361_MetadataUsageId;
extern const uint32_t XRDepthSubsystem_InvokePointCloudUpdatedEvent_m4090616323_MetadataUsageId;
extern const uint32_t XRDepthSubsystem_add_PointCloudUpdated_m3369518994_MetadataUsageId;
extern const uint32_t XRDepthSubsystem_remove_PointCloudUpdated_m74894791_MetadataUsageId;
extern const uint32_t XRNodeState_TryGetPosition_m2700381506_MetadataUsageId;
extern const uint32_t XRNodeState_TryGetRotation_m2439801437_MetadataUsageId;
extern const uint32_t XRPlaneSubsystem_GetAllPlanes_m1313721439_MetadataUsageId;
extern const uint32_t XRPlaneSubsystem_InvokePlaneAddedEvent_m2287049231_MetadataUsageId;
extern const uint32_t XRPlaneSubsystem_InvokePlaneRemovedEvent_m3495166678_MetadataUsageId;
extern const uint32_t XRPlaneSubsystem_InvokePlaneUpdatedEvent_m3431602433_MetadataUsageId;
extern const uint32_t XRPlaneSubsystem_add_PlaneAdded_m4075589642_MetadataUsageId;
extern const uint32_t XRPlaneSubsystem_add_PlaneRemoved_m894814380_MetadataUsageId;
extern const uint32_t XRPlaneSubsystem_add_PlaneUpdated_m167230714_MetadataUsageId;
extern const uint32_t XRPlaneSubsystem_remove_PlaneAdded_m28955542_MetadataUsageId;
extern const uint32_t XRPlaneSubsystem_remove_PlaneRemoved_m3207440425_MetadataUsageId;
extern const uint32_t XRPlaneSubsystem_remove_PlaneUpdated_m1675113179_MetadataUsageId;
extern const uint32_t XRRaycastSubsystem_Raycast_m2841114376_MetadataUsageId;
extern const uint32_t XRRaycastSubsystem_Raycast_m4086064154_MetadataUsageId;
extern const uint32_t XRReferencePointSubsystem_InvokeReferencePointUpdatedEvent_m2042954667_MetadataUsageId;
extern const uint32_t XRReferencePointSubsystem_add_ReferencePointUpdated_m294229468_MetadataUsageId;
extern const uint32_t XRReferencePointSubsystem_remove_ReferencePointUpdated_m1056993445_MetadataUsageId;
extern const uint32_t XRSessionSubsystem_InvokeTrackingStateChangedEvent_m3292975511_MetadataUsageId;
extern const uint32_t XRSessionSubsystem_add_TrackingStateChanged_m1723182294_MetadataUsageId;
extern const uint32_t XRSessionSubsystem_remove_TrackingStateChanged_m2915536988_MetadataUsageId;



#ifndef U3CMODULEU3E_T692745533_H
#define U3CMODULEU3E_T692745533_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_t692745533 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_T692745533_H
#ifndef RUNTIMEOBJECT_H
#define RUNTIMEOBJECT_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Object

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEOBJECT_H
struct Il2CppArrayBounds;
#ifndef RUNTIMEARRAY_H
#define RUNTIMEARRAY_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Array

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEARRAY_H
#ifndef LIST_1_T2869341516_H
#define LIST_1_T2869341516_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.List`1<System.Single>
struct  List_1_t2869341516  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	SingleU5BU5D_t1444911251* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_t2869341516, ____items_1)); }
	inline SingleU5BU5D_t1444911251* get__items_1() const { return ____items_1; }
	inline SingleU5BU5D_t1444911251** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(SingleU5BU5D_t1444911251* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((&____items_1), value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_t2869341516, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_t2869341516, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}
};

struct List_1_t2869341516_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::EmptyArray
	SingleU5BU5D_t1444911251* ___EmptyArray_4;

public:
	inline static int32_t get_offset_of_EmptyArray_4() { return static_cast<int32_t>(offsetof(List_1_t2869341516_StaticFields, ___EmptyArray_4)); }
	inline SingleU5BU5D_t1444911251* get_EmptyArray_4() const { return ___EmptyArray_4; }
	inline SingleU5BU5D_t1444911251** get_address_of_EmptyArray_4() { return &___EmptyArray_4; }
	inline void set_EmptyArray_4(SingleU5BU5D_t1444911251* value)
	{
		___EmptyArray_4 = value;
		Il2CppCodeGenWriteBarrier((&___EmptyArray_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LIST_1_T2869341516_H
#ifndef LIST_1_T60503245_H
#define LIST_1_T60503245_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.List`1<UnityEngine.Experimental.ISubsystemDescriptorImpl>
struct  List_1_t60503245  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	ISubsystemDescriptorImplU5BU5D_t2330535406* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_t60503245, ____items_1)); }
	inline ISubsystemDescriptorImplU5BU5D_t2330535406* get__items_1() const { return ____items_1; }
	inline ISubsystemDescriptorImplU5BU5D_t2330535406** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(ISubsystemDescriptorImplU5BU5D_t2330535406* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((&____items_1), value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_t60503245, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_t60503245, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}
};

struct List_1_t60503245_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::EmptyArray
	ISubsystemDescriptorImplU5BU5D_t2330535406* ___EmptyArray_4;

public:
	inline static int32_t get_offset_of_EmptyArray_4() { return static_cast<int32_t>(offsetof(List_1_t60503245_StaticFields, ___EmptyArray_4)); }
	inline ISubsystemDescriptorImplU5BU5D_t2330535406* get_EmptyArray_4() const { return ___EmptyArray_4; }
	inline ISubsystemDescriptorImplU5BU5D_t2330535406** get_address_of_EmptyArray_4() { return &___EmptyArray_4; }
	inline void set_EmptyArray_4(ISubsystemDescriptorImplU5BU5D_t2330535406* value)
	{
		___EmptyArray_4 = value;
		Il2CppCodeGenWriteBarrier((&___EmptyArray_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LIST_1_T60503245_H
#ifndef LIST_1_T1561798217_H
#define LIST_1_T1561798217_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.List`1<UnityEngine.Experimental.Subsystem>
struct  List_1_t1561798217  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	SubsystemU5BU5D_t3923325698* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_t1561798217, ____items_1)); }
	inline SubsystemU5BU5D_t3923325698* get__items_1() const { return ____items_1; }
	inline SubsystemU5BU5D_t3923325698** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(SubsystemU5BU5D_t3923325698* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((&____items_1), value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_t1561798217, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_t1561798217, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}
};

struct List_1_t1561798217_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::EmptyArray
	SubsystemU5BU5D_t3923325698* ___EmptyArray_4;

public:
	inline static int32_t get_offset_of_EmptyArray_4() { return static_cast<int32_t>(offsetof(List_1_t1561798217_StaticFields, ___EmptyArray_4)); }
	inline SubsystemU5BU5D_t3923325698* get_EmptyArray_4() const { return ___EmptyArray_4; }
	inline SubsystemU5BU5D_t3923325698** get_address_of_EmptyArray_4() { return &___EmptyArray_4; }
	inline void set_EmptyArray_4(SubsystemU5BU5D_t3923325698* value)
	{
		___EmptyArray_4 = value;
		Il2CppCodeGenWriteBarrier((&___EmptyArray_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LIST_1_T1561798217_H
#ifndef LIST_1_T2789567076_H
#define LIST_1_T2789567076_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.List`1<UnityEngine.Experimental.XR.BoundedPlane>
struct  List_1_t2789567076  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	BoundedPlaneU5BU5D_t1105497115* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_t2789567076, ____items_1)); }
	inline BoundedPlaneU5BU5D_t1105497115* get__items_1() const { return ____items_1; }
	inline BoundedPlaneU5BU5D_t1105497115** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(BoundedPlaneU5BU5D_t1105497115* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((&____items_1), value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_t2789567076, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_t2789567076, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}
};

struct List_1_t2789567076_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::EmptyArray
	BoundedPlaneU5BU5D_t1105497115* ___EmptyArray_4;

public:
	inline static int32_t get_offset_of_EmptyArray_4() { return static_cast<int32_t>(offsetof(List_1_t2789567076_StaticFields, ___EmptyArray_4)); }
	inline BoundedPlaneU5BU5D_t1105497115* get_EmptyArray_4() const { return ___EmptyArray_4; }
	inline BoundedPlaneU5BU5D_t1105497115** get_address_of_EmptyArray_4() { return &___EmptyArray_4; }
	inline void set_EmptyArray_4(BoundedPlaneU5BU5D_t1105497115* value)
	{
		___EmptyArray_4 = value;
		Il2CppCodeGenWriteBarrier((&___EmptyArray_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LIST_1_T2789567076_H
#ifndef LIST_1_T3842879816_H
#define LIST_1_T3842879816_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.List`1<UnityEngine.Experimental.XR.XRRaycastHit>
struct  List_1_t3842879816  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	XRRaycastHitU5BU5D_t3736959271* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_t3842879816, ____items_1)); }
	inline XRRaycastHitU5BU5D_t3736959271* get__items_1() const { return ____items_1; }
	inline XRRaycastHitU5BU5D_t3736959271** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(XRRaycastHitU5BU5D_t3736959271* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((&____items_1), value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_t3842879816, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_t3842879816, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}
};

struct List_1_t3842879816_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::EmptyArray
	XRRaycastHitU5BU5D_t3736959271* ___EmptyArray_4;

public:
	inline static int32_t get_offset_of_EmptyArray_4() { return static_cast<int32_t>(offsetof(List_1_t3842879816_StaticFields, ___EmptyArray_4)); }
	inline XRRaycastHitU5BU5D_t3736959271* get_EmptyArray_4() const { return ___EmptyArray_4; }
	inline XRRaycastHitU5BU5D_t3736959271** get_address_of_EmptyArray_4() { return &___EmptyArray_4; }
	inline void set_EmptyArray_4(XRRaycastHitU5BU5D_t3736959271* value)
	{
		___EmptyArray_4 = value;
		Il2CppCodeGenWriteBarrier((&___EmptyArray_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LIST_1_T3842879816_H
#ifndef LIST_1_T899420910_H
#define LIST_1_T899420910_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.List`1<UnityEngine.Vector3>
struct  List_1_t899420910  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	Vector3U5BU5D_t1718750761* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_t899420910, ____items_1)); }
	inline Vector3U5BU5D_t1718750761* get__items_1() const { return ____items_1; }
	inline Vector3U5BU5D_t1718750761** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(Vector3U5BU5D_t1718750761* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((&____items_1), value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_t899420910, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_t899420910, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}
};

struct List_1_t899420910_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::EmptyArray
	Vector3U5BU5D_t1718750761* ___EmptyArray_4;

public:
	inline static int32_t get_offset_of_EmptyArray_4() { return static_cast<int32_t>(offsetof(List_1_t899420910_StaticFields, ___EmptyArray_4)); }
	inline Vector3U5BU5D_t1718750761* get_EmptyArray_4() const { return ___EmptyArray_4; }
	inline Vector3U5BU5D_t1718750761** get_address_of_EmptyArray_4() { return &___EmptyArray_4; }
	inline void set_EmptyArray_4(Vector3U5BU5D_t1718750761* value)
	{
		___EmptyArray_4 = value;
		Il2CppCodeGenWriteBarrier((&___EmptyArray_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LIST_1_T899420910_H
#ifndef LIST_1_T929709876_H
#define LIST_1_T929709876_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.List`1<UnityEngine.XR.XRNodeState>
struct  List_1_t929709876  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	XRNodeStateU5BU5D_t1311914507* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_t929709876, ____items_1)); }
	inline XRNodeStateU5BU5D_t1311914507* get__items_1() const { return ____items_1; }
	inline XRNodeStateU5BU5D_t1311914507** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(XRNodeStateU5BU5D_t1311914507* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((&____items_1), value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_t929709876, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_t929709876, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}
};

struct List_1_t929709876_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::EmptyArray
	XRNodeStateU5BU5D_t1311914507* ___EmptyArray_4;

public:
	inline static int32_t get_offset_of_EmptyArray_4() { return static_cast<int32_t>(offsetof(List_1_t929709876_StaticFields, ___EmptyArray_4)); }
	inline XRNodeStateU5BU5D_t1311914507* get_EmptyArray_4() const { return ___EmptyArray_4; }
	inline XRNodeStateU5BU5D_t1311914507** get_address_of_EmptyArray_4() { return &___EmptyArray_4; }
	inline void set_EmptyArray_4(XRNodeStateU5BU5D_t1311914507* value)
	{
		___EmptyArray_4 = value;
		Il2CppCodeGenWriteBarrier((&___EmptyArray_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LIST_1_T929709876_H
#ifndef EXCEPTION_T_H
#define EXCEPTION_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Exception
struct  Exception_t  : public RuntimeObject
{
public:
	// System.IntPtr[] System.Exception::trace_ips
	IntPtrU5BU5D_t4013366056* ___trace_ips_0;
	// System.Exception System.Exception::inner_exception
	Exception_t * ___inner_exception_1;
	// System.String System.Exception::message
	String_t* ___message_2;
	// System.String System.Exception::help_link
	String_t* ___help_link_3;
	// System.String System.Exception::class_name
	String_t* ___class_name_4;
	// System.String System.Exception::stack_trace
	String_t* ___stack_trace_5;
	// System.String System.Exception::_remoteStackTraceString
	String_t* ____remoteStackTraceString_6;
	// System.Int32 System.Exception::remote_stack_index
	int32_t ___remote_stack_index_7;
	// System.Int32 System.Exception::hresult
	int32_t ___hresult_8;
	// System.String System.Exception::source
	String_t* ___source_9;
	// System.Collections.IDictionary System.Exception::_data
	RuntimeObject* ____data_10;

public:
	inline static int32_t get_offset_of_trace_ips_0() { return static_cast<int32_t>(offsetof(Exception_t, ___trace_ips_0)); }
	inline IntPtrU5BU5D_t4013366056* get_trace_ips_0() const { return ___trace_ips_0; }
	inline IntPtrU5BU5D_t4013366056** get_address_of_trace_ips_0() { return &___trace_ips_0; }
	inline void set_trace_ips_0(IntPtrU5BU5D_t4013366056* value)
	{
		___trace_ips_0 = value;
		Il2CppCodeGenWriteBarrier((&___trace_ips_0), value);
	}

	inline static int32_t get_offset_of_inner_exception_1() { return static_cast<int32_t>(offsetof(Exception_t, ___inner_exception_1)); }
	inline Exception_t * get_inner_exception_1() const { return ___inner_exception_1; }
	inline Exception_t ** get_address_of_inner_exception_1() { return &___inner_exception_1; }
	inline void set_inner_exception_1(Exception_t * value)
	{
		___inner_exception_1 = value;
		Il2CppCodeGenWriteBarrier((&___inner_exception_1), value);
	}

	inline static int32_t get_offset_of_message_2() { return static_cast<int32_t>(offsetof(Exception_t, ___message_2)); }
	inline String_t* get_message_2() const { return ___message_2; }
	inline String_t** get_address_of_message_2() { return &___message_2; }
	inline void set_message_2(String_t* value)
	{
		___message_2 = value;
		Il2CppCodeGenWriteBarrier((&___message_2), value);
	}

	inline static int32_t get_offset_of_help_link_3() { return static_cast<int32_t>(offsetof(Exception_t, ___help_link_3)); }
	inline String_t* get_help_link_3() const { return ___help_link_3; }
	inline String_t** get_address_of_help_link_3() { return &___help_link_3; }
	inline void set_help_link_3(String_t* value)
	{
		___help_link_3 = value;
		Il2CppCodeGenWriteBarrier((&___help_link_3), value);
	}

	inline static int32_t get_offset_of_class_name_4() { return static_cast<int32_t>(offsetof(Exception_t, ___class_name_4)); }
	inline String_t* get_class_name_4() const { return ___class_name_4; }
	inline String_t** get_address_of_class_name_4() { return &___class_name_4; }
	inline void set_class_name_4(String_t* value)
	{
		___class_name_4 = value;
		Il2CppCodeGenWriteBarrier((&___class_name_4), value);
	}

	inline static int32_t get_offset_of_stack_trace_5() { return static_cast<int32_t>(offsetof(Exception_t, ___stack_trace_5)); }
	inline String_t* get_stack_trace_5() const { return ___stack_trace_5; }
	inline String_t** get_address_of_stack_trace_5() { return &___stack_trace_5; }
	inline void set_stack_trace_5(String_t* value)
	{
		___stack_trace_5 = value;
		Il2CppCodeGenWriteBarrier((&___stack_trace_5), value);
	}

	inline static int32_t get_offset_of__remoteStackTraceString_6() { return static_cast<int32_t>(offsetof(Exception_t, ____remoteStackTraceString_6)); }
	inline String_t* get__remoteStackTraceString_6() const { return ____remoteStackTraceString_6; }
	inline String_t** get_address_of__remoteStackTraceString_6() { return &____remoteStackTraceString_6; }
	inline void set__remoteStackTraceString_6(String_t* value)
	{
		____remoteStackTraceString_6 = value;
		Il2CppCodeGenWriteBarrier((&____remoteStackTraceString_6), value);
	}

	inline static int32_t get_offset_of_remote_stack_index_7() { return static_cast<int32_t>(offsetof(Exception_t, ___remote_stack_index_7)); }
	inline int32_t get_remote_stack_index_7() const { return ___remote_stack_index_7; }
	inline int32_t* get_address_of_remote_stack_index_7() { return &___remote_stack_index_7; }
	inline void set_remote_stack_index_7(int32_t value)
	{
		___remote_stack_index_7 = value;
	}

	inline static int32_t get_offset_of_hresult_8() { return static_cast<int32_t>(offsetof(Exception_t, ___hresult_8)); }
	inline int32_t get_hresult_8() const { return ___hresult_8; }
	inline int32_t* get_address_of_hresult_8() { return &___hresult_8; }
	inline void set_hresult_8(int32_t value)
	{
		___hresult_8 = value;
	}

	inline static int32_t get_offset_of_source_9() { return static_cast<int32_t>(offsetof(Exception_t, ___source_9)); }
	inline String_t* get_source_9() const { return ___source_9; }
	inline String_t** get_address_of_source_9() { return &___source_9; }
	inline void set_source_9(String_t* value)
	{
		___source_9 = value;
		Il2CppCodeGenWriteBarrier((&___source_9), value);
	}

	inline static int32_t get_offset_of__data_10() { return static_cast<int32_t>(offsetof(Exception_t, ____data_10)); }
	inline RuntimeObject* get__data_10() const { return ____data_10; }
	inline RuntimeObject** get_address_of__data_10() { return &____data_10; }
	inline void set__data_10(RuntimeObject* value)
	{
		____data_10 = value;
		Il2CppCodeGenWriteBarrier((&____data_10), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EXCEPTION_T_H
#ifndef STRING_T_H
#define STRING_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.String
struct  String_t  : public RuntimeObject
{
public:
	// System.Int32 System.String::length
	int32_t ___length_0;
	// System.Char System.String::start_char
	Il2CppChar ___start_char_1;

public:
	inline static int32_t get_offset_of_length_0() { return static_cast<int32_t>(offsetof(String_t, ___length_0)); }
	inline int32_t get_length_0() const { return ___length_0; }
	inline int32_t* get_address_of_length_0() { return &___length_0; }
	inline void set_length_0(int32_t value)
	{
		___length_0 = value;
	}

	inline static int32_t get_offset_of_start_char_1() { return static_cast<int32_t>(offsetof(String_t, ___start_char_1)); }
	inline Il2CppChar get_start_char_1() const { return ___start_char_1; }
	inline Il2CppChar* get_address_of_start_char_1() { return &___start_char_1; }
	inline void set_start_char_1(Il2CppChar value)
	{
		___start_char_1 = value;
	}
};

struct String_t_StaticFields
{
public:
	// System.String System.String::Empty
	String_t* ___Empty_2;
	// System.Char[] System.String::WhiteChars
	CharU5BU5D_t3528271667* ___WhiteChars_3;

public:
	inline static int32_t get_offset_of_Empty_2() { return static_cast<int32_t>(offsetof(String_t_StaticFields, ___Empty_2)); }
	inline String_t* get_Empty_2() const { return ___Empty_2; }
	inline String_t** get_address_of_Empty_2() { return &___Empty_2; }
	inline void set_Empty_2(String_t* value)
	{
		___Empty_2 = value;
		Il2CppCodeGenWriteBarrier((&___Empty_2), value);
	}

	inline static int32_t get_offset_of_WhiteChars_3() { return static_cast<int32_t>(offsetof(String_t_StaticFields, ___WhiteChars_3)); }
	inline CharU5BU5D_t3528271667* get_WhiteChars_3() const { return ___WhiteChars_3; }
	inline CharU5BU5D_t3528271667** get_address_of_WhiteChars_3() { return &___WhiteChars_3; }
	inline void set_WhiteChars_3(CharU5BU5D_t3528271667* value)
	{
		___WhiteChars_3 = value;
		Il2CppCodeGenWriteBarrier((&___WhiteChars_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // STRING_T_H
#ifndef VALUETYPE_T3640485471_H
#define VALUETYPE_T3640485471_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ValueType
struct  ValueType_t3640485471  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t3640485471_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t3640485471_marshaled_com
{
};
#endif // VALUETYPE_T3640485471_H
#ifndef INTERNAL_SUBSYSTEMDESCRIPTORS_T691162017_H
#define INTERNAL_SUBSYSTEMDESCRIPTORS_T691162017_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.Internal_SubsystemDescriptors
struct  Internal_SubsystemDescriptors_t691162017  : public RuntimeObject
{
public:

public:
};

struct Internal_SubsystemDescriptors_t691162017_StaticFields
{
public:
	// System.Collections.Generic.List`1<UnityEngine.Experimental.ISubsystemDescriptorImpl> UnityEngine.Experimental.Internal_SubsystemDescriptors::s_SubsystemDescriptors
	List_1_t60503245 * ___s_SubsystemDescriptors_0;

public:
	inline static int32_t get_offset_of_s_SubsystemDescriptors_0() { return static_cast<int32_t>(offsetof(Internal_SubsystemDescriptors_t691162017_StaticFields, ___s_SubsystemDescriptors_0)); }
	inline List_1_t60503245 * get_s_SubsystemDescriptors_0() const { return ___s_SubsystemDescriptors_0; }
	inline List_1_t60503245 ** get_address_of_s_SubsystemDescriptors_0() { return &___s_SubsystemDescriptors_0; }
	inline void set_s_SubsystemDescriptors_0(List_1_t60503245 * value)
	{
		___s_SubsystemDescriptors_0 = value;
		Il2CppCodeGenWriteBarrier((&___s_SubsystemDescriptors_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTERNAL_SUBSYSTEMDESCRIPTORS_T691162017_H
#ifndef INTERNAL_SUBSYSTEMINSTANCES_T893566515_H
#define INTERNAL_SUBSYSTEMINSTANCES_T893566515_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.Internal_SubsystemInstances
struct  Internal_SubsystemInstances_t893566515  : public RuntimeObject
{
public:

public:
};

struct Internal_SubsystemInstances_t893566515_StaticFields
{
public:
	// System.Collections.Generic.List`1<UnityEngine.Experimental.Subsystem> UnityEngine.Experimental.Internal_SubsystemInstances::s_SubsystemInstances
	List_1_t1561798217 * ___s_SubsystemInstances_0;

public:
	inline static int32_t get_offset_of_s_SubsystemInstances_0() { return static_cast<int32_t>(offsetof(Internal_SubsystemInstances_t893566515_StaticFields, ___s_SubsystemInstances_0)); }
	inline List_1_t1561798217 * get_s_SubsystemInstances_0() const { return ___s_SubsystemInstances_0; }
	inline List_1_t1561798217 ** get_address_of_s_SubsystemInstances_0() { return &___s_SubsystemInstances_0; }
	inline void set_s_SubsystemInstances_0(List_1_t1561798217 * value)
	{
		___s_SubsystemInstances_0 = value;
		Il2CppCodeGenWriteBarrier((&___s_SubsystemInstances_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTERNAL_SUBSYSTEMINSTANCES_T893566515_H
#ifndef SUBSYSTEMMANAGER_T1056502336_H
#define SUBSYSTEMMANAGER_T1056502336_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.SubsystemManager
struct  SubsystemManager_t1056502336  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SUBSYSTEMMANAGER_T1056502336_H
#ifndef INPUTTRACKING_T2240286067_H
#define INPUTTRACKING_T2240286067_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.InputTracking
struct  InputTracking_t2240286067  : public RuntimeObject
{
public:

public:
};

struct InputTracking_t2240286067_StaticFields
{
public:
	// System.Action`1<UnityEngine.XR.XRNodeState> UnityEngine.XR.InputTracking::trackingAcquired
	Action_1_t3925070025 * ___trackingAcquired_0;
	// System.Action`1<UnityEngine.XR.XRNodeState> UnityEngine.XR.InputTracking::trackingLost
	Action_1_t3925070025 * ___trackingLost_1;
	// System.Action`1<UnityEngine.XR.XRNodeState> UnityEngine.XR.InputTracking::nodeAdded
	Action_1_t3925070025 * ___nodeAdded_2;
	// System.Action`1<UnityEngine.XR.XRNodeState> UnityEngine.XR.InputTracking::nodeRemoved
	Action_1_t3925070025 * ___nodeRemoved_3;

public:
	inline static int32_t get_offset_of_trackingAcquired_0() { return static_cast<int32_t>(offsetof(InputTracking_t2240286067_StaticFields, ___trackingAcquired_0)); }
	inline Action_1_t3925070025 * get_trackingAcquired_0() const { return ___trackingAcquired_0; }
	inline Action_1_t3925070025 ** get_address_of_trackingAcquired_0() { return &___trackingAcquired_0; }
	inline void set_trackingAcquired_0(Action_1_t3925070025 * value)
	{
		___trackingAcquired_0 = value;
		Il2CppCodeGenWriteBarrier((&___trackingAcquired_0), value);
	}

	inline static int32_t get_offset_of_trackingLost_1() { return static_cast<int32_t>(offsetof(InputTracking_t2240286067_StaticFields, ___trackingLost_1)); }
	inline Action_1_t3925070025 * get_trackingLost_1() const { return ___trackingLost_1; }
	inline Action_1_t3925070025 ** get_address_of_trackingLost_1() { return &___trackingLost_1; }
	inline void set_trackingLost_1(Action_1_t3925070025 * value)
	{
		___trackingLost_1 = value;
		Il2CppCodeGenWriteBarrier((&___trackingLost_1), value);
	}

	inline static int32_t get_offset_of_nodeAdded_2() { return static_cast<int32_t>(offsetof(InputTracking_t2240286067_StaticFields, ___nodeAdded_2)); }
	inline Action_1_t3925070025 * get_nodeAdded_2() const { return ___nodeAdded_2; }
	inline Action_1_t3925070025 ** get_address_of_nodeAdded_2() { return &___nodeAdded_2; }
	inline void set_nodeAdded_2(Action_1_t3925070025 * value)
	{
		___nodeAdded_2 = value;
		Il2CppCodeGenWriteBarrier((&___nodeAdded_2), value);
	}

	inline static int32_t get_offset_of_nodeRemoved_3() { return static_cast<int32_t>(offsetof(InputTracking_t2240286067_StaticFields, ___nodeRemoved_3)); }
	inline Action_1_t3925070025 * get_nodeRemoved_3() const { return ___nodeRemoved_3; }
	inline Action_1_t3925070025 ** get_address_of_nodeRemoved_3() { return &___nodeRemoved_3; }
	inline void set_nodeRemoved_3(Action_1_t3925070025 * value)
	{
		___nodeRemoved_3 = value;
		Il2CppCodeGenWriteBarrier((&___nodeRemoved_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INPUTTRACKING_T2240286067_H
#ifndef BOOLEAN_T97287965_H
#define BOOLEAN_T97287965_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Boolean
struct  Boolean_t97287965 
{
public:
	// System.Boolean System.Boolean::m_value
	bool ___m_value_2;

public:
	inline static int32_t get_offset_of_m_value_2() { return static_cast<int32_t>(offsetof(Boolean_t97287965, ___m_value_2)); }
	inline bool get_m_value_2() const { return ___m_value_2; }
	inline bool* get_address_of_m_value_2() { return &___m_value_2; }
	inline void set_m_value_2(bool value)
	{
		___m_value_2 = value;
	}
};

struct Boolean_t97287965_StaticFields
{
public:
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_0;
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_1;

public:
	inline static int32_t get_offset_of_FalseString_0() { return static_cast<int32_t>(offsetof(Boolean_t97287965_StaticFields, ___FalseString_0)); }
	inline String_t* get_FalseString_0() const { return ___FalseString_0; }
	inline String_t** get_address_of_FalseString_0() { return &___FalseString_0; }
	inline void set_FalseString_0(String_t* value)
	{
		___FalseString_0 = value;
		Il2CppCodeGenWriteBarrier((&___FalseString_0), value);
	}

	inline static int32_t get_offset_of_TrueString_1() { return static_cast<int32_t>(offsetof(Boolean_t97287965_StaticFields, ___TrueString_1)); }
	inline String_t* get_TrueString_1() const { return ___TrueString_1; }
	inline String_t** get_address_of_TrueString_1() { return &___TrueString_1; }
	inline void set_TrueString_1(String_t* value)
	{
		___TrueString_1 = value;
		Il2CppCodeGenWriteBarrier((&___TrueString_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BOOLEAN_T97287965_H
#ifndef ENUMERATOR_T2146457487_H
#define ENUMERATOR_T2146457487_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.List`1/Enumerator<System.Object>
struct  Enumerator_t2146457487 
{
public:
	// System.Collections.Generic.List`1<T> System.Collections.Generic.List`1/Enumerator::l
	List_1_t257213610 * ___l_0;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::next
	int32_t ___next_1;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::ver
	int32_t ___ver_2;
	// T System.Collections.Generic.List`1/Enumerator::current
	RuntimeObject * ___current_3;

public:
	inline static int32_t get_offset_of_l_0() { return static_cast<int32_t>(offsetof(Enumerator_t2146457487, ___l_0)); }
	inline List_1_t257213610 * get_l_0() const { return ___l_0; }
	inline List_1_t257213610 ** get_address_of_l_0() { return &___l_0; }
	inline void set_l_0(List_1_t257213610 * value)
	{
		___l_0 = value;
		Il2CppCodeGenWriteBarrier((&___l_0), value);
	}

	inline static int32_t get_offset_of_next_1() { return static_cast<int32_t>(offsetof(Enumerator_t2146457487, ___next_1)); }
	inline int32_t get_next_1() const { return ___next_1; }
	inline int32_t* get_address_of_next_1() { return &___next_1; }
	inline void set_next_1(int32_t value)
	{
		___next_1 = value;
	}

	inline static int32_t get_offset_of_ver_2() { return static_cast<int32_t>(offsetof(Enumerator_t2146457487, ___ver_2)); }
	inline int32_t get_ver_2() const { return ___ver_2; }
	inline int32_t* get_address_of_ver_2() { return &___ver_2; }
	inline void set_ver_2(int32_t value)
	{
		___ver_2 = value;
	}

	inline static int32_t get_offset_of_current_3() { return static_cast<int32_t>(offsetof(Enumerator_t2146457487, ___current_3)); }
	inline RuntimeObject * get_current_3() const { return ___current_3; }
	inline RuntimeObject ** get_address_of_current_3() { return &___current_3; }
	inline void set_current_3(RuntimeObject * value)
	{
		___current_3 = value;
		Il2CppCodeGenWriteBarrier((&___current_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENUMERATOR_T2146457487_H
#ifndef ENUMERATOR_T1949747122_H
#define ENUMERATOR_T1949747122_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.List`1/Enumerator<UnityEngine.Experimental.ISubsystemDescriptorImpl>
struct  Enumerator_t1949747122 
{
public:
	// System.Collections.Generic.List`1<T> System.Collections.Generic.List`1/Enumerator::l
	List_1_t60503245 * ___l_0;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::next
	int32_t ___next_1;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::ver
	int32_t ___ver_2;
	// T System.Collections.Generic.List`1/Enumerator::current
	RuntimeObject* ___current_3;

public:
	inline static int32_t get_offset_of_l_0() { return static_cast<int32_t>(offsetof(Enumerator_t1949747122, ___l_0)); }
	inline List_1_t60503245 * get_l_0() const { return ___l_0; }
	inline List_1_t60503245 ** get_address_of_l_0() { return &___l_0; }
	inline void set_l_0(List_1_t60503245 * value)
	{
		___l_0 = value;
		Il2CppCodeGenWriteBarrier((&___l_0), value);
	}

	inline static int32_t get_offset_of_next_1() { return static_cast<int32_t>(offsetof(Enumerator_t1949747122, ___next_1)); }
	inline int32_t get_next_1() const { return ___next_1; }
	inline int32_t* get_address_of_next_1() { return &___next_1; }
	inline void set_next_1(int32_t value)
	{
		___next_1 = value;
	}

	inline static int32_t get_offset_of_ver_2() { return static_cast<int32_t>(offsetof(Enumerator_t1949747122, ___ver_2)); }
	inline int32_t get_ver_2() const { return ___ver_2; }
	inline int32_t* get_address_of_ver_2() { return &___ver_2; }
	inline void set_ver_2(int32_t value)
	{
		___ver_2 = value;
	}

	inline static int32_t get_offset_of_current_3() { return static_cast<int32_t>(offsetof(Enumerator_t1949747122, ___current_3)); }
	inline RuntimeObject* get_current_3() const { return ___current_3; }
	inline RuntimeObject** get_address_of_current_3() { return &___current_3; }
	inline void set_current_3(RuntimeObject* value)
	{
		___current_3 = value;
		Il2CppCodeGenWriteBarrier((&___current_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENUMERATOR_T1949747122_H
#ifndef ENUMERATOR_T3451042094_H
#define ENUMERATOR_T3451042094_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.List`1/Enumerator<UnityEngine.Experimental.Subsystem>
struct  Enumerator_t3451042094 
{
public:
	// System.Collections.Generic.List`1<T> System.Collections.Generic.List`1/Enumerator::l
	List_1_t1561798217 * ___l_0;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::next
	int32_t ___next_1;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::ver
	int32_t ___ver_2;
	// T System.Collections.Generic.List`1/Enumerator::current
	Subsystem_t89723475 * ___current_3;

public:
	inline static int32_t get_offset_of_l_0() { return static_cast<int32_t>(offsetof(Enumerator_t3451042094, ___l_0)); }
	inline List_1_t1561798217 * get_l_0() const { return ___l_0; }
	inline List_1_t1561798217 ** get_address_of_l_0() { return &___l_0; }
	inline void set_l_0(List_1_t1561798217 * value)
	{
		___l_0 = value;
		Il2CppCodeGenWriteBarrier((&___l_0), value);
	}

	inline static int32_t get_offset_of_next_1() { return static_cast<int32_t>(offsetof(Enumerator_t3451042094, ___next_1)); }
	inline int32_t get_next_1() const { return ___next_1; }
	inline int32_t* get_address_of_next_1() { return &___next_1; }
	inline void set_next_1(int32_t value)
	{
		___next_1 = value;
	}

	inline static int32_t get_offset_of_ver_2() { return static_cast<int32_t>(offsetof(Enumerator_t3451042094, ___ver_2)); }
	inline int32_t get_ver_2() const { return ___ver_2; }
	inline int32_t* get_address_of_ver_2() { return &___ver_2; }
	inline void set_ver_2(int32_t value)
	{
		___ver_2 = value;
	}

	inline static int32_t get_offset_of_current_3() { return static_cast<int32_t>(offsetof(Enumerator_t3451042094, ___current_3)); }
	inline Subsystem_t89723475 * get_current_3() const { return ___current_3; }
	inline Subsystem_t89723475 ** get_address_of_current_3() { return &___current_3; }
	inline void set_current_3(Subsystem_t89723475 * value)
	{
		___current_3 = value;
		Il2CppCodeGenWriteBarrier((&___current_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENUMERATOR_T3451042094_H
#ifndef ENUM_T4135868527_H
#define ENUM_T4135868527_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Enum
struct  Enum_t4135868527  : public ValueType_t3640485471
{
public:

public:
};

struct Enum_t4135868527_StaticFields
{
public:
	// System.Char[] System.Enum::split_char
	CharU5BU5D_t3528271667* ___split_char_0;

public:
	inline static int32_t get_offset_of_split_char_0() { return static_cast<int32_t>(offsetof(Enum_t4135868527_StaticFields, ___split_char_0)); }
	inline CharU5BU5D_t3528271667* get_split_char_0() const { return ___split_char_0; }
	inline CharU5BU5D_t3528271667** get_address_of_split_char_0() { return &___split_char_0; }
	inline void set_split_char_0(CharU5BU5D_t3528271667* value)
	{
		___split_char_0 = value;
		Il2CppCodeGenWriteBarrier((&___split_char_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t4135868527_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t4135868527_marshaled_com
{
};
#endif // ENUM_T4135868527_H
#ifndef INT32_T2950945753_H
#define INT32_T2950945753_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Int32
struct  Int32_t2950945753 
{
public:
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_2;

public:
	inline static int32_t get_offset_of_m_value_2() { return static_cast<int32_t>(offsetof(Int32_t2950945753, ___m_value_2)); }
	inline int32_t get_m_value_2() const { return ___m_value_2; }
	inline int32_t* get_address_of_m_value_2() { return &___m_value_2; }
	inline void set_m_value_2(int32_t value)
	{
		___m_value_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INT32_T2950945753_H
#ifndef INT64_T3736567304_H
#define INT64_T3736567304_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Int64
struct  Int64_t3736567304 
{
public:
	// System.Int64 System.Int64::m_value
	int64_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int64_t3736567304, ___m_value_0)); }
	inline int64_t get_m_value_0() const { return ___m_value_0; }
	inline int64_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int64_t value)
	{
		___m_value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INT64_T3736567304_H
#ifndef INTPTR_T_H
#define INTPTR_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTPTR_T_H
#ifndef SINGLE_T1397266774_H
#define SINGLE_T1397266774_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Single
struct  Single_t1397266774 
{
public:
	// System.Single System.Single::m_value
	float ___m_value_7;

public:
	inline static int32_t get_offset_of_m_value_7() { return static_cast<int32_t>(offsetof(Single_t1397266774, ___m_value_7)); }
	inline float get_m_value_7() const { return ___m_value_7; }
	inline float* get_address_of_m_value_7() { return &___m_value_7; }
	inline void set_m_value_7(float value)
	{
		___m_value_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SINGLE_T1397266774_H
#ifndef SYSTEMEXCEPTION_T176217640_H
#define SYSTEMEXCEPTION_T176217640_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.SystemException
struct  SystemException_t176217640  : public Exception_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SYSTEMEXCEPTION_T176217640_H
#ifndef UINT32_T2560061978_H
#define UINT32_T2560061978_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.UInt32
struct  UInt32_t2560061978 
{
public:
	// System.UInt32 System.UInt32::m_value
	uint32_t ___m_value_2;

public:
	inline static int32_t get_offset_of_m_value_2() { return static_cast<int32_t>(offsetof(UInt32_t2560061978, ___m_value_2)); }
	inline uint32_t get_m_value_2() const { return ___m_value_2; }
	inline uint32_t* get_address_of_m_value_2() { return &___m_value_2; }
	inline void set_m_value_2(uint32_t value)
	{
		___m_value_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UINT32_T2560061978_H
#ifndef UINT64_T4134040092_H
#define UINT64_T4134040092_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.UInt64
struct  UInt64_t4134040092 
{
public:
	// System.UInt64 System.UInt64::m_value
	uint64_t ___m_value_2;

public:
	inline static int32_t get_offset_of_m_value_2() { return static_cast<int32_t>(offsetof(UInt64_t4134040092, ___m_value_2)); }
	inline uint64_t get_m_value_2() const { return ___m_value_2; }
	inline uint64_t* get_address_of_m_value_2() { return &___m_value_2; }
	inline void set_m_value_2(uint64_t value)
	{
		___m_value_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UINT64_T4134040092_H
#ifndef VOID_T1185182177_H
#define VOID_T1185182177_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Void
struct  Void_t1185182177 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VOID_T1185182177_H
#ifndef FRAMERECEIVEDEVENTARGS_T2588080103_H
#define FRAMERECEIVEDEVENTARGS_T2588080103_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.FrameReceivedEventArgs
struct  FrameReceivedEventArgs_t2588080103 
{
public:
	// UnityEngine.Experimental.XR.XRCameraSubsystem UnityEngine.Experimental.XR.FrameReceivedEventArgs::m_CameraSubsystem
	XRCameraSubsystem_t4195795144 * ___m_CameraSubsystem_0;

public:
	inline static int32_t get_offset_of_m_CameraSubsystem_0() { return static_cast<int32_t>(offsetof(FrameReceivedEventArgs_t2588080103, ___m_CameraSubsystem_0)); }
	inline XRCameraSubsystem_t4195795144 * get_m_CameraSubsystem_0() const { return ___m_CameraSubsystem_0; }
	inline XRCameraSubsystem_t4195795144 ** get_address_of_m_CameraSubsystem_0() { return &___m_CameraSubsystem_0; }
	inline void set_m_CameraSubsystem_0(XRCameraSubsystem_t4195795144 * value)
	{
		___m_CameraSubsystem_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_CameraSubsystem_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Experimental.XR.FrameReceivedEventArgs
struct FrameReceivedEventArgs_t2588080103_marshaled_pinvoke
{
	XRCameraSubsystem_t4195795144 * ___m_CameraSubsystem_0;
};
// Native definition for COM marshalling of UnityEngine.Experimental.XR.FrameReceivedEventArgs
struct FrameReceivedEventArgs_t2588080103_marshaled_com
{
	XRCameraSubsystem_t4195795144 * ___m_CameraSubsystem_0;
};
#endif // FRAMERECEIVEDEVENTARGS_T2588080103_H
#ifndef POINTCLOUDUPDATEDEVENTARGS_T3436657348_H
#define POINTCLOUDUPDATEDEVENTARGS_T3436657348_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.PointCloudUpdatedEventArgs
struct  PointCloudUpdatedEventArgs_t3436657348 
{
public:
	// UnityEngine.Experimental.XR.XRDepthSubsystem UnityEngine.Experimental.XR.PointCloudUpdatedEventArgs::m_DepthSubsystem
	XRDepthSubsystem_t4084359858 * ___m_DepthSubsystem_0;

public:
	inline static int32_t get_offset_of_m_DepthSubsystem_0() { return static_cast<int32_t>(offsetof(PointCloudUpdatedEventArgs_t3436657348, ___m_DepthSubsystem_0)); }
	inline XRDepthSubsystem_t4084359858 * get_m_DepthSubsystem_0() const { return ___m_DepthSubsystem_0; }
	inline XRDepthSubsystem_t4084359858 ** get_address_of_m_DepthSubsystem_0() { return &___m_DepthSubsystem_0; }
	inline void set_m_DepthSubsystem_0(XRDepthSubsystem_t4084359858 * value)
	{
		___m_DepthSubsystem_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_DepthSubsystem_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Experimental.XR.PointCloudUpdatedEventArgs
struct PointCloudUpdatedEventArgs_t3436657348_marshaled_pinvoke
{
	XRDepthSubsystem_t4084359858 * ___m_DepthSubsystem_0;
};
// Native definition for COM marshalling of UnityEngine.Experimental.XR.PointCloudUpdatedEventArgs
struct PointCloudUpdatedEventArgs_t3436657348_marshaled_com
{
	XRDepthSubsystem_t4084359858 * ___m_DepthSubsystem_0;
};
#endif // POINTCLOUDUPDATEDEVENTARGS_T3436657348_H
#ifndef TRACKABLEID_T1251031970_H
#define TRACKABLEID_T1251031970_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.TrackableId
struct  TrackableId_t1251031970 
{
public:
	// System.UInt64 UnityEngine.Experimental.XR.TrackableId::m_SubId1
	uint64_t ___m_SubId1_1;
	// System.UInt64 UnityEngine.Experimental.XR.TrackableId::m_SubId2
	uint64_t ___m_SubId2_2;

public:
	inline static int32_t get_offset_of_m_SubId1_1() { return static_cast<int32_t>(offsetof(TrackableId_t1251031970, ___m_SubId1_1)); }
	inline uint64_t get_m_SubId1_1() const { return ___m_SubId1_1; }
	inline uint64_t* get_address_of_m_SubId1_1() { return &___m_SubId1_1; }
	inline void set_m_SubId1_1(uint64_t value)
	{
		___m_SubId1_1 = value;
	}

	inline static int32_t get_offset_of_m_SubId2_2() { return static_cast<int32_t>(offsetof(TrackableId_t1251031970, ___m_SubId2_2)); }
	inline uint64_t get_m_SubId2_2() const { return ___m_SubId2_2; }
	inline uint64_t* get_address_of_m_SubId2_2() { return &___m_SubId2_2; }
	inline void set_m_SubId2_2(uint64_t value)
	{
		___m_SubId2_2 = value;
	}
};

struct TrackableId_t1251031970_StaticFields
{
public:
	// UnityEngine.Experimental.XR.TrackableId UnityEngine.Experimental.XR.TrackableId::s_InvalidId
	TrackableId_t1251031970  ___s_InvalidId_0;

public:
	inline static int32_t get_offset_of_s_InvalidId_0() { return static_cast<int32_t>(offsetof(TrackableId_t1251031970_StaticFields, ___s_InvalidId_0)); }
	inline TrackableId_t1251031970  get_s_InvalidId_0() const { return ___s_InvalidId_0; }
	inline TrackableId_t1251031970 * get_address_of_s_InvalidId_0() { return &___s_InvalidId_0; }
	inline void set_s_InvalidId_0(TrackableId_t1251031970  value)
	{
		___s_InvalidId_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TRACKABLEID_T1251031970_H
#ifndef QUATERNION_T2301928331_H
#define QUATERNION_T2301928331_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Quaternion
struct  Quaternion_t2301928331 
{
public:
	// System.Single UnityEngine.Quaternion::x
	float ___x_0;
	// System.Single UnityEngine.Quaternion::y
	float ___y_1;
	// System.Single UnityEngine.Quaternion::z
	float ___z_2;
	// System.Single UnityEngine.Quaternion::w
	float ___w_3;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(Quaternion_t2301928331, ___x_0)); }
	inline float get_x_0() const { return ___x_0; }
	inline float* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(float value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(Quaternion_t2301928331, ___y_1)); }
	inline float get_y_1() const { return ___y_1; }
	inline float* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(float value)
	{
		___y_1 = value;
	}

	inline static int32_t get_offset_of_z_2() { return static_cast<int32_t>(offsetof(Quaternion_t2301928331, ___z_2)); }
	inline float get_z_2() const { return ___z_2; }
	inline float* get_address_of_z_2() { return &___z_2; }
	inline void set_z_2(float value)
	{
		___z_2 = value;
	}

	inline static int32_t get_offset_of_w_3() { return static_cast<int32_t>(offsetof(Quaternion_t2301928331, ___w_3)); }
	inline float get_w_3() const { return ___w_3; }
	inline float* get_address_of_w_3() { return &___w_3; }
	inline void set_w_3(float value)
	{
		___w_3 = value;
	}
};

struct Quaternion_t2301928331_StaticFields
{
public:
	// UnityEngine.Quaternion UnityEngine.Quaternion::identityQuaternion
	Quaternion_t2301928331  ___identityQuaternion_4;

public:
	inline static int32_t get_offset_of_identityQuaternion_4() { return static_cast<int32_t>(offsetof(Quaternion_t2301928331_StaticFields, ___identityQuaternion_4)); }
	inline Quaternion_t2301928331  get_identityQuaternion_4() const { return ___identityQuaternion_4; }
	inline Quaternion_t2301928331 * get_address_of_identityQuaternion_4() { return &___identityQuaternion_4; }
	inline void set_identityQuaternion_4(Quaternion_t2301928331  value)
	{
		___identityQuaternion_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // QUATERNION_T2301928331_H
#ifndef VECTOR2_T2156229523_H
#define VECTOR2_T2156229523_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Vector2
struct  Vector2_t2156229523 
{
public:
	// System.Single UnityEngine.Vector2::x
	float ___x_0;
	// System.Single UnityEngine.Vector2::y
	float ___y_1;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(Vector2_t2156229523, ___x_0)); }
	inline float get_x_0() const { return ___x_0; }
	inline float* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(float value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(Vector2_t2156229523, ___y_1)); }
	inline float get_y_1() const { return ___y_1; }
	inline float* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(float value)
	{
		___y_1 = value;
	}
};

struct Vector2_t2156229523_StaticFields
{
public:
	// UnityEngine.Vector2 UnityEngine.Vector2::zeroVector
	Vector2_t2156229523  ___zeroVector_2;
	// UnityEngine.Vector2 UnityEngine.Vector2::oneVector
	Vector2_t2156229523  ___oneVector_3;
	// UnityEngine.Vector2 UnityEngine.Vector2::upVector
	Vector2_t2156229523  ___upVector_4;
	// UnityEngine.Vector2 UnityEngine.Vector2::downVector
	Vector2_t2156229523  ___downVector_5;
	// UnityEngine.Vector2 UnityEngine.Vector2::leftVector
	Vector2_t2156229523  ___leftVector_6;
	// UnityEngine.Vector2 UnityEngine.Vector2::rightVector
	Vector2_t2156229523  ___rightVector_7;
	// UnityEngine.Vector2 UnityEngine.Vector2::positiveInfinityVector
	Vector2_t2156229523  ___positiveInfinityVector_8;
	// UnityEngine.Vector2 UnityEngine.Vector2::negativeInfinityVector
	Vector2_t2156229523  ___negativeInfinityVector_9;

public:
	inline static int32_t get_offset_of_zeroVector_2() { return static_cast<int32_t>(offsetof(Vector2_t2156229523_StaticFields, ___zeroVector_2)); }
	inline Vector2_t2156229523  get_zeroVector_2() const { return ___zeroVector_2; }
	inline Vector2_t2156229523 * get_address_of_zeroVector_2() { return &___zeroVector_2; }
	inline void set_zeroVector_2(Vector2_t2156229523  value)
	{
		___zeroVector_2 = value;
	}

	inline static int32_t get_offset_of_oneVector_3() { return static_cast<int32_t>(offsetof(Vector2_t2156229523_StaticFields, ___oneVector_3)); }
	inline Vector2_t2156229523  get_oneVector_3() const { return ___oneVector_3; }
	inline Vector2_t2156229523 * get_address_of_oneVector_3() { return &___oneVector_3; }
	inline void set_oneVector_3(Vector2_t2156229523  value)
	{
		___oneVector_3 = value;
	}

	inline static int32_t get_offset_of_upVector_4() { return static_cast<int32_t>(offsetof(Vector2_t2156229523_StaticFields, ___upVector_4)); }
	inline Vector2_t2156229523  get_upVector_4() const { return ___upVector_4; }
	inline Vector2_t2156229523 * get_address_of_upVector_4() { return &___upVector_4; }
	inline void set_upVector_4(Vector2_t2156229523  value)
	{
		___upVector_4 = value;
	}

	inline static int32_t get_offset_of_downVector_5() { return static_cast<int32_t>(offsetof(Vector2_t2156229523_StaticFields, ___downVector_5)); }
	inline Vector2_t2156229523  get_downVector_5() const { return ___downVector_5; }
	inline Vector2_t2156229523 * get_address_of_downVector_5() { return &___downVector_5; }
	inline void set_downVector_5(Vector2_t2156229523  value)
	{
		___downVector_5 = value;
	}

	inline static int32_t get_offset_of_leftVector_6() { return static_cast<int32_t>(offsetof(Vector2_t2156229523_StaticFields, ___leftVector_6)); }
	inline Vector2_t2156229523  get_leftVector_6() const { return ___leftVector_6; }
	inline Vector2_t2156229523 * get_address_of_leftVector_6() { return &___leftVector_6; }
	inline void set_leftVector_6(Vector2_t2156229523  value)
	{
		___leftVector_6 = value;
	}

	inline static int32_t get_offset_of_rightVector_7() { return static_cast<int32_t>(offsetof(Vector2_t2156229523_StaticFields, ___rightVector_7)); }
	inline Vector2_t2156229523  get_rightVector_7() const { return ___rightVector_7; }
	inline Vector2_t2156229523 * get_address_of_rightVector_7() { return &___rightVector_7; }
	inline void set_rightVector_7(Vector2_t2156229523  value)
	{
		___rightVector_7 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_8() { return static_cast<int32_t>(offsetof(Vector2_t2156229523_StaticFields, ___positiveInfinityVector_8)); }
	inline Vector2_t2156229523  get_positiveInfinityVector_8() const { return ___positiveInfinityVector_8; }
	inline Vector2_t2156229523 * get_address_of_positiveInfinityVector_8() { return &___positiveInfinityVector_8; }
	inline void set_positiveInfinityVector_8(Vector2_t2156229523  value)
	{
		___positiveInfinityVector_8 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_9() { return static_cast<int32_t>(offsetof(Vector2_t2156229523_StaticFields, ___negativeInfinityVector_9)); }
	inline Vector2_t2156229523  get_negativeInfinityVector_9() const { return ___negativeInfinityVector_9; }
	inline Vector2_t2156229523 * get_address_of_negativeInfinityVector_9() { return &___negativeInfinityVector_9; }
	inline void set_negativeInfinityVector_9(Vector2_t2156229523  value)
	{
		___negativeInfinityVector_9 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VECTOR2_T2156229523_H
#ifndef VECTOR3_T3722313464_H
#define VECTOR3_T3722313464_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Vector3
struct  Vector3_t3722313464 
{
public:
	// System.Single UnityEngine.Vector3::x
	float ___x_2;
	// System.Single UnityEngine.Vector3::y
	float ___y_3;
	// System.Single UnityEngine.Vector3::z
	float ___z_4;

public:
	inline static int32_t get_offset_of_x_2() { return static_cast<int32_t>(offsetof(Vector3_t3722313464, ___x_2)); }
	inline float get_x_2() const { return ___x_2; }
	inline float* get_address_of_x_2() { return &___x_2; }
	inline void set_x_2(float value)
	{
		___x_2 = value;
	}

	inline static int32_t get_offset_of_y_3() { return static_cast<int32_t>(offsetof(Vector3_t3722313464, ___y_3)); }
	inline float get_y_3() const { return ___y_3; }
	inline float* get_address_of_y_3() { return &___y_3; }
	inline void set_y_3(float value)
	{
		___y_3 = value;
	}

	inline static int32_t get_offset_of_z_4() { return static_cast<int32_t>(offsetof(Vector3_t3722313464, ___z_4)); }
	inline float get_z_4() const { return ___z_4; }
	inline float* get_address_of_z_4() { return &___z_4; }
	inline void set_z_4(float value)
	{
		___z_4 = value;
	}
};

struct Vector3_t3722313464_StaticFields
{
public:
	// UnityEngine.Vector3 UnityEngine.Vector3::zeroVector
	Vector3_t3722313464  ___zeroVector_5;
	// UnityEngine.Vector3 UnityEngine.Vector3::oneVector
	Vector3_t3722313464  ___oneVector_6;
	// UnityEngine.Vector3 UnityEngine.Vector3::upVector
	Vector3_t3722313464  ___upVector_7;
	// UnityEngine.Vector3 UnityEngine.Vector3::downVector
	Vector3_t3722313464  ___downVector_8;
	// UnityEngine.Vector3 UnityEngine.Vector3::leftVector
	Vector3_t3722313464  ___leftVector_9;
	// UnityEngine.Vector3 UnityEngine.Vector3::rightVector
	Vector3_t3722313464  ___rightVector_10;
	// UnityEngine.Vector3 UnityEngine.Vector3::forwardVector
	Vector3_t3722313464  ___forwardVector_11;
	// UnityEngine.Vector3 UnityEngine.Vector3::backVector
	Vector3_t3722313464  ___backVector_12;
	// UnityEngine.Vector3 UnityEngine.Vector3::positiveInfinityVector
	Vector3_t3722313464  ___positiveInfinityVector_13;
	// UnityEngine.Vector3 UnityEngine.Vector3::negativeInfinityVector
	Vector3_t3722313464  ___negativeInfinityVector_14;

public:
	inline static int32_t get_offset_of_zeroVector_5() { return static_cast<int32_t>(offsetof(Vector3_t3722313464_StaticFields, ___zeroVector_5)); }
	inline Vector3_t3722313464  get_zeroVector_5() const { return ___zeroVector_5; }
	inline Vector3_t3722313464 * get_address_of_zeroVector_5() { return &___zeroVector_5; }
	inline void set_zeroVector_5(Vector3_t3722313464  value)
	{
		___zeroVector_5 = value;
	}

	inline static int32_t get_offset_of_oneVector_6() { return static_cast<int32_t>(offsetof(Vector3_t3722313464_StaticFields, ___oneVector_6)); }
	inline Vector3_t3722313464  get_oneVector_6() const { return ___oneVector_6; }
	inline Vector3_t3722313464 * get_address_of_oneVector_6() { return &___oneVector_6; }
	inline void set_oneVector_6(Vector3_t3722313464  value)
	{
		___oneVector_6 = value;
	}

	inline static int32_t get_offset_of_upVector_7() { return static_cast<int32_t>(offsetof(Vector3_t3722313464_StaticFields, ___upVector_7)); }
	inline Vector3_t3722313464  get_upVector_7() const { return ___upVector_7; }
	inline Vector3_t3722313464 * get_address_of_upVector_7() { return &___upVector_7; }
	inline void set_upVector_7(Vector3_t3722313464  value)
	{
		___upVector_7 = value;
	}

	inline static int32_t get_offset_of_downVector_8() { return static_cast<int32_t>(offsetof(Vector3_t3722313464_StaticFields, ___downVector_8)); }
	inline Vector3_t3722313464  get_downVector_8() const { return ___downVector_8; }
	inline Vector3_t3722313464 * get_address_of_downVector_8() { return &___downVector_8; }
	inline void set_downVector_8(Vector3_t3722313464  value)
	{
		___downVector_8 = value;
	}

	inline static int32_t get_offset_of_leftVector_9() { return static_cast<int32_t>(offsetof(Vector3_t3722313464_StaticFields, ___leftVector_9)); }
	inline Vector3_t3722313464  get_leftVector_9() const { return ___leftVector_9; }
	inline Vector3_t3722313464 * get_address_of_leftVector_9() { return &___leftVector_9; }
	inline void set_leftVector_9(Vector3_t3722313464  value)
	{
		___leftVector_9 = value;
	}

	inline static int32_t get_offset_of_rightVector_10() { return static_cast<int32_t>(offsetof(Vector3_t3722313464_StaticFields, ___rightVector_10)); }
	inline Vector3_t3722313464  get_rightVector_10() const { return ___rightVector_10; }
	inline Vector3_t3722313464 * get_address_of_rightVector_10() { return &___rightVector_10; }
	inline void set_rightVector_10(Vector3_t3722313464  value)
	{
		___rightVector_10 = value;
	}

	inline static int32_t get_offset_of_forwardVector_11() { return static_cast<int32_t>(offsetof(Vector3_t3722313464_StaticFields, ___forwardVector_11)); }
	inline Vector3_t3722313464  get_forwardVector_11() const { return ___forwardVector_11; }
	inline Vector3_t3722313464 * get_address_of_forwardVector_11() { return &___forwardVector_11; }
	inline void set_forwardVector_11(Vector3_t3722313464  value)
	{
		___forwardVector_11 = value;
	}

	inline static int32_t get_offset_of_backVector_12() { return static_cast<int32_t>(offsetof(Vector3_t3722313464_StaticFields, ___backVector_12)); }
	inline Vector3_t3722313464  get_backVector_12() const { return ___backVector_12; }
	inline Vector3_t3722313464 * get_address_of_backVector_12() { return &___backVector_12; }
	inline void set_backVector_12(Vector3_t3722313464  value)
	{
		___backVector_12 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_13() { return static_cast<int32_t>(offsetof(Vector3_t3722313464_StaticFields, ___positiveInfinityVector_13)); }
	inline Vector3_t3722313464  get_positiveInfinityVector_13() const { return ___positiveInfinityVector_13; }
	inline Vector3_t3722313464 * get_address_of_positiveInfinityVector_13() { return &___positiveInfinityVector_13; }
	inline void set_positiveInfinityVector_13(Vector3_t3722313464  value)
	{
		___positiveInfinityVector_13 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_14() { return static_cast<int32_t>(offsetof(Vector3_t3722313464_StaticFields, ___negativeInfinityVector_14)); }
	inline Vector3_t3722313464  get_negativeInfinityVector_14() const { return ___negativeInfinityVector_14; }
	inline Vector3_t3722313464 * get_address_of_negativeInfinityVector_14() { return &___negativeInfinityVector_14; }
	inline void set_negativeInfinityVector_14(Vector3_t3722313464  value)
	{
		___negativeInfinityVector_14 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VECTOR3_T3722313464_H
#ifndef ARGUMENTEXCEPTION_T132251570_H
#define ARGUMENTEXCEPTION_T132251570_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ArgumentException
struct  ArgumentException_t132251570  : public SystemException_t176217640
{
public:
	// System.String System.ArgumentException::param_name
	String_t* ___param_name_12;

public:
	inline static int32_t get_offset_of_param_name_12() { return static_cast<int32_t>(offsetof(ArgumentException_t132251570, ___param_name_12)); }
	inline String_t* get_param_name_12() const { return ___param_name_12; }
	inline String_t** get_address_of_param_name_12() { return &___param_name_12; }
	inline void set_param_name_12(String_t* value)
	{
		___param_name_12 = value;
		Il2CppCodeGenWriteBarrier((&___param_name_12), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ARGUMENTEXCEPTION_T132251570_H
#ifndef DELEGATE_T1188392813_H
#define DELEGATE_T1188392813_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Delegate
struct  Delegate_t1188392813  : public RuntimeObject
{
public:
	// System.IntPtr System.Delegate::method_ptr
	Il2CppMethodPointer ___method_ptr_0;
	// System.IntPtr System.Delegate::invoke_impl
	intptr_t ___invoke_impl_1;
	// System.Object System.Delegate::m_target
	RuntimeObject * ___m_target_2;
	// System.IntPtr System.Delegate::method
	intptr_t ___method_3;
	// System.IntPtr System.Delegate::delegate_trampoline
	intptr_t ___delegate_trampoline_4;
	// System.IntPtr System.Delegate::method_code
	intptr_t ___method_code_5;
	// System.Reflection.MethodInfo System.Delegate::method_info
	MethodInfo_t * ___method_info_6;
	// System.Reflection.MethodInfo System.Delegate::original_method_info
	MethodInfo_t * ___original_method_info_7;
	// System.DelegateData System.Delegate::data
	DelegateData_t1677132599 * ___data_8;

public:
	inline static int32_t get_offset_of_method_ptr_0() { return static_cast<int32_t>(offsetof(Delegate_t1188392813, ___method_ptr_0)); }
	inline Il2CppMethodPointer get_method_ptr_0() const { return ___method_ptr_0; }
	inline Il2CppMethodPointer* get_address_of_method_ptr_0() { return &___method_ptr_0; }
	inline void set_method_ptr_0(Il2CppMethodPointer value)
	{
		___method_ptr_0 = value;
	}

	inline static int32_t get_offset_of_invoke_impl_1() { return static_cast<int32_t>(offsetof(Delegate_t1188392813, ___invoke_impl_1)); }
	inline intptr_t get_invoke_impl_1() const { return ___invoke_impl_1; }
	inline intptr_t* get_address_of_invoke_impl_1() { return &___invoke_impl_1; }
	inline void set_invoke_impl_1(intptr_t value)
	{
		___invoke_impl_1 = value;
	}

	inline static int32_t get_offset_of_m_target_2() { return static_cast<int32_t>(offsetof(Delegate_t1188392813, ___m_target_2)); }
	inline RuntimeObject * get_m_target_2() const { return ___m_target_2; }
	inline RuntimeObject ** get_address_of_m_target_2() { return &___m_target_2; }
	inline void set_m_target_2(RuntimeObject * value)
	{
		___m_target_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_target_2), value);
	}

	inline static int32_t get_offset_of_method_3() { return static_cast<int32_t>(offsetof(Delegate_t1188392813, ___method_3)); }
	inline intptr_t get_method_3() const { return ___method_3; }
	inline intptr_t* get_address_of_method_3() { return &___method_3; }
	inline void set_method_3(intptr_t value)
	{
		___method_3 = value;
	}

	inline static int32_t get_offset_of_delegate_trampoline_4() { return static_cast<int32_t>(offsetof(Delegate_t1188392813, ___delegate_trampoline_4)); }
	inline intptr_t get_delegate_trampoline_4() const { return ___delegate_trampoline_4; }
	inline intptr_t* get_address_of_delegate_trampoline_4() { return &___delegate_trampoline_4; }
	inline void set_delegate_trampoline_4(intptr_t value)
	{
		___delegate_trampoline_4 = value;
	}

	inline static int32_t get_offset_of_method_code_5() { return static_cast<int32_t>(offsetof(Delegate_t1188392813, ___method_code_5)); }
	inline intptr_t get_method_code_5() const { return ___method_code_5; }
	inline intptr_t* get_address_of_method_code_5() { return &___method_code_5; }
	inline void set_method_code_5(intptr_t value)
	{
		___method_code_5 = value;
	}

	inline static int32_t get_offset_of_method_info_6() { return static_cast<int32_t>(offsetof(Delegate_t1188392813, ___method_info_6)); }
	inline MethodInfo_t * get_method_info_6() const { return ___method_info_6; }
	inline MethodInfo_t ** get_address_of_method_info_6() { return &___method_info_6; }
	inline void set_method_info_6(MethodInfo_t * value)
	{
		___method_info_6 = value;
		Il2CppCodeGenWriteBarrier((&___method_info_6), value);
	}

	inline static int32_t get_offset_of_original_method_info_7() { return static_cast<int32_t>(offsetof(Delegate_t1188392813, ___original_method_info_7)); }
	inline MethodInfo_t * get_original_method_info_7() const { return ___original_method_info_7; }
	inline MethodInfo_t ** get_address_of_original_method_info_7() { return &___original_method_info_7; }
	inline void set_original_method_info_7(MethodInfo_t * value)
	{
		___original_method_info_7 = value;
		Il2CppCodeGenWriteBarrier((&___original_method_info_7), value);
	}

	inline static int32_t get_offset_of_data_8() { return static_cast<int32_t>(offsetof(Delegate_t1188392813, ___data_8)); }
	inline DelegateData_t1677132599 * get_data_8() const { return ___data_8; }
	inline DelegateData_t1677132599 ** get_address_of_data_8() { return &___data_8; }
	inline void set_data_8(DelegateData_t1677132599 * value)
	{
		___data_8 = value;
		Il2CppCodeGenWriteBarrier((&___data_8), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DELEGATE_T1188392813_H
#ifndef SUBSYSTEM_T89723475_H
#define SUBSYSTEM_T89723475_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.Subsystem
struct  Subsystem_t89723475  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Experimental.Subsystem::m_Ptr
	intptr_t ___m_Ptr_0;
	// UnityEngine.Experimental.ISubsystemDescriptor UnityEngine.Experimental.Subsystem::m_subsystemDescriptor
	RuntimeObject* ___m_subsystemDescriptor_1;

public:
	inline static int32_t get_offset_of_m_Ptr_0() { return static_cast<int32_t>(offsetof(Subsystem_t89723475, ___m_Ptr_0)); }
	inline intptr_t get_m_Ptr_0() const { return ___m_Ptr_0; }
	inline intptr_t* get_address_of_m_Ptr_0() { return &___m_Ptr_0; }
	inline void set_m_Ptr_0(intptr_t value)
	{
		___m_Ptr_0 = value;
	}

	inline static int32_t get_offset_of_m_subsystemDescriptor_1() { return static_cast<int32_t>(offsetof(Subsystem_t89723475, ___m_subsystemDescriptor_1)); }
	inline RuntimeObject* get_m_subsystemDescriptor_1() const { return ___m_subsystemDescriptor_1; }
	inline RuntimeObject** get_address_of_m_subsystemDescriptor_1() { return &___m_subsystemDescriptor_1; }
	inline void set_m_subsystemDescriptor_1(RuntimeObject* value)
	{
		___m_subsystemDescriptor_1 = value;
		Il2CppCodeGenWriteBarrier((&___m_subsystemDescriptor_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Experimental.Subsystem
struct Subsystem_t89723475_marshaled_pinvoke
{
	intptr_t ___m_Ptr_0;
	RuntimeObject* ___m_subsystemDescriptor_1;
};
// Native definition for COM marshalling of UnityEngine.Experimental.Subsystem
struct Subsystem_t89723475_marshaled_com
{
	intptr_t ___m_Ptr_0;
	RuntimeObject* ___m_subsystemDescriptor_1;
};
#endif // SUBSYSTEM_T89723475_H
#ifndef SUBSYSTEMDESCRIPTORBASE_T2374447182_H
#define SUBSYSTEMDESCRIPTORBASE_T2374447182_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.SubsystemDescriptorBase
struct  SubsystemDescriptorBase_t2374447182  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Experimental.SubsystemDescriptorBase::m_Ptr
	intptr_t ___m_Ptr_0;

public:
	inline static int32_t get_offset_of_m_Ptr_0() { return static_cast<int32_t>(offsetof(SubsystemDescriptorBase_t2374447182, ___m_Ptr_0)); }
	inline intptr_t get_m_Ptr_0() const { return ___m_Ptr_0; }
	inline intptr_t* get_address_of_m_Ptr_0() { return &___m_Ptr_0; }
	inline void set_m_Ptr_0(intptr_t value)
	{
		___m_Ptr_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Experimental.SubsystemDescriptorBase
struct SubsystemDescriptorBase_t2374447182_marshaled_pinvoke
{
	intptr_t ___m_Ptr_0;
};
// Native definition for COM marshalling of UnityEngine.Experimental.SubsystemDescriptorBase
struct SubsystemDescriptorBase_t2374447182_marshaled_com
{
	intptr_t ___m_Ptr_0;
};
#endif // SUBSYSTEMDESCRIPTORBASE_T2374447182_H
#ifndef PLANEALIGNMENT_T1259054711_H
#define PLANEALIGNMENT_T1259054711_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.PlaneAlignment
struct  PlaneAlignment_t1259054711 
{
public:
	// System.Int32 UnityEngine.Experimental.XR.PlaneAlignment::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(PlaneAlignment_t1259054711, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PLANEALIGNMENT_T1259054711_H
#ifndef TRACKABLETYPE_T775678994_H
#define TRACKABLETYPE_T775678994_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.TrackableType
struct  TrackableType_t775678994 
{
public:
	// System.Int32 UnityEngine.Experimental.XR.TrackableType::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(TrackableType_t775678994, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TRACKABLETYPE_T775678994_H
#ifndef TRACKINGSTATE_T1935085052_H
#define TRACKINGSTATE_T1935085052_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.TrackingState
struct  TrackingState_t1935085052 
{
public:
	// System.Int32 UnityEngine.Experimental.XR.TrackingState::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(TrackingState_t1935085052, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TRACKINGSTATE_T1935085052_H
#ifndef OBJECT_T631007953_H
#define OBJECT_T631007953_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Object
struct  Object_t631007953  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	intptr_t ___m_CachedPtr_0;

public:
	inline static int32_t get_offset_of_m_CachedPtr_0() { return static_cast<int32_t>(offsetof(Object_t631007953, ___m_CachedPtr_0)); }
	inline intptr_t get_m_CachedPtr_0() const { return ___m_CachedPtr_0; }
	inline intptr_t* get_address_of_m_CachedPtr_0() { return &___m_CachedPtr_0; }
	inline void set_m_CachedPtr_0(intptr_t value)
	{
		___m_CachedPtr_0 = value;
	}
};

struct Object_t631007953_StaticFields
{
public:
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;

public:
	inline static int32_t get_offset_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return static_cast<int32_t>(offsetof(Object_t631007953_StaticFields, ___OffsetOfInstanceIDInCPlusPlusObject_1)); }
	inline int32_t get_OffsetOfInstanceIDInCPlusPlusObject_1() const { return ___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline int32_t* get_address_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return &___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline void set_OffsetOfInstanceIDInCPlusPlusObject_1(int32_t value)
	{
		___OffsetOfInstanceIDInCPlusPlusObject_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_t631007953_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_t631007953_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};
#endif // OBJECT_T631007953_H
#ifndef POSE_T545244865_H
#define POSE_T545244865_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Pose
struct  Pose_t545244865 
{
public:
	// UnityEngine.Vector3 UnityEngine.Pose::position
	Vector3_t3722313464  ___position_0;
	// UnityEngine.Quaternion UnityEngine.Pose::rotation
	Quaternion_t2301928331  ___rotation_1;

public:
	inline static int32_t get_offset_of_position_0() { return static_cast<int32_t>(offsetof(Pose_t545244865, ___position_0)); }
	inline Vector3_t3722313464  get_position_0() const { return ___position_0; }
	inline Vector3_t3722313464 * get_address_of_position_0() { return &___position_0; }
	inline void set_position_0(Vector3_t3722313464  value)
	{
		___position_0 = value;
	}

	inline static int32_t get_offset_of_rotation_1() { return static_cast<int32_t>(offsetof(Pose_t545244865, ___rotation_1)); }
	inline Quaternion_t2301928331  get_rotation_1() const { return ___rotation_1; }
	inline Quaternion_t2301928331 * get_address_of_rotation_1() { return &___rotation_1; }
	inline void set_rotation_1(Quaternion_t2301928331  value)
	{
		___rotation_1 = value;
	}
};

struct Pose_t545244865_StaticFields
{
public:
	// UnityEngine.Pose UnityEngine.Pose::k_Identity
	Pose_t545244865  ___k_Identity_2;

public:
	inline static int32_t get_offset_of_k_Identity_2() { return static_cast<int32_t>(offsetof(Pose_t545244865_StaticFields, ___k_Identity_2)); }
	inline Pose_t545244865  get_k_Identity_2() const { return ___k_Identity_2; }
	inline Pose_t545244865 * get_address_of_k_Identity_2() { return &___k_Identity_2; }
	inline void set_k_Identity_2(Pose_t545244865  value)
	{
		___k_Identity_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSE_T545244865_H
#ifndef RAY_T3785851493_H
#define RAY_T3785851493_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Ray
struct  Ray_t3785851493 
{
public:
	// UnityEngine.Vector3 UnityEngine.Ray::m_Origin
	Vector3_t3722313464  ___m_Origin_0;
	// UnityEngine.Vector3 UnityEngine.Ray::m_Direction
	Vector3_t3722313464  ___m_Direction_1;

public:
	inline static int32_t get_offset_of_m_Origin_0() { return static_cast<int32_t>(offsetof(Ray_t3785851493, ___m_Origin_0)); }
	inline Vector3_t3722313464  get_m_Origin_0() const { return ___m_Origin_0; }
	inline Vector3_t3722313464 * get_address_of_m_Origin_0() { return &___m_Origin_0; }
	inline void set_m_Origin_0(Vector3_t3722313464  value)
	{
		___m_Origin_0 = value;
	}

	inline static int32_t get_offset_of_m_Direction_1() { return static_cast<int32_t>(offsetof(Ray_t3785851493, ___m_Direction_1)); }
	inline Vector3_t3722313464  get_m_Direction_1() const { return ___m_Direction_1; }
	inline Vector3_t3722313464 * get_address_of_m_Direction_1() { return &___m_Direction_1; }
	inline void set_m_Direction_1(Vector3_t3722313464  value)
	{
		___m_Direction_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RAY_T3785851493_H
#ifndef AVAILABLETRACKINGDATA_T3752197997_H
#define AVAILABLETRACKINGDATA_T3752197997_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.AvailableTrackingData
struct  AvailableTrackingData_t3752197997 
{
public:
	// System.Int32 UnityEngine.XR.AvailableTrackingData::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(AvailableTrackingData_t3752197997, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // AVAILABLETRACKINGDATA_T3752197997_H
#ifndef TRACKINGSTATEEVENTTYPE_T4085253601_H
#define TRACKINGSTATEEVENTTYPE_T4085253601_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.InputTracking/TrackingStateEventType
struct  TrackingStateEventType_t4085253601 
{
public:
	// System.Int32 UnityEngine.XR.InputTracking/TrackingStateEventType::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(TrackingStateEventType_t4085253601, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TRACKINGSTATEEVENTTYPE_T4085253601_H
#ifndef XRNODE_T3929440994_H
#define XRNODE_T3929440994_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.XRNode
struct  XRNode_t3929440994 
{
public:
	// System.Int32 UnityEngine.XR.XRNode::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(XRNode_t3929440994, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRNODE_T3929440994_H
#ifndef ARGUMENTNULLEXCEPTION_T1615371798_H
#define ARGUMENTNULLEXCEPTION_T1615371798_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ArgumentNullException
struct  ArgumentNullException_t1615371798  : public ArgumentException_t132251570
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ARGUMENTNULLEXCEPTION_T1615371798_H
#ifndef MULTICASTDELEGATE_T_H
#define MULTICASTDELEGATE_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.MulticastDelegate
struct  MulticastDelegate_t  : public Delegate_t1188392813
{
public:
	// System.MulticastDelegate System.MulticastDelegate::prev
	MulticastDelegate_t * ___prev_9;
	// System.MulticastDelegate System.MulticastDelegate::kpm_next
	MulticastDelegate_t * ___kpm_next_10;

public:
	inline static int32_t get_offset_of_prev_9() { return static_cast<int32_t>(offsetof(MulticastDelegate_t, ___prev_9)); }
	inline MulticastDelegate_t * get_prev_9() const { return ___prev_9; }
	inline MulticastDelegate_t ** get_address_of_prev_9() { return &___prev_9; }
	inline void set_prev_9(MulticastDelegate_t * value)
	{
		___prev_9 = value;
		Il2CppCodeGenWriteBarrier((&___prev_9), value);
	}

	inline static int32_t get_offset_of_kpm_next_10() { return static_cast<int32_t>(offsetof(MulticastDelegate_t, ___kpm_next_10)); }
	inline MulticastDelegate_t * get_kpm_next_10() const { return ___kpm_next_10; }
	inline MulticastDelegate_t ** get_address_of_kpm_next_10() { return &___kpm_next_10; }
	inline void set_kpm_next_10(MulticastDelegate_t * value)
	{
		___kpm_next_10 = value;
		Il2CppCodeGenWriteBarrier((&___kpm_next_10), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MULTICASTDELEGATE_T_H
#ifndef COMPONENT_T1923634451_H
#define COMPONENT_T1923634451_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Component
struct  Component_t1923634451  : public Object_t631007953
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COMPONENT_T1923634451_H
#ifndef SUBSYSTEMDESCRIPTOR_1_T1932951644_H
#define SUBSYSTEMDESCRIPTOR_1_T1932951644_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.SubsystemDescriptor`1<UnityEngine.Experimental.XR.XRCameraSubsystem>
struct  SubsystemDescriptor_1_t1932951644  : public SubsystemDescriptorBase_t2374447182
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SUBSYSTEMDESCRIPTOR_1_T1932951644_H
#ifndef SUBSYSTEMDESCRIPTOR_1_T1821516358_H
#define SUBSYSTEMDESCRIPTOR_1_T1821516358_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.SubsystemDescriptor`1<UnityEngine.Experimental.XR.XRDepthSubsystem>
struct  SubsystemDescriptor_1_t1821516358  : public SubsystemDescriptorBase_t2374447182
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SUBSYSTEMDESCRIPTOR_1_T1821516358_H
#ifndef SUBSYSTEMDESCRIPTOR_1_T3339253739_H
#define SUBSYSTEMDESCRIPTOR_1_T3339253739_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.SubsystemDescriptor`1<UnityEngine.Experimental.XR.XRInputSubsystem>
struct  SubsystemDescriptor_1_t3339253739  : public SubsystemDescriptorBase_t2374447182
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SUBSYSTEMDESCRIPTOR_1_T3339253739_H
#ifndef SUBSYSTEMDESCRIPTOR_1_T4292266728_H
#define SUBSYSTEMDESCRIPTOR_1_T4292266728_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.SubsystemDescriptor`1<UnityEngine.Experimental.XR.XRPlaneSubsystem>
struct  SubsystemDescriptor_1_t4292266728  : public SubsystemDescriptorBase_t2374447182
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SUBSYSTEMDESCRIPTOR_1_T4292266728_H
#ifndef SUBSYSTEMDESCRIPTOR_1_T484716919_H
#define SUBSYSTEMDESCRIPTOR_1_T484716919_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.SubsystemDescriptor`1<UnityEngine.Experimental.XR.XRRaycastSubsystem>
struct  SubsystemDescriptor_1_t484716919  : public SubsystemDescriptorBase_t2374447182
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SUBSYSTEMDESCRIPTOR_1_T484716919_H
#ifndef SUBSYSTEMDESCRIPTOR_1_T2448998858_H
#define SUBSYSTEMDESCRIPTOR_1_T2448998858_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.SubsystemDescriptor`1<UnityEngine.Experimental.XR.XRReferencePointSubsystem>
struct  SubsystemDescriptor_1_t2448998858  : public SubsystemDescriptorBase_t2374447182
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SUBSYSTEMDESCRIPTOR_1_T2448998858_H
#ifndef SUBSYSTEMDESCRIPTOR_1_T1353494744_H
#define SUBSYSTEMDESCRIPTOR_1_T1353494744_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.SubsystemDescriptor`1<UnityEngine.Experimental.XR.XRSessionSubsystem>
struct  SubsystemDescriptor_1_t1353494744  : public SubsystemDescriptorBase_t2374447182
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SUBSYSTEMDESCRIPTOR_1_T1353494744_H
#ifndef SUBSYSTEM_1_T588646725_H
#define SUBSYSTEM_1_T588646725_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.Subsystem`1<UnityEngine.Experimental.XR.XRCameraSubsystemDescriptor>
struct  Subsystem_1_t588646725  : public Subsystem_t89723475
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SUBSYSTEM_1_T588646725_H
#ifndef SUBSYSTEM_1_T3920528600_H
#define SUBSYSTEM_1_T3920528600_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.Subsystem`1<UnityEngine.Experimental.XR.XRDepthSubsystemDescriptor>
struct  Subsystem_1_t3920528600  : public Subsystem_t89723475
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SUBSYSTEM_1_T3920528600_H
#ifndef SUBSYSTEM_1_T207590349_H
#define SUBSYSTEM_1_T207590349_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.Subsystem`1<UnityEngine.Experimental.XR.XRInputSubsystemDescriptor>
struct  Subsystem_1_t207590349  : public Subsystem_t89723475
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SUBSYSTEM_1_T207590349_H
#ifndef SUBSYSTEM_1_T1428396990_H
#define SUBSYSTEM_1_T1428396990_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.Subsystem`1<UnityEngine.Experimental.XR.XRPlaneSubsystemDescriptor>
struct  Subsystem_1_t1428396990  : public Subsystem_t89723475
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SUBSYSTEM_1_T1428396990_H
#ifndef SUBSYSTEM_1_T1129293546_H
#define SUBSYSTEM_1_T1129293546_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.Subsystem`1<UnityEngine.Experimental.XR.XRRaycastSubsystemDescriptor>
struct  Subsystem_1_t1129293546  : public Subsystem_t89723475
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SUBSYSTEM_1_T1129293546_H
#ifndef SUBSYSTEM_1_T2853778384_H
#define SUBSYSTEM_1_T2853778384_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.Subsystem`1<UnityEngine.Experimental.XR.XRReferencePointSubsystemDescriptor>
struct  Subsystem_1_t2853778384  : public Subsystem_t89723475
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SUBSYSTEM_1_T2853778384_H
#ifndef SUBSYSTEM_1_T2383066733_H
#define SUBSYSTEM_1_T2383066733_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.Subsystem`1<UnityEngine.Experimental.XR.XRSessionSubsystemDescriptor>
struct  Subsystem_1_t2383066733  : public Subsystem_t89723475
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SUBSYSTEM_1_T2383066733_H
#ifndef BOUNDEDPLANE_T1317492334_H
#define BOUNDEDPLANE_T1317492334_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.BoundedPlane
struct  BoundedPlane_t1317492334 
{
public:
	// System.UInt32 UnityEngine.Experimental.XR.BoundedPlane::m_InstanceId
	uint32_t ___m_InstanceId_0;
	// UnityEngine.Experimental.XR.TrackableId UnityEngine.Experimental.XR.BoundedPlane::<Id>k__BackingField
	TrackableId_t1251031970  ___U3CIdU3Ek__BackingField_1;
	// UnityEngine.Experimental.XR.TrackableId UnityEngine.Experimental.XR.BoundedPlane::<SubsumedById>k__BackingField
	TrackableId_t1251031970  ___U3CSubsumedByIdU3Ek__BackingField_2;
	// UnityEngine.Pose UnityEngine.Experimental.XR.BoundedPlane::<Pose>k__BackingField
	Pose_t545244865  ___U3CPoseU3Ek__BackingField_3;
	// UnityEngine.Vector3 UnityEngine.Experimental.XR.BoundedPlane::<Center>k__BackingField
	Vector3_t3722313464  ___U3CCenterU3Ek__BackingField_4;
	// UnityEngine.Vector2 UnityEngine.Experimental.XR.BoundedPlane::<Size>k__BackingField
	Vector2_t2156229523  ___U3CSizeU3Ek__BackingField_5;
	// UnityEngine.Experimental.XR.PlaneAlignment UnityEngine.Experimental.XR.BoundedPlane::<Alignment>k__BackingField
	int32_t ___U3CAlignmentU3Ek__BackingField_6;

public:
	inline static int32_t get_offset_of_m_InstanceId_0() { return static_cast<int32_t>(offsetof(BoundedPlane_t1317492334, ___m_InstanceId_0)); }
	inline uint32_t get_m_InstanceId_0() const { return ___m_InstanceId_0; }
	inline uint32_t* get_address_of_m_InstanceId_0() { return &___m_InstanceId_0; }
	inline void set_m_InstanceId_0(uint32_t value)
	{
		___m_InstanceId_0 = value;
	}

	inline static int32_t get_offset_of_U3CIdU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(BoundedPlane_t1317492334, ___U3CIdU3Ek__BackingField_1)); }
	inline TrackableId_t1251031970  get_U3CIdU3Ek__BackingField_1() const { return ___U3CIdU3Ek__BackingField_1; }
	inline TrackableId_t1251031970 * get_address_of_U3CIdU3Ek__BackingField_1() { return &___U3CIdU3Ek__BackingField_1; }
	inline void set_U3CIdU3Ek__BackingField_1(TrackableId_t1251031970  value)
	{
		___U3CIdU3Ek__BackingField_1 = value;
	}

	inline static int32_t get_offset_of_U3CSubsumedByIdU3Ek__BackingField_2() { return static_cast<int32_t>(offsetof(BoundedPlane_t1317492334, ___U3CSubsumedByIdU3Ek__BackingField_2)); }
	inline TrackableId_t1251031970  get_U3CSubsumedByIdU3Ek__BackingField_2() const { return ___U3CSubsumedByIdU3Ek__BackingField_2; }
	inline TrackableId_t1251031970 * get_address_of_U3CSubsumedByIdU3Ek__BackingField_2() { return &___U3CSubsumedByIdU3Ek__BackingField_2; }
	inline void set_U3CSubsumedByIdU3Ek__BackingField_2(TrackableId_t1251031970  value)
	{
		___U3CSubsumedByIdU3Ek__BackingField_2 = value;
	}

	inline static int32_t get_offset_of_U3CPoseU3Ek__BackingField_3() { return static_cast<int32_t>(offsetof(BoundedPlane_t1317492334, ___U3CPoseU3Ek__BackingField_3)); }
	inline Pose_t545244865  get_U3CPoseU3Ek__BackingField_3() const { return ___U3CPoseU3Ek__BackingField_3; }
	inline Pose_t545244865 * get_address_of_U3CPoseU3Ek__BackingField_3() { return &___U3CPoseU3Ek__BackingField_3; }
	inline void set_U3CPoseU3Ek__BackingField_3(Pose_t545244865  value)
	{
		___U3CPoseU3Ek__BackingField_3 = value;
	}

	inline static int32_t get_offset_of_U3CCenterU3Ek__BackingField_4() { return static_cast<int32_t>(offsetof(BoundedPlane_t1317492334, ___U3CCenterU3Ek__BackingField_4)); }
	inline Vector3_t3722313464  get_U3CCenterU3Ek__BackingField_4() const { return ___U3CCenterU3Ek__BackingField_4; }
	inline Vector3_t3722313464 * get_address_of_U3CCenterU3Ek__BackingField_4() { return &___U3CCenterU3Ek__BackingField_4; }
	inline void set_U3CCenterU3Ek__BackingField_4(Vector3_t3722313464  value)
	{
		___U3CCenterU3Ek__BackingField_4 = value;
	}

	inline static int32_t get_offset_of_U3CSizeU3Ek__BackingField_5() { return static_cast<int32_t>(offsetof(BoundedPlane_t1317492334, ___U3CSizeU3Ek__BackingField_5)); }
	inline Vector2_t2156229523  get_U3CSizeU3Ek__BackingField_5() const { return ___U3CSizeU3Ek__BackingField_5; }
	inline Vector2_t2156229523 * get_address_of_U3CSizeU3Ek__BackingField_5() { return &___U3CSizeU3Ek__BackingField_5; }
	inline void set_U3CSizeU3Ek__BackingField_5(Vector2_t2156229523  value)
	{
		___U3CSizeU3Ek__BackingField_5 = value;
	}

	inline static int32_t get_offset_of_U3CAlignmentU3Ek__BackingField_6() { return static_cast<int32_t>(offsetof(BoundedPlane_t1317492334, ___U3CAlignmentU3Ek__BackingField_6)); }
	inline int32_t get_U3CAlignmentU3Ek__BackingField_6() const { return ___U3CAlignmentU3Ek__BackingField_6; }
	inline int32_t* get_address_of_U3CAlignmentU3Ek__BackingField_6() { return &___U3CAlignmentU3Ek__BackingField_6; }
	inline void set_U3CAlignmentU3Ek__BackingField_6(int32_t value)
	{
		___U3CAlignmentU3Ek__BackingField_6 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BOUNDEDPLANE_T1317492334_H
#ifndef REFERENCEPOINT_T394942483_H
#define REFERENCEPOINT_T394942483_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.ReferencePoint
struct  ReferencePoint_t394942483 
{
public:
	// UnityEngine.Experimental.XR.TrackableId UnityEngine.Experimental.XR.ReferencePoint::<Id>k__BackingField
	TrackableId_t1251031970  ___U3CIdU3Ek__BackingField_0;
	// UnityEngine.Experimental.XR.TrackingState UnityEngine.Experimental.XR.ReferencePoint::<TrackingState>k__BackingField
	int32_t ___U3CTrackingStateU3Ek__BackingField_1;
	// UnityEngine.Pose UnityEngine.Experimental.XR.ReferencePoint::<Pose>k__BackingField
	Pose_t545244865  ___U3CPoseU3Ek__BackingField_2;

public:
	inline static int32_t get_offset_of_U3CIdU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(ReferencePoint_t394942483, ___U3CIdU3Ek__BackingField_0)); }
	inline TrackableId_t1251031970  get_U3CIdU3Ek__BackingField_0() const { return ___U3CIdU3Ek__BackingField_0; }
	inline TrackableId_t1251031970 * get_address_of_U3CIdU3Ek__BackingField_0() { return &___U3CIdU3Ek__BackingField_0; }
	inline void set_U3CIdU3Ek__BackingField_0(TrackableId_t1251031970  value)
	{
		___U3CIdU3Ek__BackingField_0 = value;
	}

	inline static int32_t get_offset_of_U3CTrackingStateU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(ReferencePoint_t394942483, ___U3CTrackingStateU3Ek__BackingField_1)); }
	inline int32_t get_U3CTrackingStateU3Ek__BackingField_1() const { return ___U3CTrackingStateU3Ek__BackingField_1; }
	inline int32_t* get_address_of_U3CTrackingStateU3Ek__BackingField_1() { return &___U3CTrackingStateU3Ek__BackingField_1; }
	inline void set_U3CTrackingStateU3Ek__BackingField_1(int32_t value)
	{
		___U3CTrackingStateU3Ek__BackingField_1 = value;
	}

	inline static int32_t get_offset_of_U3CPoseU3Ek__BackingField_2() { return static_cast<int32_t>(offsetof(ReferencePoint_t394942483, ___U3CPoseU3Ek__BackingField_2)); }
	inline Pose_t545244865  get_U3CPoseU3Ek__BackingField_2() const { return ___U3CPoseU3Ek__BackingField_2; }
	inline Pose_t545244865 * get_address_of_U3CPoseU3Ek__BackingField_2() { return &___U3CPoseU3Ek__BackingField_2; }
	inline void set_U3CPoseU3Ek__BackingField_2(Pose_t545244865  value)
	{
		___U3CPoseU3Ek__BackingField_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // REFERENCEPOINT_T394942483_H
#ifndef SESSIONTRACKINGSTATECHANGEDEVENTARGS_T2343035655_H
#define SESSIONTRACKINGSTATECHANGEDEVENTARGS_T2343035655_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.SessionTrackingStateChangedEventArgs
struct  SessionTrackingStateChangedEventArgs_t2343035655 
{
public:
	// UnityEngine.Experimental.XR.XRSessionSubsystem UnityEngine.Experimental.XR.SessionTrackingStateChangedEventArgs::m_Session
	XRSessionSubsystem_t3616338244 * ___m_Session_0;
	// UnityEngine.Experimental.XR.TrackingState UnityEngine.Experimental.XR.SessionTrackingStateChangedEventArgs::<NewState>k__BackingField
	int32_t ___U3CNewStateU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of_m_Session_0() { return static_cast<int32_t>(offsetof(SessionTrackingStateChangedEventArgs_t2343035655, ___m_Session_0)); }
	inline XRSessionSubsystem_t3616338244 * get_m_Session_0() const { return ___m_Session_0; }
	inline XRSessionSubsystem_t3616338244 ** get_address_of_m_Session_0() { return &___m_Session_0; }
	inline void set_m_Session_0(XRSessionSubsystem_t3616338244 * value)
	{
		___m_Session_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_Session_0), value);
	}

	inline static int32_t get_offset_of_U3CNewStateU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(SessionTrackingStateChangedEventArgs_t2343035655, ___U3CNewStateU3Ek__BackingField_1)); }
	inline int32_t get_U3CNewStateU3Ek__BackingField_1() const { return ___U3CNewStateU3Ek__BackingField_1; }
	inline int32_t* get_address_of_U3CNewStateU3Ek__BackingField_1() { return &___U3CNewStateU3Ek__BackingField_1; }
	inline void set_U3CNewStateU3Ek__BackingField_1(int32_t value)
	{
		___U3CNewStateU3Ek__BackingField_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Experimental.XR.SessionTrackingStateChangedEventArgs
struct SessionTrackingStateChangedEventArgs_t2343035655_marshaled_pinvoke
{
	XRSessionSubsystem_t3616338244 * ___m_Session_0;
	int32_t ___U3CNewStateU3Ek__BackingField_1;
};
// Native definition for COM marshalling of UnityEngine.Experimental.XR.SessionTrackingStateChangedEventArgs
struct SessionTrackingStateChangedEventArgs_t2343035655_marshaled_com
{
	XRSessionSubsystem_t3616338244 * ___m_Session_0;
	int32_t ___U3CNewStateU3Ek__BackingField_1;
};
#endif // SESSIONTRACKINGSTATECHANGEDEVENTARGS_T2343035655_H
#ifndef XRRAYCASTHIT_T2370805074_H
#define XRRAYCASTHIT_T2370805074_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.XRRaycastHit
struct  XRRaycastHit_t2370805074 
{
public:
	// UnityEngine.Experimental.XR.TrackableId UnityEngine.Experimental.XR.XRRaycastHit::<TrackableId>k__BackingField
	TrackableId_t1251031970  ___U3CTrackableIdU3Ek__BackingField_0;
	// UnityEngine.Pose UnityEngine.Experimental.XR.XRRaycastHit::<Pose>k__BackingField
	Pose_t545244865  ___U3CPoseU3Ek__BackingField_1;
	// System.Single UnityEngine.Experimental.XR.XRRaycastHit::<Distance>k__BackingField
	float ___U3CDistanceU3Ek__BackingField_2;
	// UnityEngine.Experimental.XR.TrackableType UnityEngine.Experimental.XR.XRRaycastHit::<HitType>k__BackingField
	int32_t ___U3CHitTypeU3Ek__BackingField_3;

public:
	inline static int32_t get_offset_of_U3CTrackableIdU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(XRRaycastHit_t2370805074, ___U3CTrackableIdU3Ek__BackingField_0)); }
	inline TrackableId_t1251031970  get_U3CTrackableIdU3Ek__BackingField_0() const { return ___U3CTrackableIdU3Ek__BackingField_0; }
	inline TrackableId_t1251031970 * get_address_of_U3CTrackableIdU3Ek__BackingField_0() { return &___U3CTrackableIdU3Ek__BackingField_0; }
	inline void set_U3CTrackableIdU3Ek__BackingField_0(TrackableId_t1251031970  value)
	{
		___U3CTrackableIdU3Ek__BackingField_0 = value;
	}

	inline static int32_t get_offset_of_U3CPoseU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(XRRaycastHit_t2370805074, ___U3CPoseU3Ek__BackingField_1)); }
	inline Pose_t545244865  get_U3CPoseU3Ek__BackingField_1() const { return ___U3CPoseU3Ek__BackingField_1; }
	inline Pose_t545244865 * get_address_of_U3CPoseU3Ek__BackingField_1() { return &___U3CPoseU3Ek__BackingField_1; }
	inline void set_U3CPoseU3Ek__BackingField_1(Pose_t545244865  value)
	{
		___U3CPoseU3Ek__BackingField_1 = value;
	}

	inline static int32_t get_offset_of_U3CDistanceU3Ek__BackingField_2() { return static_cast<int32_t>(offsetof(XRRaycastHit_t2370805074, ___U3CDistanceU3Ek__BackingField_2)); }
	inline float get_U3CDistanceU3Ek__BackingField_2() const { return ___U3CDistanceU3Ek__BackingField_2; }
	inline float* get_address_of_U3CDistanceU3Ek__BackingField_2() { return &___U3CDistanceU3Ek__BackingField_2; }
	inline void set_U3CDistanceU3Ek__BackingField_2(float value)
	{
		___U3CDistanceU3Ek__BackingField_2 = value;
	}

	inline static int32_t get_offset_of_U3CHitTypeU3Ek__BackingField_3() { return static_cast<int32_t>(offsetof(XRRaycastHit_t2370805074, ___U3CHitTypeU3Ek__BackingField_3)); }
	inline int32_t get_U3CHitTypeU3Ek__BackingField_3() const { return ___U3CHitTypeU3Ek__BackingField_3; }
	inline int32_t* get_address_of_U3CHitTypeU3Ek__BackingField_3() { return &___U3CHitTypeU3Ek__BackingField_3; }
	inline void set_U3CHitTypeU3Ek__BackingField_3(int32_t value)
	{
		___U3CHitTypeU3Ek__BackingField_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRRAYCASTHIT_T2370805074_H
#ifndef MATERIAL_T340375123_H
#define MATERIAL_T340375123_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Material
struct  Material_t340375123  : public Object_t631007953
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MATERIAL_T340375123_H
#ifndef XRNODESTATE_T3752602430_H
#define XRNODESTATE_T3752602430_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.XRNodeState
struct  XRNodeState_t3752602430 
{
public:
	// UnityEngine.XR.XRNode UnityEngine.XR.XRNodeState::m_Type
	int32_t ___m_Type_0;
	// UnityEngine.XR.AvailableTrackingData UnityEngine.XR.XRNodeState::m_AvailableFields
	int32_t ___m_AvailableFields_1;
	// UnityEngine.Vector3 UnityEngine.XR.XRNodeState::m_Position
	Vector3_t3722313464  ___m_Position_2;
	// UnityEngine.Quaternion UnityEngine.XR.XRNodeState::m_Rotation
	Quaternion_t2301928331  ___m_Rotation_3;
	// UnityEngine.Vector3 UnityEngine.XR.XRNodeState::m_Velocity
	Vector3_t3722313464  ___m_Velocity_4;
	// UnityEngine.Vector3 UnityEngine.XR.XRNodeState::m_AngularVelocity
	Vector3_t3722313464  ___m_AngularVelocity_5;
	// UnityEngine.Vector3 UnityEngine.XR.XRNodeState::m_Acceleration
	Vector3_t3722313464  ___m_Acceleration_6;
	// UnityEngine.Vector3 UnityEngine.XR.XRNodeState::m_AngularAcceleration
	Vector3_t3722313464  ___m_AngularAcceleration_7;
	// System.Int32 UnityEngine.XR.XRNodeState::m_Tracked
	int32_t ___m_Tracked_8;
	// System.UInt64 UnityEngine.XR.XRNodeState::m_UniqueID
	uint64_t ___m_UniqueID_9;

public:
	inline static int32_t get_offset_of_m_Type_0() { return static_cast<int32_t>(offsetof(XRNodeState_t3752602430, ___m_Type_0)); }
	inline int32_t get_m_Type_0() const { return ___m_Type_0; }
	inline int32_t* get_address_of_m_Type_0() { return &___m_Type_0; }
	inline void set_m_Type_0(int32_t value)
	{
		___m_Type_0 = value;
	}

	inline static int32_t get_offset_of_m_AvailableFields_1() { return static_cast<int32_t>(offsetof(XRNodeState_t3752602430, ___m_AvailableFields_1)); }
	inline int32_t get_m_AvailableFields_1() const { return ___m_AvailableFields_1; }
	inline int32_t* get_address_of_m_AvailableFields_1() { return &___m_AvailableFields_1; }
	inline void set_m_AvailableFields_1(int32_t value)
	{
		___m_AvailableFields_1 = value;
	}

	inline static int32_t get_offset_of_m_Position_2() { return static_cast<int32_t>(offsetof(XRNodeState_t3752602430, ___m_Position_2)); }
	inline Vector3_t3722313464  get_m_Position_2() const { return ___m_Position_2; }
	inline Vector3_t3722313464 * get_address_of_m_Position_2() { return &___m_Position_2; }
	inline void set_m_Position_2(Vector3_t3722313464  value)
	{
		___m_Position_2 = value;
	}

	inline static int32_t get_offset_of_m_Rotation_3() { return static_cast<int32_t>(offsetof(XRNodeState_t3752602430, ___m_Rotation_3)); }
	inline Quaternion_t2301928331  get_m_Rotation_3() const { return ___m_Rotation_3; }
	inline Quaternion_t2301928331 * get_address_of_m_Rotation_3() { return &___m_Rotation_3; }
	inline void set_m_Rotation_3(Quaternion_t2301928331  value)
	{
		___m_Rotation_3 = value;
	}

	inline static int32_t get_offset_of_m_Velocity_4() { return static_cast<int32_t>(offsetof(XRNodeState_t3752602430, ___m_Velocity_4)); }
	inline Vector3_t3722313464  get_m_Velocity_4() const { return ___m_Velocity_4; }
	inline Vector3_t3722313464 * get_address_of_m_Velocity_4() { return &___m_Velocity_4; }
	inline void set_m_Velocity_4(Vector3_t3722313464  value)
	{
		___m_Velocity_4 = value;
	}

	inline static int32_t get_offset_of_m_AngularVelocity_5() { return static_cast<int32_t>(offsetof(XRNodeState_t3752602430, ___m_AngularVelocity_5)); }
	inline Vector3_t3722313464  get_m_AngularVelocity_5() const { return ___m_AngularVelocity_5; }
	inline Vector3_t3722313464 * get_address_of_m_AngularVelocity_5() { return &___m_AngularVelocity_5; }
	inline void set_m_AngularVelocity_5(Vector3_t3722313464  value)
	{
		___m_AngularVelocity_5 = value;
	}

	inline static int32_t get_offset_of_m_Acceleration_6() { return static_cast<int32_t>(offsetof(XRNodeState_t3752602430, ___m_Acceleration_6)); }
	inline Vector3_t3722313464  get_m_Acceleration_6() const { return ___m_Acceleration_6; }
	inline Vector3_t3722313464 * get_address_of_m_Acceleration_6() { return &___m_Acceleration_6; }
	inline void set_m_Acceleration_6(Vector3_t3722313464  value)
	{
		___m_Acceleration_6 = value;
	}

	inline static int32_t get_offset_of_m_AngularAcceleration_7() { return static_cast<int32_t>(offsetof(XRNodeState_t3752602430, ___m_AngularAcceleration_7)); }
	inline Vector3_t3722313464  get_m_AngularAcceleration_7() const { return ___m_AngularAcceleration_7; }
	inline Vector3_t3722313464 * get_address_of_m_AngularAcceleration_7() { return &___m_AngularAcceleration_7; }
	inline void set_m_AngularAcceleration_7(Vector3_t3722313464  value)
	{
		___m_AngularAcceleration_7 = value;
	}

	inline static int32_t get_offset_of_m_Tracked_8() { return static_cast<int32_t>(offsetof(XRNodeState_t3752602430, ___m_Tracked_8)); }
	inline int32_t get_m_Tracked_8() const { return ___m_Tracked_8; }
	inline int32_t* get_address_of_m_Tracked_8() { return &___m_Tracked_8; }
	inline void set_m_Tracked_8(int32_t value)
	{
		___m_Tracked_8 = value;
	}

	inline static int32_t get_offset_of_m_UniqueID_9() { return static_cast<int32_t>(offsetof(XRNodeState_t3752602430, ___m_UniqueID_9)); }
	inline uint64_t get_m_UniqueID_9() const { return ___m_UniqueID_9; }
	inline uint64_t* get_address_of_m_UniqueID_9() { return &___m_UniqueID_9; }
	inline void set_m_UniqueID_9(uint64_t value)
	{
		___m_UniqueID_9 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRNODESTATE_T3752602430_H
#ifndef ACTION_1_T2760547698_H
#define ACTION_1_T2760547698_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Action`1<UnityEngine.Experimental.XR.FrameReceivedEventArgs>
struct  Action_1_t2760547698  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ACTION_1_T2760547698_H
#ifndef ACTION_1_T3609124943_H
#define ACTION_1_T3609124943_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Action`1<UnityEngine.Experimental.XR.PointCloudUpdatedEventArgs>
struct  Action_1_t3609124943  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ACTION_1_T3609124943_H
#ifndef ACTION_1_T2515503250_H
#define ACTION_1_T2515503250_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Action`1<UnityEngine.Experimental.XR.SessionTrackingStateChangedEventArgs>
struct  Action_1_t2515503250  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ACTION_1_T2515503250_H
#ifndef ACTION_1_T3925070025_H
#define ACTION_1_T3925070025_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Action`1<UnityEngine.XR.XRNodeState>
struct  Action_1_t3925070025  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ACTION_1_T3925070025_H
#ifndef BEHAVIOUR_T1437897464_H
#define BEHAVIOUR_T1437897464_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Behaviour
struct  Behaviour_t1437897464  : public Component_t1923634451
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BEHAVIOUR_T1437897464_H
#ifndef PLANEADDEDEVENTARGS_T2550175725_H
#define PLANEADDEDEVENTARGS_T2550175725_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.PlaneAddedEventArgs
struct  PlaneAddedEventArgs_t2550175725 
{
public:
	// UnityEngine.Experimental.XR.XRPlaneSubsystem UnityEngine.Experimental.XR.PlaneAddedEventArgs::<PlaneSubsystem>k__BackingField
	XRPlaneSubsystem_t2260142932 * ___U3CPlaneSubsystemU3Ek__BackingField_0;
	// UnityEngine.Experimental.XR.BoundedPlane UnityEngine.Experimental.XR.PlaneAddedEventArgs::<Plane>k__BackingField
	BoundedPlane_t1317492334  ___U3CPlaneU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of_U3CPlaneSubsystemU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(PlaneAddedEventArgs_t2550175725, ___U3CPlaneSubsystemU3Ek__BackingField_0)); }
	inline XRPlaneSubsystem_t2260142932 * get_U3CPlaneSubsystemU3Ek__BackingField_0() const { return ___U3CPlaneSubsystemU3Ek__BackingField_0; }
	inline XRPlaneSubsystem_t2260142932 ** get_address_of_U3CPlaneSubsystemU3Ek__BackingField_0() { return &___U3CPlaneSubsystemU3Ek__BackingField_0; }
	inline void set_U3CPlaneSubsystemU3Ek__BackingField_0(XRPlaneSubsystem_t2260142932 * value)
	{
		___U3CPlaneSubsystemU3Ek__BackingField_0 = value;
		Il2CppCodeGenWriteBarrier((&___U3CPlaneSubsystemU3Ek__BackingField_0), value);
	}

	inline static int32_t get_offset_of_U3CPlaneU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(PlaneAddedEventArgs_t2550175725, ___U3CPlaneU3Ek__BackingField_1)); }
	inline BoundedPlane_t1317492334  get_U3CPlaneU3Ek__BackingField_1() const { return ___U3CPlaneU3Ek__BackingField_1; }
	inline BoundedPlane_t1317492334 * get_address_of_U3CPlaneU3Ek__BackingField_1() { return &___U3CPlaneU3Ek__BackingField_1; }
	inline void set_U3CPlaneU3Ek__BackingField_1(BoundedPlane_t1317492334  value)
	{
		___U3CPlaneU3Ek__BackingField_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Experimental.XR.PlaneAddedEventArgs
struct PlaneAddedEventArgs_t2550175725_marshaled_pinvoke
{
	XRPlaneSubsystem_t2260142932 * ___U3CPlaneSubsystemU3Ek__BackingField_0;
	BoundedPlane_t1317492334  ___U3CPlaneU3Ek__BackingField_1;
};
// Native definition for COM marshalling of UnityEngine.Experimental.XR.PlaneAddedEventArgs
struct PlaneAddedEventArgs_t2550175725_marshaled_com
{
	XRPlaneSubsystem_t2260142932 * ___U3CPlaneSubsystemU3Ek__BackingField_0;
	BoundedPlane_t1317492334  ___U3CPlaneU3Ek__BackingField_1;
};
#endif // PLANEADDEDEVENTARGS_T2550175725_H
#ifndef PLANEREMOVEDEVENTARGS_T1567129782_H
#define PLANEREMOVEDEVENTARGS_T1567129782_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.PlaneRemovedEventArgs
struct  PlaneRemovedEventArgs_t1567129782 
{
public:
	// UnityEngine.Experimental.XR.XRPlaneSubsystem UnityEngine.Experimental.XR.PlaneRemovedEventArgs::<PlaneSubsystem>k__BackingField
	XRPlaneSubsystem_t2260142932 * ___U3CPlaneSubsystemU3Ek__BackingField_0;
	// UnityEngine.Experimental.XR.BoundedPlane UnityEngine.Experimental.XR.PlaneRemovedEventArgs::<Plane>k__BackingField
	BoundedPlane_t1317492334  ___U3CPlaneU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of_U3CPlaneSubsystemU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(PlaneRemovedEventArgs_t1567129782, ___U3CPlaneSubsystemU3Ek__BackingField_0)); }
	inline XRPlaneSubsystem_t2260142932 * get_U3CPlaneSubsystemU3Ek__BackingField_0() const { return ___U3CPlaneSubsystemU3Ek__BackingField_0; }
	inline XRPlaneSubsystem_t2260142932 ** get_address_of_U3CPlaneSubsystemU3Ek__BackingField_0() { return &___U3CPlaneSubsystemU3Ek__BackingField_0; }
	inline void set_U3CPlaneSubsystemU3Ek__BackingField_0(XRPlaneSubsystem_t2260142932 * value)
	{
		___U3CPlaneSubsystemU3Ek__BackingField_0 = value;
		Il2CppCodeGenWriteBarrier((&___U3CPlaneSubsystemU3Ek__BackingField_0), value);
	}

	inline static int32_t get_offset_of_U3CPlaneU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(PlaneRemovedEventArgs_t1567129782, ___U3CPlaneU3Ek__BackingField_1)); }
	inline BoundedPlane_t1317492334  get_U3CPlaneU3Ek__BackingField_1() const { return ___U3CPlaneU3Ek__BackingField_1; }
	inline BoundedPlane_t1317492334 * get_address_of_U3CPlaneU3Ek__BackingField_1() { return &___U3CPlaneU3Ek__BackingField_1; }
	inline void set_U3CPlaneU3Ek__BackingField_1(BoundedPlane_t1317492334  value)
	{
		___U3CPlaneU3Ek__BackingField_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Experimental.XR.PlaneRemovedEventArgs
struct PlaneRemovedEventArgs_t1567129782_marshaled_pinvoke
{
	XRPlaneSubsystem_t2260142932 * ___U3CPlaneSubsystemU3Ek__BackingField_0;
	BoundedPlane_t1317492334  ___U3CPlaneU3Ek__BackingField_1;
};
// Native definition for COM marshalling of UnityEngine.Experimental.XR.PlaneRemovedEventArgs
struct PlaneRemovedEventArgs_t1567129782_marshaled_com
{
	XRPlaneSubsystem_t2260142932 * ___U3CPlaneSubsystemU3Ek__BackingField_0;
	BoundedPlane_t1317492334  ___U3CPlaneU3Ek__BackingField_1;
};
#endif // PLANEREMOVEDEVENTARGS_T1567129782_H
#ifndef PLANEUPDATEDEVENTARGS_T349485851_H
#define PLANEUPDATEDEVENTARGS_T349485851_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.PlaneUpdatedEventArgs
struct  PlaneUpdatedEventArgs_t349485851 
{
public:
	// UnityEngine.Experimental.XR.XRPlaneSubsystem UnityEngine.Experimental.XR.PlaneUpdatedEventArgs::<PlaneSubsystem>k__BackingField
	XRPlaneSubsystem_t2260142932 * ___U3CPlaneSubsystemU3Ek__BackingField_0;
	// UnityEngine.Experimental.XR.BoundedPlane UnityEngine.Experimental.XR.PlaneUpdatedEventArgs::<Plane>k__BackingField
	BoundedPlane_t1317492334  ___U3CPlaneU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of_U3CPlaneSubsystemU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(PlaneUpdatedEventArgs_t349485851, ___U3CPlaneSubsystemU3Ek__BackingField_0)); }
	inline XRPlaneSubsystem_t2260142932 * get_U3CPlaneSubsystemU3Ek__BackingField_0() const { return ___U3CPlaneSubsystemU3Ek__BackingField_0; }
	inline XRPlaneSubsystem_t2260142932 ** get_address_of_U3CPlaneSubsystemU3Ek__BackingField_0() { return &___U3CPlaneSubsystemU3Ek__BackingField_0; }
	inline void set_U3CPlaneSubsystemU3Ek__BackingField_0(XRPlaneSubsystem_t2260142932 * value)
	{
		___U3CPlaneSubsystemU3Ek__BackingField_0 = value;
		Il2CppCodeGenWriteBarrier((&___U3CPlaneSubsystemU3Ek__BackingField_0), value);
	}

	inline static int32_t get_offset_of_U3CPlaneU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(PlaneUpdatedEventArgs_t349485851, ___U3CPlaneU3Ek__BackingField_1)); }
	inline BoundedPlane_t1317492334  get_U3CPlaneU3Ek__BackingField_1() const { return ___U3CPlaneU3Ek__BackingField_1; }
	inline BoundedPlane_t1317492334 * get_address_of_U3CPlaneU3Ek__BackingField_1() { return &___U3CPlaneU3Ek__BackingField_1; }
	inline void set_U3CPlaneU3Ek__BackingField_1(BoundedPlane_t1317492334  value)
	{
		___U3CPlaneU3Ek__BackingField_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Experimental.XR.PlaneUpdatedEventArgs
struct PlaneUpdatedEventArgs_t349485851_marshaled_pinvoke
{
	XRPlaneSubsystem_t2260142932 * ___U3CPlaneSubsystemU3Ek__BackingField_0;
	BoundedPlane_t1317492334  ___U3CPlaneU3Ek__BackingField_1;
};
// Native definition for COM marshalling of UnityEngine.Experimental.XR.PlaneUpdatedEventArgs
struct PlaneUpdatedEventArgs_t349485851_marshaled_com
{
	XRPlaneSubsystem_t2260142932 * ___U3CPlaneSubsystemU3Ek__BackingField_0;
	BoundedPlane_t1317492334  ___U3CPlaneU3Ek__BackingField_1;
};
#endif // PLANEUPDATEDEVENTARGS_T349485851_H
#ifndef REFERENCEPOINTUPDATEDEVENTARGS_T2046512733_H
#define REFERENCEPOINTUPDATEDEVENTARGS_T2046512733_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.ReferencePointUpdatedEventArgs
struct  ReferencePointUpdatedEventArgs_t2046512733 
{
public:
	// UnityEngine.Experimental.XR.ReferencePoint UnityEngine.Experimental.XR.ReferencePointUpdatedEventArgs::<ReferencePoint>k__BackingField
	ReferencePoint_t394942483  ___U3CReferencePointU3Ek__BackingField_0;
	// UnityEngine.Experimental.XR.TrackingState UnityEngine.Experimental.XR.ReferencePointUpdatedEventArgs::<PreviousTrackingState>k__BackingField
	int32_t ___U3CPreviousTrackingStateU3Ek__BackingField_1;
	// UnityEngine.Pose UnityEngine.Experimental.XR.ReferencePointUpdatedEventArgs::<PreviousPose>k__BackingField
	Pose_t545244865  ___U3CPreviousPoseU3Ek__BackingField_2;

public:
	inline static int32_t get_offset_of_U3CReferencePointU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(ReferencePointUpdatedEventArgs_t2046512733, ___U3CReferencePointU3Ek__BackingField_0)); }
	inline ReferencePoint_t394942483  get_U3CReferencePointU3Ek__BackingField_0() const { return ___U3CReferencePointU3Ek__BackingField_0; }
	inline ReferencePoint_t394942483 * get_address_of_U3CReferencePointU3Ek__BackingField_0() { return &___U3CReferencePointU3Ek__BackingField_0; }
	inline void set_U3CReferencePointU3Ek__BackingField_0(ReferencePoint_t394942483  value)
	{
		___U3CReferencePointU3Ek__BackingField_0 = value;
	}

	inline static int32_t get_offset_of_U3CPreviousTrackingStateU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(ReferencePointUpdatedEventArgs_t2046512733, ___U3CPreviousTrackingStateU3Ek__BackingField_1)); }
	inline int32_t get_U3CPreviousTrackingStateU3Ek__BackingField_1() const { return ___U3CPreviousTrackingStateU3Ek__BackingField_1; }
	inline int32_t* get_address_of_U3CPreviousTrackingStateU3Ek__BackingField_1() { return &___U3CPreviousTrackingStateU3Ek__BackingField_1; }
	inline void set_U3CPreviousTrackingStateU3Ek__BackingField_1(int32_t value)
	{
		___U3CPreviousTrackingStateU3Ek__BackingField_1 = value;
	}

	inline static int32_t get_offset_of_U3CPreviousPoseU3Ek__BackingField_2() { return static_cast<int32_t>(offsetof(ReferencePointUpdatedEventArgs_t2046512733, ___U3CPreviousPoseU3Ek__BackingField_2)); }
	inline Pose_t545244865  get_U3CPreviousPoseU3Ek__BackingField_2() const { return ___U3CPreviousPoseU3Ek__BackingField_2; }
	inline Pose_t545244865 * get_address_of_U3CPreviousPoseU3Ek__BackingField_2() { return &___U3CPreviousPoseU3Ek__BackingField_2; }
	inline void set_U3CPreviousPoseU3Ek__BackingField_2(Pose_t545244865  value)
	{
		___U3CPreviousPoseU3Ek__BackingField_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // REFERENCEPOINTUPDATEDEVENTARGS_T2046512733_H
#ifndef XRCAMERASUBSYSTEM_T4195795144_H
#define XRCAMERASUBSYSTEM_T4195795144_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.XRCameraSubsystem
struct  XRCameraSubsystem_t4195795144  : public Subsystem_1_t588646725
{
public:
	// System.Action`1<UnityEngine.Experimental.XR.FrameReceivedEventArgs> UnityEngine.Experimental.XR.XRCameraSubsystem::FrameReceived
	Action_1_t2760547698 * ___FrameReceived_2;

public:
	inline static int32_t get_offset_of_FrameReceived_2() { return static_cast<int32_t>(offsetof(XRCameraSubsystem_t4195795144, ___FrameReceived_2)); }
	inline Action_1_t2760547698 * get_FrameReceived_2() const { return ___FrameReceived_2; }
	inline Action_1_t2760547698 ** get_address_of_FrameReceived_2() { return &___FrameReceived_2; }
	inline void set_FrameReceived_2(Action_1_t2760547698 * value)
	{
		___FrameReceived_2 = value;
		Il2CppCodeGenWriteBarrier((&___FrameReceived_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRCAMERASUBSYSTEM_T4195795144_H
#ifndef XRCAMERASUBSYSTEMDESCRIPTOR_T3689383335_H
#define XRCAMERASUBSYSTEMDESCRIPTOR_T3689383335_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.XRCameraSubsystemDescriptor
struct  XRCameraSubsystemDescriptor_t3689383335  : public SubsystemDescriptor_1_t1932951644
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRCAMERASUBSYSTEMDESCRIPTOR_T3689383335_H
#ifndef XRDEPTHSUBSYSTEM_T4084359858_H
#define XRDEPTHSUBSYSTEM_T4084359858_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.XRDepthSubsystem
struct  XRDepthSubsystem_t4084359858  : public Subsystem_1_t3920528600
{
public:
	// System.Action`1<UnityEngine.Experimental.XR.PointCloudUpdatedEventArgs> UnityEngine.Experimental.XR.XRDepthSubsystem::PointCloudUpdated
	Action_1_t3609124943 * ___PointCloudUpdated_2;

public:
	inline static int32_t get_offset_of_PointCloudUpdated_2() { return static_cast<int32_t>(offsetof(XRDepthSubsystem_t4084359858, ___PointCloudUpdated_2)); }
	inline Action_1_t3609124943 * get_PointCloudUpdated_2() const { return ___PointCloudUpdated_2; }
	inline Action_1_t3609124943 ** get_address_of_PointCloudUpdated_2() { return &___PointCloudUpdated_2; }
	inline void set_PointCloudUpdated_2(Action_1_t3609124943 * value)
	{
		___PointCloudUpdated_2 = value;
		Il2CppCodeGenWriteBarrier((&___PointCloudUpdated_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRDEPTHSUBSYSTEM_T4084359858_H
#ifndef XRDEPTHSUBSYSTEMDESCRIPTOR_T2726297914_H
#define XRDEPTHSUBSYSTEMDESCRIPTOR_T2726297914_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.XRDepthSubsystemDescriptor
struct  XRDepthSubsystemDescriptor_t2726297914  : public SubsystemDescriptor_1_t1821516358
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRDEPTHSUBSYSTEMDESCRIPTOR_T2726297914_H
#ifndef XRINPUTSUBSYSTEM_T1307129943_H
#define XRINPUTSUBSYSTEM_T1307129943_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.XRInputSubsystem
struct  XRInputSubsystem_t1307129943  : public Subsystem_1_t207590349
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRINPUTSUBSYSTEM_T1307129943_H
#ifndef XRINPUTSUBSYSTEMDESCRIPTOR_T3308326959_H
#define XRINPUTSUBSYSTEMDESCRIPTOR_T3308326959_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.XRInputSubsystemDescriptor
struct  XRInputSubsystemDescriptor_t3308326959  : public SubsystemDescriptor_1_t3339253739
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRINPUTSUBSYSTEMDESCRIPTOR_T3308326959_H
#ifndef XRPLANESUBSYSTEM_T2260142932_H
#define XRPLANESUBSYSTEM_T2260142932_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.XRPlaneSubsystem
struct  XRPlaneSubsystem_t2260142932  : public Subsystem_1_t1428396990
{
public:
	// System.Action`1<UnityEngine.Experimental.XR.PlaneAddedEventArgs> UnityEngine.Experimental.XR.XRPlaneSubsystem::PlaneAdded
	Action_1_t2722643320 * ___PlaneAdded_2;
	// System.Action`1<UnityEngine.Experimental.XR.PlaneUpdatedEventArgs> UnityEngine.Experimental.XR.XRPlaneSubsystem::PlaneUpdated
	Action_1_t521953446 * ___PlaneUpdated_3;
	// System.Action`1<UnityEngine.Experimental.XR.PlaneRemovedEventArgs> UnityEngine.Experimental.XR.XRPlaneSubsystem::PlaneRemoved
	Action_1_t1739597377 * ___PlaneRemoved_4;

public:
	inline static int32_t get_offset_of_PlaneAdded_2() { return static_cast<int32_t>(offsetof(XRPlaneSubsystem_t2260142932, ___PlaneAdded_2)); }
	inline Action_1_t2722643320 * get_PlaneAdded_2() const { return ___PlaneAdded_2; }
	inline Action_1_t2722643320 ** get_address_of_PlaneAdded_2() { return &___PlaneAdded_2; }
	inline void set_PlaneAdded_2(Action_1_t2722643320 * value)
	{
		___PlaneAdded_2 = value;
		Il2CppCodeGenWriteBarrier((&___PlaneAdded_2), value);
	}

	inline static int32_t get_offset_of_PlaneUpdated_3() { return static_cast<int32_t>(offsetof(XRPlaneSubsystem_t2260142932, ___PlaneUpdated_3)); }
	inline Action_1_t521953446 * get_PlaneUpdated_3() const { return ___PlaneUpdated_3; }
	inline Action_1_t521953446 ** get_address_of_PlaneUpdated_3() { return &___PlaneUpdated_3; }
	inline void set_PlaneUpdated_3(Action_1_t521953446 * value)
	{
		___PlaneUpdated_3 = value;
		Il2CppCodeGenWriteBarrier((&___PlaneUpdated_3), value);
	}

	inline static int32_t get_offset_of_PlaneRemoved_4() { return static_cast<int32_t>(offsetof(XRPlaneSubsystem_t2260142932, ___PlaneRemoved_4)); }
	inline Action_1_t1739597377 * get_PlaneRemoved_4() const { return ___PlaneRemoved_4; }
	inline Action_1_t1739597377 ** get_address_of_PlaneRemoved_4() { return &___PlaneRemoved_4; }
	inline void set_PlaneRemoved_4(Action_1_t1739597377 * value)
	{
		___PlaneRemoved_4 = value;
		Il2CppCodeGenWriteBarrier((&___PlaneRemoved_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRPLANESUBSYSTEM_T2260142932_H
#ifndef XRPLANESUBSYSTEMDESCRIPTOR_T234166304_H
#define XRPLANESUBSYSTEMDESCRIPTOR_T234166304_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.XRPlaneSubsystemDescriptor
struct  XRPlaneSubsystemDescriptor_t234166304  : public SubsystemDescriptor_1_t4292266728
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRPLANESUBSYSTEMDESCRIPTOR_T234166304_H
#ifndef XRRAYCASTSUBSYSTEM_T2747560419_H
#define XRRAYCASTSUBSYSTEM_T2747560419_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.XRRaycastSubsystem
struct  XRRaycastSubsystem_t2747560419  : public Subsystem_1_t1129293546
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRRAYCASTSUBSYSTEM_T2747560419_H
#ifndef XRRAYCASTSUBSYSTEMDESCRIPTOR_T4230030156_H
#define XRRAYCASTSUBSYSTEMDESCRIPTOR_T4230030156_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.XRRaycastSubsystemDescriptor
struct  XRRaycastSubsystemDescriptor_t4230030156  : public SubsystemDescriptor_1_t484716919
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRRAYCASTSUBSYSTEMDESCRIPTOR_T4230030156_H
#ifndef XRREFERENCEPOINTSUBSYSTEM_T416875062_H
#define XRREFERENCEPOINTSUBSYSTEM_T416875062_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.XRReferencePointSubsystem
struct  XRReferencePointSubsystem_t416875062  : public Subsystem_1_t2853778384
{
public:
	// System.Action`1<UnityEngine.Experimental.XR.ReferencePointUpdatedEventArgs> UnityEngine.Experimental.XR.XRReferencePointSubsystem::ReferencePointUpdated
	Action_1_t2218980328 * ___ReferencePointUpdated_2;

public:
	inline static int32_t get_offset_of_ReferencePointUpdated_2() { return static_cast<int32_t>(offsetof(XRReferencePointSubsystem_t416875062, ___ReferencePointUpdated_2)); }
	inline Action_1_t2218980328 * get_ReferencePointUpdated_2() const { return ___ReferencePointUpdated_2; }
	inline Action_1_t2218980328 ** get_address_of_ReferencePointUpdated_2() { return &___ReferencePointUpdated_2; }
	inline void set_ReferencePointUpdated_2(Action_1_t2218980328 * value)
	{
		___ReferencePointUpdated_2 = value;
		Il2CppCodeGenWriteBarrier((&___ReferencePointUpdated_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRREFERENCEPOINTSUBSYSTEM_T416875062_H
#ifndef XRREFERENCEPOINTSUBSYSTEMDESCRIPTOR_T1659547698_H
#define XRREFERENCEPOINTSUBSYSTEMDESCRIPTOR_T1659547698_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.XRReferencePointSubsystemDescriptor
struct  XRReferencePointSubsystemDescriptor_t1659547698  : public SubsystemDescriptor_1_t2448998858
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRREFERENCEPOINTSUBSYSTEMDESCRIPTOR_T1659547698_H
#ifndef XRSESSIONSUBSYSTEM_T3616338244_H
#define XRSESSIONSUBSYSTEM_T3616338244_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.XRSessionSubsystem
struct  XRSessionSubsystem_t3616338244  : public Subsystem_1_t2383066733
{
public:
	// System.Action`1<UnityEngine.Experimental.XR.SessionTrackingStateChangedEventArgs> UnityEngine.Experimental.XR.XRSessionSubsystem::TrackingStateChanged
	Action_1_t2515503250 * ___TrackingStateChanged_2;

public:
	inline static int32_t get_offset_of_TrackingStateChanged_2() { return static_cast<int32_t>(offsetof(XRSessionSubsystem_t3616338244, ___TrackingStateChanged_2)); }
	inline Action_1_t2515503250 * get_TrackingStateChanged_2() const { return ___TrackingStateChanged_2; }
	inline Action_1_t2515503250 ** get_address_of_TrackingStateChanged_2() { return &___TrackingStateChanged_2; }
	inline void set_TrackingStateChanged_2(Action_1_t2515503250 * value)
	{
		___TrackingStateChanged_2 = value;
		Il2CppCodeGenWriteBarrier((&___TrackingStateChanged_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRSESSIONSUBSYSTEM_T3616338244_H
#ifndef XRSESSIONSUBSYSTEMDESCRIPTOR_T1188836047_H
#define XRSESSIONSUBSYSTEMDESCRIPTOR_T1188836047_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.XRSessionSubsystemDescriptor
struct  XRSessionSubsystemDescriptor_t1188836047  : public SubsystemDescriptor_1_t1353494744
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRSESSIONSUBSYSTEMDESCRIPTOR_T1188836047_H
#ifndef ACTION_1_T2722643320_H
#define ACTION_1_T2722643320_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Action`1<UnityEngine.Experimental.XR.PlaneAddedEventArgs>
struct  Action_1_t2722643320  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ACTION_1_T2722643320_H
#ifndef ACTION_1_T1739597377_H
#define ACTION_1_T1739597377_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Action`1<UnityEngine.Experimental.XR.PlaneRemovedEventArgs>
struct  Action_1_t1739597377  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ACTION_1_T1739597377_H
#ifndef ACTION_1_T521953446_H
#define ACTION_1_T521953446_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Action`1<UnityEngine.Experimental.XR.PlaneUpdatedEventArgs>
struct  Action_1_t521953446  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ACTION_1_T521953446_H
#ifndef ACTION_1_T2218980328_H
#define ACTION_1_T2218980328_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Action`1<UnityEngine.Experimental.XR.ReferencePointUpdatedEventArgs>
struct  Action_1_t2218980328  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ACTION_1_T2218980328_H
#ifndef CAMERA_T4157153871_H
#define CAMERA_T4157153871_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Camera
struct  Camera_t4157153871  : public Behaviour_t1437897464
{
public:

public:
};

struct Camera_t4157153871_StaticFields
{
public:
	// UnityEngine.Camera/CameraCallback UnityEngine.Camera::onPreCull
	CameraCallback_t190067161 * ___onPreCull_4;
	// UnityEngine.Camera/CameraCallback UnityEngine.Camera::onPreRender
	CameraCallback_t190067161 * ___onPreRender_5;
	// UnityEngine.Camera/CameraCallback UnityEngine.Camera::onPostRender
	CameraCallback_t190067161 * ___onPostRender_6;

public:
	inline static int32_t get_offset_of_onPreCull_4() { return static_cast<int32_t>(offsetof(Camera_t4157153871_StaticFields, ___onPreCull_4)); }
	inline CameraCallback_t190067161 * get_onPreCull_4() const { return ___onPreCull_4; }
	inline CameraCallback_t190067161 ** get_address_of_onPreCull_4() { return &___onPreCull_4; }
	inline void set_onPreCull_4(CameraCallback_t190067161 * value)
	{
		___onPreCull_4 = value;
		Il2CppCodeGenWriteBarrier((&___onPreCull_4), value);
	}

	inline static int32_t get_offset_of_onPreRender_5() { return static_cast<int32_t>(offsetof(Camera_t4157153871_StaticFields, ___onPreRender_5)); }
	inline CameraCallback_t190067161 * get_onPreRender_5() const { return ___onPreRender_5; }
	inline CameraCallback_t190067161 ** get_address_of_onPreRender_5() { return &___onPreRender_5; }
	inline void set_onPreRender_5(CameraCallback_t190067161 * value)
	{
		___onPreRender_5 = value;
		Il2CppCodeGenWriteBarrier((&___onPreRender_5), value);
	}

	inline static int32_t get_offset_of_onPostRender_6() { return static_cast<int32_t>(offsetof(Camera_t4157153871_StaticFields, ___onPostRender_6)); }
	inline CameraCallback_t190067161 * get_onPostRender_6() const { return ___onPostRender_6; }
	inline CameraCallback_t190067161 ** get_address_of_onPostRender_6() { return &___onPostRender_6; }
	inline void set_onPostRender_6(CameraCallback_t190067161 * value)
	{
		___onPostRender_6 = value;
		Il2CppCodeGenWriteBarrier((&___onPostRender_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CAMERA_T4157153871_H


// System.Void System.Collections.Generic.List`1<System.Object>::Add(!0)
extern "C" IL2CPP_METHOD_ATTR void List_1_Add_m3338814081_gshared (List_1_t257213610 * __this, RuntimeObject * p0, const RuntimeMethod* method);
// System.Collections.Generic.List`1/Enumerator<!0> System.Collections.Generic.List`1<System.Object>::GetEnumerator()
extern "C" IL2CPP_METHOD_ATTR Enumerator_t2146457487  List_1_GetEnumerator_m2930774921_gshared (List_1_t257213610 * __this, const RuntimeMethod* method);
// !0 System.Collections.Generic.List`1/Enumerator<System.Object>::get_Current()
extern "C" IL2CPP_METHOD_ATTR RuntimeObject * Enumerator_get_Current_m470245444_gshared (Enumerator_t2146457487 * __this, const RuntimeMethod* method);
// System.Boolean System.Collections.Generic.List`1/Enumerator<System.Object>::MoveNext()
extern "C" IL2CPP_METHOD_ATTR bool Enumerator_MoveNext_m2142368520_gshared (Enumerator_t2146457487 * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1/Enumerator<System.Object>::Dispose()
extern "C" IL2CPP_METHOD_ATTR void Enumerator_Dispose_m3007748546_gshared (Enumerator_t2146457487 * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<System.Object>::Clear()
extern "C" IL2CPP_METHOD_ATTR void List_1_Clear_m3697625829_gshared (List_1_t257213610 * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<System.Object>::.ctor()
extern "C" IL2CPP_METHOD_ATTR void List_1__ctor_m2321703786_gshared (List_1_t257213610 * __this, const RuntimeMethod* method);
// System.Int32 System.Collections.Generic.List`1<System.Object>::get_Count()
extern "C" IL2CPP_METHOD_ATTR int32_t List_1_get_Count_m2934127733_gshared (List_1_t257213610 * __this, const RuntimeMethod* method);
// !0 System.Collections.Generic.List`1<System.Object>::get_Item(System.Int32)
extern "C" IL2CPP_METHOD_ATTR RuntimeObject * List_1_get_Item_m2287542950_gshared (List_1_t257213610 * __this, int32_t p0, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<System.Object>::RemoveAt(System.Int32)
extern "C" IL2CPP_METHOD_ATTR void List_1_RemoveAt_m2730968292_gshared (List_1_t257213610 * __this, int32_t p0, const RuntimeMethod* method);
// System.Void System.Action`1<UnityEngine.Experimental.XR.FrameReceivedEventArgs>::Invoke(!0)
extern "C" IL2CPP_METHOD_ATTR void Action_1_Invoke_m2953615518_gshared (Action_1_t2760547698 * __this, FrameReceivedEventArgs_t2588080103  p0, const RuntimeMethod* method);
// System.Void System.Action`1<UnityEngine.Experimental.XR.PointCloudUpdatedEventArgs>::Invoke(!0)
extern "C" IL2CPP_METHOD_ATTR void Action_1_Invoke_m3012248422_gshared (Action_1_t3609124943 * __this, PointCloudUpdatedEventArgs_t3436657348  p0, const RuntimeMethod* method);
// System.Void System.Action`1<UnityEngine.Experimental.XR.PlaneAddedEventArgs>::Invoke(!0)
extern "C" IL2CPP_METHOD_ATTR void Action_1_Invoke_m3662407658_gshared (Action_1_t2722643320 * __this, PlaneAddedEventArgs_t2550175725  p0, const RuntimeMethod* method);
// System.Void System.Action`1<UnityEngine.Experimental.XR.PlaneUpdatedEventArgs>::Invoke(!0)
extern "C" IL2CPP_METHOD_ATTR void Action_1_Invoke_m4140516850_gshared (Action_1_t521953446 * __this, PlaneUpdatedEventArgs_t349485851  p0, const RuntimeMethod* method);
// System.Void System.Action`1<UnityEngine.Experimental.XR.PlaneRemovedEventArgs>::Invoke(!0)
extern "C" IL2CPP_METHOD_ATTR void Action_1_Invoke_m316788244_gshared (Action_1_t1739597377 * __this, PlaneRemovedEventArgs_t1567129782  p0, const RuntimeMethod* method);
// System.Void System.Action`1<UnityEngine.Experimental.XR.ReferencePointUpdatedEventArgs>::Invoke(!0)
extern "C" IL2CPP_METHOD_ATTR void Action_1_Invoke_m1143137826_gshared (Action_1_t2218980328 * __this, ReferencePointUpdatedEventArgs_t2046512733  p0, const RuntimeMethod* method);
// System.Void System.Action`1<UnityEngine.Experimental.XR.SessionTrackingStateChangedEventArgs>::Invoke(!0)
extern "C" IL2CPP_METHOD_ATTR void Action_1_Invoke_m3768946330_gshared (Action_1_t2515503250 * __this, SessionTrackingStateChangedEventArgs_t2343035655  p0, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<UnityEngine.XR.XRNodeState>::Clear()
extern "C" IL2CPP_METHOD_ATTR void List_1_Clear_m1794174222_gshared (List_1_t929709876 * __this, const RuntimeMethod* method);
// System.Void System.Action`1<UnityEngine.XR.XRNodeState>::Invoke(!0)
extern "C" IL2CPP_METHOD_ATTR void Action_1_Invoke_m1458665122_gshared (Action_1_t3925070025 * __this, XRNodeState_t3752602430  p0, const RuntimeMethod* method);
// System.Boolean UnityEngine.XR.XRNodeState::TryGet<UnityEngine.Vector3>(T,UnityEngine.XR.AvailableTrackingData,T&)
extern "C" IL2CPP_METHOD_ATTR bool XRNodeState_TryGet_TisVector3_t3722313464_m270903620_gshared (XRNodeState_t3752602430 * __this, Vector3_t3722313464  ___inValue0, int32_t ___availabilityFlag1, Vector3_t3722313464 * ___outValue2, const RuntimeMethod* method);
// System.Boolean UnityEngine.XR.XRNodeState::TryGet<UnityEngine.Quaternion>(T,UnityEngine.XR.AvailableTrackingData,T&)
extern "C" IL2CPP_METHOD_ATTR bool XRNodeState_TryGet_TisQuaternion_t2301928331_m1353060540_gshared (XRNodeState_t3752602430 * __this, Quaternion_t2301928331  ___inValue0, int32_t ___availabilityFlag1, Quaternion_t2301928331 * ___outValue2, const RuntimeMethod* method);

// System.Void System.Collections.Generic.List`1<UnityEngine.Experimental.ISubsystemDescriptorImpl>::Add(!0)
inline void List_1_Add_m3860418725 (List_1_t60503245 * __this, RuntimeObject* p0, const RuntimeMethod* method)
{
	((  void (*) (List_1_t60503245 *, RuntimeObject*, const RuntimeMethod*))List_1_Add_m3338814081_gshared)(__this, p0, method);
}
// System.Collections.Generic.List`1/Enumerator<!0> System.Collections.Generic.List`1<UnityEngine.Experimental.ISubsystemDescriptorImpl>::GetEnumerator()
inline Enumerator_t1949747122  List_1_GetEnumerator_m2059771147 (List_1_t60503245 * __this, const RuntimeMethod* method)
{
	return ((  Enumerator_t1949747122  (*) (List_1_t60503245 *, const RuntimeMethod*))List_1_GetEnumerator_m2930774921_gshared)(__this, method);
}
// !0 System.Collections.Generic.List`1/Enumerator<UnityEngine.Experimental.ISubsystemDescriptorImpl>::get_Current()
inline RuntimeObject* Enumerator_get_Current_m1367904766 (Enumerator_t1949747122 * __this, const RuntimeMethod* method)
{
	return ((  RuntimeObject* (*) (Enumerator_t1949747122 *, const RuntimeMethod*))Enumerator_get_Current_m470245444_gshared)(__this, method);
}
// System.Boolean System.Collections.Generic.List`1/Enumerator<UnityEngine.Experimental.ISubsystemDescriptorImpl>::MoveNext()
inline bool Enumerator_MoveNext_m3572286872 (Enumerator_t1949747122 * __this, const RuntimeMethod* method)
{
	return ((  bool (*) (Enumerator_t1949747122 *, const RuntimeMethod*))Enumerator_MoveNext_m2142368520_gshared)(__this, method);
}
// System.Void System.Collections.Generic.List`1/Enumerator<UnityEngine.Experimental.ISubsystemDescriptorImpl>::Dispose()
inline void Enumerator_Dispose_m2979251017 (Enumerator_t1949747122 * __this, const RuntimeMethod* method)
{
	((  void (*) (Enumerator_t1949747122 *, const RuntimeMethod*))Enumerator_Dispose_m3007748546_gshared)(__this, method);
}
// System.Void System.Collections.Generic.List`1<UnityEngine.Experimental.ISubsystemDescriptorImpl>::Clear()
inline void List_1_Clear_m2804938920 (List_1_t60503245 * __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_t60503245 *, const RuntimeMethod*))List_1_Clear_m3697625829_gshared)(__this, method);
}
// System.Void System.Collections.Generic.List`1<UnityEngine.Experimental.ISubsystemDescriptorImpl>::.ctor()
inline void List_1__ctor_m3747657077 (List_1_t60503245 * __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_t60503245 *, const RuntimeMethod*))List_1__ctor_m2321703786_gshared)(__this, method);
}
// System.Void UnityEngine.Experimental.Subsystem::SetHandle(UnityEngine.Experimental.Subsystem)
extern "C" IL2CPP_METHOD_ATTR void Subsystem_SetHandle_m3808293838 (Subsystem_t89723475 * __this, Subsystem_t89723475 * ___inst0, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<UnityEngine.Experimental.Subsystem>::Add(!0)
inline void List_1_Add_m2793820062 (List_1_t1561798217 * __this, Subsystem_t89723475 * p0, const RuntimeMethod* method)
{
	((  void (*) (List_1_t1561798217 *, Subsystem_t89723475 *, const RuntimeMethod*))List_1_Add_m3338814081_gshared)(__this, p0, method);
}
// System.Collections.Generic.List`1/Enumerator<!0> System.Collections.Generic.List`1<UnityEngine.Experimental.Subsystem>::GetEnumerator()
inline Enumerator_t3451042094  List_1_GetEnumerator_m489737270 (List_1_t1561798217 * __this, const RuntimeMethod* method)
{
	return ((  Enumerator_t3451042094  (*) (List_1_t1561798217 *, const RuntimeMethod*))List_1_GetEnumerator_m2930774921_gshared)(__this, method);
}
// !0 System.Collections.Generic.List`1/Enumerator<UnityEngine.Experimental.Subsystem>::get_Current()
inline Subsystem_t89723475 * Enumerator_get_Current_m4233439720 (Enumerator_t3451042094 * __this, const RuntimeMethod* method)
{
	return ((  Subsystem_t89723475 * (*) (Enumerator_t3451042094 *, const RuntimeMethod*))Enumerator_get_Current_m470245444_gshared)(__this, method);
}
// System.Boolean System.Collections.Generic.List`1/Enumerator<UnityEngine.Experimental.Subsystem>::MoveNext()
inline bool Enumerator_MoveNext_m2084212791 (Enumerator_t3451042094 * __this, const RuntimeMethod* method)
{
	return ((  bool (*) (Enumerator_t3451042094 *, const RuntimeMethod*))Enumerator_MoveNext_m2142368520_gshared)(__this, method);
}
// System.Void System.Collections.Generic.List`1/Enumerator<UnityEngine.Experimental.Subsystem>::Dispose()
inline void Enumerator_Dispose_m4163083902 (Enumerator_t3451042094 * __this, const RuntimeMethod* method)
{
	((  void (*) (Enumerator_t3451042094 *, const RuntimeMethod*))Enumerator_Dispose_m3007748546_gshared)(__this, method);
}
// System.Void System.Collections.Generic.List`1<UnityEngine.Experimental.Subsystem>::Clear()
inline void List_1_Clear_m2449803944 (List_1_t1561798217 * __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_t1561798217 *, const RuntimeMethod*))List_1_Clear_m3697625829_gshared)(__this, method);
}
// System.Int32 System.Collections.Generic.List`1<UnityEngine.Experimental.Subsystem>::get_Count()
inline int32_t List_1_get_Count_m4144085239 (List_1_t1561798217 * __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (List_1_t1561798217 *, const RuntimeMethod*))List_1_get_Count_m2934127733_gshared)(__this, method);
}
// !0 System.Collections.Generic.List`1<UnityEngine.Experimental.Subsystem>::get_Item(System.Int32)
inline Subsystem_t89723475 * List_1_get_Item_m4223061980 (List_1_t1561798217 * __this, int32_t p0, const RuntimeMethod* method)
{
	return ((  Subsystem_t89723475 * (*) (List_1_t1561798217 *, int32_t, const RuntimeMethod*))List_1_get_Item_m2287542950_gshared)(__this, p0, method);
}
// System.Boolean System.IntPtr::op_Equality(System.IntPtr,System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR bool IntPtr_op_Equality_m408849716 (RuntimeObject * __this /* static, unused */, intptr_t p0, intptr_t p1, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<UnityEngine.Experimental.Subsystem>::RemoveAt(System.Int32)
inline void List_1_RemoveAt_m1171746181 (List_1_t1561798217 * __this, int32_t p0, const RuntimeMethod* method)
{
	((  void (*) (List_1_t1561798217 *, int32_t, const RuntimeMethod*))List_1_RemoveAt_m2730968292_gshared)(__this, p0, method);
}
// System.Void System.Collections.Generic.List`1<UnityEngine.Experimental.Subsystem>::.ctor()
inline void List_1__ctor_m910085292 (List_1_t1561798217 * __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_t1561798217 *, const RuntimeMethod*))List_1__ctor_m2321703786_gshared)(__this, method);
}
// System.Void UnityEngine.Experimental.Internal_SubsystemInstances::Internal_RemoveInstanceByPtr(System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR void Internal_SubsystemInstances_Internal_RemoveInstanceByPtr_m3992065214 (RuntimeObject * __this /* static, unused */, intptr_t ___ptr0, const RuntimeMethod* method);
// System.Void UnityEngine.Experimental.SubsystemManager::DestroyInstance_Internal(System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR void SubsystemManager_DestroyInstance_Internal_m3781448766 (RuntimeObject * __this /* static, unused */, intptr_t ___instancePtr0, const RuntimeMethod* method);
// System.String UnityEngine.Experimental.Internal_SubsystemDescriptors::GetId(System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR String_t* Internal_SubsystemDescriptors_GetId_m3581253800 (RuntimeObject * __this /* static, unused */, intptr_t ___descriptorPtr0, const RuntimeMethod* method);
// System.Void UnityEngine.Experimental.SubsystemManager::StaticConstructScriptingClassMap()
extern "C" IL2CPP_METHOD_ATTR void SubsystemManager_StaticConstructScriptingClassMap_m3263645951 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method);
// UnityEngine.Experimental.XR.TrackableId UnityEngine.Experimental.XR.BoundedPlane::get_Id()
extern "C" IL2CPP_METHOD_ATTR TrackableId_t1251031970  BoundedPlane_get_Id_m4119012809 (BoundedPlane_t1317492334 * __this, const RuntimeMethod* method);
// UnityEngine.Experimental.XR.TrackableId UnityEngine.Experimental.XR.BoundedPlane::get_SubsumedById()
extern "C" IL2CPP_METHOD_ATTR TrackableId_t1251031970  BoundedPlane_get_SubsumedById_m1556489410 (BoundedPlane_t1317492334 * __this, const RuntimeMethod* method);
// UnityEngine.Pose UnityEngine.Experimental.XR.BoundedPlane::get_Pose()
extern "C" IL2CPP_METHOD_ATTR Pose_t545244865  BoundedPlane_get_Pose_m820068544 (BoundedPlane_t1317492334 * __this, const RuntimeMethod* method);
// UnityEngine.Vector3 UnityEngine.Experimental.XR.BoundedPlane::get_Center()
extern "C" IL2CPP_METHOD_ATTR Vector3_t3722313464  BoundedPlane_get_Center_m3129244743 (BoundedPlane_t1317492334 * __this, const RuntimeMethod* method);
// UnityEngine.Vector3 UnityEngine.Pose::get_up()
extern "C" IL2CPP_METHOD_ATTR Vector3_t3722313464  Pose_get_up_m2443616131 (Pose_t545244865 * __this, const RuntimeMethod* method);
// UnityEngine.Vector3 UnityEngine.Experimental.XR.BoundedPlane::get_Normal()
extern "C" IL2CPP_METHOD_ATTR Vector3_t3722313464  BoundedPlane_get_Normal_m1663591676 (BoundedPlane_t1317492334 * __this, const RuntimeMethod* method);
// System.Void System.ArgumentNullException::.ctor(System.String)
extern "C" IL2CPP_METHOD_ATTR void ArgumentNullException__ctor_m1170824041 (ArgumentNullException_t1615371798 * __this, String_t* p0, const RuntimeMethod* method);
// System.Boolean UnityEngine.Experimental.XR.BoundedPlane::Internal_GetBoundaryAsList(System.UInt32,UnityEngine.Experimental.XR.TrackableId,System.Collections.Generic.List`1<UnityEngine.Vector3>)
extern "C" IL2CPP_METHOD_ATTR bool BoundedPlane_Internal_GetBoundaryAsList_m50365802 (RuntimeObject * __this /* static, unused */, uint32_t ___instanceId0, TrackableId_t1251031970  ___id1, List_1_t899420910 * ___boundaryOut2, const RuntimeMethod* method);
// System.Boolean UnityEngine.Experimental.XR.BoundedPlane::TryGetBoundary(System.Collections.Generic.List`1<UnityEngine.Vector3>)
extern "C" IL2CPP_METHOD_ATTR bool BoundedPlane_TryGetBoundary_m3909741008 (BoundedPlane_t1317492334 * __this, List_1_t899420910 * ___boundaryOut0, const RuntimeMethod* method);
// System.Boolean UnityEngine.Experimental.XR.BoundedPlane::Internal_GetBoundaryAsList_Injected(System.UInt32,UnityEngine.Experimental.XR.TrackableId&,System.Collections.Generic.List`1<UnityEngine.Vector3>)
extern "C" IL2CPP_METHOD_ATTR bool BoundedPlane_Internal_GetBoundaryAsList_Injected_m2590883096 (RuntimeObject * __this /* static, unused */, uint32_t ___instanceId0, TrackableId_t1251031970 * ___id1, List_1_t899420910 * ___boundaryOut2, const RuntimeMethod* method);
// System.Void UnityEngine.Experimental.XR.PlaneAddedEventArgs::set_PlaneSubsystem(UnityEngine.Experimental.XR.XRPlaneSubsystem)
extern "C" IL2CPP_METHOD_ATTR void PlaneAddedEventArgs_set_PlaneSubsystem_m3627276178 (PlaneAddedEventArgs_t2550175725 * __this, XRPlaneSubsystem_t2260142932 * ___value0, const RuntimeMethod* method);
// UnityEngine.Experimental.XR.BoundedPlane UnityEngine.Experimental.XR.PlaneAddedEventArgs::get_Plane()
extern "C" IL2CPP_METHOD_ATTR BoundedPlane_t1317492334  PlaneAddedEventArgs_get_Plane_m1121979519 (PlaneAddedEventArgs_t2550175725 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.Experimental.XR.PlaneAddedEventArgs::set_Plane(UnityEngine.Experimental.XR.BoundedPlane)
extern "C" IL2CPP_METHOD_ATTR void PlaneAddedEventArgs_set_Plane_m3532199823 (PlaneAddedEventArgs_t2550175725 * __this, BoundedPlane_t1317492334  ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.Experimental.XR.PlaneRemovedEventArgs::set_PlaneSubsystem(UnityEngine.Experimental.XR.XRPlaneSubsystem)
extern "C" IL2CPP_METHOD_ATTR void PlaneRemovedEventArgs_set_PlaneSubsystem_m2373342326 (PlaneRemovedEventArgs_t1567129782 * __this, XRPlaneSubsystem_t2260142932 * ___value0, const RuntimeMethod* method);
// UnityEngine.Experimental.XR.BoundedPlane UnityEngine.Experimental.XR.PlaneRemovedEventArgs::get_Plane()
extern "C" IL2CPP_METHOD_ATTR BoundedPlane_t1317492334  PlaneRemovedEventArgs_get_Plane_m1826377031 (PlaneRemovedEventArgs_t1567129782 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.Experimental.XR.PlaneRemovedEventArgs::set_Plane(UnityEngine.Experimental.XR.BoundedPlane)
extern "C" IL2CPP_METHOD_ATTR void PlaneRemovedEventArgs_set_Plane_m290598833 (PlaneRemovedEventArgs_t1567129782 * __this, BoundedPlane_t1317492334  ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.Experimental.XR.PlaneUpdatedEventArgs::set_PlaneSubsystem(UnityEngine.Experimental.XR.XRPlaneSubsystem)
extern "C" IL2CPP_METHOD_ATTR void PlaneUpdatedEventArgs_set_PlaneSubsystem_m79632840 (PlaneUpdatedEventArgs_t349485851 * __this, XRPlaneSubsystem_t2260142932 * ___value0, const RuntimeMethod* method);
// UnityEngine.Experimental.XR.BoundedPlane UnityEngine.Experimental.XR.PlaneUpdatedEventArgs::get_Plane()
extern "C" IL2CPP_METHOD_ATTR BoundedPlane_t1317492334  PlaneUpdatedEventArgs_get_Plane_m4053759216 (PlaneUpdatedEventArgs_t349485851 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.Experimental.XR.PlaneUpdatedEventArgs::set_Plane(UnityEngine.Experimental.XR.BoundedPlane)
extern "C" IL2CPP_METHOD_ATTR void PlaneUpdatedEventArgs_set_Plane_m3296874754 (PlaneUpdatedEventArgs_t349485851 * __this, BoundedPlane_t1317492334  ___value0, const RuntimeMethod* method);
// UnityEngine.Experimental.XR.TrackableId UnityEngine.Experimental.XR.ReferencePoint::get_Id()
extern "C" IL2CPP_METHOD_ATTR TrackableId_t1251031970  ReferencePoint_get_Id_m2943140397 (ReferencePoint_t394942483 * __this, const RuntimeMethod* method);
// UnityEngine.Experimental.XR.TrackingState UnityEngine.Experimental.XR.ReferencePoint::get_TrackingState()
extern "C" IL2CPP_METHOD_ATTR int32_t ReferencePoint_get_TrackingState_m1298782521 (ReferencePoint_t394942483 * __this, const RuntimeMethod* method);
// UnityEngine.Pose UnityEngine.Experimental.XR.ReferencePoint::get_Pose()
extern "C" IL2CPP_METHOD_ATTR Pose_t545244865  ReferencePoint_get_Pose_m3423701085 (ReferencePoint_t394942483 * __this, const RuntimeMethod* method);
// UnityEngine.Experimental.XR.ReferencePoint UnityEngine.Experimental.XR.ReferencePointUpdatedEventArgs::get_ReferencePoint()
extern "C" IL2CPP_METHOD_ATTR ReferencePoint_t394942483  ReferencePointUpdatedEventArgs_get_ReferencePoint_m598134072 (ReferencePointUpdatedEventArgs_t2046512733 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.Experimental.XR.ReferencePointUpdatedEventArgs::set_ReferencePoint(UnityEngine.Experimental.XR.ReferencePoint)
extern "C" IL2CPP_METHOD_ATTR void ReferencePointUpdatedEventArgs_set_ReferencePoint_m2108838300 (ReferencePointUpdatedEventArgs_t2046512733 * __this, ReferencePoint_t394942483  ___value0, const RuntimeMethod* method);
// UnityEngine.Experimental.XR.TrackingState UnityEngine.Experimental.XR.ReferencePointUpdatedEventArgs::get_PreviousTrackingState()
extern "C" IL2CPP_METHOD_ATTR int32_t ReferencePointUpdatedEventArgs_get_PreviousTrackingState_m4262564055 (ReferencePointUpdatedEventArgs_t2046512733 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.Experimental.XR.ReferencePointUpdatedEventArgs::set_PreviousTrackingState(UnityEngine.Experimental.XR.TrackingState)
extern "C" IL2CPP_METHOD_ATTR void ReferencePointUpdatedEventArgs_set_PreviousTrackingState_m363545448 (ReferencePointUpdatedEventArgs_t2046512733 * __this, int32_t ___value0, const RuntimeMethod* method);
// UnityEngine.Pose UnityEngine.Experimental.XR.ReferencePointUpdatedEventArgs::get_PreviousPose()
extern "C" IL2CPP_METHOD_ATTR Pose_t545244865  ReferencePointUpdatedEventArgs_get_PreviousPose_m4125863928 (ReferencePointUpdatedEventArgs_t2046512733 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.Experimental.XR.ReferencePointUpdatedEventArgs::set_PreviousPose(UnityEngine.Pose)
extern "C" IL2CPP_METHOD_ATTR void ReferencePointUpdatedEventArgs_set_PreviousPose_m2838622129 (ReferencePointUpdatedEventArgs_t2046512733 * __this, Pose_t545244865  ___value0, const RuntimeMethod* method);
// UnityEngine.Experimental.XR.TrackingState UnityEngine.Experimental.XR.SessionTrackingStateChangedEventArgs::get_NewState()
extern "C" IL2CPP_METHOD_ATTR int32_t SessionTrackingStateChangedEventArgs_get_NewState_m1657962755 (SessionTrackingStateChangedEventArgs_t2343035655 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.Experimental.XR.SessionTrackingStateChangedEventArgs::set_NewState(UnityEngine.Experimental.XR.TrackingState)
extern "C" IL2CPP_METHOD_ATTR void SessionTrackingStateChangedEventArgs_set_NewState_m3890790011 (SessionTrackingStateChangedEventArgs_t2343035655 * __this, int32_t ___value0, const RuntimeMethod* method);
// System.String System.UInt64::ToString(System.String)
extern "C" IL2CPP_METHOD_ATTR String_t* UInt64_ToString_m2177233542 (uint64_t* __this, String_t* p0, const RuntimeMethod* method);
// System.String System.String::Format(System.String,System.Object,System.Object)
extern "C" IL2CPP_METHOD_ATTR String_t* String_Format_m2556382932 (RuntimeObject * __this /* static, unused */, String_t* p0, RuntimeObject * p1, RuntimeObject * p2, const RuntimeMethod* method);
// System.String UnityEngine.Experimental.XR.TrackableId::ToString()
extern "C" IL2CPP_METHOD_ATTR String_t* TrackableId_ToString_m2456781735 (TrackableId_t1251031970 * __this, const RuntimeMethod* method);
// System.Int32 System.UInt64::GetHashCode()
extern "C" IL2CPP_METHOD_ATTR int32_t UInt64_GetHashCode_m4209760355 (uint64_t* __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.Experimental.XR.TrackableId::GetHashCode()
extern "C" IL2CPP_METHOD_ATTR int32_t TrackableId_GetHashCode_m3350007337 (TrackableId_t1251031970 * __this, const RuntimeMethod* method);
// System.Boolean UnityEngine.Experimental.XR.TrackableId::Equals(UnityEngine.Experimental.XR.TrackableId)
extern "C" IL2CPP_METHOD_ATTR bool TrackableId_Equals_m902745601 (TrackableId_t1251031970 * __this, TrackableId_t1251031970  ___other0, const RuntimeMethod* method);
// System.Boolean UnityEngine.Experimental.XR.TrackableId::Equals(System.Object)
extern "C" IL2CPP_METHOD_ATTR bool TrackableId_Equals_m1354170007 (TrackableId_t1251031970 * __this, RuntimeObject * ___obj0, const RuntimeMethod* method);
// System.Boolean UnityEngine.Experimental.XR.XRCameraSubsystem::Internal_TryGetShaderName(System.String&)
extern "C" IL2CPP_METHOD_ATTR bool XRCameraSubsystem_Internal_TryGetShaderName_m650882322 (XRCameraSubsystem_t4195795144 * __this, String_t** ___shaderName0, const RuntimeMethod* method);
// System.Delegate System.Delegate::Combine(System.Delegate,System.Delegate)
extern "C" IL2CPP_METHOD_ATTR Delegate_t1188392813 * Delegate_Combine_m1859655160 (RuntimeObject * __this /* static, unused */, Delegate_t1188392813 * p0, Delegate_t1188392813 * p1, const RuntimeMethod* method);
// System.Delegate System.Delegate::Remove(System.Delegate,System.Delegate)
extern "C" IL2CPP_METHOD_ATTR Delegate_t1188392813 * Delegate_Remove_m334097152 (RuntimeObject * __this /* static, unused */, Delegate_t1188392813 * p0, Delegate_t1188392813 * p1, const RuntimeMethod* method);
// System.Void System.Action`1<UnityEngine.Experimental.XR.FrameReceivedEventArgs>::Invoke(!0)
inline void Action_1_Invoke_m2953615518 (Action_1_t2760547698 * __this, FrameReceivedEventArgs_t2588080103  p0, const RuntimeMethod* method)
{
	((  void (*) (Action_1_t2760547698 *, FrameReceivedEventArgs_t2588080103 , const RuntimeMethod*))Action_1_Invoke_m2953615518_gshared)(__this, p0, method);
}
// System.Void UnityEngine.Experimental.XR.XRDepthSubsystem::Internal_GetPointCloudPointsAsList(System.Collections.Generic.List`1<UnityEngine.Vector3>)
extern "C" IL2CPP_METHOD_ATTR void XRDepthSubsystem_Internal_GetPointCloudPointsAsList_m1867663777 (XRDepthSubsystem_t4084359858 * __this, List_1_t899420910 * ___pointsOut0, const RuntimeMethod* method);
// System.Void UnityEngine.Experimental.XR.XRDepthSubsystem::Internal_GetPointCloudConfidenceAsList(System.Collections.Generic.List`1<System.Single>)
extern "C" IL2CPP_METHOD_ATTR void XRDepthSubsystem_Internal_GetPointCloudConfidenceAsList_m2782565433 (XRDepthSubsystem_t4084359858 * __this, List_1_t2869341516 * ___confidenceOut0, const RuntimeMethod* method);
// System.Void System.Action`1<UnityEngine.Experimental.XR.PointCloudUpdatedEventArgs>::Invoke(!0)
inline void Action_1_Invoke_m3012248422 (Action_1_t3609124943 * __this, PointCloudUpdatedEventArgs_t3436657348  p0, const RuntimeMethod* method)
{
	((  void (*) (Action_1_t3609124943 *, PointCloudUpdatedEventArgs_t3436657348 , const RuntimeMethod*))Action_1_Invoke_m3012248422_gshared)(__this, p0, method);
}
// System.Void UnityEngine.Experimental.XR.XRPlaneSubsystem::GetAllPlanesAsList(System.Collections.Generic.List`1<UnityEngine.Experimental.XR.BoundedPlane>)
extern "C" IL2CPP_METHOD_ATTR void XRPlaneSubsystem_GetAllPlanesAsList_m575400322 (XRPlaneSubsystem_t2260142932 * __this, List_1_t2789567076 * ___planes0, const RuntimeMethod* method);
// System.Void System.Action`1<UnityEngine.Experimental.XR.PlaneAddedEventArgs>::Invoke(!0)
inline void Action_1_Invoke_m3662407658 (Action_1_t2722643320 * __this, PlaneAddedEventArgs_t2550175725  p0, const RuntimeMethod* method)
{
	((  void (*) (Action_1_t2722643320 *, PlaneAddedEventArgs_t2550175725 , const RuntimeMethod*))Action_1_Invoke_m3662407658_gshared)(__this, p0, method);
}
// System.Void System.Action`1<UnityEngine.Experimental.XR.PlaneUpdatedEventArgs>::Invoke(!0)
inline void Action_1_Invoke_m4140516850 (Action_1_t521953446 * __this, PlaneUpdatedEventArgs_t349485851  p0, const RuntimeMethod* method)
{
	((  void (*) (Action_1_t521953446 *, PlaneUpdatedEventArgs_t349485851 , const RuntimeMethod*))Action_1_Invoke_m4140516850_gshared)(__this, p0, method);
}
// System.Void System.Action`1<UnityEngine.Experimental.XR.PlaneRemovedEventArgs>::Invoke(!0)
inline void Action_1_Invoke_m316788244 (Action_1_t1739597377 * __this, PlaneRemovedEventArgs_t1567129782  p0, const RuntimeMethod* method)
{
	((  void (*) (Action_1_t1739597377 *, PlaneRemovedEventArgs_t1567129782 , const RuntimeMethod*))Action_1_Invoke_m316788244_gshared)(__this, p0, method);
}
// UnityEngine.Experimental.XR.TrackableId UnityEngine.Experimental.XR.XRRaycastHit::get_TrackableId()
extern "C" IL2CPP_METHOD_ATTR TrackableId_t1251031970  XRRaycastHit_get_TrackableId_m3341694854 (XRRaycastHit_t2370805074 * __this, const RuntimeMethod* method);
// UnityEngine.Pose UnityEngine.Experimental.XR.XRRaycastHit::get_Pose()
extern "C" IL2CPP_METHOD_ATTR Pose_t545244865  XRRaycastHit_get_Pose_m3198015053 (XRRaycastHit_t2370805074 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.Experimental.XR.XRRaycastHit::set_Pose(UnityEngine.Pose)
extern "C" IL2CPP_METHOD_ATTR void XRRaycastHit_set_Pose_m4202558867 (XRRaycastHit_t2370805074 * __this, Pose_t545244865  ___value0, const RuntimeMethod* method);
// System.Single UnityEngine.Experimental.XR.XRRaycastHit::get_Distance()
extern "C" IL2CPP_METHOD_ATTR float XRRaycastHit_get_Distance_m2947783709 (XRRaycastHit_t2370805074 * __this, const RuntimeMethod* method);
// UnityEngine.Experimental.XR.TrackableType UnityEngine.Experimental.XR.XRRaycastHit::get_HitType()
extern "C" IL2CPP_METHOD_ATTR int32_t XRRaycastHit_get_HitType_m3113473311 (XRRaycastHit_t2370805074 * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.Screen::get_width()
extern "C" IL2CPP_METHOD_ATTR int32_t Screen_get_width_m345039817 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method);
// System.Single UnityEngine.Mathf::Clamp01(System.Single)
extern "C" IL2CPP_METHOD_ATTR float Mathf_Clamp01_m56433566 (RuntimeObject * __this /* static, unused */, float p0, const RuntimeMethod* method);
// System.Int32 UnityEngine.Screen::get_height()
extern "C" IL2CPP_METHOD_ATTR int32_t Screen_get_height_m1623532518 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method);
// System.Boolean UnityEngine.Experimental.XR.XRRaycastSubsystem::Internal_ScreenRaycastAsList(System.Single,System.Single,UnityEngine.Experimental.XR.TrackableType,System.Collections.Generic.List`1<UnityEngine.Experimental.XR.XRRaycastHit>)
extern "C" IL2CPP_METHOD_ATTR bool XRRaycastSubsystem_Internal_ScreenRaycastAsList_m964488973 (XRRaycastSubsystem_t2747560419 * __this, float ___screenX0, float ___screenY1, int32_t ___hitMask2, List_1_t3842879816 * ___hitResultsOut3, const RuntimeMethod* method);
// System.Void UnityEngine.Experimental.XR.XRRaycastSubsystem::Internal_RaycastAsList(UnityEngine.Ray,System.Single,System.IntPtr,System.IntPtr,UnityEngine.Experimental.XR.TrackableType,System.Collections.Generic.List`1<UnityEngine.Experimental.XR.XRRaycastHit>)
extern "C" IL2CPP_METHOD_ATTR void XRRaycastSubsystem_Internal_RaycastAsList_m2597254506 (RuntimeObject * __this /* static, unused */, Ray_t3785851493  ___ray0, float ___pointCloudRaycastAngleInDegrees1, intptr_t ___depthSubsystem2, intptr_t ___planeSubsystem3, int32_t ___trackableTypeMask4, List_1_t3842879816 * ___hitResultsOut5, const RuntimeMethod* method);
// System.Void UnityEngine.Experimental.XR.XRRaycastSubsystem::Internal_RaycastAsList_Injected(UnityEngine.Ray&,System.Single,System.IntPtr,System.IntPtr,UnityEngine.Experimental.XR.TrackableType,System.Collections.Generic.List`1<UnityEngine.Experimental.XR.XRRaycastHit>)
extern "C" IL2CPP_METHOD_ATTR void XRRaycastSubsystem_Internal_RaycastAsList_Injected_m1278429163 (RuntimeObject * __this /* static, unused */, Ray_t3785851493 * ___ray0, float ___pointCloudRaycastAngleInDegrees1, intptr_t ___depthSubsystem2, intptr_t ___planeSubsystem3, int32_t ___trackableTypeMask4, List_1_t3842879816 * ___hitResultsOut5, const RuntimeMethod* method);
// System.Boolean UnityEngine.Experimental.XR.XRReferencePointSubsystem::TryAddReferencePoint_Injected(UnityEngine.Vector3&,UnityEngine.Quaternion&,UnityEngine.Experimental.XR.TrackableId&)
extern "C" IL2CPP_METHOD_ATTR bool XRReferencePointSubsystem_TryAddReferencePoint_Injected_m620548233 (XRReferencePointSubsystem_t416875062 * __this, Vector3_t3722313464 * ___position0, Quaternion_t2301928331 * ___rotation1, TrackableId_t1251031970 * ___referencePointId2, const RuntimeMethod* method);
// System.Boolean UnityEngine.Experimental.XR.XRReferencePointSubsystem::TryRemoveReferencePoint_Injected(UnityEngine.Experimental.XR.TrackableId&)
extern "C" IL2CPP_METHOD_ATTR bool XRReferencePointSubsystem_TryRemoveReferencePoint_Injected_m3144697073 (XRReferencePointSubsystem_t416875062 * __this, TrackableId_t1251031970 * ___referencePointId0, const RuntimeMethod* method);
// System.Boolean UnityEngine.Experimental.XR.XRReferencePointSubsystem::TryGetReferencePoint_Injected(UnityEngine.Experimental.XR.TrackableId&,UnityEngine.Experimental.XR.ReferencePoint&)
extern "C" IL2CPP_METHOD_ATTR bool XRReferencePointSubsystem_TryGetReferencePoint_Injected_m4266629244 (XRReferencePointSubsystem_t416875062 * __this, TrackableId_t1251031970 * ___referencePointId0, ReferencePoint_t394942483 * ___referencePoint1, const RuntimeMethod* method);
// System.Void System.Action`1<UnityEngine.Experimental.XR.ReferencePointUpdatedEventArgs>::Invoke(!0)
inline void Action_1_Invoke_m1143137826 (Action_1_t2218980328 * __this, ReferencePointUpdatedEventArgs_t2046512733  p0, const RuntimeMethod* method)
{
	((  void (*) (Action_1_t2218980328 *, ReferencePointUpdatedEventArgs_t2046512733 , const RuntimeMethod*))Action_1_Invoke_m1143137826_gshared)(__this, p0, method);
}
// System.Void System.Action`1<UnityEngine.Experimental.XR.SessionTrackingStateChangedEventArgs>::Invoke(!0)
inline void Action_1_Invoke_m3768946330 (Action_1_t2515503250 * __this, SessionTrackingStateChangedEventArgs_t2343035655  p0, const RuntimeMethod* method)
{
	((  void (*) (Action_1_t2515503250 *, SessionTrackingStateChangedEventArgs_t2343035655 , const RuntimeMethod*))Action_1_Invoke_m3768946330_gshared)(__this, p0, method);
}
// System.Void System.Collections.Generic.List`1<UnityEngine.XR.XRNodeState>::Clear()
inline void List_1_Clear_m1794174222 (List_1_t929709876 * __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_t929709876 *, const RuntimeMethod*))List_1_Clear_m1794174222_gshared)(__this, method);
}
// System.Void UnityEngine.XR.InputTracking::GetNodeStatesInternal(System.Object)
extern "C" IL2CPP_METHOD_ATTR void InputTracking_GetNodeStatesInternal_m1640706757 (RuntimeObject * __this /* static, unused */, RuntimeObject * ___nodeStates0, const RuntimeMethod* method);
// System.Void UnityEngine.XR.XRNodeState::set_uniqueID(System.UInt64)
extern "C" IL2CPP_METHOD_ATTR void XRNodeState_set_uniqueID_m721524361 (XRNodeState_t3752602430 * __this, uint64_t ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.XR.XRNodeState::set_nodeType(UnityEngine.XR.XRNode)
extern "C" IL2CPP_METHOD_ATTR void XRNodeState_set_nodeType_m1597434625 (XRNodeState_t3752602430 * __this, int32_t ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.XR.XRNodeState::set_tracked(System.Boolean)
extern "C" IL2CPP_METHOD_ATTR void XRNodeState_set_tracked_m3066928959 (XRNodeState_t3752602430 * __this, bool ___value0, const RuntimeMethod* method);
// System.String System.String::Concat(System.Object,System.Object)
extern "C" IL2CPP_METHOD_ATTR String_t* String_Concat_m904156431 (RuntimeObject * __this /* static, unused */, RuntimeObject * p0, RuntimeObject * p1, const RuntimeMethod* method);
// System.Void System.ArgumentException::.ctor(System.String)
extern "C" IL2CPP_METHOD_ATTR void ArgumentException__ctor_m1312628991 (ArgumentException_t132251570 * __this, String_t* p0, const RuntimeMethod* method);
// System.Void System.Action`1<UnityEngine.XR.XRNodeState>::Invoke(!0)
inline void Action_1_Invoke_m1458665122 (Action_1_t3925070025 * __this, XRNodeState_t3752602430  p0, const RuntimeMethod* method)
{
	((  void (*) (Action_1_t3925070025 *, XRNodeState_t3752602430 , const RuntimeMethod*))Action_1_Invoke_m1458665122_gshared)(__this, p0, method);
}
// UnityEngine.XR.XRNode UnityEngine.XR.XRNodeState::get_nodeType()
extern "C" IL2CPP_METHOD_ATTR int32_t XRNodeState_get_nodeType_m1565792694 (XRNodeState_t3752602430 * __this, const RuntimeMethod* method);
// System.Boolean UnityEngine.XR.XRNodeState::TryGet<UnityEngine.Vector3>(T,UnityEngine.XR.AvailableTrackingData,T&)
inline bool XRNodeState_TryGet_TisVector3_t3722313464_m270903620 (XRNodeState_t3752602430 * __this, Vector3_t3722313464  ___inValue0, int32_t ___availabilityFlag1, Vector3_t3722313464 * ___outValue2, const RuntimeMethod* method)
{
	return ((  bool (*) (XRNodeState_t3752602430 *, Vector3_t3722313464 , int32_t, Vector3_t3722313464 *, const RuntimeMethod*))XRNodeState_TryGet_TisVector3_t3722313464_m270903620_gshared)(__this, ___inValue0, ___availabilityFlag1, ___outValue2, method);
}
// System.Boolean UnityEngine.XR.XRNodeState::TryGetPosition(UnityEngine.Vector3&)
extern "C" IL2CPP_METHOD_ATTR bool XRNodeState_TryGetPosition_m2700381506 (XRNodeState_t3752602430 * __this, Vector3_t3722313464 * ___position0, const RuntimeMethod* method);
// System.Boolean UnityEngine.XR.XRNodeState::TryGet<UnityEngine.Quaternion>(T,UnityEngine.XR.AvailableTrackingData,T&)
inline bool XRNodeState_TryGet_TisQuaternion_t2301928331_m1353060540 (XRNodeState_t3752602430 * __this, Quaternion_t2301928331  ___inValue0, int32_t ___availabilityFlag1, Quaternion_t2301928331 * ___outValue2, const RuntimeMethod* method)
{
	return ((  bool (*) (XRNodeState_t3752602430 *, Quaternion_t2301928331 , int32_t, Quaternion_t2301928331 *, const RuntimeMethod*))XRNodeState_TryGet_TisQuaternion_t2301928331_m1353060540_gshared)(__this, ___inValue0, ___availabilityFlag1, ___outValue2, method);
}
// System.Boolean UnityEngine.XR.XRNodeState::TryGetRotation(UnityEngine.Quaternion&)
extern "C" IL2CPP_METHOD_ATTR bool XRNodeState_TryGetRotation_m2439801437 (XRNodeState_t3752602430 * __this, Quaternion_t2301928331 * ___rotation0, const RuntimeMethod* method);
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.Experimental.Internal_SubsystemDescriptors::Internal_InitializeManagedDescriptor(System.IntPtr,UnityEngine.Experimental.ISubsystemDescriptorImpl)
extern "C" IL2CPP_METHOD_ATTR void Internal_SubsystemDescriptors_Internal_InitializeManagedDescriptor_m2393151601 (RuntimeObject * __this /* static, unused */, intptr_t ___ptr0, RuntimeObject* ___desc1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Internal_SubsystemDescriptors_Internal_InitializeManagedDescriptor_m2393151601_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		RuntimeObject* L_0 = ___desc1;
		intptr_t L_1 = ___ptr0;
		NullCheck(L_0);
		InterfaceActionInvoker1< intptr_t >::Invoke(0 /* System.Void UnityEngine.Experimental.ISubsystemDescriptorImpl::set_ptr(System.IntPtr) */, ISubsystemDescriptorImpl_t2883395799_il2cpp_TypeInfo_var, L_0, (intptr_t)L_1);
		IL2CPP_RUNTIME_CLASS_INIT(Internal_SubsystemDescriptors_t691162017_il2cpp_TypeInfo_var);
		List_1_t60503245 * L_2 = ((Internal_SubsystemDescriptors_t691162017_StaticFields*)il2cpp_codegen_static_fields_for(Internal_SubsystemDescriptors_t691162017_il2cpp_TypeInfo_var))->get_s_SubsystemDescriptors_0();
		RuntimeObject* L_3 = ___desc1;
		NullCheck(L_2);
		List_1_Add_m3860418725(L_2, L_3, /*hidden argument*/List_1_Add_m3860418725_RuntimeMethod_var);
		return;
	}
}
// System.Void UnityEngine.Experimental.Internal_SubsystemDescriptors::Internal_ClearManagedDescriptors()
extern "C" IL2CPP_METHOD_ATTR void Internal_SubsystemDescriptors_Internal_ClearManagedDescriptors_m1351509011 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Internal_SubsystemDescriptors_Internal_ClearManagedDescriptors_m1351509011_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	RuntimeObject* V_0 = NULL;
	Enumerator_t1949747122  V_1;
	memset(&V_1, 0, sizeof(V_1));
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = -1;
	NO_UNUSED_WARNING (__leave_target);
	{
		IL2CPP_RUNTIME_CLASS_INIT(Internal_SubsystemDescriptors_t691162017_il2cpp_TypeInfo_var);
		List_1_t60503245 * L_0 = ((Internal_SubsystemDescriptors_t691162017_StaticFields*)il2cpp_codegen_static_fields_for(Internal_SubsystemDescriptors_t691162017_il2cpp_TypeInfo_var))->get_s_SubsystemDescriptors_0();
		NullCheck(L_0);
		Enumerator_t1949747122  L_1 = List_1_GetEnumerator_m2059771147(L_0, /*hidden argument*/List_1_GetEnumerator_m2059771147_RuntimeMethod_var);
		V_1 = L_1;
	}

IL_000d:
	try
	{ // begin try (depth: 1)
		{
			goto IL_0027;
		}

IL_0012:
		{
			RuntimeObject* L_2 = Enumerator_get_Current_m1367904766((Enumerator_t1949747122 *)(&V_1), /*hidden argument*/Enumerator_get_Current_m1367904766_RuntimeMethod_var);
			V_0 = L_2;
			RuntimeObject* L_3 = V_0;
			NullCheck(L_3);
			InterfaceActionInvoker1< intptr_t >::Invoke(0 /* System.Void UnityEngine.Experimental.ISubsystemDescriptorImpl::set_ptr(System.IntPtr) */, ISubsystemDescriptorImpl_t2883395799_il2cpp_TypeInfo_var, L_3, (intptr_t)(0));
		}

IL_0027:
		{
			bool L_4 = Enumerator_MoveNext_m3572286872((Enumerator_t1949747122 *)(&V_1), /*hidden argument*/Enumerator_MoveNext_m3572286872_RuntimeMethod_var);
			if (L_4)
			{
				goto IL_0012;
			}
		}

IL_0033:
		{
			IL2CPP_LEAVE(0x46, FINALLY_0038);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t *)e.ex;
		goto FINALLY_0038;
	}

FINALLY_0038:
	{ // begin finally (depth: 1)
		Enumerator_Dispose_m2979251017((Enumerator_t1949747122 *)(&V_1), /*hidden argument*/Enumerator_Dispose_m2979251017_RuntimeMethod_var);
		IL2CPP_END_FINALLY(56)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(56)
	{
		IL2CPP_JUMP_TBL(0x46, IL_0046)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t *)
	}

IL_0046:
	{
		IL2CPP_RUNTIME_CLASS_INIT(Internal_SubsystemDescriptors_t691162017_il2cpp_TypeInfo_var);
		List_1_t60503245 * L_5 = ((Internal_SubsystemDescriptors_t691162017_StaticFields*)il2cpp_codegen_static_fields_for(Internal_SubsystemDescriptors_t691162017_il2cpp_TypeInfo_var))->get_s_SubsystemDescriptors_0();
		NullCheck(L_5);
		List_1_Clear_m2804938920(L_5, /*hidden argument*/List_1_Clear_m2804938920_RuntimeMethod_var);
		return;
	}
}
// System.IntPtr UnityEngine.Experimental.Internal_SubsystemDescriptors::Create(System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR intptr_t Internal_SubsystemDescriptors_Create_m2780843198 (RuntimeObject * __this /* static, unused */, intptr_t ___descriptorPtr0, const RuntimeMethod* method)
{
	typedef intptr_t (*Internal_SubsystemDescriptors_Create_m2780843198_ftn) (intptr_t);
	static Internal_SubsystemDescriptors_Create_m2780843198_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (Internal_SubsystemDescriptors_Create_m2780843198_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.Experimental.Internal_SubsystemDescriptors::Create(System.IntPtr)");
	intptr_t retVal = _il2cpp_icall_func(___descriptorPtr0);
	return retVal;
}
// System.String UnityEngine.Experimental.Internal_SubsystemDescriptors::GetId(System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR String_t* Internal_SubsystemDescriptors_GetId_m3581253800 (RuntimeObject * __this /* static, unused */, intptr_t ___descriptorPtr0, const RuntimeMethod* method)
{
	typedef String_t* (*Internal_SubsystemDescriptors_GetId_m3581253800_ftn) (intptr_t);
	static Internal_SubsystemDescriptors_GetId_m3581253800_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (Internal_SubsystemDescriptors_GetId_m3581253800_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.Experimental.Internal_SubsystemDescriptors::GetId(System.IntPtr)");
	String_t* retVal = _il2cpp_icall_func(___descriptorPtr0);
	return retVal;
}
// System.Void UnityEngine.Experimental.Internal_SubsystemDescriptors::.cctor()
extern "C" IL2CPP_METHOD_ATTR void Internal_SubsystemDescriptors__cctor_m2670682352 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Internal_SubsystemDescriptors__cctor_m2670682352_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		List_1_t60503245 * L_0 = (List_1_t60503245 *)il2cpp_codegen_object_new(List_1_t60503245_il2cpp_TypeInfo_var);
		List_1__ctor_m3747657077(L_0, /*hidden argument*/List_1__ctor_m3747657077_RuntimeMethod_var);
		((Internal_SubsystemDescriptors_t691162017_StaticFields*)il2cpp_codegen_static_fields_for(Internal_SubsystemDescriptors_t691162017_il2cpp_TypeInfo_var))->set_s_SubsystemDescriptors_0(L_0);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.Experimental.Internal_SubsystemInstances::Internal_InitializeManagedInstance(System.IntPtr,UnityEngine.Experimental.Subsystem)
extern "C" IL2CPP_METHOD_ATTR void Internal_SubsystemInstances_Internal_InitializeManagedInstance_m317893559 (RuntimeObject * __this /* static, unused */, intptr_t ___ptr0, Subsystem_t89723475 * ___inst1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Internal_SubsystemInstances_Internal_InitializeManagedInstance_m317893559_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Subsystem_t89723475 * L_0 = ___inst1;
		intptr_t L_1 = ___ptr0;
		NullCheck(L_0);
		L_0->set_m_Ptr_0((intptr_t)L_1);
		Subsystem_t89723475 * L_2 = ___inst1;
		Subsystem_t89723475 * L_3 = ___inst1;
		NullCheck(L_2);
		Subsystem_SetHandle_m3808293838(L_2, L_3, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Internal_SubsystemInstances_t893566515_il2cpp_TypeInfo_var);
		List_1_t1561798217 * L_4 = ((Internal_SubsystemInstances_t893566515_StaticFields*)il2cpp_codegen_static_fields_for(Internal_SubsystemInstances_t893566515_il2cpp_TypeInfo_var))->get_s_SubsystemInstances_0();
		Subsystem_t89723475 * L_5 = ___inst1;
		NullCheck(L_4);
		List_1_Add_m2793820062(L_4, L_5, /*hidden argument*/List_1_Add_m2793820062_RuntimeMethod_var);
		return;
	}
}
// System.Void UnityEngine.Experimental.Internal_SubsystemInstances::Internal_ClearManagedInstances()
extern "C" IL2CPP_METHOD_ATTR void Internal_SubsystemInstances_Internal_ClearManagedInstances_m856038640 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Internal_SubsystemInstances_Internal_ClearManagedInstances_m856038640_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Subsystem_t89723475 * V_0 = NULL;
	Enumerator_t3451042094  V_1;
	memset(&V_1, 0, sizeof(V_1));
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = -1;
	NO_UNUSED_WARNING (__leave_target);
	{
		IL2CPP_RUNTIME_CLASS_INIT(Internal_SubsystemInstances_t893566515_il2cpp_TypeInfo_var);
		List_1_t1561798217 * L_0 = ((Internal_SubsystemInstances_t893566515_StaticFields*)il2cpp_codegen_static_fields_for(Internal_SubsystemInstances_t893566515_il2cpp_TypeInfo_var))->get_s_SubsystemInstances_0();
		NullCheck(L_0);
		Enumerator_t3451042094  L_1 = List_1_GetEnumerator_m489737270(L_0, /*hidden argument*/List_1_GetEnumerator_m489737270_RuntimeMethod_var);
		V_1 = L_1;
	}

IL_000d:
	try
	{ // begin try (depth: 1)
		{
			goto IL_0027;
		}

IL_0012:
		{
			Subsystem_t89723475 * L_2 = Enumerator_get_Current_m4233439720((Enumerator_t3451042094 *)(&V_1), /*hidden argument*/Enumerator_get_Current_m4233439720_RuntimeMethod_var);
			V_0 = L_2;
			Subsystem_t89723475 * L_3 = V_0;
			NullCheck(L_3);
			L_3->set_m_Ptr_0((intptr_t)(0));
		}

IL_0027:
		{
			bool L_4 = Enumerator_MoveNext_m2084212791((Enumerator_t3451042094 *)(&V_1), /*hidden argument*/Enumerator_MoveNext_m2084212791_RuntimeMethod_var);
			if (L_4)
			{
				goto IL_0012;
			}
		}

IL_0033:
		{
			IL2CPP_LEAVE(0x46, FINALLY_0038);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t *)e.ex;
		goto FINALLY_0038;
	}

FINALLY_0038:
	{ // begin finally (depth: 1)
		Enumerator_Dispose_m4163083902((Enumerator_t3451042094 *)(&V_1), /*hidden argument*/Enumerator_Dispose_m4163083902_RuntimeMethod_var);
		IL2CPP_END_FINALLY(56)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(56)
	{
		IL2CPP_JUMP_TBL(0x46, IL_0046)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t *)
	}

IL_0046:
	{
		IL2CPP_RUNTIME_CLASS_INIT(Internal_SubsystemInstances_t893566515_il2cpp_TypeInfo_var);
		List_1_t1561798217 * L_5 = ((Internal_SubsystemInstances_t893566515_StaticFields*)il2cpp_codegen_static_fields_for(Internal_SubsystemInstances_t893566515_il2cpp_TypeInfo_var))->get_s_SubsystemInstances_0();
		NullCheck(L_5);
		List_1_Clear_m2449803944(L_5, /*hidden argument*/List_1_Clear_m2449803944_RuntimeMethod_var);
		return;
	}
}
// System.Void UnityEngine.Experimental.Internal_SubsystemInstances::Internal_RemoveInstanceByPtr(System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR void Internal_SubsystemInstances_Internal_RemoveInstanceByPtr_m3992065214 (RuntimeObject * __this /* static, unused */, intptr_t ___ptr0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Internal_SubsystemInstances_Internal_RemoveInstanceByPtr_m3992065214_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	{
		IL2CPP_RUNTIME_CLASS_INIT(Internal_SubsystemInstances_t893566515_il2cpp_TypeInfo_var);
		List_1_t1561798217 * L_0 = ((Internal_SubsystemInstances_t893566515_StaticFields*)il2cpp_codegen_static_fields_for(Internal_SubsystemInstances_t893566515_il2cpp_TypeInfo_var))->get_s_SubsystemInstances_0();
		NullCheck(L_0);
		int32_t L_1 = List_1_get_Count_m4144085239(L_0, /*hidden argument*/List_1_get_Count_m4144085239_RuntimeMethod_var);
		V_0 = ((int32_t)il2cpp_codegen_subtract((int32_t)L_1, (int32_t)1));
		goto IL_0056;
	}

IL_0013:
	{
		IL2CPP_RUNTIME_CLASS_INIT(Internal_SubsystemInstances_t893566515_il2cpp_TypeInfo_var);
		List_1_t1561798217 * L_2 = ((Internal_SubsystemInstances_t893566515_StaticFields*)il2cpp_codegen_static_fields_for(Internal_SubsystemInstances_t893566515_il2cpp_TypeInfo_var))->get_s_SubsystemInstances_0();
		int32_t L_3 = V_0;
		NullCheck(L_2);
		Subsystem_t89723475 * L_4 = List_1_get_Item_m4223061980(L_2, L_3, /*hidden argument*/List_1_get_Item_m4223061980_RuntimeMethod_var);
		NullCheck(L_4);
		intptr_t L_5 = L_4->get_m_Ptr_0();
		intptr_t L_6 = ___ptr0;
		bool L_7 = IntPtr_op_Equality_m408849716(NULL /*static, unused*/, (intptr_t)L_5, (intptr_t)L_6, /*hidden argument*/NULL);
		if (!L_7)
		{
			goto IL_0051;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Internal_SubsystemInstances_t893566515_il2cpp_TypeInfo_var);
		List_1_t1561798217 * L_8 = ((Internal_SubsystemInstances_t893566515_StaticFields*)il2cpp_codegen_static_fields_for(Internal_SubsystemInstances_t893566515_il2cpp_TypeInfo_var))->get_s_SubsystemInstances_0();
		int32_t L_9 = V_0;
		NullCheck(L_8);
		Subsystem_t89723475 * L_10 = List_1_get_Item_m4223061980(L_8, L_9, /*hidden argument*/List_1_get_Item_m4223061980_RuntimeMethod_var);
		NullCheck(L_10);
		L_10->set_m_Ptr_0((intptr_t)(0));
		List_1_t1561798217 * L_11 = ((Internal_SubsystemInstances_t893566515_StaticFields*)il2cpp_codegen_static_fields_for(Internal_SubsystemInstances_t893566515_il2cpp_TypeInfo_var))->get_s_SubsystemInstances_0();
		int32_t L_12 = V_0;
		NullCheck(L_11);
		List_1_RemoveAt_m1171746181(L_11, L_12, /*hidden argument*/List_1_RemoveAt_m1171746181_RuntimeMethod_var);
	}

IL_0051:
	{
		int32_t L_13 = V_0;
		V_0 = ((int32_t)il2cpp_codegen_subtract((int32_t)L_13, (int32_t)1));
	}

IL_0056:
	{
		int32_t L_14 = V_0;
		if ((((int32_t)L_14) >= ((int32_t)0)))
		{
			goto IL_0013;
		}
	}
	{
		return;
	}
}
// UnityEngine.Experimental.Subsystem UnityEngine.Experimental.Internal_SubsystemInstances::Internal_GetInstanceByPtr(System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR Subsystem_t89723475 * Internal_SubsystemInstances_Internal_GetInstanceByPtr_m1622708940 (RuntimeObject * __this /* static, unused */, intptr_t ___ptr0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Internal_SubsystemInstances_Internal_GetInstanceByPtr_m1622708940_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Subsystem_t89723475 * V_0 = NULL;
	Enumerator_t3451042094  V_1;
	memset(&V_1, 0, sizeof(V_1));
	Subsystem_t89723475 * V_2 = NULL;
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = -1;
	NO_UNUSED_WARNING (__leave_target);
	{
		IL2CPP_RUNTIME_CLASS_INIT(Internal_SubsystemInstances_t893566515_il2cpp_TypeInfo_var);
		List_1_t1561798217 * L_0 = ((Internal_SubsystemInstances_t893566515_StaticFields*)il2cpp_codegen_static_fields_for(Internal_SubsystemInstances_t893566515_il2cpp_TypeInfo_var))->get_s_SubsystemInstances_0();
		NullCheck(L_0);
		Enumerator_t3451042094  L_1 = List_1_GetEnumerator_m489737270(L_0, /*hidden argument*/List_1_GetEnumerator_m489737270_RuntimeMethod_var);
		V_1 = L_1;
	}

IL_000d:
	try
	{ // begin try (depth: 1)
		{
			goto IL_0034;
		}

IL_0012:
		{
			Subsystem_t89723475 * L_2 = Enumerator_get_Current_m4233439720((Enumerator_t3451042094 *)(&V_1), /*hidden argument*/Enumerator_get_Current_m4233439720_RuntimeMethod_var);
			V_0 = L_2;
			Subsystem_t89723475 * L_3 = V_0;
			NullCheck(L_3);
			intptr_t L_4 = L_3->get_m_Ptr_0();
			intptr_t L_5 = ___ptr0;
			bool L_6 = IntPtr_op_Equality_m408849716(NULL /*static, unused*/, (intptr_t)L_4, (intptr_t)L_5, /*hidden argument*/NULL);
			if (!L_6)
			{
				goto IL_0033;
			}
		}

IL_002c:
		{
			Subsystem_t89723475 * L_7 = V_0;
			V_2 = L_7;
			IL2CPP_LEAVE(0x5A, FINALLY_0045);
		}

IL_0033:
		{
		}

IL_0034:
		{
			bool L_8 = Enumerator_MoveNext_m2084212791((Enumerator_t3451042094 *)(&V_1), /*hidden argument*/Enumerator_MoveNext_m2084212791_RuntimeMethod_var);
			if (L_8)
			{
				goto IL_0012;
			}
		}

IL_0040:
		{
			IL2CPP_LEAVE(0x53, FINALLY_0045);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t *)e.ex;
		goto FINALLY_0045;
	}

FINALLY_0045:
	{ // begin finally (depth: 1)
		Enumerator_Dispose_m4163083902((Enumerator_t3451042094 *)(&V_1), /*hidden argument*/Enumerator_Dispose_m4163083902_RuntimeMethod_var);
		IL2CPP_END_FINALLY(69)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(69)
	{
		IL2CPP_JUMP_TBL(0x5A, IL_005a)
		IL2CPP_JUMP_TBL(0x53, IL_0053)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t *)
	}

IL_0053:
	{
		V_2 = (Subsystem_t89723475 *)NULL;
		goto IL_005a;
	}

IL_005a:
	{
		Subsystem_t89723475 * L_9 = V_2;
		return L_9;
	}
}
// System.Void UnityEngine.Experimental.Internal_SubsystemInstances::.cctor()
extern "C" IL2CPP_METHOD_ATTR void Internal_SubsystemInstances__cctor_m482657293 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Internal_SubsystemInstances__cctor_m482657293_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		List_1_t1561798217 * L_0 = (List_1_t1561798217 *)il2cpp_codegen_object_new(List_1_t1561798217_il2cpp_TypeInfo_var);
		List_1__ctor_m910085292(L_0, /*hidden argument*/List_1__ctor_m910085292_RuntimeMethod_var);
		((Internal_SubsystemInstances_t893566515_StaticFields*)il2cpp_codegen_static_fields_for(Internal_SubsystemInstances_t893566515_il2cpp_TypeInfo_var))->set_s_SubsystemInstances_0(L_0);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: UnityEngine.Experimental.Subsystem
extern "C" void Subsystem_t89723475_marshal_pinvoke(const Subsystem_t89723475& unmarshaled, Subsystem_t89723475_marshaled_pinvoke& marshaled)
{
	Exception_t* ___m_subsystemDescriptor_1Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_subsystemDescriptor' of type 'Subsystem': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_subsystemDescriptor_1Exception, NULL, NULL);
}
extern "C" void Subsystem_t89723475_marshal_pinvoke_back(const Subsystem_t89723475_marshaled_pinvoke& marshaled, Subsystem_t89723475& unmarshaled)
{
	Exception_t* ___m_subsystemDescriptor_1Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_subsystemDescriptor' of type 'Subsystem': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_subsystemDescriptor_1Exception, NULL, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.Experimental.Subsystem
extern "C" void Subsystem_t89723475_marshal_pinvoke_cleanup(Subsystem_t89723475_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: UnityEngine.Experimental.Subsystem
extern "C" void Subsystem_t89723475_marshal_com(const Subsystem_t89723475& unmarshaled, Subsystem_t89723475_marshaled_com& marshaled)
{
	Exception_t* ___m_subsystemDescriptor_1Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_subsystemDescriptor' of type 'Subsystem': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_subsystemDescriptor_1Exception, NULL, NULL);
}
extern "C" void Subsystem_t89723475_marshal_com_back(const Subsystem_t89723475_marshaled_com& marshaled, Subsystem_t89723475& unmarshaled)
{
	Exception_t* ___m_subsystemDescriptor_1Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_subsystemDescriptor' of type 'Subsystem': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_subsystemDescriptor_1Exception, NULL, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.Experimental.Subsystem
extern "C" void Subsystem_t89723475_marshal_com_cleanup(Subsystem_t89723475_marshaled_com& marshaled)
{
}
// System.Void UnityEngine.Experimental.Subsystem::SetHandle(UnityEngine.Experimental.Subsystem)
extern "C" IL2CPP_METHOD_ATTR void Subsystem_SetHandle_m3808293838 (Subsystem_t89723475 * __this, Subsystem_t89723475 * ___inst0, const RuntimeMethod* method)
{
	typedef void (*Subsystem_SetHandle_m3808293838_ftn) (Subsystem_t89723475 *, Subsystem_t89723475 *);
	static Subsystem_SetHandle_m3808293838_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (Subsystem_SetHandle_m3808293838_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.Experimental.Subsystem::SetHandle(UnityEngine.Experimental.Subsystem)");
	_il2cpp_icall_func(__this, ___inst0);
}
// System.Void UnityEngine.Experimental.Subsystem::Start()
extern "C" IL2CPP_METHOD_ATTR void Subsystem_Start_m2677732529 (Subsystem_t89723475 * __this, const RuntimeMethod* method)
{
	typedef void (*Subsystem_Start_m2677732529_ftn) (Subsystem_t89723475 *);
	static Subsystem_Start_m2677732529_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (Subsystem_Start_m2677732529_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.Experimental.Subsystem::Start()");
	_il2cpp_icall_func(__this);
}
// System.Void UnityEngine.Experimental.Subsystem::Stop()
extern "C" IL2CPP_METHOD_ATTR void Subsystem_Stop_m2884462926 (Subsystem_t89723475 * __this, const RuntimeMethod* method)
{
	typedef void (*Subsystem_Stop_m2884462926_ftn) (Subsystem_t89723475 *);
	static Subsystem_Stop_m2884462926_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (Subsystem_Stop_m2884462926_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.Experimental.Subsystem::Stop()");
	_il2cpp_icall_func(__this);
}
// System.Void UnityEngine.Experimental.Subsystem::Destroy()
extern "C" IL2CPP_METHOD_ATTR void Subsystem_Destroy_m328346957 (Subsystem_t89723475 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Subsystem_Destroy_m328346957_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	intptr_t V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		intptr_t L_0 = __this->get_m_Ptr_0();
		V_0 = (intptr_t)L_0;
		intptr_t L_1 = __this->get_m_Ptr_0();
		IL2CPP_RUNTIME_CLASS_INIT(Internal_SubsystemInstances_t893566515_il2cpp_TypeInfo_var);
		Internal_SubsystemInstances_Internal_RemoveInstanceByPtr_m3992065214(NULL /*static, unused*/, (intptr_t)L_1, /*hidden argument*/NULL);
		intptr_t L_2 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(SubsystemManager_t1056502336_il2cpp_TypeInfo_var);
		SubsystemManager_DestroyInstance_Internal_m3781448766(NULL /*static, unused*/, (intptr_t)L_2, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: UnityEngine.Experimental.SubsystemDescriptorBase
extern "C" void SubsystemDescriptorBase_t2374447182_marshal_pinvoke(const SubsystemDescriptorBase_t2374447182& unmarshaled, SubsystemDescriptorBase_t2374447182_marshaled_pinvoke& marshaled)
{
	marshaled.___m_Ptr_0 = unmarshaled.get_m_Ptr_0();
}
extern "C" void SubsystemDescriptorBase_t2374447182_marshal_pinvoke_back(const SubsystemDescriptorBase_t2374447182_marshaled_pinvoke& marshaled, SubsystemDescriptorBase_t2374447182& unmarshaled)
{
	intptr_t unmarshaled_m_Ptr_temp_0;
	memset(&unmarshaled_m_Ptr_temp_0, 0, sizeof(unmarshaled_m_Ptr_temp_0));
	unmarshaled_m_Ptr_temp_0 = marshaled.___m_Ptr_0;
	unmarshaled.set_m_Ptr_0(unmarshaled_m_Ptr_temp_0);
}
// Conversion method for clean up from marshalling of: UnityEngine.Experimental.SubsystemDescriptorBase
extern "C" void SubsystemDescriptorBase_t2374447182_marshal_pinvoke_cleanup(SubsystemDescriptorBase_t2374447182_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: UnityEngine.Experimental.SubsystemDescriptorBase
extern "C" void SubsystemDescriptorBase_t2374447182_marshal_com(const SubsystemDescriptorBase_t2374447182& unmarshaled, SubsystemDescriptorBase_t2374447182_marshaled_com& marshaled)
{
	marshaled.___m_Ptr_0 = unmarshaled.get_m_Ptr_0();
}
extern "C" void SubsystemDescriptorBase_t2374447182_marshal_com_back(const SubsystemDescriptorBase_t2374447182_marshaled_com& marshaled, SubsystemDescriptorBase_t2374447182& unmarshaled)
{
	intptr_t unmarshaled_m_Ptr_temp_0;
	memset(&unmarshaled_m_Ptr_temp_0, 0, sizeof(unmarshaled_m_Ptr_temp_0));
	unmarshaled_m_Ptr_temp_0 = marshaled.___m_Ptr_0;
	unmarshaled.set_m_Ptr_0(unmarshaled_m_Ptr_temp_0);
}
// Conversion method for clean up from marshalling of: UnityEngine.Experimental.SubsystemDescriptorBase
extern "C" void SubsystemDescriptorBase_t2374447182_marshal_com_cleanup(SubsystemDescriptorBase_t2374447182_marshaled_com& marshaled)
{
}
// System.String UnityEngine.Experimental.SubsystemDescriptorBase::get_id()
extern "C" IL2CPP_METHOD_ATTR String_t* SubsystemDescriptorBase_get_id_m893539935 (SubsystemDescriptorBase_t2374447182 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (SubsystemDescriptorBase_get_id_m893539935_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	String_t* V_0 = NULL;
	{
		intptr_t L_0 = __this->get_m_Ptr_0();
		IL2CPP_RUNTIME_CLASS_INIT(Internal_SubsystemDescriptors_t691162017_il2cpp_TypeInfo_var);
		String_t* L_1 = Internal_SubsystemDescriptors_GetId_m3581253800(NULL /*static, unused*/, (intptr_t)L_0, /*hidden argument*/NULL);
		V_0 = L_1;
		goto IL_0012;
	}

IL_0012:
	{
		String_t* L_2 = V_0;
		return L_2;
	}
}
// System.Void UnityEngine.Experimental.SubsystemDescriptorBase::UnityEngine.Experimental.ISubsystemDescriptorImpl.set_ptr(System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR void SubsystemDescriptorBase_UnityEngine_Experimental_ISubsystemDescriptorImpl_set_ptr_m3713478713 (SubsystemDescriptorBase_t2374447182 * __this, intptr_t ___value0, const RuntimeMethod* method)
{
	{
		intptr_t L_0 = ___value0;
		__this->set_m_Ptr_0((intptr_t)L_0);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.Experimental.SubsystemManager::.cctor()
extern "C" IL2CPP_METHOD_ATTR void SubsystemManager__cctor_m2868782737 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method)
{
	{
		SubsystemManager_StaticConstructScriptingClassMap_m3263645951(NULL /*static, unused*/, /*hidden argument*/NULL);
		return;
	}
}
// System.Void UnityEngine.Experimental.SubsystemManager::DestroyInstance_Internal(System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR void SubsystemManager_DestroyInstance_Internal_m3781448766 (RuntimeObject * __this /* static, unused */, intptr_t ___instancePtr0, const RuntimeMethod* method)
{
	typedef void (*SubsystemManager_DestroyInstance_Internal_m3781448766_ftn) (intptr_t);
	static SubsystemManager_DestroyInstance_Internal_m3781448766_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (SubsystemManager_DestroyInstance_Internal_m3781448766_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.Experimental.SubsystemManager::DestroyInstance_Internal(System.IntPtr)");
	_il2cpp_icall_func(___instancePtr0);
}
// System.Void UnityEngine.Experimental.SubsystemManager::StaticConstructScriptingClassMap()
extern "C" IL2CPP_METHOD_ATTR void SubsystemManager_StaticConstructScriptingClassMap_m3263645951 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method)
{
	typedef void (*SubsystemManager_StaticConstructScriptingClassMap_m3263645951_ftn) ();
	static SubsystemManager_StaticConstructScriptingClassMap_m3263645951_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (SubsystemManager_StaticConstructScriptingClassMap_m3263645951_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.Experimental.SubsystemManager::StaticConstructScriptingClassMap()");
	_il2cpp_icall_func();
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// UnityEngine.Experimental.XR.TrackableId UnityEngine.Experimental.XR.BoundedPlane::get_Id()
extern "C" IL2CPP_METHOD_ATTR TrackableId_t1251031970  BoundedPlane_get_Id_m4119012809 (BoundedPlane_t1317492334 * __this, const RuntimeMethod* method)
{
	TrackableId_t1251031970  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		TrackableId_t1251031970  L_0 = __this->get_U3CIdU3Ek__BackingField_1();
		V_0 = L_0;
		goto IL_000c;
	}

IL_000c:
	{
		TrackableId_t1251031970  L_1 = V_0;
		return L_1;
	}
}
extern "C"  TrackableId_t1251031970  BoundedPlane_get_Id_m4119012809_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	BoundedPlane_t1317492334 * _thisAdjusted = reinterpret_cast<BoundedPlane_t1317492334 *>(__this + 1);
	return BoundedPlane_get_Id_m4119012809(_thisAdjusted, method);
}
// UnityEngine.Experimental.XR.TrackableId UnityEngine.Experimental.XR.BoundedPlane::get_SubsumedById()
extern "C" IL2CPP_METHOD_ATTR TrackableId_t1251031970  BoundedPlane_get_SubsumedById_m1556489410 (BoundedPlane_t1317492334 * __this, const RuntimeMethod* method)
{
	TrackableId_t1251031970  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		TrackableId_t1251031970  L_0 = __this->get_U3CSubsumedByIdU3Ek__BackingField_2();
		V_0 = L_0;
		goto IL_000c;
	}

IL_000c:
	{
		TrackableId_t1251031970  L_1 = V_0;
		return L_1;
	}
}
extern "C"  TrackableId_t1251031970  BoundedPlane_get_SubsumedById_m1556489410_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	BoundedPlane_t1317492334 * _thisAdjusted = reinterpret_cast<BoundedPlane_t1317492334 *>(__this + 1);
	return BoundedPlane_get_SubsumedById_m1556489410(_thisAdjusted, method);
}
// UnityEngine.Pose UnityEngine.Experimental.XR.BoundedPlane::get_Pose()
extern "C" IL2CPP_METHOD_ATTR Pose_t545244865  BoundedPlane_get_Pose_m820068544 (BoundedPlane_t1317492334 * __this, const RuntimeMethod* method)
{
	Pose_t545244865  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		Pose_t545244865  L_0 = __this->get_U3CPoseU3Ek__BackingField_3();
		V_0 = L_0;
		goto IL_000c;
	}

IL_000c:
	{
		Pose_t545244865  L_1 = V_0;
		return L_1;
	}
}
extern "C"  Pose_t545244865  BoundedPlane_get_Pose_m820068544_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	BoundedPlane_t1317492334 * _thisAdjusted = reinterpret_cast<BoundedPlane_t1317492334 *>(__this + 1);
	return BoundedPlane_get_Pose_m820068544(_thisAdjusted, method);
}
// UnityEngine.Vector3 UnityEngine.Experimental.XR.BoundedPlane::get_Center()
extern "C" IL2CPP_METHOD_ATTR Vector3_t3722313464  BoundedPlane_get_Center_m3129244743 (BoundedPlane_t1317492334 * __this, const RuntimeMethod* method)
{
	Vector3_t3722313464  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		Vector3_t3722313464  L_0 = __this->get_U3CCenterU3Ek__BackingField_4();
		V_0 = L_0;
		goto IL_000c;
	}

IL_000c:
	{
		Vector3_t3722313464  L_1 = V_0;
		return L_1;
	}
}
extern "C"  Vector3_t3722313464  BoundedPlane_get_Center_m3129244743_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	BoundedPlane_t1317492334 * _thisAdjusted = reinterpret_cast<BoundedPlane_t1317492334 *>(__this + 1);
	return BoundedPlane_get_Center_m3129244743(_thisAdjusted, method);
}
// UnityEngine.Vector3 UnityEngine.Experimental.XR.BoundedPlane::get_Normal()
extern "C" IL2CPP_METHOD_ATTR Vector3_t3722313464  BoundedPlane_get_Normal_m1663591676 (BoundedPlane_t1317492334 * __this, const RuntimeMethod* method)
{
	Pose_t545244865  V_0;
	memset(&V_0, 0, sizeof(V_0));
	Vector3_t3722313464  V_1;
	memset(&V_1, 0, sizeof(V_1));
	{
		Pose_t545244865  L_0 = BoundedPlane_get_Pose_m820068544((BoundedPlane_t1317492334 *)__this, /*hidden argument*/NULL);
		V_0 = L_0;
		Vector3_t3722313464  L_1 = Pose_get_up_m2443616131((Pose_t545244865 *)(&V_0), /*hidden argument*/NULL);
		V_1 = L_1;
		goto IL_0015;
	}

IL_0015:
	{
		Vector3_t3722313464  L_2 = V_1;
		return L_2;
	}
}
extern "C"  Vector3_t3722313464  BoundedPlane_get_Normal_m1663591676_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	BoundedPlane_t1317492334 * _thisAdjusted = reinterpret_cast<BoundedPlane_t1317492334 *>(__this + 1);
	return BoundedPlane_get_Normal_m1663591676(_thisAdjusted, method);
}
// System.Boolean UnityEngine.Experimental.XR.BoundedPlane::TryGetBoundary(System.Collections.Generic.List`1<UnityEngine.Vector3>)
extern "C" IL2CPP_METHOD_ATTR bool BoundedPlane_TryGetBoundary_m3909741008 (BoundedPlane_t1317492334 * __this, List_1_t899420910 * ___boundaryOut0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (BoundedPlane_TryGetBoundary_m3909741008_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	{
		List_1_t899420910 * L_0 = ___boundaryOut0;
		if (L_0)
		{
			goto IL_0012;
		}
	}
	{
		ArgumentNullException_t1615371798 * L_1 = (ArgumentNullException_t1615371798 *)il2cpp_codegen_object_new(ArgumentNullException_t1615371798_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m1170824041(L_1, _stringLiteral2112669954, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1, NULL, BoundedPlane_TryGetBoundary_m3909741008_RuntimeMethod_var);
	}

IL_0012:
	{
		uint32_t L_2 = __this->get_m_InstanceId_0();
		TrackableId_t1251031970  L_3 = BoundedPlane_get_Id_m4119012809((BoundedPlane_t1317492334 *)__this, /*hidden argument*/NULL);
		List_1_t899420910 * L_4 = ___boundaryOut0;
		bool L_5 = BoundedPlane_Internal_GetBoundaryAsList_m50365802(NULL /*static, unused*/, L_2, L_3, L_4, /*hidden argument*/NULL);
		V_0 = L_5;
		goto IL_002a;
	}

IL_002a:
	{
		bool L_6 = V_0;
		return L_6;
	}
}
extern "C"  bool BoundedPlane_TryGetBoundary_m3909741008_AdjustorThunk (RuntimeObject * __this, List_1_t899420910 * ___boundaryOut0, const RuntimeMethod* method)
{
	BoundedPlane_t1317492334 * _thisAdjusted = reinterpret_cast<BoundedPlane_t1317492334 *>(__this + 1);
	return BoundedPlane_TryGetBoundary_m3909741008(_thisAdjusted, ___boundaryOut0, method);
}
// System.Boolean UnityEngine.Experimental.XR.BoundedPlane::Internal_GetBoundaryAsList(System.UInt32,UnityEngine.Experimental.XR.TrackableId,System.Collections.Generic.List`1<UnityEngine.Vector3>)
extern "C" IL2CPP_METHOD_ATTR bool BoundedPlane_Internal_GetBoundaryAsList_m50365802 (RuntimeObject * __this /* static, unused */, uint32_t ___instanceId0, TrackableId_t1251031970  ___id1, List_1_t899420910 * ___boundaryOut2, const RuntimeMethod* method)
{
	{
		uint32_t L_0 = ___instanceId0;
		List_1_t899420910 * L_1 = ___boundaryOut2;
		bool L_2 = BoundedPlane_Internal_GetBoundaryAsList_Injected_m2590883096(NULL /*static, unused*/, L_0, (TrackableId_t1251031970 *)(&___id1), L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Boolean UnityEngine.Experimental.XR.BoundedPlane::Internal_GetBoundaryAsList_Injected(System.UInt32,UnityEngine.Experimental.XR.TrackableId&,System.Collections.Generic.List`1<UnityEngine.Vector3>)
extern "C" IL2CPP_METHOD_ATTR bool BoundedPlane_Internal_GetBoundaryAsList_Injected_m2590883096 (RuntimeObject * __this /* static, unused */, uint32_t ___instanceId0, TrackableId_t1251031970 * ___id1, List_1_t899420910 * ___boundaryOut2, const RuntimeMethod* method)
{
	typedef bool (*BoundedPlane_Internal_GetBoundaryAsList_Injected_m2590883096_ftn) (uint32_t, TrackableId_t1251031970 *, List_1_t899420910 *);
	static BoundedPlane_Internal_GetBoundaryAsList_Injected_m2590883096_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (BoundedPlane_Internal_GetBoundaryAsList_Injected_m2590883096_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.Experimental.XR.BoundedPlane::Internal_GetBoundaryAsList_Injected(System.UInt32,UnityEngine.Experimental.XR.TrackableId&,System.Collections.Generic.List`1<UnityEngine.Vector3>)");
	bool retVal = _il2cpp_icall_func(___instanceId0, ___id1, ___boundaryOut2);
	return retVal;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: UnityEngine.Experimental.XR.FrameReceivedEventArgs
extern "C" void FrameReceivedEventArgs_t2588080103_marshal_pinvoke(const FrameReceivedEventArgs_t2588080103& unmarshaled, FrameReceivedEventArgs_t2588080103_marshaled_pinvoke& marshaled)
{
	Exception_t* ___m_CameraSubsystem_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_CameraSubsystem' of type 'FrameReceivedEventArgs': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_CameraSubsystem_0Exception, NULL, NULL);
}
extern "C" void FrameReceivedEventArgs_t2588080103_marshal_pinvoke_back(const FrameReceivedEventArgs_t2588080103_marshaled_pinvoke& marshaled, FrameReceivedEventArgs_t2588080103& unmarshaled)
{
	Exception_t* ___m_CameraSubsystem_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_CameraSubsystem' of type 'FrameReceivedEventArgs': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_CameraSubsystem_0Exception, NULL, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.Experimental.XR.FrameReceivedEventArgs
extern "C" void FrameReceivedEventArgs_t2588080103_marshal_pinvoke_cleanup(FrameReceivedEventArgs_t2588080103_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: UnityEngine.Experimental.XR.FrameReceivedEventArgs
extern "C" void FrameReceivedEventArgs_t2588080103_marshal_com(const FrameReceivedEventArgs_t2588080103& unmarshaled, FrameReceivedEventArgs_t2588080103_marshaled_com& marshaled)
{
	Exception_t* ___m_CameraSubsystem_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_CameraSubsystem' of type 'FrameReceivedEventArgs': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_CameraSubsystem_0Exception, NULL, NULL);
}
extern "C" void FrameReceivedEventArgs_t2588080103_marshal_com_back(const FrameReceivedEventArgs_t2588080103_marshaled_com& marshaled, FrameReceivedEventArgs_t2588080103& unmarshaled)
{
	Exception_t* ___m_CameraSubsystem_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_CameraSubsystem' of type 'FrameReceivedEventArgs': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_CameraSubsystem_0Exception, NULL, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.Experimental.XR.FrameReceivedEventArgs
extern "C" void FrameReceivedEventArgs_t2588080103_marshal_com_cleanup(FrameReceivedEventArgs_t2588080103_marshaled_com& marshaled)
{
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: UnityEngine.Experimental.XR.PlaneAddedEventArgs
extern "C" void PlaneAddedEventArgs_t2550175725_marshal_pinvoke(const PlaneAddedEventArgs_t2550175725& unmarshaled, PlaneAddedEventArgs_t2550175725_marshaled_pinvoke& marshaled)
{
	Exception_t* ___U3CPlaneSubsystemU3Ek__BackingField_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '<PlaneSubsystem>k__BackingField' of type 'PlaneAddedEventArgs': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___U3CPlaneSubsystemU3Ek__BackingField_0Exception, NULL, NULL);
}
extern "C" void PlaneAddedEventArgs_t2550175725_marshal_pinvoke_back(const PlaneAddedEventArgs_t2550175725_marshaled_pinvoke& marshaled, PlaneAddedEventArgs_t2550175725& unmarshaled)
{
	Exception_t* ___U3CPlaneSubsystemU3Ek__BackingField_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '<PlaneSubsystem>k__BackingField' of type 'PlaneAddedEventArgs': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___U3CPlaneSubsystemU3Ek__BackingField_0Exception, NULL, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.Experimental.XR.PlaneAddedEventArgs
extern "C" void PlaneAddedEventArgs_t2550175725_marshal_pinvoke_cleanup(PlaneAddedEventArgs_t2550175725_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: UnityEngine.Experimental.XR.PlaneAddedEventArgs
extern "C" void PlaneAddedEventArgs_t2550175725_marshal_com(const PlaneAddedEventArgs_t2550175725& unmarshaled, PlaneAddedEventArgs_t2550175725_marshaled_com& marshaled)
{
	Exception_t* ___U3CPlaneSubsystemU3Ek__BackingField_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '<PlaneSubsystem>k__BackingField' of type 'PlaneAddedEventArgs': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___U3CPlaneSubsystemU3Ek__BackingField_0Exception, NULL, NULL);
}
extern "C" void PlaneAddedEventArgs_t2550175725_marshal_com_back(const PlaneAddedEventArgs_t2550175725_marshaled_com& marshaled, PlaneAddedEventArgs_t2550175725& unmarshaled)
{
	Exception_t* ___U3CPlaneSubsystemU3Ek__BackingField_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '<PlaneSubsystem>k__BackingField' of type 'PlaneAddedEventArgs': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___U3CPlaneSubsystemU3Ek__BackingField_0Exception, NULL, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.Experimental.XR.PlaneAddedEventArgs
extern "C" void PlaneAddedEventArgs_t2550175725_marshal_com_cleanup(PlaneAddedEventArgs_t2550175725_marshaled_com& marshaled)
{
}
// System.Void UnityEngine.Experimental.XR.PlaneAddedEventArgs::set_PlaneSubsystem(UnityEngine.Experimental.XR.XRPlaneSubsystem)
extern "C" IL2CPP_METHOD_ATTR void PlaneAddedEventArgs_set_PlaneSubsystem_m3627276178 (PlaneAddedEventArgs_t2550175725 * __this, XRPlaneSubsystem_t2260142932 * ___value0, const RuntimeMethod* method)
{
	{
		XRPlaneSubsystem_t2260142932 * L_0 = ___value0;
		__this->set_U3CPlaneSubsystemU3Ek__BackingField_0(L_0);
		return;
	}
}
extern "C"  void PlaneAddedEventArgs_set_PlaneSubsystem_m3627276178_AdjustorThunk (RuntimeObject * __this, XRPlaneSubsystem_t2260142932 * ___value0, const RuntimeMethod* method)
{
	PlaneAddedEventArgs_t2550175725 * _thisAdjusted = reinterpret_cast<PlaneAddedEventArgs_t2550175725 *>(__this + 1);
	PlaneAddedEventArgs_set_PlaneSubsystem_m3627276178(_thisAdjusted, ___value0, method);
}
// UnityEngine.Experimental.XR.BoundedPlane UnityEngine.Experimental.XR.PlaneAddedEventArgs::get_Plane()
extern "C" IL2CPP_METHOD_ATTR BoundedPlane_t1317492334  PlaneAddedEventArgs_get_Plane_m1121979519 (PlaneAddedEventArgs_t2550175725 * __this, const RuntimeMethod* method)
{
	BoundedPlane_t1317492334  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		BoundedPlane_t1317492334  L_0 = __this->get_U3CPlaneU3Ek__BackingField_1();
		V_0 = L_0;
		goto IL_000c;
	}

IL_000c:
	{
		BoundedPlane_t1317492334  L_1 = V_0;
		return L_1;
	}
}
extern "C"  BoundedPlane_t1317492334  PlaneAddedEventArgs_get_Plane_m1121979519_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	PlaneAddedEventArgs_t2550175725 * _thisAdjusted = reinterpret_cast<PlaneAddedEventArgs_t2550175725 *>(__this + 1);
	return PlaneAddedEventArgs_get_Plane_m1121979519(_thisAdjusted, method);
}
// System.Void UnityEngine.Experimental.XR.PlaneAddedEventArgs::set_Plane(UnityEngine.Experimental.XR.BoundedPlane)
extern "C" IL2CPP_METHOD_ATTR void PlaneAddedEventArgs_set_Plane_m3532199823 (PlaneAddedEventArgs_t2550175725 * __this, BoundedPlane_t1317492334  ___value0, const RuntimeMethod* method)
{
	{
		BoundedPlane_t1317492334  L_0 = ___value0;
		__this->set_U3CPlaneU3Ek__BackingField_1(L_0);
		return;
	}
}
extern "C"  void PlaneAddedEventArgs_set_Plane_m3532199823_AdjustorThunk (RuntimeObject * __this, BoundedPlane_t1317492334  ___value0, const RuntimeMethod* method)
{
	PlaneAddedEventArgs_t2550175725 * _thisAdjusted = reinterpret_cast<PlaneAddedEventArgs_t2550175725 *>(__this + 1);
	PlaneAddedEventArgs_set_Plane_m3532199823(_thisAdjusted, ___value0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: UnityEngine.Experimental.XR.PlaneRemovedEventArgs
extern "C" void PlaneRemovedEventArgs_t1567129782_marshal_pinvoke(const PlaneRemovedEventArgs_t1567129782& unmarshaled, PlaneRemovedEventArgs_t1567129782_marshaled_pinvoke& marshaled)
{
	Exception_t* ___U3CPlaneSubsystemU3Ek__BackingField_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '<PlaneSubsystem>k__BackingField' of type 'PlaneRemovedEventArgs': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___U3CPlaneSubsystemU3Ek__BackingField_0Exception, NULL, NULL);
}
extern "C" void PlaneRemovedEventArgs_t1567129782_marshal_pinvoke_back(const PlaneRemovedEventArgs_t1567129782_marshaled_pinvoke& marshaled, PlaneRemovedEventArgs_t1567129782& unmarshaled)
{
	Exception_t* ___U3CPlaneSubsystemU3Ek__BackingField_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '<PlaneSubsystem>k__BackingField' of type 'PlaneRemovedEventArgs': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___U3CPlaneSubsystemU3Ek__BackingField_0Exception, NULL, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.Experimental.XR.PlaneRemovedEventArgs
extern "C" void PlaneRemovedEventArgs_t1567129782_marshal_pinvoke_cleanup(PlaneRemovedEventArgs_t1567129782_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: UnityEngine.Experimental.XR.PlaneRemovedEventArgs
extern "C" void PlaneRemovedEventArgs_t1567129782_marshal_com(const PlaneRemovedEventArgs_t1567129782& unmarshaled, PlaneRemovedEventArgs_t1567129782_marshaled_com& marshaled)
{
	Exception_t* ___U3CPlaneSubsystemU3Ek__BackingField_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '<PlaneSubsystem>k__BackingField' of type 'PlaneRemovedEventArgs': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___U3CPlaneSubsystemU3Ek__BackingField_0Exception, NULL, NULL);
}
extern "C" void PlaneRemovedEventArgs_t1567129782_marshal_com_back(const PlaneRemovedEventArgs_t1567129782_marshaled_com& marshaled, PlaneRemovedEventArgs_t1567129782& unmarshaled)
{
	Exception_t* ___U3CPlaneSubsystemU3Ek__BackingField_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '<PlaneSubsystem>k__BackingField' of type 'PlaneRemovedEventArgs': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___U3CPlaneSubsystemU3Ek__BackingField_0Exception, NULL, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.Experimental.XR.PlaneRemovedEventArgs
extern "C" void PlaneRemovedEventArgs_t1567129782_marshal_com_cleanup(PlaneRemovedEventArgs_t1567129782_marshaled_com& marshaled)
{
}
// System.Void UnityEngine.Experimental.XR.PlaneRemovedEventArgs::set_PlaneSubsystem(UnityEngine.Experimental.XR.XRPlaneSubsystem)
extern "C" IL2CPP_METHOD_ATTR void PlaneRemovedEventArgs_set_PlaneSubsystem_m2373342326 (PlaneRemovedEventArgs_t1567129782 * __this, XRPlaneSubsystem_t2260142932 * ___value0, const RuntimeMethod* method)
{
	{
		XRPlaneSubsystem_t2260142932 * L_0 = ___value0;
		__this->set_U3CPlaneSubsystemU3Ek__BackingField_0(L_0);
		return;
	}
}
extern "C"  void PlaneRemovedEventArgs_set_PlaneSubsystem_m2373342326_AdjustorThunk (RuntimeObject * __this, XRPlaneSubsystem_t2260142932 * ___value0, const RuntimeMethod* method)
{
	PlaneRemovedEventArgs_t1567129782 * _thisAdjusted = reinterpret_cast<PlaneRemovedEventArgs_t1567129782 *>(__this + 1);
	PlaneRemovedEventArgs_set_PlaneSubsystem_m2373342326(_thisAdjusted, ___value0, method);
}
// UnityEngine.Experimental.XR.BoundedPlane UnityEngine.Experimental.XR.PlaneRemovedEventArgs::get_Plane()
extern "C" IL2CPP_METHOD_ATTR BoundedPlane_t1317492334  PlaneRemovedEventArgs_get_Plane_m1826377031 (PlaneRemovedEventArgs_t1567129782 * __this, const RuntimeMethod* method)
{
	BoundedPlane_t1317492334  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		BoundedPlane_t1317492334  L_0 = __this->get_U3CPlaneU3Ek__BackingField_1();
		V_0 = L_0;
		goto IL_000c;
	}

IL_000c:
	{
		BoundedPlane_t1317492334  L_1 = V_0;
		return L_1;
	}
}
extern "C"  BoundedPlane_t1317492334  PlaneRemovedEventArgs_get_Plane_m1826377031_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	PlaneRemovedEventArgs_t1567129782 * _thisAdjusted = reinterpret_cast<PlaneRemovedEventArgs_t1567129782 *>(__this + 1);
	return PlaneRemovedEventArgs_get_Plane_m1826377031(_thisAdjusted, method);
}
// System.Void UnityEngine.Experimental.XR.PlaneRemovedEventArgs::set_Plane(UnityEngine.Experimental.XR.BoundedPlane)
extern "C" IL2CPP_METHOD_ATTR void PlaneRemovedEventArgs_set_Plane_m290598833 (PlaneRemovedEventArgs_t1567129782 * __this, BoundedPlane_t1317492334  ___value0, const RuntimeMethod* method)
{
	{
		BoundedPlane_t1317492334  L_0 = ___value0;
		__this->set_U3CPlaneU3Ek__BackingField_1(L_0);
		return;
	}
}
extern "C"  void PlaneRemovedEventArgs_set_Plane_m290598833_AdjustorThunk (RuntimeObject * __this, BoundedPlane_t1317492334  ___value0, const RuntimeMethod* method)
{
	PlaneRemovedEventArgs_t1567129782 * _thisAdjusted = reinterpret_cast<PlaneRemovedEventArgs_t1567129782 *>(__this + 1);
	PlaneRemovedEventArgs_set_Plane_m290598833(_thisAdjusted, ___value0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: UnityEngine.Experimental.XR.PlaneUpdatedEventArgs
extern "C" void PlaneUpdatedEventArgs_t349485851_marshal_pinvoke(const PlaneUpdatedEventArgs_t349485851& unmarshaled, PlaneUpdatedEventArgs_t349485851_marshaled_pinvoke& marshaled)
{
	Exception_t* ___U3CPlaneSubsystemU3Ek__BackingField_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '<PlaneSubsystem>k__BackingField' of type 'PlaneUpdatedEventArgs': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___U3CPlaneSubsystemU3Ek__BackingField_0Exception, NULL, NULL);
}
extern "C" void PlaneUpdatedEventArgs_t349485851_marshal_pinvoke_back(const PlaneUpdatedEventArgs_t349485851_marshaled_pinvoke& marshaled, PlaneUpdatedEventArgs_t349485851& unmarshaled)
{
	Exception_t* ___U3CPlaneSubsystemU3Ek__BackingField_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '<PlaneSubsystem>k__BackingField' of type 'PlaneUpdatedEventArgs': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___U3CPlaneSubsystemU3Ek__BackingField_0Exception, NULL, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.Experimental.XR.PlaneUpdatedEventArgs
extern "C" void PlaneUpdatedEventArgs_t349485851_marshal_pinvoke_cleanup(PlaneUpdatedEventArgs_t349485851_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: UnityEngine.Experimental.XR.PlaneUpdatedEventArgs
extern "C" void PlaneUpdatedEventArgs_t349485851_marshal_com(const PlaneUpdatedEventArgs_t349485851& unmarshaled, PlaneUpdatedEventArgs_t349485851_marshaled_com& marshaled)
{
	Exception_t* ___U3CPlaneSubsystemU3Ek__BackingField_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '<PlaneSubsystem>k__BackingField' of type 'PlaneUpdatedEventArgs': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___U3CPlaneSubsystemU3Ek__BackingField_0Exception, NULL, NULL);
}
extern "C" void PlaneUpdatedEventArgs_t349485851_marshal_com_back(const PlaneUpdatedEventArgs_t349485851_marshaled_com& marshaled, PlaneUpdatedEventArgs_t349485851& unmarshaled)
{
	Exception_t* ___U3CPlaneSubsystemU3Ek__BackingField_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field '<PlaneSubsystem>k__BackingField' of type 'PlaneUpdatedEventArgs': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___U3CPlaneSubsystemU3Ek__BackingField_0Exception, NULL, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.Experimental.XR.PlaneUpdatedEventArgs
extern "C" void PlaneUpdatedEventArgs_t349485851_marshal_com_cleanup(PlaneUpdatedEventArgs_t349485851_marshaled_com& marshaled)
{
}
// System.Void UnityEngine.Experimental.XR.PlaneUpdatedEventArgs::set_PlaneSubsystem(UnityEngine.Experimental.XR.XRPlaneSubsystem)
extern "C" IL2CPP_METHOD_ATTR void PlaneUpdatedEventArgs_set_PlaneSubsystem_m79632840 (PlaneUpdatedEventArgs_t349485851 * __this, XRPlaneSubsystem_t2260142932 * ___value0, const RuntimeMethod* method)
{
	{
		XRPlaneSubsystem_t2260142932 * L_0 = ___value0;
		__this->set_U3CPlaneSubsystemU3Ek__BackingField_0(L_0);
		return;
	}
}
extern "C"  void PlaneUpdatedEventArgs_set_PlaneSubsystem_m79632840_AdjustorThunk (RuntimeObject * __this, XRPlaneSubsystem_t2260142932 * ___value0, const RuntimeMethod* method)
{
	PlaneUpdatedEventArgs_t349485851 * _thisAdjusted = reinterpret_cast<PlaneUpdatedEventArgs_t349485851 *>(__this + 1);
	PlaneUpdatedEventArgs_set_PlaneSubsystem_m79632840(_thisAdjusted, ___value0, method);
}
// UnityEngine.Experimental.XR.BoundedPlane UnityEngine.Experimental.XR.PlaneUpdatedEventArgs::get_Plane()
extern "C" IL2CPP_METHOD_ATTR BoundedPlane_t1317492334  PlaneUpdatedEventArgs_get_Plane_m4053759216 (PlaneUpdatedEventArgs_t349485851 * __this, const RuntimeMethod* method)
{
	BoundedPlane_t1317492334  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		BoundedPlane_t1317492334  L_0 = __this->get_U3CPlaneU3Ek__BackingField_1();
		V_0 = L_0;
		goto IL_000c;
	}

IL_000c:
	{
		BoundedPlane_t1317492334  L_1 = V_0;
		return L_1;
	}
}
extern "C"  BoundedPlane_t1317492334  PlaneUpdatedEventArgs_get_Plane_m4053759216_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	PlaneUpdatedEventArgs_t349485851 * _thisAdjusted = reinterpret_cast<PlaneUpdatedEventArgs_t349485851 *>(__this + 1);
	return PlaneUpdatedEventArgs_get_Plane_m4053759216(_thisAdjusted, method);
}
// System.Void UnityEngine.Experimental.XR.PlaneUpdatedEventArgs::set_Plane(UnityEngine.Experimental.XR.BoundedPlane)
extern "C" IL2CPP_METHOD_ATTR void PlaneUpdatedEventArgs_set_Plane_m3296874754 (PlaneUpdatedEventArgs_t349485851 * __this, BoundedPlane_t1317492334  ___value0, const RuntimeMethod* method)
{
	{
		BoundedPlane_t1317492334  L_0 = ___value0;
		__this->set_U3CPlaneU3Ek__BackingField_1(L_0);
		return;
	}
}
extern "C"  void PlaneUpdatedEventArgs_set_Plane_m3296874754_AdjustorThunk (RuntimeObject * __this, BoundedPlane_t1317492334  ___value0, const RuntimeMethod* method)
{
	PlaneUpdatedEventArgs_t349485851 * _thisAdjusted = reinterpret_cast<PlaneUpdatedEventArgs_t349485851 *>(__this + 1);
	PlaneUpdatedEventArgs_set_Plane_m3296874754(_thisAdjusted, ___value0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: UnityEngine.Experimental.XR.PointCloudUpdatedEventArgs
extern "C" void PointCloudUpdatedEventArgs_t3436657348_marshal_pinvoke(const PointCloudUpdatedEventArgs_t3436657348& unmarshaled, PointCloudUpdatedEventArgs_t3436657348_marshaled_pinvoke& marshaled)
{
	Exception_t* ___m_DepthSubsystem_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_DepthSubsystem' of type 'PointCloudUpdatedEventArgs': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_DepthSubsystem_0Exception, NULL, NULL);
}
extern "C" void PointCloudUpdatedEventArgs_t3436657348_marshal_pinvoke_back(const PointCloudUpdatedEventArgs_t3436657348_marshaled_pinvoke& marshaled, PointCloudUpdatedEventArgs_t3436657348& unmarshaled)
{
	Exception_t* ___m_DepthSubsystem_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_DepthSubsystem' of type 'PointCloudUpdatedEventArgs': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_DepthSubsystem_0Exception, NULL, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.Experimental.XR.PointCloudUpdatedEventArgs
extern "C" void PointCloudUpdatedEventArgs_t3436657348_marshal_pinvoke_cleanup(PointCloudUpdatedEventArgs_t3436657348_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: UnityEngine.Experimental.XR.PointCloudUpdatedEventArgs
extern "C" void PointCloudUpdatedEventArgs_t3436657348_marshal_com(const PointCloudUpdatedEventArgs_t3436657348& unmarshaled, PointCloudUpdatedEventArgs_t3436657348_marshaled_com& marshaled)
{
	Exception_t* ___m_DepthSubsystem_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_DepthSubsystem' of type 'PointCloudUpdatedEventArgs': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_DepthSubsystem_0Exception, NULL, NULL);
}
extern "C" void PointCloudUpdatedEventArgs_t3436657348_marshal_com_back(const PointCloudUpdatedEventArgs_t3436657348_marshaled_com& marshaled, PointCloudUpdatedEventArgs_t3436657348& unmarshaled)
{
	Exception_t* ___m_DepthSubsystem_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_DepthSubsystem' of type 'PointCloudUpdatedEventArgs': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_DepthSubsystem_0Exception, NULL, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.Experimental.XR.PointCloudUpdatedEventArgs
extern "C" void PointCloudUpdatedEventArgs_t3436657348_marshal_com_cleanup(PointCloudUpdatedEventArgs_t3436657348_marshaled_com& marshaled)
{
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// UnityEngine.Experimental.XR.TrackableId UnityEngine.Experimental.XR.ReferencePoint::get_Id()
extern "C" IL2CPP_METHOD_ATTR TrackableId_t1251031970  ReferencePoint_get_Id_m2943140397 (ReferencePoint_t394942483 * __this, const RuntimeMethod* method)
{
	TrackableId_t1251031970  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		TrackableId_t1251031970  L_0 = __this->get_U3CIdU3Ek__BackingField_0();
		V_0 = L_0;
		goto IL_000c;
	}

IL_000c:
	{
		TrackableId_t1251031970  L_1 = V_0;
		return L_1;
	}
}
extern "C"  TrackableId_t1251031970  ReferencePoint_get_Id_m2943140397_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	ReferencePoint_t394942483 * _thisAdjusted = reinterpret_cast<ReferencePoint_t394942483 *>(__this + 1);
	return ReferencePoint_get_Id_m2943140397(_thisAdjusted, method);
}
// UnityEngine.Experimental.XR.TrackingState UnityEngine.Experimental.XR.ReferencePoint::get_TrackingState()
extern "C" IL2CPP_METHOD_ATTR int32_t ReferencePoint_get_TrackingState_m1298782521 (ReferencePoint_t394942483 * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	{
		int32_t L_0 = __this->get_U3CTrackingStateU3Ek__BackingField_1();
		V_0 = L_0;
		goto IL_000c;
	}

IL_000c:
	{
		int32_t L_1 = V_0;
		return L_1;
	}
}
extern "C"  int32_t ReferencePoint_get_TrackingState_m1298782521_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	ReferencePoint_t394942483 * _thisAdjusted = reinterpret_cast<ReferencePoint_t394942483 *>(__this + 1);
	return ReferencePoint_get_TrackingState_m1298782521(_thisAdjusted, method);
}
// UnityEngine.Pose UnityEngine.Experimental.XR.ReferencePoint::get_Pose()
extern "C" IL2CPP_METHOD_ATTR Pose_t545244865  ReferencePoint_get_Pose_m3423701085 (ReferencePoint_t394942483 * __this, const RuntimeMethod* method)
{
	Pose_t545244865  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		Pose_t545244865  L_0 = __this->get_U3CPoseU3Ek__BackingField_2();
		V_0 = L_0;
		goto IL_000c;
	}

IL_000c:
	{
		Pose_t545244865  L_1 = V_0;
		return L_1;
	}
}
extern "C"  Pose_t545244865  ReferencePoint_get_Pose_m3423701085_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	ReferencePoint_t394942483 * _thisAdjusted = reinterpret_cast<ReferencePoint_t394942483 *>(__this + 1);
	return ReferencePoint_get_Pose_m3423701085(_thisAdjusted, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// UnityEngine.Experimental.XR.ReferencePoint UnityEngine.Experimental.XR.ReferencePointUpdatedEventArgs::get_ReferencePoint()
extern "C" IL2CPP_METHOD_ATTR ReferencePoint_t394942483  ReferencePointUpdatedEventArgs_get_ReferencePoint_m598134072 (ReferencePointUpdatedEventArgs_t2046512733 * __this, const RuntimeMethod* method)
{
	ReferencePoint_t394942483  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		ReferencePoint_t394942483  L_0 = __this->get_U3CReferencePointU3Ek__BackingField_0();
		V_0 = L_0;
		goto IL_000c;
	}

IL_000c:
	{
		ReferencePoint_t394942483  L_1 = V_0;
		return L_1;
	}
}
extern "C"  ReferencePoint_t394942483  ReferencePointUpdatedEventArgs_get_ReferencePoint_m598134072_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	ReferencePointUpdatedEventArgs_t2046512733 * _thisAdjusted = reinterpret_cast<ReferencePointUpdatedEventArgs_t2046512733 *>(__this + 1);
	return ReferencePointUpdatedEventArgs_get_ReferencePoint_m598134072(_thisAdjusted, method);
}
// System.Void UnityEngine.Experimental.XR.ReferencePointUpdatedEventArgs::set_ReferencePoint(UnityEngine.Experimental.XR.ReferencePoint)
extern "C" IL2CPP_METHOD_ATTR void ReferencePointUpdatedEventArgs_set_ReferencePoint_m2108838300 (ReferencePointUpdatedEventArgs_t2046512733 * __this, ReferencePoint_t394942483  ___value0, const RuntimeMethod* method)
{
	{
		ReferencePoint_t394942483  L_0 = ___value0;
		__this->set_U3CReferencePointU3Ek__BackingField_0(L_0);
		return;
	}
}
extern "C"  void ReferencePointUpdatedEventArgs_set_ReferencePoint_m2108838300_AdjustorThunk (RuntimeObject * __this, ReferencePoint_t394942483  ___value0, const RuntimeMethod* method)
{
	ReferencePointUpdatedEventArgs_t2046512733 * _thisAdjusted = reinterpret_cast<ReferencePointUpdatedEventArgs_t2046512733 *>(__this + 1);
	ReferencePointUpdatedEventArgs_set_ReferencePoint_m2108838300(_thisAdjusted, ___value0, method);
}
// UnityEngine.Experimental.XR.TrackingState UnityEngine.Experimental.XR.ReferencePointUpdatedEventArgs::get_PreviousTrackingState()
extern "C" IL2CPP_METHOD_ATTR int32_t ReferencePointUpdatedEventArgs_get_PreviousTrackingState_m4262564055 (ReferencePointUpdatedEventArgs_t2046512733 * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	{
		int32_t L_0 = __this->get_U3CPreviousTrackingStateU3Ek__BackingField_1();
		V_0 = L_0;
		goto IL_000c;
	}

IL_000c:
	{
		int32_t L_1 = V_0;
		return L_1;
	}
}
extern "C"  int32_t ReferencePointUpdatedEventArgs_get_PreviousTrackingState_m4262564055_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	ReferencePointUpdatedEventArgs_t2046512733 * _thisAdjusted = reinterpret_cast<ReferencePointUpdatedEventArgs_t2046512733 *>(__this + 1);
	return ReferencePointUpdatedEventArgs_get_PreviousTrackingState_m4262564055(_thisAdjusted, method);
}
// System.Void UnityEngine.Experimental.XR.ReferencePointUpdatedEventArgs::set_PreviousTrackingState(UnityEngine.Experimental.XR.TrackingState)
extern "C" IL2CPP_METHOD_ATTR void ReferencePointUpdatedEventArgs_set_PreviousTrackingState_m363545448 (ReferencePointUpdatedEventArgs_t2046512733 * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		int32_t L_0 = ___value0;
		__this->set_U3CPreviousTrackingStateU3Ek__BackingField_1(L_0);
		return;
	}
}
extern "C"  void ReferencePointUpdatedEventArgs_set_PreviousTrackingState_m363545448_AdjustorThunk (RuntimeObject * __this, int32_t ___value0, const RuntimeMethod* method)
{
	ReferencePointUpdatedEventArgs_t2046512733 * _thisAdjusted = reinterpret_cast<ReferencePointUpdatedEventArgs_t2046512733 *>(__this + 1);
	ReferencePointUpdatedEventArgs_set_PreviousTrackingState_m363545448(_thisAdjusted, ___value0, method);
}
// UnityEngine.Pose UnityEngine.Experimental.XR.ReferencePointUpdatedEventArgs::get_PreviousPose()
extern "C" IL2CPP_METHOD_ATTR Pose_t545244865  ReferencePointUpdatedEventArgs_get_PreviousPose_m4125863928 (ReferencePointUpdatedEventArgs_t2046512733 * __this, const RuntimeMethod* method)
{
	Pose_t545244865  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		Pose_t545244865  L_0 = __this->get_U3CPreviousPoseU3Ek__BackingField_2();
		V_0 = L_0;
		goto IL_000c;
	}

IL_000c:
	{
		Pose_t545244865  L_1 = V_0;
		return L_1;
	}
}
extern "C"  Pose_t545244865  ReferencePointUpdatedEventArgs_get_PreviousPose_m4125863928_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	ReferencePointUpdatedEventArgs_t2046512733 * _thisAdjusted = reinterpret_cast<ReferencePointUpdatedEventArgs_t2046512733 *>(__this + 1);
	return ReferencePointUpdatedEventArgs_get_PreviousPose_m4125863928(_thisAdjusted, method);
}
// System.Void UnityEngine.Experimental.XR.ReferencePointUpdatedEventArgs::set_PreviousPose(UnityEngine.Pose)
extern "C" IL2CPP_METHOD_ATTR void ReferencePointUpdatedEventArgs_set_PreviousPose_m2838622129 (ReferencePointUpdatedEventArgs_t2046512733 * __this, Pose_t545244865  ___value0, const RuntimeMethod* method)
{
	{
		Pose_t545244865  L_0 = ___value0;
		__this->set_U3CPreviousPoseU3Ek__BackingField_2(L_0);
		return;
	}
}
extern "C"  void ReferencePointUpdatedEventArgs_set_PreviousPose_m2838622129_AdjustorThunk (RuntimeObject * __this, Pose_t545244865  ___value0, const RuntimeMethod* method)
{
	ReferencePointUpdatedEventArgs_t2046512733 * _thisAdjusted = reinterpret_cast<ReferencePointUpdatedEventArgs_t2046512733 *>(__this + 1);
	ReferencePointUpdatedEventArgs_set_PreviousPose_m2838622129(_thisAdjusted, ___value0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: UnityEngine.Experimental.XR.SessionTrackingStateChangedEventArgs
extern "C" void SessionTrackingStateChangedEventArgs_t2343035655_marshal_pinvoke(const SessionTrackingStateChangedEventArgs_t2343035655& unmarshaled, SessionTrackingStateChangedEventArgs_t2343035655_marshaled_pinvoke& marshaled)
{
	Exception_t* ___m_Session_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_Session' of type 'SessionTrackingStateChangedEventArgs': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_Session_0Exception, NULL, NULL);
}
extern "C" void SessionTrackingStateChangedEventArgs_t2343035655_marshal_pinvoke_back(const SessionTrackingStateChangedEventArgs_t2343035655_marshaled_pinvoke& marshaled, SessionTrackingStateChangedEventArgs_t2343035655& unmarshaled)
{
	Exception_t* ___m_Session_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_Session' of type 'SessionTrackingStateChangedEventArgs': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_Session_0Exception, NULL, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.Experimental.XR.SessionTrackingStateChangedEventArgs
extern "C" void SessionTrackingStateChangedEventArgs_t2343035655_marshal_pinvoke_cleanup(SessionTrackingStateChangedEventArgs_t2343035655_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: UnityEngine.Experimental.XR.SessionTrackingStateChangedEventArgs
extern "C" void SessionTrackingStateChangedEventArgs_t2343035655_marshal_com(const SessionTrackingStateChangedEventArgs_t2343035655& unmarshaled, SessionTrackingStateChangedEventArgs_t2343035655_marshaled_com& marshaled)
{
	Exception_t* ___m_Session_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_Session' of type 'SessionTrackingStateChangedEventArgs': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_Session_0Exception, NULL, NULL);
}
extern "C" void SessionTrackingStateChangedEventArgs_t2343035655_marshal_com_back(const SessionTrackingStateChangedEventArgs_t2343035655_marshaled_com& marshaled, SessionTrackingStateChangedEventArgs_t2343035655& unmarshaled)
{
	Exception_t* ___m_Session_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_Session' of type 'SessionTrackingStateChangedEventArgs': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_Session_0Exception, NULL, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.Experimental.XR.SessionTrackingStateChangedEventArgs
extern "C" void SessionTrackingStateChangedEventArgs_t2343035655_marshal_com_cleanup(SessionTrackingStateChangedEventArgs_t2343035655_marshaled_com& marshaled)
{
}
// UnityEngine.Experimental.XR.TrackingState UnityEngine.Experimental.XR.SessionTrackingStateChangedEventArgs::get_NewState()
extern "C" IL2CPP_METHOD_ATTR int32_t SessionTrackingStateChangedEventArgs_get_NewState_m1657962755 (SessionTrackingStateChangedEventArgs_t2343035655 * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	{
		int32_t L_0 = __this->get_U3CNewStateU3Ek__BackingField_1();
		V_0 = L_0;
		goto IL_000c;
	}

IL_000c:
	{
		int32_t L_1 = V_0;
		return L_1;
	}
}
extern "C"  int32_t SessionTrackingStateChangedEventArgs_get_NewState_m1657962755_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	SessionTrackingStateChangedEventArgs_t2343035655 * _thisAdjusted = reinterpret_cast<SessionTrackingStateChangedEventArgs_t2343035655 *>(__this + 1);
	return SessionTrackingStateChangedEventArgs_get_NewState_m1657962755(_thisAdjusted, method);
}
// System.Void UnityEngine.Experimental.XR.SessionTrackingStateChangedEventArgs::set_NewState(UnityEngine.Experimental.XR.TrackingState)
extern "C" IL2CPP_METHOD_ATTR void SessionTrackingStateChangedEventArgs_set_NewState_m3890790011 (SessionTrackingStateChangedEventArgs_t2343035655 * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		int32_t L_0 = ___value0;
		__this->set_U3CNewStateU3Ek__BackingField_1(L_0);
		return;
	}
}
extern "C"  void SessionTrackingStateChangedEventArgs_set_NewState_m3890790011_AdjustorThunk (RuntimeObject * __this, int32_t ___value0, const RuntimeMethod* method)
{
	SessionTrackingStateChangedEventArgs_t2343035655 * _thisAdjusted = reinterpret_cast<SessionTrackingStateChangedEventArgs_t2343035655 *>(__this + 1);
	SessionTrackingStateChangedEventArgs_set_NewState_m3890790011(_thisAdjusted, ___value0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.String UnityEngine.Experimental.XR.TrackableId::ToString()
extern "C" IL2CPP_METHOD_ATTR String_t* TrackableId_ToString_m2456781735 (TrackableId_t1251031970 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TrackableId_ToString_m2456781735_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	String_t* V_0 = NULL;
	{
		uint64_t* L_0 = __this->get_address_of_m_SubId1_1();
		String_t* L_1 = UInt64_ToString_m2177233542((uint64_t*)L_0, _stringLiteral2268009268, /*hidden argument*/NULL);
		uint64_t* L_2 = __this->get_address_of_m_SubId2_2();
		String_t* L_3 = UInt64_ToString_m2177233542((uint64_t*)L_2, _stringLiteral2268009268, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_4 = String_Format_m2556382932(NULL /*static, unused*/, _stringLiteral4273954858, L_1, L_3, /*hidden argument*/NULL);
		V_0 = L_4;
		goto IL_0031;
	}

IL_0031:
	{
		String_t* L_5 = V_0;
		return L_5;
	}
}
extern "C"  String_t* TrackableId_ToString_m2456781735_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	TrackableId_t1251031970 * _thisAdjusted = reinterpret_cast<TrackableId_t1251031970 *>(__this + 1);
	return TrackableId_ToString_m2456781735(_thisAdjusted, method);
}
// System.Int32 UnityEngine.Experimental.XR.TrackableId::GetHashCode()
extern "C" IL2CPP_METHOD_ATTR int32_t TrackableId_GetHashCode_m3350007337 (TrackableId_t1251031970 * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	{
		uint64_t* L_0 = __this->get_address_of_m_SubId1_1();
		int32_t L_1 = UInt64_GetHashCode_m4209760355((uint64_t*)L_0, /*hidden argument*/NULL);
		uint64_t* L_2 = __this->get_address_of_m_SubId2_2();
		int32_t L_3 = UInt64_GetHashCode_m4209760355((uint64_t*)L_2, /*hidden argument*/NULL);
		V_0 = ((int32_t)((int32_t)L_1^(int32_t)L_3));
		goto IL_002a;
	}

IL_002a:
	{
		int32_t L_4 = V_0;
		return L_4;
	}
}
extern "C"  int32_t TrackableId_GetHashCode_m3350007337_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	TrackableId_t1251031970 * _thisAdjusted = reinterpret_cast<TrackableId_t1251031970 *>(__this + 1);
	return TrackableId_GetHashCode_m3350007337(_thisAdjusted, method);
}
// System.Boolean UnityEngine.Experimental.XR.TrackableId::Equals(System.Object)
extern "C" IL2CPP_METHOD_ATTR bool TrackableId_Equals_m1354170007 (TrackableId_t1251031970 * __this, RuntimeObject * ___obj0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TrackableId_Equals_m1354170007_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	int32_t G_B3_0 = 0;
	{
		RuntimeObject * L_0 = ___obj0;
		if (!((RuntimeObject *)IsInstSealed((RuntimeObject*)L_0, TrackableId_t1251031970_il2cpp_TypeInfo_var)))
		{
			goto IL_001a;
		}
	}
	{
		RuntimeObject * L_1 = ___obj0;
		bool L_2 = TrackableId_Equals_m902745601((TrackableId_t1251031970 *)__this, ((*(TrackableId_t1251031970 *)((TrackableId_t1251031970 *)UnBox(L_1, TrackableId_t1251031970_il2cpp_TypeInfo_var)))), /*hidden argument*/NULL);
		G_B3_0 = ((int32_t)(L_2));
		goto IL_001b;
	}

IL_001a:
	{
		G_B3_0 = 0;
	}

IL_001b:
	{
		V_0 = (bool)G_B3_0;
		goto IL_0021;
	}

IL_0021:
	{
		bool L_3 = V_0;
		return L_3;
	}
}
extern "C"  bool TrackableId_Equals_m1354170007_AdjustorThunk (RuntimeObject * __this, RuntimeObject * ___obj0, const RuntimeMethod* method)
{
	TrackableId_t1251031970 * _thisAdjusted = reinterpret_cast<TrackableId_t1251031970 *>(__this + 1);
	return TrackableId_Equals_m1354170007(_thisAdjusted, ___obj0, method);
}
// System.Boolean UnityEngine.Experimental.XR.TrackableId::Equals(UnityEngine.Experimental.XR.TrackableId)
extern "C" IL2CPP_METHOD_ATTR bool TrackableId_Equals_m902745601 (TrackableId_t1251031970 * __this, TrackableId_t1251031970  ___other0, const RuntimeMethod* method)
{
	bool V_0 = false;
	int32_t G_B3_0 = 0;
	{
		uint64_t L_0 = __this->get_m_SubId1_1();
		uint64_t L_1 = (&___other0)->get_m_SubId1_1();
		if ((!(((uint64_t)L_0) == ((uint64_t)L_1))))
		{
			goto IL_0024;
		}
	}
	{
		uint64_t L_2 = __this->get_m_SubId2_2();
		uint64_t L_3 = (&___other0)->get_m_SubId2_2();
		G_B3_0 = ((((int64_t)L_2) == ((int64_t)L_3))? 1 : 0);
		goto IL_0025;
	}

IL_0024:
	{
		G_B3_0 = 0;
	}

IL_0025:
	{
		V_0 = (bool)G_B3_0;
		goto IL_002b;
	}

IL_002b:
	{
		bool L_4 = V_0;
		return L_4;
	}
}
extern "C"  bool TrackableId_Equals_m902745601_AdjustorThunk (RuntimeObject * __this, TrackableId_t1251031970  ___other0, const RuntimeMethod* method)
{
	TrackableId_t1251031970 * _thisAdjusted = reinterpret_cast<TrackableId_t1251031970 *>(__this + 1);
	return TrackableId_Equals_m902745601(_thisAdjusted, ___other0, method);
}
// System.Boolean UnityEngine.Experimental.XR.TrackableId::op_Equality(UnityEngine.Experimental.XR.TrackableId,UnityEngine.Experimental.XR.TrackableId)
extern "C" IL2CPP_METHOD_ATTR bool TrackableId_op_Equality_m3948346579 (RuntimeObject * __this /* static, unused */, TrackableId_t1251031970  ___id10, TrackableId_t1251031970  ___id21, const RuntimeMethod* method)
{
	bool V_0 = false;
	int32_t G_B3_0 = 0;
	{
		uint64_t L_0 = (&___id10)->get_m_SubId1_1();
		uint64_t L_1 = (&___id21)->get_m_SubId1_1();
		if ((!(((uint64_t)L_0) == ((uint64_t)L_1))))
		{
			goto IL_0026;
		}
	}
	{
		uint64_t L_2 = (&___id10)->get_m_SubId2_2();
		uint64_t L_3 = (&___id21)->get_m_SubId2_2();
		G_B3_0 = ((((int64_t)L_2) == ((int64_t)L_3))? 1 : 0);
		goto IL_0027;
	}

IL_0026:
	{
		G_B3_0 = 0;
	}

IL_0027:
	{
		V_0 = (bool)G_B3_0;
		goto IL_002d;
	}

IL_002d:
	{
		bool L_4 = V_0;
		return L_4;
	}
}
// System.Boolean UnityEngine.Experimental.XR.TrackableId::op_Inequality(UnityEngine.Experimental.XR.TrackableId,UnityEngine.Experimental.XR.TrackableId)
extern "C" IL2CPP_METHOD_ATTR bool TrackableId_op_Inequality_m1871721427 (RuntimeObject * __this /* static, unused */, TrackableId_t1251031970  ___id10, TrackableId_t1251031970  ___id21, const RuntimeMethod* method)
{
	bool V_0 = false;
	int32_t G_B3_0 = 0;
	{
		uint64_t L_0 = (&___id10)->get_m_SubId1_1();
		uint64_t L_1 = (&___id21)->get_m_SubId1_1();
		if ((!(((uint64_t)L_0) == ((uint64_t)L_1))))
		{
			goto IL_0029;
		}
	}
	{
		uint64_t L_2 = (&___id10)->get_m_SubId2_2();
		uint64_t L_3 = (&___id21)->get_m_SubId2_2();
		G_B3_0 = ((((int32_t)((((int64_t)L_2) == ((int64_t)L_3))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_002a;
	}

IL_0029:
	{
		G_B3_0 = 1;
	}

IL_002a:
	{
		V_0 = (bool)G_B3_0;
		goto IL_0030;
	}

IL_0030:
	{
		bool L_4 = V_0;
		return L_4;
	}
}
// UnityEngine.Experimental.XR.TrackableId UnityEngine.Experimental.XR.TrackableId::get_InvalidId()
extern "C" IL2CPP_METHOD_ATTR TrackableId_t1251031970  TrackableId_get_InvalidId_m4062814271 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TrackableId_get_InvalidId_m4062814271_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	TrackableId_t1251031970  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		IL2CPP_RUNTIME_CLASS_INIT(TrackableId_t1251031970_il2cpp_TypeInfo_var);
		TrackableId_t1251031970  L_0 = ((TrackableId_t1251031970_StaticFields*)il2cpp_codegen_static_fields_for(TrackableId_t1251031970_il2cpp_TypeInfo_var))->get_s_InvalidId_0();
		V_0 = L_0;
		goto IL_000c;
	}

IL_000c:
	{
		TrackableId_t1251031970  L_1 = V_0;
		return L_1;
	}
}
// System.Void UnityEngine.Experimental.XR.TrackableId::.cctor()
extern "C" IL2CPP_METHOD_ATTR void TrackableId__cctor_m2923896333 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TrackableId__cctor_m2923896333_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	TrackableId_t1251031970  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		il2cpp_codegen_initobj((&V_0), sizeof(TrackableId_t1251031970 ));
		TrackableId_t1251031970  L_0 = V_0;
		((TrackableId_t1251031970_StaticFields*)il2cpp_codegen_static_fields_for(TrackableId_t1251031970_il2cpp_TypeInfo_var))->set_s_InvalidId_0(L_0);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.Experimental.XR.XRCameraSubsystem::set_LightEstimationRequested(System.Boolean)
extern "C" IL2CPP_METHOD_ATTR void XRCameraSubsystem_set_LightEstimationRequested_m2390610739 (XRCameraSubsystem_t4195795144 * __this, bool ___value0, const RuntimeMethod* method)
{
	typedef void (*XRCameraSubsystem_set_LightEstimationRequested_m2390610739_ftn) (XRCameraSubsystem_t4195795144 *, bool);
	static XRCameraSubsystem_set_LightEstimationRequested_m2390610739_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (XRCameraSubsystem_set_LightEstimationRequested_m2390610739_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.Experimental.XR.XRCameraSubsystem::set_LightEstimationRequested(System.Boolean)");
	_il2cpp_icall_func(__this, ___value0);
}
// System.Void UnityEngine.Experimental.XR.XRCameraSubsystem::set_Material(UnityEngine.Material)
extern "C" IL2CPP_METHOD_ATTR void XRCameraSubsystem_set_Material_m1835296269 (XRCameraSubsystem_t4195795144 * __this, Material_t340375123 * ___value0, const RuntimeMethod* method)
{
	typedef void (*XRCameraSubsystem_set_Material_m1835296269_ftn) (XRCameraSubsystem_t4195795144 *, Material_t340375123 *);
	static XRCameraSubsystem_set_Material_m1835296269_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (XRCameraSubsystem_set_Material_m1835296269_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.Experimental.XR.XRCameraSubsystem::set_Material(UnityEngine.Material)");
	_il2cpp_icall_func(__this, ___value0);
}
// UnityEngine.Camera UnityEngine.Experimental.XR.XRCameraSubsystem::get_Camera()
extern "C" IL2CPP_METHOD_ATTR Camera_t4157153871 * XRCameraSubsystem_get_Camera_m839867077 (XRCameraSubsystem_t4195795144 * __this, const RuntimeMethod* method)
{
	typedef Camera_t4157153871 * (*XRCameraSubsystem_get_Camera_m839867077_ftn) (XRCameraSubsystem_t4195795144 *);
	static XRCameraSubsystem_get_Camera_m839867077_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (XRCameraSubsystem_get_Camera_m839867077_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.Experimental.XR.XRCameraSubsystem::get_Camera()");
	Camera_t4157153871 * retVal = _il2cpp_icall_func(__this);
	return retVal;
}
// System.Void UnityEngine.Experimental.XR.XRCameraSubsystem::set_Camera(UnityEngine.Camera)
extern "C" IL2CPP_METHOD_ATTR void XRCameraSubsystem_set_Camera_m1391491698 (XRCameraSubsystem_t4195795144 * __this, Camera_t4157153871 * ___value0, const RuntimeMethod* method)
{
	typedef void (*XRCameraSubsystem_set_Camera_m1391491698_ftn) (XRCameraSubsystem_t4195795144 *, Camera_t4157153871 *);
	static XRCameraSubsystem_set_Camera_m1391491698_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (XRCameraSubsystem_set_Camera_m1391491698_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.Experimental.XR.XRCameraSubsystem::set_Camera(UnityEngine.Camera)");
	_il2cpp_icall_func(__this, ___value0);
}
// System.Boolean UnityEngine.Experimental.XR.XRCameraSubsystem::TryGetAverageBrightness(System.Single&)
extern "C" IL2CPP_METHOD_ATTR bool XRCameraSubsystem_TryGetAverageBrightness_m2260308262 (XRCameraSubsystem_t4195795144 * __this, float* ___averageBrightness0, const RuntimeMethod* method)
{
	typedef bool (*XRCameraSubsystem_TryGetAverageBrightness_m2260308262_ftn) (XRCameraSubsystem_t4195795144 *, float*);
	static XRCameraSubsystem_TryGetAverageBrightness_m2260308262_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (XRCameraSubsystem_TryGetAverageBrightness_m2260308262_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.Experimental.XR.XRCameraSubsystem::TryGetAverageBrightness(System.Single&)");
	bool retVal = _il2cpp_icall_func(__this, ___averageBrightness0);
	return retVal;
}
// System.Boolean UnityEngine.Experimental.XR.XRCameraSubsystem::TryGetAverageColorTemperature(System.Single&)
extern "C" IL2CPP_METHOD_ATTR bool XRCameraSubsystem_TryGetAverageColorTemperature_m1524856423 (XRCameraSubsystem_t4195795144 * __this, float* ___averageColorTemperature0, const RuntimeMethod* method)
{
	typedef bool (*XRCameraSubsystem_TryGetAverageColorTemperature_m1524856423_ftn) (XRCameraSubsystem_t4195795144 *, float*);
	static XRCameraSubsystem_TryGetAverageColorTemperature_m1524856423_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (XRCameraSubsystem_TryGetAverageColorTemperature_m1524856423_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.Experimental.XR.XRCameraSubsystem::TryGetAverageColorTemperature(System.Single&)");
	bool retVal = _il2cpp_icall_func(__this, ___averageColorTemperature0);
	return retVal;
}
// System.Boolean UnityEngine.Experimental.XR.XRCameraSubsystem::TryGetTimestamp(System.Int64&)
extern "C" IL2CPP_METHOD_ATTR bool XRCameraSubsystem_TryGetTimestamp_m253559658 (XRCameraSubsystem_t4195795144 * __this, int64_t* ___timestampNs0, const RuntimeMethod* method)
{
	typedef bool (*XRCameraSubsystem_TryGetTimestamp_m253559658_ftn) (XRCameraSubsystem_t4195795144 *, int64_t*);
	static XRCameraSubsystem_TryGetTimestamp_m253559658_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (XRCameraSubsystem_TryGetTimestamp_m253559658_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.Experimental.XR.XRCameraSubsystem::TryGetTimestamp(System.Int64&)");
	bool retVal = _il2cpp_icall_func(__this, ___timestampNs0);
	return retVal;
}
// System.Boolean UnityEngine.Experimental.XR.XRCameraSubsystem::TryGetShaderName(System.String&)
extern "C" IL2CPP_METHOD_ATTR bool XRCameraSubsystem_TryGetShaderName_m614827800 (XRCameraSubsystem_t4195795144 * __this, String_t** ___shaderName0, const RuntimeMethod* method)
{
	bool V_0 = false;
	{
		String_t** L_0 = ___shaderName0;
		bool L_1 = XRCameraSubsystem_Internal_TryGetShaderName_m650882322(__this, (String_t**)L_0, /*hidden argument*/NULL);
		V_0 = L_1;
		goto IL_000e;
	}

IL_000e:
	{
		bool L_2 = V_0;
		return L_2;
	}
}
// System.Boolean UnityEngine.Experimental.XR.XRCameraSubsystem::Internal_TryGetShaderName(System.String&)
extern "C" IL2CPP_METHOD_ATTR bool XRCameraSubsystem_Internal_TryGetShaderName_m650882322 (XRCameraSubsystem_t4195795144 * __this, String_t** ___shaderName0, const RuntimeMethod* method)
{
	typedef bool (*XRCameraSubsystem_Internal_TryGetShaderName_m650882322_ftn) (XRCameraSubsystem_t4195795144 *, String_t**);
	static XRCameraSubsystem_Internal_TryGetShaderName_m650882322_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (XRCameraSubsystem_Internal_TryGetShaderName_m650882322_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.Experimental.XR.XRCameraSubsystem::Internal_TryGetShaderName(System.String&)");
	bool retVal = _il2cpp_icall_func(__this, ___shaderName0);
	return retVal;
}
// System.Void UnityEngine.Experimental.XR.XRCameraSubsystem::add_FrameReceived(System.Action`1<UnityEngine.Experimental.XR.FrameReceivedEventArgs>)
extern "C" IL2CPP_METHOD_ATTR void XRCameraSubsystem_add_FrameReceived_m1573821284 (XRCameraSubsystem_t4195795144 * __this, Action_1_t2760547698 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRCameraSubsystem_add_FrameReceived_m1573821284_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Action_1_t2760547698 * V_0 = NULL;
	Action_1_t2760547698 * V_1 = NULL;
	{
		Action_1_t2760547698 * L_0 = __this->get_FrameReceived_2();
		V_0 = L_0;
	}

IL_0007:
	{
		Action_1_t2760547698 * L_1 = V_0;
		V_1 = L_1;
		Action_1_t2760547698 ** L_2 = __this->get_address_of_FrameReceived_2();
		Action_1_t2760547698 * L_3 = V_1;
		Action_1_t2760547698 * L_4 = ___value0;
		Delegate_t1188392813 * L_5 = Delegate_Combine_m1859655160(NULL /*static, unused*/, L_3, L_4, /*hidden argument*/NULL);
		Action_1_t2760547698 * L_6 = V_0;
		Action_1_t2760547698 * L_7 = InterlockedCompareExchangeImpl<Action_1_t2760547698 *>((Action_1_t2760547698 **)L_2, ((Action_1_t2760547698 *)CastclassSealed((RuntimeObject*)L_5, Action_1_t2760547698_il2cpp_TypeInfo_var)), L_6);
		V_0 = L_7;
		Action_1_t2760547698 * L_8 = V_0;
		Action_1_t2760547698 * L_9 = V_1;
		if ((!(((RuntimeObject*)(Action_1_t2760547698 *)L_8) == ((RuntimeObject*)(Action_1_t2760547698 *)L_9))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Void UnityEngine.Experimental.XR.XRCameraSubsystem::remove_FrameReceived(System.Action`1<UnityEngine.Experimental.XR.FrameReceivedEventArgs>)
extern "C" IL2CPP_METHOD_ATTR void XRCameraSubsystem_remove_FrameReceived_m700817009 (XRCameraSubsystem_t4195795144 * __this, Action_1_t2760547698 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRCameraSubsystem_remove_FrameReceived_m700817009_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Action_1_t2760547698 * V_0 = NULL;
	Action_1_t2760547698 * V_1 = NULL;
	{
		Action_1_t2760547698 * L_0 = __this->get_FrameReceived_2();
		V_0 = L_0;
	}

IL_0007:
	{
		Action_1_t2760547698 * L_1 = V_0;
		V_1 = L_1;
		Action_1_t2760547698 ** L_2 = __this->get_address_of_FrameReceived_2();
		Action_1_t2760547698 * L_3 = V_1;
		Action_1_t2760547698 * L_4 = ___value0;
		Delegate_t1188392813 * L_5 = Delegate_Remove_m334097152(NULL /*static, unused*/, L_3, L_4, /*hidden argument*/NULL);
		Action_1_t2760547698 * L_6 = V_0;
		Action_1_t2760547698 * L_7 = InterlockedCompareExchangeImpl<Action_1_t2760547698 *>((Action_1_t2760547698 **)L_2, ((Action_1_t2760547698 *)CastclassSealed((RuntimeObject*)L_5, Action_1_t2760547698_il2cpp_TypeInfo_var)), L_6);
		V_0 = L_7;
		Action_1_t2760547698 * L_8 = V_0;
		Action_1_t2760547698 * L_9 = V_1;
		if ((!(((RuntimeObject*)(Action_1_t2760547698 *)L_8) == ((RuntimeObject*)(Action_1_t2760547698 *)L_9))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Void UnityEngine.Experimental.XR.XRCameraSubsystem::InvokeFrameReceivedEvent()
extern "C" IL2CPP_METHOD_ATTR void XRCameraSubsystem_InvokeFrameReceivedEvent_m3350736905 (XRCameraSubsystem_t4195795144 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRCameraSubsystem_InvokeFrameReceivedEvent_m3350736905_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	FrameReceivedEventArgs_t2588080103  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		Action_1_t2760547698 * L_0 = __this->get_FrameReceived_2();
		if (!L_0)
		{
			goto IL_002a;
		}
	}
	{
		Action_1_t2760547698 * L_1 = __this->get_FrameReceived_2();
		il2cpp_codegen_initobj((&V_0), sizeof(FrameReceivedEventArgs_t2588080103 ));
		(&V_0)->set_m_CameraSubsystem_0(__this);
		FrameReceivedEventArgs_t2588080103  L_2 = V_0;
		NullCheck(L_1);
		Action_1_Invoke_m2953615518(L_1, L_2, /*hidden argument*/Action_1_Invoke_m2953615518_RuntimeMethod_var);
	}

IL_002a:
	{
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.Experimental.XR.XRDepthSubsystem::add_PointCloudUpdated(System.Action`1<UnityEngine.Experimental.XR.PointCloudUpdatedEventArgs>)
extern "C" IL2CPP_METHOD_ATTR void XRDepthSubsystem_add_PointCloudUpdated_m3369518994 (XRDepthSubsystem_t4084359858 * __this, Action_1_t3609124943 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRDepthSubsystem_add_PointCloudUpdated_m3369518994_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Action_1_t3609124943 * V_0 = NULL;
	Action_1_t3609124943 * V_1 = NULL;
	{
		Action_1_t3609124943 * L_0 = __this->get_PointCloudUpdated_2();
		V_0 = L_0;
	}

IL_0007:
	{
		Action_1_t3609124943 * L_1 = V_0;
		V_1 = L_1;
		Action_1_t3609124943 ** L_2 = __this->get_address_of_PointCloudUpdated_2();
		Action_1_t3609124943 * L_3 = V_1;
		Action_1_t3609124943 * L_4 = ___value0;
		Delegate_t1188392813 * L_5 = Delegate_Combine_m1859655160(NULL /*static, unused*/, L_3, L_4, /*hidden argument*/NULL);
		Action_1_t3609124943 * L_6 = V_0;
		Action_1_t3609124943 * L_7 = InterlockedCompareExchangeImpl<Action_1_t3609124943 *>((Action_1_t3609124943 **)L_2, ((Action_1_t3609124943 *)CastclassSealed((RuntimeObject*)L_5, Action_1_t3609124943_il2cpp_TypeInfo_var)), L_6);
		V_0 = L_7;
		Action_1_t3609124943 * L_8 = V_0;
		Action_1_t3609124943 * L_9 = V_1;
		if ((!(((RuntimeObject*)(Action_1_t3609124943 *)L_8) == ((RuntimeObject*)(Action_1_t3609124943 *)L_9))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Void UnityEngine.Experimental.XR.XRDepthSubsystem::remove_PointCloudUpdated(System.Action`1<UnityEngine.Experimental.XR.PointCloudUpdatedEventArgs>)
extern "C" IL2CPP_METHOD_ATTR void XRDepthSubsystem_remove_PointCloudUpdated_m74894791 (XRDepthSubsystem_t4084359858 * __this, Action_1_t3609124943 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRDepthSubsystem_remove_PointCloudUpdated_m74894791_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Action_1_t3609124943 * V_0 = NULL;
	Action_1_t3609124943 * V_1 = NULL;
	{
		Action_1_t3609124943 * L_0 = __this->get_PointCloudUpdated_2();
		V_0 = L_0;
	}

IL_0007:
	{
		Action_1_t3609124943 * L_1 = V_0;
		V_1 = L_1;
		Action_1_t3609124943 ** L_2 = __this->get_address_of_PointCloudUpdated_2();
		Action_1_t3609124943 * L_3 = V_1;
		Action_1_t3609124943 * L_4 = ___value0;
		Delegate_t1188392813 * L_5 = Delegate_Remove_m334097152(NULL /*static, unused*/, L_3, L_4, /*hidden argument*/NULL);
		Action_1_t3609124943 * L_6 = V_0;
		Action_1_t3609124943 * L_7 = InterlockedCompareExchangeImpl<Action_1_t3609124943 *>((Action_1_t3609124943 **)L_2, ((Action_1_t3609124943 *)CastclassSealed((RuntimeObject*)L_5, Action_1_t3609124943_il2cpp_TypeInfo_var)), L_6);
		V_0 = L_7;
		Action_1_t3609124943 * L_8 = V_0;
		Action_1_t3609124943 * L_9 = V_1;
		if ((!(((RuntimeObject*)(Action_1_t3609124943 *)L_8) == ((RuntimeObject*)(Action_1_t3609124943 *)L_9))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Int32 UnityEngine.Experimental.XR.XRDepthSubsystem::get_LastUpdatedFrame()
extern "C" IL2CPP_METHOD_ATTR int32_t XRDepthSubsystem_get_LastUpdatedFrame_m2486545929 (XRDepthSubsystem_t4084359858 * __this, const RuntimeMethod* method)
{
	typedef int32_t (*XRDepthSubsystem_get_LastUpdatedFrame_m2486545929_ftn) (XRDepthSubsystem_t4084359858 *);
	static XRDepthSubsystem_get_LastUpdatedFrame_m2486545929_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (XRDepthSubsystem_get_LastUpdatedFrame_m2486545929_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.Experimental.XR.XRDepthSubsystem::get_LastUpdatedFrame()");
	int32_t retVal = _il2cpp_icall_func(__this);
	return retVal;
}
// System.Void UnityEngine.Experimental.XR.XRDepthSubsystem::GetPoints(System.Collections.Generic.List`1<UnityEngine.Vector3>)
extern "C" IL2CPP_METHOD_ATTR void XRDepthSubsystem_GetPoints_m2117729361 (XRDepthSubsystem_t4084359858 * __this, List_1_t899420910 * ___pointsOut0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRDepthSubsystem_GetPoints_m2117729361_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		List_1_t899420910 * L_0 = ___pointsOut0;
		if (L_0)
		{
			goto IL_0012;
		}
	}
	{
		ArgumentNullException_t1615371798 * L_1 = (ArgumentNullException_t1615371798 *)il2cpp_codegen_object_new(ArgumentNullException_t1615371798_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m1170824041(L_1, _stringLiteral772464777, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1, NULL, XRDepthSubsystem_GetPoints_m2117729361_RuntimeMethod_var);
	}

IL_0012:
	{
		List_1_t899420910 * L_2 = ___pointsOut0;
		XRDepthSubsystem_Internal_GetPointCloudPointsAsList_m1867663777(__this, L_2, /*hidden argument*/NULL);
		return;
	}
}
// System.Void UnityEngine.Experimental.XR.XRDepthSubsystem::GetConfidence(System.Collections.Generic.List`1<System.Single>)
extern "C" IL2CPP_METHOD_ATTR void XRDepthSubsystem_GetConfidence_m621056309 (XRDepthSubsystem_t4084359858 * __this, List_1_t2869341516 * ___confidenceOut0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRDepthSubsystem_GetConfidence_m621056309_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		List_1_t2869341516 * L_0 = ___confidenceOut0;
		if (L_0)
		{
			goto IL_0012;
		}
	}
	{
		ArgumentNullException_t1615371798 * L_1 = (ArgumentNullException_t1615371798 *)il2cpp_codegen_object_new(ArgumentNullException_t1615371798_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m1170824041(L_1, _stringLiteral1754079207, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1, NULL, XRDepthSubsystem_GetConfidence_m621056309_RuntimeMethod_var);
	}

IL_0012:
	{
		List_1_t2869341516 * L_2 = ___confidenceOut0;
		XRDepthSubsystem_Internal_GetPointCloudConfidenceAsList_m2782565433(__this, L_2, /*hidden argument*/NULL);
		return;
	}
}
// System.Void UnityEngine.Experimental.XR.XRDepthSubsystem::InvokePointCloudUpdatedEvent()
extern "C" IL2CPP_METHOD_ATTR void XRDepthSubsystem_InvokePointCloudUpdatedEvent_m4090616323 (XRDepthSubsystem_t4084359858 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRDepthSubsystem_InvokePointCloudUpdatedEvent_m4090616323_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	PointCloudUpdatedEventArgs_t3436657348  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		Action_1_t3609124943 * L_0 = __this->get_PointCloudUpdated_2();
		if (!L_0)
		{
			goto IL_002a;
		}
	}
	{
		Action_1_t3609124943 * L_1 = __this->get_PointCloudUpdated_2();
		il2cpp_codegen_initobj((&V_0), sizeof(PointCloudUpdatedEventArgs_t3436657348 ));
		(&V_0)->set_m_DepthSubsystem_0(__this);
		PointCloudUpdatedEventArgs_t3436657348  L_2 = V_0;
		NullCheck(L_1);
		Action_1_Invoke_m3012248422(L_1, L_2, /*hidden argument*/Action_1_Invoke_m3012248422_RuntimeMethod_var);
	}

IL_002a:
	{
		return;
	}
}
// System.Void UnityEngine.Experimental.XR.XRDepthSubsystem::Internal_GetPointCloudPointsAsList(System.Collections.Generic.List`1<UnityEngine.Vector3>)
extern "C" IL2CPP_METHOD_ATTR void XRDepthSubsystem_Internal_GetPointCloudPointsAsList_m1867663777 (XRDepthSubsystem_t4084359858 * __this, List_1_t899420910 * ___pointsOut0, const RuntimeMethod* method)
{
	typedef void (*XRDepthSubsystem_Internal_GetPointCloudPointsAsList_m1867663777_ftn) (XRDepthSubsystem_t4084359858 *, List_1_t899420910 *);
	static XRDepthSubsystem_Internal_GetPointCloudPointsAsList_m1867663777_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (XRDepthSubsystem_Internal_GetPointCloudPointsAsList_m1867663777_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.Experimental.XR.XRDepthSubsystem::Internal_GetPointCloudPointsAsList(System.Collections.Generic.List`1<UnityEngine.Vector3>)");
	_il2cpp_icall_func(__this, ___pointsOut0);
}
// System.Void UnityEngine.Experimental.XR.XRDepthSubsystem::Internal_GetPointCloudConfidenceAsList(System.Collections.Generic.List`1<System.Single>)
extern "C" IL2CPP_METHOD_ATTR void XRDepthSubsystem_Internal_GetPointCloudConfidenceAsList_m2782565433 (XRDepthSubsystem_t4084359858 * __this, List_1_t2869341516 * ___confidenceOut0, const RuntimeMethod* method)
{
	typedef void (*XRDepthSubsystem_Internal_GetPointCloudConfidenceAsList_m2782565433_ftn) (XRDepthSubsystem_t4084359858 *, List_1_t2869341516 *);
	static XRDepthSubsystem_Internal_GetPointCloudConfidenceAsList_m2782565433_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (XRDepthSubsystem_Internal_GetPointCloudConfidenceAsList_m2782565433_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.Experimental.XR.XRDepthSubsystem::Internal_GetPointCloudConfidenceAsList(System.Collections.Generic.List`1<System.Single>)");
	_il2cpp_icall_func(__this, ___confidenceOut0);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.Experimental.XR.XRPlaneSubsystem::add_PlaneAdded(System.Action`1<UnityEngine.Experimental.XR.PlaneAddedEventArgs>)
extern "C" IL2CPP_METHOD_ATTR void XRPlaneSubsystem_add_PlaneAdded_m4075589642 (XRPlaneSubsystem_t2260142932 * __this, Action_1_t2722643320 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRPlaneSubsystem_add_PlaneAdded_m4075589642_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Action_1_t2722643320 * V_0 = NULL;
	Action_1_t2722643320 * V_1 = NULL;
	{
		Action_1_t2722643320 * L_0 = __this->get_PlaneAdded_2();
		V_0 = L_0;
	}

IL_0007:
	{
		Action_1_t2722643320 * L_1 = V_0;
		V_1 = L_1;
		Action_1_t2722643320 ** L_2 = __this->get_address_of_PlaneAdded_2();
		Action_1_t2722643320 * L_3 = V_1;
		Action_1_t2722643320 * L_4 = ___value0;
		Delegate_t1188392813 * L_5 = Delegate_Combine_m1859655160(NULL /*static, unused*/, L_3, L_4, /*hidden argument*/NULL);
		Action_1_t2722643320 * L_6 = V_0;
		Action_1_t2722643320 * L_7 = InterlockedCompareExchangeImpl<Action_1_t2722643320 *>((Action_1_t2722643320 **)L_2, ((Action_1_t2722643320 *)CastclassSealed((RuntimeObject*)L_5, Action_1_t2722643320_il2cpp_TypeInfo_var)), L_6);
		V_0 = L_7;
		Action_1_t2722643320 * L_8 = V_0;
		Action_1_t2722643320 * L_9 = V_1;
		if ((!(((RuntimeObject*)(Action_1_t2722643320 *)L_8) == ((RuntimeObject*)(Action_1_t2722643320 *)L_9))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Void UnityEngine.Experimental.XR.XRPlaneSubsystem::remove_PlaneAdded(System.Action`1<UnityEngine.Experimental.XR.PlaneAddedEventArgs>)
extern "C" IL2CPP_METHOD_ATTR void XRPlaneSubsystem_remove_PlaneAdded_m28955542 (XRPlaneSubsystem_t2260142932 * __this, Action_1_t2722643320 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRPlaneSubsystem_remove_PlaneAdded_m28955542_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Action_1_t2722643320 * V_0 = NULL;
	Action_1_t2722643320 * V_1 = NULL;
	{
		Action_1_t2722643320 * L_0 = __this->get_PlaneAdded_2();
		V_0 = L_0;
	}

IL_0007:
	{
		Action_1_t2722643320 * L_1 = V_0;
		V_1 = L_1;
		Action_1_t2722643320 ** L_2 = __this->get_address_of_PlaneAdded_2();
		Action_1_t2722643320 * L_3 = V_1;
		Action_1_t2722643320 * L_4 = ___value0;
		Delegate_t1188392813 * L_5 = Delegate_Remove_m334097152(NULL /*static, unused*/, L_3, L_4, /*hidden argument*/NULL);
		Action_1_t2722643320 * L_6 = V_0;
		Action_1_t2722643320 * L_7 = InterlockedCompareExchangeImpl<Action_1_t2722643320 *>((Action_1_t2722643320 **)L_2, ((Action_1_t2722643320 *)CastclassSealed((RuntimeObject*)L_5, Action_1_t2722643320_il2cpp_TypeInfo_var)), L_6);
		V_0 = L_7;
		Action_1_t2722643320 * L_8 = V_0;
		Action_1_t2722643320 * L_9 = V_1;
		if ((!(((RuntimeObject*)(Action_1_t2722643320 *)L_8) == ((RuntimeObject*)(Action_1_t2722643320 *)L_9))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Void UnityEngine.Experimental.XR.XRPlaneSubsystem::add_PlaneUpdated(System.Action`1<UnityEngine.Experimental.XR.PlaneUpdatedEventArgs>)
extern "C" IL2CPP_METHOD_ATTR void XRPlaneSubsystem_add_PlaneUpdated_m167230714 (XRPlaneSubsystem_t2260142932 * __this, Action_1_t521953446 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRPlaneSubsystem_add_PlaneUpdated_m167230714_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Action_1_t521953446 * V_0 = NULL;
	Action_1_t521953446 * V_1 = NULL;
	{
		Action_1_t521953446 * L_0 = __this->get_PlaneUpdated_3();
		V_0 = L_0;
	}

IL_0007:
	{
		Action_1_t521953446 * L_1 = V_0;
		V_1 = L_1;
		Action_1_t521953446 ** L_2 = __this->get_address_of_PlaneUpdated_3();
		Action_1_t521953446 * L_3 = V_1;
		Action_1_t521953446 * L_4 = ___value0;
		Delegate_t1188392813 * L_5 = Delegate_Combine_m1859655160(NULL /*static, unused*/, L_3, L_4, /*hidden argument*/NULL);
		Action_1_t521953446 * L_6 = V_0;
		Action_1_t521953446 * L_7 = InterlockedCompareExchangeImpl<Action_1_t521953446 *>((Action_1_t521953446 **)L_2, ((Action_1_t521953446 *)CastclassSealed((RuntimeObject*)L_5, Action_1_t521953446_il2cpp_TypeInfo_var)), L_6);
		V_0 = L_7;
		Action_1_t521953446 * L_8 = V_0;
		Action_1_t521953446 * L_9 = V_1;
		if ((!(((RuntimeObject*)(Action_1_t521953446 *)L_8) == ((RuntimeObject*)(Action_1_t521953446 *)L_9))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Void UnityEngine.Experimental.XR.XRPlaneSubsystem::remove_PlaneUpdated(System.Action`1<UnityEngine.Experimental.XR.PlaneUpdatedEventArgs>)
extern "C" IL2CPP_METHOD_ATTR void XRPlaneSubsystem_remove_PlaneUpdated_m1675113179 (XRPlaneSubsystem_t2260142932 * __this, Action_1_t521953446 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRPlaneSubsystem_remove_PlaneUpdated_m1675113179_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Action_1_t521953446 * V_0 = NULL;
	Action_1_t521953446 * V_1 = NULL;
	{
		Action_1_t521953446 * L_0 = __this->get_PlaneUpdated_3();
		V_0 = L_0;
	}

IL_0007:
	{
		Action_1_t521953446 * L_1 = V_0;
		V_1 = L_1;
		Action_1_t521953446 ** L_2 = __this->get_address_of_PlaneUpdated_3();
		Action_1_t521953446 * L_3 = V_1;
		Action_1_t521953446 * L_4 = ___value0;
		Delegate_t1188392813 * L_5 = Delegate_Remove_m334097152(NULL /*static, unused*/, L_3, L_4, /*hidden argument*/NULL);
		Action_1_t521953446 * L_6 = V_0;
		Action_1_t521953446 * L_7 = InterlockedCompareExchangeImpl<Action_1_t521953446 *>((Action_1_t521953446 **)L_2, ((Action_1_t521953446 *)CastclassSealed((RuntimeObject*)L_5, Action_1_t521953446_il2cpp_TypeInfo_var)), L_6);
		V_0 = L_7;
		Action_1_t521953446 * L_8 = V_0;
		Action_1_t521953446 * L_9 = V_1;
		if ((!(((RuntimeObject*)(Action_1_t521953446 *)L_8) == ((RuntimeObject*)(Action_1_t521953446 *)L_9))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Void UnityEngine.Experimental.XR.XRPlaneSubsystem::add_PlaneRemoved(System.Action`1<UnityEngine.Experimental.XR.PlaneRemovedEventArgs>)
extern "C" IL2CPP_METHOD_ATTR void XRPlaneSubsystem_add_PlaneRemoved_m894814380 (XRPlaneSubsystem_t2260142932 * __this, Action_1_t1739597377 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRPlaneSubsystem_add_PlaneRemoved_m894814380_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Action_1_t1739597377 * V_0 = NULL;
	Action_1_t1739597377 * V_1 = NULL;
	{
		Action_1_t1739597377 * L_0 = __this->get_PlaneRemoved_4();
		V_0 = L_0;
	}

IL_0007:
	{
		Action_1_t1739597377 * L_1 = V_0;
		V_1 = L_1;
		Action_1_t1739597377 ** L_2 = __this->get_address_of_PlaneRemoved_4();
		Action_1_t1739597377 * L_3 = V_1;
		Action_1_t1739597377 * L_4 = ___value0;
		Delegate_t1188392813 * L_5 = Delegate_Combine_m1859655160(NULL /*static, unused*/, L_3, L_4, /*hidden argument*/NULL);
		Action_1_t1739597377 * L_6 = V_0;
		Action_1_t1739597377 * L_7 = InterlockedCompareExchangeImpl<Action_1_t1739597377 *>((Action_1_t1739597377 **)L_2, ((Action_1_t1739597377 *)CastclassSealed((RuntimeObject*)L_5, Action_1_t1739597377_il2cpp_TypeInfo_var)), L_6);
		V_0 = L_7;
		Action_1_t1739597377 * L_8 = V_0;
		Action_1_t1739597377 * L_9 = V_1;
		if ((!(((RuntimeObject*)(Action_1_t1739597377 *)L_8) == ((RuntimeObject*)(Action_1_t1739597377 *)L_9))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Void UnityEngine.Experimental.XR.XRPlaneSubsystem::remove_PlaneRemoved(System.Action`1<UnityEngine.Experimental.XR.PlaneRemovedEventArgs>)
extern "C" IL2CPP_METHOD_ATTR void XRPlaneSubsystem_remove_PlaneRemoved_m3207440425 (XRPlaneSubsystem_t2260142932 * __this, Action_1_t1739597377 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRPlaneSubsystem_remove_PlaneRemoved_m3207440425_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Action_1_t1739597377 * V_0 = NULL;
	Action_1_t1739597377 * V_1 = NULL;
	{
		Action_1_t1739597377 * L_0 = __this->get_PlaneRemoved_4();
		V_0 = L_0;
	}

IL_0007:
	{
		Action_1_t1739597377 * L_1 = V_0;
		V_1 = L_1;
		Action_1_t1739597377 ** L_2 = __this->get_address_of_PlaneRemoved_4();
		Action_1_t1739597377 * L_3 = V_1;
		Action_1_t1739597377 * L_4 = ___value0;
		Delegate_t1188392813 * L_5 = Delegate_Remove_m334097152(NULL /*static, unused*/, L_3, L_4, /*hidden argument*/NULL);
		Action_1_t1739597377 * L_6 = V_0;
		Action_1_t1739597377 * L_7 = InterlockedCompareExchangeImpl<Action_1_t1739597377 *>((Action_1_t1739597377 **)L_2, ((Action_1_t1739597377 *)CastclassSealed((RuntimeObject*)L_5, Action_1_t1739597377_il2cpp_TypeInfo_var)), L_6);
		V_0 = L_7;
		Action_1_t1739597377 * L_8 = V_0;
		Action_1_t1739597377 * L_9 = V_1;
		if ((!(((RuntimeObject*)(Action_1_t1739597377 *)L_8) == ((RuntimeObject*)(Action_1_t1739597377 *)L_9))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Void UnityEngine.Experimental.XR.XRPlaneSubsystem::GetAllPlanes(System.Collections.Generic.List`1<UnityEngine.Experimental.XR.BoundedPlane>)
extern "C" IL2CPP_METHOD_ATTR void XRPlaneSubsystem_GetAllPlanes_m1313721439 (XRPlaneSubsystem_t2260142932 * __this, List_1_t2789567076 * ___planesOut0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRPlaneSubsystem_GetAllPlanes_m1313721439_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		List_1_t2789567076 * L_0 = ___planesOut0;
		if (L_0)
		{
			goto IL_0012;
		}
	}
	{
		ArgumentNullException_t1615371798 * L_1 = (ArgumentNullException_t1615371798 *)il2cpp_codegen_object_new(ArgumentNullException_t1615371798_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m1170824041(L_1, _stringLiteral2047980736, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1, NULL, XRPlaneSubsystem_GetAllPlanes_m1313721439_RuntimeMethod_var);
	}

IL_0012:
	{
		List_1_t2789567076 * L_2 = ___planesOut0;
		XRPlaneSubsystem_GetAllPlanesAsList_m575400322(__this, L_2, /*hidden argument*/NULL);
		return;
	}
}
// System.Void UnityEngine.Experimental.XR.XRPlaneSubsystem::InvokePlaneAddedEvent(UnityEngine.Experimental.XR.BoundedPlane)
extern "C" IL2CPP_METHOD_ATTR void XRPlaneSubsystem_InvokePlaneAddedEvent_m2287049231 (XRPlaneSubsystem_t2260142932 * __this, BoundedPlane_t1317492334  ___plane0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRPlaneSubsystem_InvokePlaneAddedEvent_m2287049231_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	PlaneAddedEventArgs_t2550175725  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		Action_1_t2722643320 * L_0 = __this->get_PlaneAdded_2();
		if (!L_0)
		{
			goto IL_0032;
		}
	}
	{
		Action_1_t2722643320 * L_1 = __this->get_PlaneAdded_2();
		il2cpp_codegen_initobj((&V_0), sizeof(PlaneAddedEventArgs_t2550175725 ));
		PlaneAddedEventArgs_set_PlaneSubsystem_m3627276178((PlaneAddedEventArgs_t2550175725 *)(&V_0), __this, /*hidden argument*/NULL);
		BoundedPlane_t1317492334  L_2 = ___plane0;
		PlaneAddedEventArgs_set_Plane_m3532199823((PlaneAddedEventArgs_t2550175725 *)(&V_0), L_2, /*hidden argument*/NULL);
		PlaneAddedEventArgs_t2550175725  L_3 = V_0;
		NullCheck(L_1);
		Action_1_Invoke_m3662407658(L_1, L_3, /*hidden argument*/Action_1_Invoke_m3662407658_RuntimeMethod_var);
	}

IL_0032:
	{
		return;
	}
}
// System.Void UnityEngine.Experimental.XR.XRPlaneSubsystem::InvokePlaneUpdatedEvent(UnityEngine.Experimental.XR.BoundedPlane)
extern "C" IL2CPP_METHOD_ATTR void XRPlaneSubsystem_InvokePlaneUpdatedEvent_m3431602433 (XRPlaneSubsystem_t2260142932 * __this, BoundedPlane_t1317492334  ___plane0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRPlaneSubsystem_InvokePlaneUpdatedEvent_m3431602433_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	PlaneUpdatedEventArgs_t349485851  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		Action_1_t521953446 * L_0 = __this->get_PlaneUpdated_3();
		if (!L_0)
		{
			goto IL_0032;
		}
	}
	{
		Action_1_t521953446 * L_1 = __this->get_PlaneUpdated_3();
		il2cpp_codegen_initobj((&V_0), sizeof(PlaneUpdatedEventArgs_t349485851 ));
		PlaneUpdatedEventArgs_set_PlaneSubsystem_m79632840((PlaneUpdatedEventArgs_t349485851 *)(&V_0), __this, /*hidden argument*/NULL);
		BoundedPlane_t1317492334  L_2 = ___plane0;
		PlaneUpdatedEventArgs_set_Plane_m3296874754((PlaneUpdatedEventArgs_t349485851 *)(&V_0), L_2, /*hidden argument*/NULL);
		PlaneUpdatedEventArgs_t349485851  L_3 = V_0;
		NullCheck(L_1);
		Action_1_Invoke_m4140516850(L_1, L_3, /*hidden argument*/Action_1_Invoke_m4140516850_RuntimeMethod_var);
	}

IL_0032:
	{
		return;
	}
}
// System.Void UnityEngine.Experimental.XR.XRPlaneSubsystem::InvokePlaneRemovedEvent(UnityEngine.Experimental.XR.BoundedPlane)
extern "C" IL2CPP_METHOD_ATTR void XRPlaneSubsystem_InvokePlaneRemovedEvent_m3495166678 (XRPlaneSubsystem_t2260142932 * __this, BoundedPlane_t1317492334  ___removedPlane0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRPlaneSubsystem_InvokePlaneRemovedEvent_m3495166678_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	PlaneRemovedEventArgs_t1567129782  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		Action_1_t1739597377 * L_0 = __this->get_PlaneRemoved_4();
		if (!L_0)
		{
			goto IL_0032;
		}
	}
	{
		Action_1_t1739597377 * L_1 = __this->get_PlaneRemoved_4();
		il2cpp_codegen_initobj((&V_0), sizeof(PlaneRemovedEventArgs_t1567129782 ));
		PlaneRemovedEventArgs_set_PlaneSubsystem_m2373342326((PlaneRemovedEventArgs_t1567129782 *)(&V_0), __this, /*hidden argument*/NULL);
		BoundedPlane_t1317492334  L_2 = ___removedPlane0;
		PlaneRemovedEventArgs_set_Plane_m290598833((PlaneRemovedEventArgs_t1567129782 *)(&V_0), L_2, /*hidden argument*/NULL);
		PlaneRemovedEventArgs_t1567129782  L_3 = V_0;
		NullCheck(L_1);
		Action_1_Invoke_m316788244(L_1, L_3, /*hidden argument*/Action_1_Invoke_m316788244_RuntimeMethod_var);
	}

IL_0032:
	{
		return;
	}
}
// System.Void UnityEngine.Experimental.XR.XRPlaneSubsystem::GetAllPlanesAsList(System.Collections.Generic.List`1<UnityEngine.Experimental.XR.BoundedPlane>)
extern "C" IL2CPP_METHOD_ATTR void XRPlaneSubsystem_GetAllPlanesAsList_m575400322 (XRPlaneSubsystem_t2260142932 * __this, List_1_t2789567076 * ___planes0, const RuntimeMethod* method)
{
	typedef void (*XRPlaneSubsystem_GetAllPlanesAsList_m575400322_ftn) (XRPlaneSubsystem_t2260142932 *, List_1_t2789567076 *);
	static XRPlaneSubsystem_GetAllPlanesAsList_m575400322_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (XRPlaneSubsystem_GetAllPlanesAsList_m575400322_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.Experimental.XR.XRPlaneSubsystem::GetAllPlanesAsList(System.Collections.Generic.List`1<UnityEngine.Experimental.XR.BoundedPlane>)");
	_il2cpp_icall_func(__this, ___planes0);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// UnityEngine.Experimental.XR.TrackableId UnityEngine.Experimental.XR.XRRaycastHit::get_TrackableId()
extern "C" IL2CPP_METHOD_ATTR TrackableId_t1251031970  XRRaycastHit_get_TrackableId_m3341694854 (XRRaycastHit_t2370805074 * __this, const RuntimeMethod* method)
{
	TrackableId_t1251031970  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		TrackableId_t1251031970  L_0 = __this->get_U3CTrackableIdU3Ek__BackingField_0();
		V_0 = L_0;
		goto IL_000c;
	}

IL_000c:
	{
		TrackableId_t1251031970  L_1 = V_0;
		return L_1;
	}
}
extern "C"  TrackableId_t1251031970  XRRaycastHit_get_TrackableId_m3341694854_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	XRRaycastHit_t2370805074 * _thisAdjusted = reinterpret_cast<XRRaycastHit_t2370805074 *>(__this + 1);
	return XRRaycastHit_get_TrackableId_m3341694854(_thisAdjusted, method);
}
// UnityEngine.Pose UnityEngine.Experimental.XR.XRRaycastHit::get_Pose()
extern "C" IL2CPP_METHOD_ATTR Pose_t545244865  XRRaycastHit_get_Pose_m3198015053 (XRRaycastHit_t2370805074 * __this, const RuntimeMethod* method)
{
	Pose_t545244865  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		Pose_t545244865  L_0 = __this->get_U3CPoseU3Ek__BackingField_1();
		V_0 = L_0;
		goto IL_000c;
	}

IL_000c:
	{
		Pose_t545244865  L_1 = V_0;
		return L_1;
	}
}
extern "C"  Pose_t545244865  XRRaycastHit_get_Pose_m3198015053_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	XRRaycastHit_t2370805074 * _thisAdjusted = reinterpret_cast<XRRaycastHit_t2370805074 *>(__this + 1);
	return XRRaycastHit_get_Pose_m3198015053(_thisAdjusted, method);
}
// System.Void UnityEngine.Experimental.XR.XRRaycastHit::set_Pose(UnityEngine.Pose)
extern "C" IL2CPP_METHOD_ATTR void XRRaycastHit_set_Pose_m4202558867 (XRRaycastHit_t2370805074 * __this, Pose_t545244865  ___value0, const RuntimeMethod* method)
{
	{
		Pose_t545244865  L_0 = ___value0;
		__this->set_U3CPoseU3Ek__BackingField_1(L_0);
		return;
	}
}
extern "C"  void XRRaycastHit_set_Pose_m4202558867_AdjustorThunk (RuntimeObject * __this, Pose_t545244865  ___value0, const RuntimeMethod* method)
{
	XRRaycastHit_t2370805074 * _thisAdjusted = reinterpret_cast<XRRaycastHit_t2370805074 *>(__this + 1);
	XRRaycastHit_set_Pose_m4202558867(_thisAdjusted, ___value0, method);
}
// System.Single UnityEngine.Experimental.XR.XRRaycastHit::get_Distance()
extern "C" IL2CPP_METHOD_ATTR float XRRaycastHit_get_Distance_m2947783709 (XRRaycastHit_t2370805074 * __this, const RuntimeMethod* method)
{
	float V_0 = 0.0f;
	{
		float L_0 = __this->get_U3CDistanceU3Ek__BackingField_2();
		V_0 = L_0;
		goto IL_000c;
	}

IL_000c:
	{
		float L_1 = V_0;
		return L_1;
	}
}
extern "C"  float XRRaycastHit_get_Distance_m2947783709_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	XRRaycastHit_t2370805074 * _thisAdjusted = reinterpret_cast<XRRaycastHit_t2370805074 *>(__this + 1);
	return XRRaycastHit_get_Distance_m2947783709(_thisAdjusted, method);
}
// UnityEngine.Experimental.XR.TrackableType UnityEngine.Experimental.XR.XRRaycastHit::get_HitType()
extern "C" IL2CPP_METHOD_ATTR int32_t XRRaycastHit_get_HitType_m3113473311 (XRRaycastHit_t2370805074 * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	{
		int32_t L_0 = __this->get_U3CHitTypeU3Ek__BackingField_3();
		V_0 = L_0;
		goto IL_000c;
	}

IL_000c:
	{
		int32_t L_1 = V_0;
		return L_1;
	}
}
extern "C"  int32_t XRRaycastHit_get_HitType_m3113473311_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	XRRaycastHit_t2370805074 * _thisAdjusted = reinterpret_cast<XRRaycastHit_t2370805074 *>(__this + 1);
	return XRRaycastHit_get_HitType_m3113473311(_thisAdjusted, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Boolean UnityEngine.Experimental.XR.XRRaycastSubsystem::Raycast(UnityEngine.Vector3,System.Collections.Generic.List`1<UnityEngine.Experimental.XR.XRRaycastHit>,UnityEngine.Experimental.XR.TrackableType)
extern "C" IL2CPP_METHOD_ATTR bool XRRaycastSubsystem_Raycast_m2841114376 (XRRaycastSubsystem_t2747560419 * __this, Vector3_t3722313464  ___screenPoint0, List_1_t3842879816 * ___hitResults1, int32_t ___trackableTypeMask2, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRRaycastSubsystem_Raycast_m2841114376_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	float V_0 = 0.0f;
	float V_1 = 0.0f;
	bool V_2 = false;
	{
		List_1_t3842879816 * L_0 = ___hitResults1;
		if (L_0)
		{
			goto IL_0012;
		}
	}
	{
		ArgumentNullException_t1615371798 * L_1 = (ArgumentNullException_t1615371798 *)il2cpp_codegen_object_new(ArgumentNullException_t1615371798_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m1170824041(L_1, _stringLiteral56995845, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1, NULL, XRRaycastSubsystem_Raycast_m2841114376_RuntimeMethod_var);
	}

IL_0012:
	{
		float L_2 = (&___screenPoint0)->get_x_2();
		int32_t L_3 = Screen_get_width_m345039817(NULL /*static, unused*/, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Mathf_t3464937446_il2cpp_TypeInfo_var);
		float L_4 = Mathf_Clamp01_m56433566(NULL /*static, unused*/, ((float)((float)L_2/(float)(((float)((float)L_3))))), /*hidden argument*/NULL);
		V_0 = L_4;
		float L_5 = (&___screenPoint0)->get_y_3();
		int32_t L_6 = Screen_get_height_m1623532518(NULL /*static, unused*/, /*hidden argument*/NULL);
		float L_7 = Mathf_Clamp01_m56433566(NULL /*static, unused*/, ((float)((float)L_5/(float)(((float)((float)L_6))))), /*hidden argument*/NULL);
		V_1 = L_7;
		float L_8 = V_0;
		float L_9 = V_1;
		int32_t L_10 = ___trackableTypeMask2;
		List_1_t3842879816 * L_11 = ___hitResults1;
		bool L_12 = XRRaycastSubsystem_Internal_ScreenRaycastAsList_m964488973(__this, L_8, L_9, L_10, L_11, /*hidden argument*/NULL);
		V_2 = L_12;
		goto IL_004a;
	}

IL_004a:
	{
		bool L_13 = V_2;
		return L_13;
	}
}
// System.Void UnityEngine.Experimental.XR.XRRaycastSubsystem::Raycast(UnityEngine.Ray,UnityEngine.Experimental.XR.XRDepthSubsystem,UnityEngine.Experimental.XR.XRPlaneSubsystem,System.Collections.Generic.List`1<UnityEngine.Experimental.XR.XRRaycastHit>,UnityEngine.Experimental.XR.TrackableType,System.Single)
extern "C" IL2CPP_METHOD_ATTR void XRRaycastSubsystem_Raycast_m4086064154 (RuntimeObject * __this /* static, unused */, Ray_t3785851493  ___ray0, XRDepthSubsystem_t4084359858 * ___depthSubsystem1, XRPlaneSubsystem_t2260142932 * ___planeSubsystem2, List_1_t3842879816 * ___hitResults3, int32_t ___trackableTypeMask4, float ___pointCloudRaycastAngleInDegrees5, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRRaycastSubsystem_Raycast_m4086064154_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	intptr_t V_0;
	memset(&V_0, 0, sizeof(V_0));
	intptr_t V_1;
	memset(&V_1, 0, sizeof(V_1));
	intptr_t G_B5_0;
	memset(&G_B5_0, 0, sizeof(G_B5_0));
	intptr_t G_B8_0;
	memset(&G_B8_0, 0, sizeof(G_B8_0));
	{
		List_1_t3842879816 * L_0 = ___hitResults3;
		if (L_0)
		{
			goto IL_0012;
		}
	}
	{
		ArgumentNullException_t1615371798 * L_1 = (ArgumentNullException_t1615371798 *)il2cpp_codegen_object_new(ArgumentNullException_t1615371798_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m1170824041(L_1, _stringLiteral56995845, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1, NULL, XRRaycastSubsystem_Raycast_m4086064154_RuntimeMethod_var);
	}

IL_0012:
	{
		XRDepthSubsystem_t4084359858 * L_2 = ___depthSubsystem1;
		if (L_2)
		{
			goto IL_0022;
		}
	}
	{
		G_B5_0 = (0);
		goto IL_0028;
	}

IL_0022:
	{
		XRDepthSubsystem_t4084359858 * L_3 = ___depthSubsystem1;
		NullCheck(L_3);
		intptr_t L_4 = ((Subsystem_t89723475 *)L_3)->get_m_Ptr_0();
		G_B5_0 = L_4;
	}

IL_0028:
	{
		V_0 = (intptr_t)G_B5_0;
		XRPlaneSubsystem_t2260142932 * L_5 = ___planeSubsystem2;
		if (L_5)
		{
			goto IL_0039;
		}
	}
	{
		G_B8_0 = (0);
		goto IL_003f;
	}

IL_0039:
	{
		XRPlaneSubsystem_t2260142932 * L_6 = ___planeSubsystem2;
		NullCheck(L_6);
		intptr_t L_7 = ((Subsystem_t89723475 *)L_6)->get_m_Ptr_0();
		G_B8_0 = L_7;
	}

IL_003f:
	{
		V_1 = (intptr_t)G_B8_0;
		Ray_t3785851493  L_8 = ___ray0;
		float L_9 = ___pointCloudRaycastAngleInDegrees5;
		intptr_t L_10 = V_0;
		intptr_t L_11 = V_1;
		int32_t L_12 = ___trackableTypeMask4;
		List_1_t3842879816 * L_13 = ___hitResults3;
		XRRaycastSubsystem_Internal_RaycastAsList_m2597254506(NULL /*static, unused*/, L_8, L_9, (intptr_t)L_10, (intptr_t)L_11, L_12, L_13, /*hidden argument*/NULL);
		return;
	}
}
// System.Void UnityEngine.Experimental.XR.XRRaycastSubsystem::Internal_RaycastAsList(UnityEngine.Ray,System.Single,System.IntPtr,System.IntPtr,UnityEngine.Experimental.XR.TrackableType,System.Collections.Generic.List`1<UnityEngine.Experimental.XR.XRRaycastHit>)
extern "C" IL2CPP_METHOD_ATTR void XRRaycastSubsystem_Internal_RaycastAsList_m2597254506 (RuntimeObject * __this /* static, unused */, Ray_t3785851493  ___ray0, float ___pointCloudRaycastAngleInDegrees1, intptr_t ___depthSubsystem2, intptr_t ___planeSubsystem3, int32_t ___trackableTypeMask4, List_1_t3842879816 * ___hitResultsOut5, const RuntimeMethod* method)
{
	{
		float L_0 = ___pointCloudRaycastAngleInDegrees1;
		intptr_t L_1 = ___depthSubsystem2;
		intptr_t L_2 = ___planeSubsystem3;
		int32_t L_3 = ___trackableTypeMask4;
		List_1_t3842879816 * L_4 = ___hitResultsOut5;
		XRRaycastSubsystem_Internal_RaycastAsList_Injected_m1278429163(NULL /*static, unused*/, (Ray_t3785851493 *)(&___ray0), L_0, (intptr_t)L_1, (intptr_t)L_2, L_3, L_4, /*hidden argument*/NULL);
		return;
	}
}
// System.Boolean UnityEngine.Experimental.XR.XRRaycastSubsystem::Internal_ScreenRaycastAsList(System.Single,System.Single,UnityEngine.Experimental.XR.TrackableType,System.Collections.Generic.List`1<UnityEngine.Experimental.XR.XRRaycastHit>)
extern "C" IL2CPP_METHOD_ATTR bool XRRaycastSubsystem_Internal_ScreenRaycastAsList_m964488973 (XRRaycastSubsystem_t2747560419 * __this, float ___screenX0, float ___screenY1, int32_t ___hitMask2, List_1_t3842879816 * ___hitResultsOut3, const RuntimeMethod* method)
{
	typedef bool (*XRRaycastSubsystem_Internal_ScreenRaycastAsList_m964488973_ftn) (XRRaycastSubsystem_t2747560419 *, float, float, int32_t, List_1_t3842879816 *);
	static XRRaycastSubsystem_Internal_ScreenRaycastAsList_m964488973_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (XRRaycastSubsystem_Internal_ScreenRaycastAsList_m964488973_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.Experimental.XR.XRRaycastSubsystem::Internal_ScreenRaycastAsList(System.Single,System.Single,UnityEngine.Experimental.XR.TrackableType,System.Collections.Generic.List`1<UnityEngine.Experimental.XR.XRRaycastHit>)");
	bool retVal = _il2cpp_icall_func(__this, ___screenX0, ___screenY1, ___hitMask2, ___hitResultsOut3);
	return retVal;
}
// System.Void UnityEngine.Experimental.XR.XRRaycastSubsystem::Internal_RaycastAsList_Injected(UnityEngine.Ray&,System.Single,System.IntPtr,System.IntPtr,UnityEngine.Experimental.XR.TrackableType,System.Collections.Generic.List`1<UnityEngine.Experimental.XR.XRRaycastHit>)
extern "C" IL2CPP_METHOD_ATTR void XRRaycastSubsystem_Internal_RaycastAsList_Injected_m1278429163 (RuntimeObject * __this /* static, unused */, Ray_t3785851493 * ___ray0, float ___pointCloudRaycastAngleInDegrees1, intptr_t ___depthSubsystem2, intptr_t ___planeSubsystem3, int32_t ___trackableTypeMask4, List_1_t3842879816 * ___hitResultsOut5, const RuntimeMethod* method)
{
	typedef void (*XRRaycastSubsystem_Internal_RaycastAsList_Injected_m1278429163_ftn) (Ray_t3785851493 *, float, intptr_t, intptr_t, int32_t, List_1_t3842879816 *);
	static XRRaycastSubsystem_Internal_RaycastAsList_Injected_m1278429163_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (XRRaycastSubsystem_Internal_RaycastAsList_Injected_m1278429163_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.Experimental.XR.XRRaycastSubsystem::Internal_RaycastAsList_Injected(UnityEngine.Ray&,System.Single,System.IntPtr,System.IntPtr,UnityEngine.Experimental.XR.TrackableType,System.Collections.Generic.List`1<UnityEngine.Experimental.XR.XRRaycastHit>)");
	_il2cpp_icall_func(___ray0, ___pointCloudRaycastAngleInDegrees1, ___depthSubsystem2, ___planeSubsystem3, ___trackableTypeMask4, ___hitResultsOut5);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.Experimental.XR.XRReferencePointSubsystem::add_ReferencePointUpdated(System.Action`1<UnityEngine.Experimental.XR.ReferencePointUpdatedEventArgs>)
extern "C" IL2CPP_METHOD_ATTR void XRReferencePointSubsystem_add_ReferencePointUpdated_m294229468 (XRReferencePointSubsystem_t416875062 * __this, Action_1_t2218980328 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRReferencePointSubsystem_add_ReferencePointUpdated_m294229468_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Action_1_t2218980328 * V_0 = NULL;
	Action_1_t2218980328 * V_1 = NULL;
	{
		Action_1_t2218980328 * L_0 = __this->get_ReferencePointUpdated_2();
		V_0 = L_0;
	}

IL_0007:
	{
		Action_1_t2218980328 * L_1 = V_0;
		V_1 = L_1;
		Action_1_t2218980328 ** L_2 = __this->get_address_of_ReferencePointUpdated_2();
		Action_1_t2218980328 * L_3 = V_1;
		Action_1_t2218980328 * L_4 = ___value0;
		Delegate_t1188392813 * L_5 = Delegate_Combine_m1859655160(NULL /*static, unused*/, L_3, L_4, /*hidden argument*/NULL);
		Action_1_t2218980328 * L_6 = V_0;
		Action_1_t2218980328 * L_7 = InterlockedCompareExchangeImpl<Action_1_t2218980328 *>((Action_1_t2218980328 **)L_2, ((Action_1_t2218980328 *)CastclassSealed((RuntimeObject*)L_5, Action_1_t2218980328_il2cpp_TypeInfo_var)), L_6);
		V_0 = L_7;
		Action_1_t2218980328 * L_8 = V_0;
		Action_1_t2218980328 * L_9 = V_1;
		if ((!(((RuntimeObject*)(Action_1_t2218980328 *)L_8) == ((RuntimeObject*)(Action_1_t2218980328 *)L_9))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Void UnityEngine.Experimental.XR.XRReferencePointSubsystem::remove_ReferencePointUpdated(System.Action`1<UnityEngine.Experimental.XR.ReferencePointUpdatedEventArgs>)
extern "C" IL2CPP_METHOD_ATTR void XRReferencePointSubsystem_remove_ReferencePointUpdated_m1056993445 (XRReferencePointSubsystem_t416875062 * __this, Action_1_t2218980328 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRReferencePointSubsystem_remove_ReferencePointUpdated_m1056993445_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Action_1_t2218980328 * V_0 = NULL;
	Action_1_t2218980328 * V_1 = NULL;
	{
		Action_1_t2218980328 * L_0 = __this->get_ReferencePointUpdated_2();
		V_0 = L_0;
	}

IL_0007:
	{
		Action_1_t2218980328 * L_1 = V_0;
		V_1 = L_1;
		Action_1_t2218980328 ** L_2 = __this->get_address_of_ReferencePointUpdated_2();
		Action_1_t2218980328 * L_3 = V_1;
		Action_1_t2218980328 * L_4 = ___value0;
		Delegate_t1188392813 * L_5 = Delegate_Remove_m334097152(NULL /*static, unused*/, L_3, L_4, /*hidden argument*/NULL);
		Action_1_t2218980328 * L_6 = V_0;
		Action_1_t2218980328 * L_7 = InterlockedCompareExchangeImpl<Action_1_t2218980328 *>((Action_1_t2218980328 **)L_2, ((Action_1_t2218980328 *)CastclassSealed((RuntimeObject*)L_5, Action_1_t2218980328_il2cpp_TypeInfo_var)), L_6);
		V_0 = L_7;
		Action_1_t2218980328 * L_8 = V_0;
		Action_1_t2218980328 * L_9 = V_1;
		if ((!(((RuntimeObject*)(Action_1_t2218980328 *)L_8) == ((RuntimeObject*)(Action_1_t2218980328 *)L_9))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Boolean UnityEngine.Experimental.XR.XRReferencePointSubsystem::TryAddReferencePoint(UnityEngine.Vector3,UnityEngine.Quaternion,UnityEngine.Experimental.XR.TrackableId&)
extern "C" IL2CPP_METHOD_ATTR bool XRReferencePointSubsystem_TryAddReferencePoint_m2441837896 (XRReferencePointSubsystem_t416875062 * __this, Vector3_t3722313464  ___position0, Quaternion_t2301928331  ___rotation1, TrackableId_t1251031970 * ___referencePointId2, const RuntimeMethod* method)
{
	{
		TrackableId_t1251031970 * L_0 = ___referencePointId2;
		bool L_1 = XRReferencePointSubsystem_TryAddReferencePoint_Injected_m620548233(__this, (Vector3_t3722313464 *)(&___position0), (Quaternion_t2301928331 *)(&___rotation1), (TrackableId_t1251031970 *)L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Boolean UnityEngine.Experimental.XR.XRReferencePointSubsystem::TryRemoveReferencePoint(UnityEngine.Experimental.XR.TrackableId)
extern "C" IL2CPP_METHOD_ATTR bool XRReferencePointSubsystem_TryRemoveReferencePoint_m2549834147 (XRReferencePointSubsystem_t416875062 * __this, TrackableId_t1251031970  ___referencePointId0, const RuntimeMethod* method)
{
	{
		bool L_0 = XRReferencePointSubsystem_TryRemoveReferencePoint_Injected_m3144697073(__this, (TrackableId_t1251031970 *)(&___referencePointId0), /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Boolean UnityEngine.Experimental.XR.XRReferencePointSubsystem::TryGetReferencePoint(UnityEngine.Experimental.XR.TrackableId,UnityEngine.Experimental.XR.ReferencePoint&)
extern "C" IL2CPP_METHOD_ATTR bool XRReferencePointSubsystem_TryGetReferencePoint_m1012561686 (XRReferencePointSubsystem_t416875062 * __this, TrackableId_t1251031970  ___referencePointId0, ReferencePoint_t394942483 * ___referencePoint1, const RuntimeMethod* method)
{
	{
		ReferencePoint_t394942483 * L_0 = ___referencePoint1;
		bool L_1 = XRReferencePointSubsystem_TryGetReferencePoint_Injected_m4266629244(__this, (TrackableId_t1251031970 *)(&___referencePointId0), (ReferencePoint_t394942483 *)L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Void UnityEngine.Experimental.XR.XRReferencePointSubsystem::InvokeReferencePointUpdatedEvent(UnityEngine.Experimental.XR.ReferencePoint,UnityEngine.Experimental.XR.TrackingState,UnityEngine.Pose)
extern "C" IL2CPP_METHOD_ATTR void XRReferencePointSubsystem_InvokeReferencePointUpdatedEvent_m2042954667 (XRReferencePointSubsystem_t416875062 * __this, ReferencePoint_t394942483  ___updatedReferencePoint0, int32_t ___previousTrackingState1, Pose_t545244865  ___previousPose2, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRReferencePointSubsystem_InvokeReferencePointUpdatedEvent_m2042954667_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ReferencePointUpdatedEventArgs_t2046512733  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		Action_1_t2218980328 * L_0 = __this->get_ReferencePointUpdated_2();
		if (!L_0)
		{
			goto IL_0038;
		}
	}
	{
		Action_1_t2218980328 * L_1 = __this->get_ReferencePointUpdated_2();
		il2cpp_codegen_initobj((&V_0), sizeof(ReferencePointUpdatedEventArgs_t2046512733 ));
		ReferencePoint_t394942483  L_2 = ___updatedReferencePoint0;
		ReferencePointUpdatedEventArgs_set_ReferencePoint_m2108838300((ReferencePointUpdatedEventArgs_t2046512733 *)(&V_0), L_2, /*hidden argument*/NULL);
		int32_t L_3 = ___previousTrackingState1;
		ReferencePointUpdatedEventArgs_set_PreviousTrackingState_m363545448((ReferencePointUpdatedEventArgs_t2046512733 *)(&V_0), L_3, /*hidden argument*/NULL);
		Pose_t545244865  L_4 = ___previousPose2;
		ReferencePointUpdatedEventArgs_set_PreviousPose_m2838622129((ReferencePointUpdatedEventArgs_t2046512733 *)(&V_0), L_4, /*hidden argument*/NULL);
		ReferencePointUpdatedEventArgs_t2046512733  L_5 = V_0;
		NullCheck(L_1);
		Action_1_Invoke_m1143137826(L_1, L_5, /*hidden argument*/Action_1_Invoke_m1143137826_RuntimeMethod_var);
	}

IL_0038:
	{
		return;
	}
}
// System.Boolean UnityEngine.Experimental.XR.XRReferencePointSubsystem::TryAddReferencePoint_Injected(UnityEngine.Vector3&,UnityEngine.Quaternion&,UnityEngine.Experimental.XR.TrackableId&)
extern "C" IL2CPP_METHOD_ATTR bool XRReferencePointSubsystem_TryAddReferencePoint_Injected_m620548233 (XRReferencePointSubsystem_t416875062 * __this, Vector3_t3722313464 * ___position0, Quaternion_t2301928331 * ___rotation1, TrackableId_t1251031970 * ___referencePointId2, const RuntimeMethod* method)
{
	typedef bool (*XRReferencePointSubsystem_TryAddReferencePoint_Injected_m620548233_ftn) (XRReferencePointSubsystem_t416875062 *, Vector3_t3722313464 *, Quaternion_t2301928331 *, TrackableId_t1251031970 *);
	static XRReferencePointSubsystem_TryAddReferencePoint_Injected_m620548233_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (XRReferencePointSubsystem_TryAddReferencePoint_Injected_m620548233_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.Experimental.XR.XRReferencePointSubsystem::TryAddReferencePoint_Injected(UnityEngine.Vector3&,UnityEngine.Quaternion&,UnityEngine.Experimental.XR.TrackableId&)");
	bool retVal = _il2cpp_icall_func(__this, ___position0, ___rotation1, ___referencePointId2);
	return retVal;
}
// System.Boolean UnityEngine.Experimental.XR.XRReferencePointSubsystem::TryRemoveReferencePoint_Injected(UnityEngine.Experimental.XR.TrackableId&)
extern "C" IL2CPP_METHOD_ATTR bool XRReferencePointSubsystem_TryRemoveReferencePoint_Injected_m3144697073 (XRReferencePointSubsystem_t416875062 * __this, TrackableId_t1251031970 * ___referencePointId0, const RuntimeMethod* method)
{
	typedef bool (*XRReferencePointSubsystem_TryRemoveReferencePoint_Injected_m3144697073_ftn) (XRReferencePointSubsystem_t416875062 *, TrackableId_t1251031970 *);
	static XRReferencePointSubsystem_TryRemoveReferencePoint_Injected_m3144697073_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (XRReferencePointSubsystem_TryRemoveReferencePoint_Injected_m3144697073_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.Experimental.XR.XRReferencePointSubsystem::TryRemoveReferencePoint_Injected(UnityEngine.Experimental.XR.TrackableId&)");
	bool retVal = _il2cpp_icall_func(__this, ___referencePointId0);
	return retVal;
}
// System.Boolean UnityEngine.Experimental.XR.XRReferencePointSubsystem::TryGetReferencePoint_Injected(UnityEngine.Experimental.XR.TrackableId&,UnityEngine.Experimental.XR.ReferencePoint&)
extern "C" IL2CPP_METHOD_ATTR bool XRReferencePointSubsystem_TryGetReferencePoint_Injected_m4266629244 (XRReferencePointSubsystem_t416875062 * __this, TrackableId_t1251031970 * ___referencePointId0, ReferencePoint_t394942483 * ___referencePoint1, const RuntimeMethod* method)
{
	typedef bool (*XRReferencePointSubsystem_TryGetReferencePoint_Injected_m4266629244_ftn) (XRReferencePointSubsystem_t416875062 *, TrackableId_t1251031970 *, ReferencePoint_t394942483 *);
	static XRReferencePointSubsystem_TryGetReferencePoint_Injected_m4266629244_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (XRReferencePointSubsystem_TryGetReferencePoint_Injected_m4266629244_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.Experimental.XR.XRReferencePointSubsystem::TryGetReferencePoint_Injected(UnityEngine.Experimental.XR.TrackableId&,UnityEngine.Experimental.XR.ReferencePoint&)");
	bool retVal = _il2cpp_icall_func(__this, ___referencePointId0, ___referencePoint1);
	return retVal;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.Experimental.XR.XRSessionSubsystem::add_TrackingStateChanged(System.Action`1<UnityEngine.Experimental.XR.SessionTrackingStateChangedEventArgs>)
extern "C" IL2CPP_METHOD_ATTR void XRSessionSubsystem_add_TrackingStateChanged_m1723182294 (XRSessionSubsystem_t3616338244 * __this, Action_1_t2515503250 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRSessionSubsystem_add_TrackingStateChanged_m1723182294_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Action_1_t2515503250 * V_0 = NULL;
	Action_1_t2515503250 * V_1 = NULL;
	{
		Action_1_t2515503250 * L_0 = __this->get_TrackingStateChanged_2();
		V_0 = L_0;
	}

IL_0007:
	{
		Action_1_t2515503250 * L_1 = V_0;
		V_1 = L_1;
		Action_1_t2515503250 ** L_2 = __this->get_address_of_TrackingStateChanged_2();
		Action_1_t2515503250 * L_3 = V_1;
		Action_1_t2515503250 * L_4 = ___value0;
		Delegate_t1188392813 * L_5 = Delegate_Combine_m1859655160(NULL /*static, unused*/, L_3, L_4, /*hidden argument*/NULL);
		Action_1_t2515503250 * L_6 = V_0;
		Action_1_t2515503250 * L_7 = InterlockedCompareExchangeImpl<Action_1_t2515503250 *>((Action_1_t2515503250 **)L_2, ((Action_1_t2515503250 *)CastclassSealed((RuntimeObject*)L_5, Action_1_t2515503250_il2cpp_TypeInfo_var)), L_6);
		V_0 = L_7;
		Action_1_t2515503250 * L_8 = V_0;
		Action_1_t2515503250 * L_9 = V_1;
		if ((!(((RuntimeObject*)(Action_1_t2515503250 *)L_8) == ((RuntimeObject*)(Action_1_t2515503250 *)L_9))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Void UnityEngine.Experimental.XR.XRSessionSubsystem::remove_TrackingStateChanged(System.Action`1<UnityEngine.Experimental.XR.SessionTrackingStateChangedEventArgs>)
extern "C" IL2CPP_METHOD_ATTR void XRSessionSubsystem_remove_TrackingStateChanged_m2915536988 (XRSessionSubsystem_t3616338244 * __this, Action_1_t2515503250 * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRSessionSubsystem_remove_TrackingStateChanged_m2915536988_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Action_1_t2515503250 * V_0 = NULL;
	Action_1_t2515503250 * V_1 = NULL;
	{
		Action_1_t2515503250 * L_0 = __this->get_TrackingStateChanged_2();
		V_0 = L_0;
	}

IL_0007:
	{
		Action_1_t2515503250 * L_1 = V_0;
		V_1 = L_1;
		Action_1_t2515503250 ** L_2 = __this->get_address_of_TrackingStateChanged_2();
		Action_1_t2515503250 * L_3 = V_1;
		Action_1_t2515503250 * L_4 = ___value0;
		Delegate_t1188392813 * L_5 = Delegate_Remove_m334097152(NULL /*static, unused*/, L_3, L_4, /*hidden argument*/NULL);
		Action_1_t2515503250 * L_6 = V_0;
		Action_1_t2515503250 * L_7 = InterlockedCompareExchangeImpl<Action_1_t2515503250 *>((Action_1_t2515503250 **)L_2, ((Action_1_t2515503250 *)CastclassSealed((RuntimeObject*)L_5, Action_1_t2515503250_il2cpp_TypeInfo_var)), L_6);
		V_0 = L_7;
		Action_1_t2515503250 * L_8 = V_0;
		Action_1_t2515503250 * L_9 = V_1;
		if ((!(((RuntimeObject*)(Action_1_t2515503250 *)L_8) == ((RuntimeObject*)(Action_1_t2515503250 *)L_9))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Void UnityEngine.Experimental.XR.XRSessionSubsystem::InvokeTrackingStateChangedEvent(UnityEngine.Experimental.XR.TrackingState)
extern "C" IL2CPP_METHOD_ATTR void XRSessionSubsystem_InvokeTrackingStateChangedEvent_m3292975511 (XRSessionSubsystem_t3616338244 * __this, int32_t ___newState0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRSessionSubsystem_InvokeTrackingStateChangedEvent_m3292975511_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	SessionTrackingStateChangedEventArgs_t2343035655  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		Action_1_t2515503250 * L_0 = __this->get_TrackingStateChanged_2();
		if (!L_0)
		{
			goto IL_0032;
		}
	}
	{
		Action_1_t2515503250 * L_1 = __this->get_TrackingStateChanged_2();
		il2cpp_codegen_initobj((&V_0), sizeof(SessionTrackingStateChangedEventArgs_t2343035655 ));
		(&V_0)->set_m_Session_0(__this);
		int32_t L_2 = ___newState0;
		SessionTrackingStateChangedEventArgs_set_NewState_m3890790011((SessionTrackingStateChangedEventArgs_t2343035655 *)(&V_0), L_2, /*hidden argument*/NULL);
		SessionTrackingStateChangedEventArgs_t2343035655  L_3 = V_0;
		NullCheck(L_1);
		Action_1_Invoke_m3768946330(L_1, L_3, /*hidden argument*/Action_1_Invoke_m3768946330_RuntimeMethod_var);
	}

IL_0032:
	{
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.XR.InputTracking::GetNodeStatesInternal(System.Object)
extern "C" IL2CPP_METHOD_ATTR void InputTracking_GetNodeStatesInternal_m1640706757 (RuntimeObject * __this /* static, unused */, RuntimeObject * ___nodeStates0, const RuntimeMethod* method)
{
	typedef void (*InputTracking_GetNodeStatesInternal_m1640706757_ftn) (RuntimeObject *);
	static InputTracking_GetNodeStatesInternal_m1640706757_ftn _il2cpp_icall_func;
	if (!_il2cpp_icall_func)
	_il2cpp_icall_func = (InputTracking_GetNodeStatesInternal_m1640706757_ftn)il2cpp_codegen_resolve_icall ("UnityEngine.XR.InputTracking::GetNodeStatesInternal(System.Object)");
	_il2cpp_icall_func(___nodeStates0);
}
// System.Void UnityEngine.XR.InputTracking::GetNodeStates(System.Collections.Generic.List`1<UnityEngine.XR.XRNodeState>)
extern "C" IL2CPP_METHOD_ATTR void InputTracking_GetNodeStates_m713678237 (RuntimeObject * __this /* static, unused */, List_1_t929709876 * ___nodeStates0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (InputTracking_GetNodeStates_m713678237_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		List_1_t929709876 * L_0 = ___nodeStates0;
		if (L_0)
		{
			goto IL_0013;
		}
	}
	{
		ArgumentNullException_t1615371798 * L_1 = (ArgumentNullException_t1615371798 *)il2cpp_codegen_object_new(ArgumentNullException_t1615371798_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m1170824041(L_1, _stringLiteral3520200148, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1, NULL, InputTracking_GetNodeStates_m713678237_RuntimeMethod_var);
	}

IL_0013:
	{
		List_1_t929709876 * L_2 = ___nodeStates0;
		NullCheck(L_2);
		List_1_Clear_m1794174222(L_2, /*hidden argument*/List_1_Clear_m1794174222_RuntimeMethod_var);
		List_1_t929709876 * L_3 = ___nodeStates0;
		IL2CPP_RUNTIME_CLASS_INIT(InputTracking_t2240286067_il2cpp_TypeInfo_var);
		InputTracking_GetNodeStatesInternal_m1640706757(NULL /*static, unused*/, L_3, /*hidden argument*/NULL);
		return;
	}
}
// System.Void UnityEngine.XR.InputTracking::InvokeTrackingEvent(UnityEngine.XR.InputTracking/TrackingStateEventType,UnityEngine.XR.XRNode,System.Int64,System.Boolean)
extern "C" IL2CPP_METHOD_ATTR void InputTracking_InvokeTrackingEvent_m2819866424 (RuntimeObject * __this /* static, unused */, int32_t ___eventType0, int32_t ___nodeType1, int64_t ___uniqueID2, bool ___tracked3, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (InputTracking_InvokeTrackingEvent_m2819866424_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Action_1_t3925070025 * V_0 = NULL;
	XRNodeState_t3752602430  V_1;
	memset(&V_1, 0, sizeof(V_1));
	{
		V_0 = (Action_1_t3925070025 *)NULL;
		il2cpp_codegen_initobj((&V_1), sizeof(XRNodeState_t3752602430 ));
		int64_t L_0 = ___uniqueID2;
		XRNodeState_set_uniqueID_m721524361((XRNodeState_t3752602430 *)(&V_1), L_0, /*hidden argument*/NULL);
		int32_t L_1 = ___nodeType1;
		XRNodeState_set_nodeType_m1597434625((XRNodeState_t3752602430 *)(&V_1), L_1, /*hidden argument*/NULL);
		bool L_2 = ___tracked3;
		XRNodeState_set_tracked_m3066928959((XRNodeState_t3752602430 *)(&V_1), L_2, /*hidden argument*/NULL);
		int32_t L_3 = ___eventType0;
		switch (L_3)
		{
			case 0:
			{
				goto IL_0054;
			}
			case 1:
			{
				goto IL_005f;
			}
			case 2:
			{
				goto IL_003e;
			}
			case 3:
			{
				goto IL_0049;
			}
		}
	}
	{
		goto IL_006a;
	}

IL_003e:
	{
		IL2CPP_RUNTIME_CLASS_INIT(InputTracking_t2240286067_il2cpp_TypeInfo_var);
		Action_1_t3925070025 * L_4 = ((InputTracking_t2240286067_StaticFields*)il2cpp_codegen_static_fields_for(InputTracking_t2240286067_il2cpp_TypeInfo_var))->get_trackingAcquired_0();
		V_0 = L_4;
		goto IL_0080;
	}

IL_0049:
	{
		IL2CPP_RUNTIME_CLASS_INIT(InputTracking_t2240286067_il2cpp_TypeInfo_var);
		Action_1_t3925070025 * L_5 = ((InputTracking_t2240286067_StaticFields*)il2cpp_codegen_static_fields_for(InputTracking_t2240286067_il2cpp_TypeInfo_var))->get_trackingLost_1();
		V_0 = L_5;
		goto IL_0080;
	}

IL_0054:
	{
		IL2CPP_RUNTIME_CLASS_INIT(InputTracking_t2240286067_il2cpp_TypeInfo_var);
		Action_1_t3925070025 * L_6 = ((InputTracking_t2240286067_StaticFields*)il2cpp_codegen_static_fields_for(InputTracking_t2240286067_il2cpp_TypeInfo_var))->get_nodeAdded_2();
		V_0 = L_6;
		goto IL_0080;
	}

IL_005f:
	{
		IL2CPP_RUNTIME_CLASS_INIT(InputTracking_t2240286067_il2cpp_TypeInfo_var);
		Action_1_t3925070025 * L_7 = ((InputTracking_t2240286067_StaticFields*)il2cpp_codegen_static_fields_for(InputTracking_t2240286067_il2cpp_TypeInfo_var))->get_nodeRemoved_3();
		V_0 = L_7;
		goto IL_0080;
	}

IL_006a:
	{
		int32_t L_8 = ___eventType0;
		int32_t L_9 = L_8;
		RuntimeObject * L_10 = Box(TrackingStateEventType_t4085253601_il2cpp_TypeInfo_var, &L_9);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_11 = String_Concat_m904156431(NULL /*static, unused*/, _stringLiteral450688759, L_10, /*hidden argument*/NULL);
		ArgumentException_t132251570 * L_12 = (ArgumentException_t132251570 *)il2cpp_codegen_object_new(ArgumentException_t132251570_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m1312628991(L_12, L_11, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_12, NULL, InputTracking_InvokeTrackingEvent_m2819866424_RuntimeMethod_var);
	}

IL_0080:
	{
		Action_1_t3925070025 * L_13 = V_0;
		if (!L_13)
		{
			goto IL_008f;
		}
	}
	{
		Action_1_t3925070025 * L_14 = V_0;
		XRNodeState_t3752602430  L_15 = V_1;
		NullCheck(L_14);
		Action_1_Invoke_m1458665122(L_14, L_15, /*hidden argument*/Action_1_Invoke_m1458665122_RuntimeMethod_var);
	}

IL_008f:
	{
		return;
	}
}
// System.Void UnityEngine.XR.InputTracking::.cctor()
extern "C" IL2CPP_METHOD_ATTR void InputTracking__cctor_m3381564435 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (InputTracking__cctor_m3381564435_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		((InputTracking_t2240286067_StaticFields*)il2cpp_codegen_static_fields_for(InputTracking_t2240286067_il2cpp_TypeInfo_var))->set_trackingAcquired_0((Action_1_t3925070025 *)NULL);
		((InputTracking_t2240286067_StaticFields*)il2cpp_codegen_static_fields_for(InputTracking_t2240286067_il2cpp_TypeInfo_var))->set_trackingLost_1((Action_1_t3925070025 *)NULL);
		((InputTracking_t2240286067_StaticFields*)il2cpp_codegen_static_fields_for(InputTracking_t2240286067_il2cpp_TypeInfo_var))->set_nodeAdded_2((Action_1_t3925070025 *)NULL);
		((InputTracking_t2240286067_StaticFields*)il2cpp_codegen_static_fields_for(InputTracking_t2240286067_il2cpp_TypeInfo_var))->set_nodeRemoved_3((Action_1_t3925070025 *)NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.XR.XRNodeState::set_uniqueID(System.UInt64)
extern "C" IL2CPP_METHOD_ATTR void XRNodeState_set_uniqueID_m721524361 (XRNodeState_t3752602430 * __this, uint64_t ___value0, const RuntimeMethod* method)
{
	{
		uint64_t L_0 = ___value0;
		__this->set_m_UniqueID_9(L_0);
		return;
	}
}
extern "C"  void XRNodeState_set_uniqueID_m721524361_AdjustorThunk (RuntimeObject * __this, uint64_t ___value0, const RuntimeMethod* method)
{
	XRNodeState_t3752602430 * _thisAdjusted = reinterpret_cast<XRNodeState_t3752602430 *>(__this + 1);
	XRNodeState_set_uniqueID_m721524361(_thisAdjusted, ___value0, method);
}
// UnityEngine.XR.XRNode UnityEngine.XR.XRNodeState::get_nodeType()
extern "C" IL2CPP_METHOD_ATTR int32_t XRNodeState_get_nodeType_m1565792694 (XRNodeState_t3752602430 * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	{
		int32_t L_0 = __this->get_m_Type_0();
		V_0 = L_0;
		goto IL_000d;
	}

IL_000d:
	{
		int32_t L_1 = V_0;
		return L_1;
	}
}
extern "C"  int32_t XRNodeState_get_nodeType_m1565792694_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	XRNodeState_t3752602430 * _thisAdjusted = reinterpret_cast<XRNodeState_t3752602430 *>(__this + 1);
	return XRNodeState_get_nodeType_m1565792694(_thisAdjusted, method);
}
// System.Void UnityEngine.XR.XRNodeState::set_nodeType(UnityEngine.XR.XRNode)
extern "C" IL2CPP_METHOD_ATTR void XRNodeState_set_nodeType_m1597434625 (XRNodeState_t3752602430 * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		int32_t L_0 = ___value0;
		__this->set_m_Type_0(L_0);
		return;
	}
}
extern "C"  void XRNodeState_set_nodeType_m1597434625_AdjustorThunk (RuntimeObject * __this, int32_t ___value0, const RuntimeMethod* method)
{
	XRNodeState_t3752602430 * _thisAdjusted = reinterpret_cast<XRNodeState_t3752602430 *>(__this + 1);
	XRNodeState_set_nodeType_m1597434625(_thisAdjusted, ___value0, method);
}
// System.Void UnityEngine.XR.XRNodeState::set_tracked(System.Boolean)
extern "C" IL2CPP_METHOD_ATTR void XRNodeState_set_tracked_m3066928959 (XRNodeState_t3752602430 * __this, bool ___value0, const RuntimeMethod* method)
{
	XRNodeState_t3752602430 * G_B2_0 = NULL;
	XRNodeState_t3752602430 * G_B1_0 = NULL;
	int32_t G_B3_0 = 0;
	XRNodeState_t3752602430 * G_B3_1 = NULL;
	{
		bool L_0 = ___value0;
		G_B1_0 = __this;
		if (!L_0)
		{
			G_B2_0 = __this;
			goto IL_000e;
		}
	}
	{
		G_B3_0 = 1;
		G_B3_1 = G_B1_0;
		goto IL_000f;
	}

IL_000e:
	{
		G_B3_0 = 0;
		G_B3_1 = G_B2_0;
	}

IL_000f:
	{
		G_B3_1->set_m_Tracked_8(G_B3_0);
		return;
	}
}
extern "C"  void XRNodeState_set_tracked_m3066928959_AdjustorThunk (RuntimeObject * __this, bool ___value0, const RuntimeMethod* method)
{
	XRNodeState_t3752602430 * _thisAdjusted = reinterpret_cast<XRNodeState_t3752602430 *>(__this + 1);
	XRNodeState_set_tracked_m3066928959(_thisAdjusted, ___value0, method);
}
// System.Boolean UnityEngine.XR.XRNodeState::TryGetPosition(UnityEngine.Vector3&)
extern "C" IL2CPP_METHOD_ATTR bool XRNodeState_TryGetPosition_m2700381506 (XRNodeState_t3752602430 * __this, Vector3_t3722313464 * ___position0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRNodeState_TryGetPosition_m2700381506_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	{
		Vector3_t3722313464  L_0 = __this->get_m_Position_2();
		Vector3_t3722313464 * L_1 = ___position0;
		bool L_2 = XRNodeState_TryGet_TisVector3_t3722313464_m270903620((XRNodeState_t3752602430 *)__this, L_0, 1, (Vector3_t3722313464 *)L_1, /*hidden argument*/XRNodeState_TryGet_TisVector3_t3722313464_m270903620_RuntimeMethod_var);
		V_0 = L_2;
		goto IL_0015;
	}

IL_0015:
	{
		bool L_3 = V_0;
		return L_3;
	}
}
extern "C"  bool XRNodeState_TryGetPosition_m2700381506_AdjustorThunk (RuntimeObject * __this, Vector3_t3722313464 * ___position0, const RuntimeMethod* method)
{
	XRNodeState_t3752602430 * _thisAdjusted = reinterpret_cast<XRNodeState_t3752602430 *>(__this + 1);
	return XRNodeState_TryGetPosition_m2700381506(_thisAdjusted, ___position0, method);
}
// System.Boolean UnityEngine.XR.XRNodeState::TryGetRotation(UnityEngine.Quaternion&)
extern "C" IL2CPP_METHOD_ATTR bool XRNodeState_TryGetRotation_m2439801437 (XRNodeState_t3752602430 * __this, Quaternion_t2301928331 * ___rotation0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRNodeState_TryGetRotation_m2439801437_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	{
		Quaternion_t2301928331  L_0 = __this->get_m_Rotation_3();
		Quaternion_t2301928331 * L_1 = ___rotation0;
		bool L_2 = XRNodeState_TryGet_TisQuaternion_t2301928331_m1353060540((XRNodeState_t3752602430 *)__this, L_0, 2, (Quaternion_t2301928331 *)L_1, /*hidden argument*/XRNodeState_TryGet_TisQuaternion_t2301928331_m1353060540_RuntimeMethod_var);
		V_0 = L_2;
		goto IL_0015;
	}

IL_0015:
	{
		bool L_3 = V_0;
		return L_3;
	}
}
extern "C"  bool XRNodeState_TryGetRotation_m2439801437_AdjustorThunk (RuntimeObject * __this, Quaternion_t2301928331 * ___rotation0, const RuntimeMethod* method)
{
	XRNodeState_t3752602430 * _thisAdjusted = reinterpret_cast<XRNodeState_t3752602430 *>(__this + 1);
	return XRNodeState_TryGetRotation_m2439801437(_thisAdjusted, ___rotation0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif

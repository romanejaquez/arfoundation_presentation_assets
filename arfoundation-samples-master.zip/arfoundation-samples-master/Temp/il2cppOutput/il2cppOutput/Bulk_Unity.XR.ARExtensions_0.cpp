﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>
#include <stdint.h>

#include "il2cpp-class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "il2cpp-object-internals.h"

template <typename R>
struct VirtFuncInvoker0
{
	typedef R (*Func)(void*, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeObject* obj)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		return ((Func)invokeData.methodPtr)(obj, invokeData.method);
	}
};
template <typename R, typename T1>
struct VirtFuncInvoker1
{
	typedef R (*Func)(void*, T1, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeObject* obj, T1 p1)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		return ((Func)invokeData.methodPtr)(obj, p1, invokeData.method);
	}
};
template <typename T1, typename T2, typename T3, typename T4, typename T5>
struct VirtActionInvoker5
{
	typedef void (*Action)(void*, T1, T2, T3, T4, T5, const RuntimeMethod*);

	static inline void Invoke (Il2CppMethodSlot slot, RuntimeObject* obj, T1 p1, T2 p2, T3 p3, T4 p4, T5 p5)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		((Action)invokeData.methodPtr)(obj, p1, p2, p3, p4, p5, invokeData.method);
	}
};
template <typename R, typename T1, typename T2>
struct VirtFuncInvoker2
{
	typedef R (*Func)(void*, T1, T2, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeObject* obj, T1 p1, T2 p2)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		return ((Func)invokeData.methodPtr)(obj, p1, p2, invokeData.method);
	}
};
template <typename R, typename T1, typename T2, typename T3>
struct VirtFuncInvoker3
{
	typedef R (*Func)(void*, T1, T2, T3, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeObject* obj, T1 p1, T2 p2, T3 p3)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		return ((Func)invokeData.methodPtr)(obj, p1, p2, p3, invokeData.method);
	}
};
template <typename T1, typename T2, typename T3, typename T4, typename T5>
struct GenericVirtActionInvoker5
{
	typedef void (*Action)(void*, T1, T2, T3, T4, T5, const RuntimeMethod*);

	static inline void Invoke (const RuntimeMethod* method, RuntimeObject* obj, T1 p1, T2 p2, T3 p3, T4 p4, T5 p5)
	{
		VirtualInvokeData invokeData;
		il2cpp_codegen_get_generic_virtual_invoke_data(method, obj, &invokeData);
		((Action)invokeData.methodPtr)(obj, p1, p2, p3, p4, p5, invokeData.method);
	}
};
template <typename R, typename T1, typename T2>
struct GenericVirtFuncInvoker2
{
	typedef R (*Func)(void*, T1, T2, const RuntimeMethod*);

	static inline R Invoke (const RuntimeMethod* method, RuntimeObject* obj, T1 p1, T2 p2)
	{
		VirtualInvokeData invokeData;
		il2cpp_codegen_get_generic_virtual_invoke_data(method, obj, &invokeData);
		return ((Func)invokeData.methodPtr)(obj, p1, p2, invokeData.method);
	}
};
template <typename R, typename T1>
struct GenericVirtFuncInvoker1
{
	typedef R (*Func)(void*, T1, const RuntimeMethod*);

	static inline R Invoke (const RuntimeMethod* method, RuntimeObject* obj, T1 p1)
	{
		VirtualInvokeData invokeData;
		il2cpp_codegen_get_generic_virtual_invoke_data(method, obj, &invokeData);
		return ((Func)invokeData.methodPtr)(obj, p1, invokeData.method);
	}
};
template <typename R, typename T1, typename T2, typename T3>
struct GenericVirtFuncInvoker3
{
	typedef R (*Func)(void*, T1, T2, T3, const RuntimeMethod*);

	static inline R Invoke (const RuntimeMethod* method, RuntimeObject* obj, T1 p1, T2 p2, T3 p3)
	{
		VirtualInvokeData invokeData;
		il2cpp_codegen_get_generic_virtual_invoke_data(method, obj, &invokeData);
		return ((Func)invokeData.methodPtr)(obj, p1, p2, p3, invokeData.method);
	}
};
template <typename R, typename T1>
struct InterfaceFuncInvoker1
{
	typedef R (*Func)(void*, T1, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj, T1 p1)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		return ((Func)invokeData.methodPtr)(obj, p1, invokeData.method);
	}
};
template <typename R, typename T1, typename T2, typename T3, typename T4>
struct InterfaceFuncInvoker4
{
	typedef R (*Func)(void*, T1, T2, T3, T4, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj, T1 p1, T2 p2, T3 p3, T4 p4)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		return ((Func)invokeData.methodPtr)(obj, p1, p2, p3, p4, invokeData.method);
	}
};
template <typename T1>
struct InterfaceActionInvoker1
{
	typedef void (*Action)(void*, T1, const RuntimeMethod*);

	static inline void Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj, T1 p1)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		((Action)invokeData.methodPtr)(obj, p1, invokeData.method);
	}
};
template <typename R, typename T1, typename T2, typename T3, typename T4, typename T5>
struct InterfaceFuncInvoker5
{
	typedef R (*Func)(void*, T1, T2, T3, T4, T5, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj, T1 p1, T2 p2, T3 p3, T4 p4, T5 p5)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		return ((Func)invokeData.methodPtr)(obj, p1, p2, p3, p4, p5, invokeData.method);
	}
};
template <typename T1, typename T2, typename T3, typename T4, typename T5>
struct InterfaceActionInvoker5
{
	typedef void (*Action)(void*, T1, T2, T3, T4, T5, const RuntimeMethod*);

	static inline void Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj, T1 p1, T2 p2, T3 p3, T4 p4, T5 p5)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		((Action)invokeData.methodPtr)(obj, p1, p2, p3, p4, p5, invokeData.method);
	}
};
template <typename R, typename T1, typename T2>
struct InterfaceFuncInvoker2
{
	typedef R (*Func)(void*, T1, T2, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj, T1 p1, T2 p2)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		return ((Func)invokeData.methodPtr)(obj, p1, p2, invokeData.method);
	}
};
template <typename R, typename T1, typename T2, typename T3>
struct InterfaceFuncInvoker3
{
	typedef R (*Func)(void*, T1, T2, T3, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj, T1 p1, T2 p2, T3 p3)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		return ((Func)invokeData.methodPtr)(obj, p1, p2, p3, invokeData.method);
	}
};
template <typename T1, typename T2, typename T3, typename T4, typename T5>
struct GenericInterfaceActionInvoker5
{
	typedef void (*Action)(void*, T1, T2, T3, T4, T5, const RuntimeMethod*);

	static inline void Invoke (const RuntimeMethod* method, RuntimeObject* obj, T1 p1, T2 p2, T3 p3, T4 p4, T5 p5)
	{
		VirtualInvokeData invokeData;
		il2cpp_codegen_get_generic_interface_invoke_data(method, obj, &invokeData);
		((Action)invokeData.methodPtr)(obj, p1, p2, p3, p4, p5, invokeData.method);
	}
};
template <typename R, typename T1, typename T2>
struct GenericInterfaceFuncInvoker2
{
	typedef R (*Func)(void*, T1, T2, const RuntimeMethod*);

	static inline R Invoke (const RuntimeMethod* method, RuntimeObject* obj, T1 p1, T2 p2)
	{
		VirtualInvokeData invokeData;
		il2cpp_codegen_get_generic_interface_invoke_data(method, obj, &invokeData);
		return ((Func)invokeData.methodPtr)(obj, p1, p2, invokeData.method);
	}
};
template <typename R, typename T1>
struct GenericInterfaceFuncInvoker1
{
	typedef R (*Func)(void*, T1, const RuntimeMethod*);

	static inline R Invoke (const RuntimeMethod* method, RuntimeObject* obj, T1 p1)
	{
		VirtualInvokeData invokeData;
		il2cpp_codegen_get_generic_interface_invoke_data(method, obj, &invokeData);
		return ((Func)invokeData.methodPtr)(obj, p1, invokeData.method);
	}
};
template <typename R, typename T1, typename T2, typename T3>
struct GenericInterfaceFuncInvoker3
{
	typedef R (*Func)(void*, T1, T2, T3, const RuntimeMethod*);

	static inline R Invoke (const RuntimeMethod* method, RuntimeObject* obj, T1 p1, T2 p2, T3 p3)
	{
		VirtualInvokeData invokeData;
		il2cpp_codegen_get_generic_interface_invoke_data(method, obj, &invokeData);
		return ((Func)invokeData.methodPtr)(obj, p1, p2, p3, invokeData.method);
	}
};

// System.Action`1<UnityEngine.Experimental.XR.FrameReceivedEventArgs>
struct Action_1_t2760547698;
// System.Action`1<UnityEngine.Experimental.XR.PlaneAddedEventArgs>
struct Action_1_t2722643320;
// System.Action`1<UnityEngine.Experimental.XR.PlaneRemovedEventArgs>
struct Action_1_t1739597377;
// System.Action`1<UnityEngine.Experimental.XR.PlaneUpdatedEventArgs>
struct Action_1_t521953446;
// System.Action`1<UnityEngine.Experimental.XR.ReferencePointUpdatedEventArgs>
struct Action_1_t2218980328;
// System.Action`1<UnityEngine.Experimental.XR.SessionTrackingStateChangedEventArgs>
struct Action_1_t2515503250;
// System.Action`3<UnityEngine.XR.ARExtensions.AsyncCameraImageConversionStatus,UnityEngine.XR.ARExtensions.CameraImageConversionParams,Unity.Collections.NativeArray`1<System.Byte>>
struct Action_3_t3607487754;
// System.ArgumentException
struct ArgumentException_t132251570;
// System.ArgumentNullException
struct ArgumentNullException_t1615371798;
// System.ArgumentOutOfRangeException
struct ArgumentOutOfRangeException_t777629997;
// System.AsyncCallback
struct AsyncCallback_t3962456242;
// System.Char[]
struct CharU5BU5D_t3528271667;
// System.Collections.Generic.Dictionary`2/Transform`1<System.String,System.Func`2<UnityEngine.Experimental.XR.XRCameraSubsystem,System.Boolean>,System.Collections.DictionaryEntry>
struct Transform_1_t3648916398;
// System.Collections.Generic.Dictionary`2/Transform`1<System.String,System.Func`3<UnityEngine.Experimental.XR.XRPlaneSubsystem,UnityEngine.Experimental.XR.TrackableId,UnityEngine.Experimental.XR.TrackingState>,System.Collections.DictionaryEntry>
struct Transform_1_t753573090;
// System.Collections.Generic.Dictionary`2/Transform`1<System.String,UnityEngine.XR.ARExtensions.ICameraImageApi,System.Collections.DictionaryEntry>
struct Transform_1_t2281318713;
// System.Collections.Generic.Dictionary`2/Transform`1<System.String,UnityEngine.XR.ARExtensions.XRCameraExtensions/TryGetColorCorrectionDelegate,System.Collections.DictionaryEntry>
struct Transform_1_t3455874290;
// System.Collections.Generic.Dictionary`2/Transform`1<System.String,UnityEngine.XR.ARExtensions.XRReferencePointExtensions/AttachReferencePointDelegate,System.Collections.DictionaryEntry>
struct Transform_1_t602873398;
// System.Collections.Generic.Dictionary`2/Transform`1<System.String,UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionAvailability>,System.Collections.DictionaryEntry>
struct Transform_1_t4131697049;
// System.Collections.Generic.Dictionary`2/Transform`1<System.String,UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionInstallationStatus>,System.Collections.DictionaryEntry>
struct Transform_1_t1853193634;
// System.Collections.Generic.Dictionary`2<System.Object,System.Object>
struct Dictionary_2_t132545152;
// System.Collections.Generic.Dictionary`2<System.String,System.Func`2<UnityEngine.Experimental.XR.XRCameraSubsystem,System.Boolean>>
struct Dictionary_2_t2760358902;
// System.Collections.Generic.Dictionary`2<System.String,System.Func`3<UnityEngine.Experimental.XR.XRPlaneSubsystem,UnityEngine.Experimental.XR.TrackableId,UnityEngine.Experimental.XR.TrackingState>>
struct Dictionary_2_t2706875346;
// System.Collections.Generic.Dictionary`2<System.String,UnityEngine.XR.ARExtensions.ICameraImageApi>
struct Dictionary_2_t1871360775;
// System.Collections.Generic.Dictionary`2<System.String,UnityEngine.XR.ARExtensions.XRCameraExtensions/TryGetColorCorrectionDelegate>
struct Dictionary_2_t820068610;
// System.Collections.Generic.Dictionary`2<System.String,UnityEngine.XR.ARExtensions.XRReferencePointExtensions/AttachReferencePointDelegate>
struct Dictionary_2_t204178958;
// System.Collections.Generic.Dictionary`2<System.String,UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionAvailability>>
struct Dictionary_2_t3245361703;
// System.Collections.Generic.Dictionary`2<System.String,UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionInstallationStatus>>
struct Dictionary_2_t757416466;
// System.Collections.Generic.IEqualityComparer`1<System.String>
struct IEqualityComparer_1_t3954782707;
// System.Collections.Generic.Link[]
struct LinkU5BU5D_t964245573;
// System.Collections.IDictionary
struct IDictionary_t1363984059;
// System.DelegateData
struct DelegateData_t1677132599;
// System.Func`2<System.Object,System.Boolean>
struct Func_2_t3759279471;
// System.Func`2<UnityEngine.Experimental.XR.XRCameraSubsystem,System.Boolean>
struct Func_2_t2975102603;
// System.Func`2<UnityEngine.Experimental.XR.XRCameraSubsystem,System.Boolean>[]
struct Func_2U5BU5D_t503537386;
// System.Func`3<System.Object,UnityEngine.Experimental.XR.TrackableId,UnityEngine.Experimental.XR.TrackingState>
struct Func_3_t2197716167;
// System.Func`3<UnityEngine.Experimental.XR.XRPlaneSubsystem,UnityEngine.Experimental.XR.TrackableId,UnityEngine.Experimental.XR.TrackingState>
struct Func_3_t2921619047;
// System.Func`3<UnityEngine.Experimental.XR.XRPlaneSubsystem,UnityEngine.Experimental.XR.TrackableId,UnityEngine.Experimental.XR.TrackingState>[]
struct Func_3U5BU5D_t1903161374;
// System.IAsyncResult
struct IAsyncResult_t767004451;
// System.Int32[]
struct Int32U5BU5D_t385246372;
// System.IntPtr[]
struct IntPtrU5BU5D_t4013366056;
// System.InvalidOperationException
struct InvalidOperationException_t56020091;
// System.Object[]
struct ObjectU5BU5D_t2843939325;
// System.Reflection.MethodInfo
struct MethodInfo_t;
// System.Runtime.Serialization.SerializationInfo
struct SerializationInfo_t950877179;
// System.String
struct String_t;
// System.String[]
struct StringU5BU5D_t1281789340;
// System.Void
struct Void_t1185182177;
// UnityEngine.Experimental.ISubsystemDescriptor
struct ISubsystemDescriptor_t515866703;
// UnityEngine.Experimental.SubsystemDescriptorBase
struct SubsystemDescriptorBase_t2374447182;
// UnityEngine.Experimental.Subsystem`1<System.Object>
struct Subsystem_1_t4274336850;
// UnityEngine.Experimental.Subsystem`1<UnityEngine.Experimental.XR.XRCameraSubsystemDescriptor>
struct Subsystem_1_t588646725;
// UnityEngine.Experimental.Subsystem`1<UnityEngine.Experimental.XR.XRPlaneSubsystemDescriptor>
struct Subsystem_1_t1428396990;
// UnityEngine.Experimental.Subsystem`1<UnityEngine.Experimental.XR.XRReferencePointSubsystemDescriptor>
struct Subsystem_1_t2853778384;
// UnityEngine.Experimental.Subsystem`1<UnityEngine.Experimental.XR.XRSessionSubsystemDescriptor>
struct Subsystem_1_t2383066733;
// UnityEngine.Experimental.XR.XRCameraSubsystem
struct XRCameraSubsystem_t4195795144;
// UnityEngine.Experimental.XR.XRCameraSubsystemDescriptor
struct XRCameraSubsystemDescriptor_t3689383335;
// UnityEngine.Experimental.XR.XRPlaneSubsystem
struct XRPlaneSubsystem_t2260142932;
// UnityEngine.Experimental.XR.XRPlaneSubsystemDescriptor
struct XRPlaneSubsystemDescriptor_t234166304;
// UnityEngine.Experimental.XR.XRReferencePointSubsystem
struct XRReferencePointSubsystem_t416875062;
// UnityEngine.Experimental.XR.XRReferencePointSubsystemDescriptor
struct XRReferencePointSubsystemDescriptor_t1659547698;
// UnityEngine.Experimental.XR.XRSessionSubsystem
struct XRSessionSubsystem_t3616338244;
// UnityEngine.Experimental.XR.XRSessionSubsystemDescriptor
struct XRSessionSubsystemDescriptor_t1188836047;
// UnityEngine.XR.ARExtensions.ICameraImageApi
struct ICameraImageApi_t2086104476;
// UnityEngine.XR.ARExtensions.ICameraImageApi[]
struct ICameraImageApiU5BU5D_t3430906997;
// UnityEngine.XR.ARExtensions.Promise`1<UnityEngine.XR.ARExtensions.SessionAvailability>
struct Promise_1_t3923167537;
// UnityEngine.XR.ARExtensions.Promise`1<UnityEngine.XR.ARExtensions.SessionInstallationStatus>
struct Promise_1_t1435222300;
// UnityEngine.XR.ARExtensions.XRCameraExtensions/DefaultCameraImageApi
struct DefaultCameraImageApi_t2442227313;
// UnityEngine.XR.ARExtensions.XRCameraExtensions/OnImageRequestCompleteDelegate
struct OnImageRequestCompleteDelegate_t4025953918;
// UnityEngine.XR.ARExtensions.XRCameraExtensions/TryGetColorCorrectionDelegate
struct TryGetColorCorrectionDelegate_t1034812311;
// UnityEngine.XR.ARExtensions.XRCameraExtensions/TryGetColorCorrectionDelegate[]
struct TryGetColorCorrectionDelegateU5BU5D_t310495278;
// UnityEngine.XR.ARExtensions.XRReferencePointExtensions/AttachReferencePointDelegate
struct AttachReferencePointDelegate_t418922659;
// UnityEngine.XR.ARExtensions.XRReferencePointExtensions/AttachReferencePointDelegate[]
struct AttachReferencePointDelegateU5BU5D_t1752461682;
// UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionAvailability>
struct AsyncDelegate_1_t3460105404;
// UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionAvailability>[]
struct AsyncDelegate_1U5BU5D_t986318037;
// UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionInstallationStatus>
struct AsyncDelegate_1_t972160167;
// UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionInstallationStatus>[]
struct AsyncDelegate_1U5BU5D_t3002781918;

extern RuntimeClass* Action_3_t3607487754_il2cpp_TypeInfo_var;
extern RuntimeClass* ArgumentException_t132251570_il2cpp_TypeInfo_var;
extern RuntimeClass* ArgumentNullException_t1615371798_il2cpp_TypeInfo_var;
extern RuntimeClass* ArgumentOutOfRangeException_t777629997_il2cpp_TypeInfo_var;
extern RuntimeClass* AsyncCameraImageConversionStatus_t11558803_il2cpp_TypeInfo_var;
extern RuntimeClass* AsyncDelegate_1_t3460105404_il2cpp_TypeInfo_var;
extern RuntimeClass* AsyncDelegate_1_t972160167_il2cpp_TypeInfo_var;
extern RuntimeClass* AttachReferencePointDelegate_t418922659_il2cpp_TypeInfo_var;
extern RuntimeClass* CameraImageConversionParams_t1109674340_il2cpp_TypeInfo_var;
extern RuntimeClass* CameraImageFormat_t1966699832_il2cpp_TypeInfo_var;
extern RuntimeClass* CameraImageTransformation_t164605461_il2cpp_TypeInfo_var;
extern RuntimeClass* CameraImage_t2783787914_il2cpp_TypeInfo_var;
extern RuntimeClass* Color_t2555686324_il2cpp_TypeInfo_var;
extern RuntimeClass* DefaultCameraImageApi_t2442227313_il2cpp_TypeInfo_var;
extern RuntimeClass* Dictionary_2_t1871360775_il2cpp_TypeInfo_var;
extern RuntimeClass* Dictionary_2_t204178958_il2cpp_TypeInfo_var;
extern RuntimeClass* Dictionary_2_t2706875346_il2cpp_TypeInfo_var;
extern RuntimeClass* Dictionary_2_t2760358902_il2cpp_TypeInfo_var;
extern RuntimeClass* Dictionary_2_t3245361703_il2cpp_TypeInfo_var;
extern RuntimeClass* Dictionary_2_t757416466_il2cpp_TypeInfo_var;
extern RuntimeClass* Dictionary_2_t820068610_il2cpp_TypeInfo_var;
extern RuntimeClass* Func_2_t2975102603_il2cpp_TypeInfo_var;
extern RuntimeClass* Func_3_t2921619047_il2cpp_TypeInfo_var;
extern RuntimeClass* ICameraImageApi_t2086104476_il2cpp_TypeInfo_var;
extern RuntimeClass* Int32_t2950945753_il2cpp_TypeInfo_var;
extern RuntimeClass* IntPtr_t_il2cpp_TypeInfo_var;
extern RuntimeClass* InvalidOperationException_t56020091_il2cpp_TypeInfo_var;
extern RuntimeClass* ObjectU5BU5D_t2843939325_il2cpp_TypeInfo_var;
extern RuntimeClass* OnImageRequestCompleteDelegate_t4025953918_il2cpp_TypeInfo_var;
extern RuntimeClass* Pose_t545244865_il2cpp_TypeInfo_var;
extern RuntimeClass* RectInt_t1875739471_il2cpp_TypeInfo_var;
extern RuntimeClass* String_t_il2cpp_TypeInfo_var;
extern RuntimeClass* TextureFormat_t2701165832_il2cpp_TypeInfo_var;
extern RuntimeClass* TrackableId_t1251031970_il2cpp_TypeInfo_var;
extern RuntimeClass* TryGetColorCorrectionDelegate_t1034812311_il2cpp_TypeInfo_var;
extern RuntimeClass* Vector2Int_t3469998543_il2cpp_TypeInfo_var;
extern RuntimeClass* XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var;
extern RuntimeClass* XRPlaneExtensions_t1202600805_il2cpp_TypeInfo_var;
extern RuntimeClass* XRReferencePointExtensions_t125072412_il2cpp_TypeInfo_var;
extern RuntimeClass* XRSessionExtensions_t411788579_il2cpp_TypeInfo_var;
extern String_t* _stringLiteral1165407477;
extern String_t* _stringLiteral1345581681;
extern String_t* _stringLiteral176405713;
extern String_t* _stringLiteral1910834845;
extern String_t* _stringLiteral1910914709;
extern String_t* _stringLiteral2063443799;
extern String_t* _stringLiteral2209503435;
extern String_t* _stringLiteral2235816782;
extern String_t* _stringLiteral2494539934;
extern String_t* _stringLiteral2514532075;
extern String_t* _stringLiteral3045809767;
extern String_t* _stringLiteral3461447331;
extern String_t* _stringLiteral3838339713;
extern String_t* _stringLiteral4081819098;
extern String_t* _stringLiteral446157247;
extern String_t* _stringLiteral452723731;
extern String_t* _stringLiteral613811463;
extern String_t* _stringLiteral772053088;
extern String_t* _stringLiteral834956432;
extern String_t* _stringLiteral863398240;
extern const RuntimeMethod* Action_3_Invoke_m609172159_RuntimeMethod_var;
extern const RuntimeMethod* AsyncDelegate_1_Invoke_m1924773735_RuntimeMethod_var;
extern const RuntimeMethod* AsyncDelegate_1_Invoke_m723727912_RuntimeMethod_var;
extern const RuntimeMethod* AsyncDelegate_1__ctor_m1054827699_RuntimeMethod_var;
extern const RuntimeMethod* AsyncDelegate_1__ctor_m2374002471_RuntimeMethod_var;
extern const RuntimeMethod* CameraImage_Convert_m2059105726_RuntimeMethod_var;
extern const RuntimeMethod* CameraImage_GetConvertedDataSize_m1842015692_RuntimeMethod_var;
extern const RuntimeMethod* CameraImage_OnAsyncConversionComplete_m926397238_RuntimeMethod_var;
extern const RuntimeMethod* CameraImage_ValidateConversionParamsAndThrow_m1179966680_RuntimeMethod_var;
extern const RuntimeMethod* CameraImage_ValidateNativeHandleAndThrow_m654558893_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2__ctor_m1771204320_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2__ctor_m1921437841_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2__ctor_m2975023327_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2__ctor_m3075159066_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2__ctor_m383910843_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2__ctor_m49728138_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2__ctor_m555241001_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2_set_Item_m2124544062_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2_set_Item_m253421643_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2_set_Item_m3033294665_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2_set_Item_m3827254201_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2_set_Item_m3849172357_RuntimeMethod_var;
extern const RuntimeMethod* Func_2__ctor_m2608148365_RuntimeMethod_var;
extern const RuntimeMethod* Func_3_Invoke_m2530530313_RuntimeMethod_var;
extern const RuntimeMethod* Func_3__ctor_m1014428649_RuntimeMethod_var;
extern const RuntimeMethod* NativeArrayUnsafeUtility_ConvertExistingDataToNativeArray_TisByte_t1134296376_m990237749_RuntimeMethod_var;
extern const RuntimeMethod* Promise_1_CreateResolvedPromise_m3838876404_RuntimeMethod_var;
extern const RuntimeMethod* Promise_1_CreateResolvedPromise_m420313478_RuntimeMethod_var;
extern const RuntimeMethod* RegistrationHelper_GetValueOrDefault_TisString_t_TisAsyncDelegate_1_t3460105404_m3679850741_RuntimeMethod_var;
extern const RuntimeMethod* RegistrationHelper_GetValueOrDefault_TisString_t_TisAsyncDelegate_1_t972160167_m3126187069_RuntimeMethod_var;
extern const RuntimeMethod* RegistrationHelper_GetValueOrDefault_TisString_t_TisAttachReferencePointDelegate_t418922659_m850717648_RuntimeMethod_var;
extern const RuntimeMethod* RegistrationHelper_GetValueOrDefault_TisString_t_TisFunc_2_t2975102603_m2306524290_RuntimeMethod_var;
extern const RuntimeMethod* RegistrationHelper_GetValueOrDefault_TisString_t_TisFunc_3_t2921619047_m1497402927_RuntimeMethod_var;
extern const RuntimeMethod* RegistrationHelper_GetValueOrDefault_TisString_t_TisICameraImageApi_t2086104476_m2420324886_RuntimeMethod_var;
extern const RuntimeMethod* RegistrationHelper_GetValueOrDefault_TisString_t_TisTryGetColorCorrectionDelegate_t1034812311_m3517983076_RuntimeMethod_var;
extern const RuntimeMethod* Subsystem_1_get_SubsystemDescriptor_m1208900687_RuntimeMethod_var;
extern const RuntimeMethod* Subsystem_1_get_SubsystemDescriptor_m2169025228_RuntimeMethod_var;
extern const RuntimeMethod* Subsystem_1_get_SubsystemDescriptor_m3649074082_RuntimeMethod_var;
extern const RuntimeMethod* Subsystem_1_get_SubsystemDescriptor_m441071667_RuntimeMethod_var;
extern const RuntimeMethod* XRCameraExtensions_DefaultIsPermissionGranted_m2477879696_RuntimeMethod_var;
extern const RuntimeMethod* XRCameraExtensions_DefaultTryGetColorCorrection_m4288959349_RuntimeMethod_var;
extern const RuntimeMethod* XRCameraExtensions_TryGetColorCorrection_m3844756087_RuntimeMethod_var;
extern const RuntimeMethod* XRCameraExtensions_TryGetLatestImage_m4279998480_RuntimeMethod_var;
extern const RuntimeMethod* XRPlaneExtensions_DefaultGetTrackingState_m2407700671_RuntimeMethod_var;
extern const RuntimeMethod* XRPlaneExtensions_GetTrackingState_m2696238282_RuntimeMethod_var;
extern const RuntimeMethod* XRReferencePointExtensions_AttachReferencePoint_m42308643_RuntimeMethod_var;
extern const RuntimeMethod* XRReferencePointExtensions_DefaultAttachReferencePoint_m4195628539_RuntimeMethod_var;
extern const RuntimeMethod* XRSessionExtensions_DefaultGetAvailabilityAsync_m4160736096_RuntimeMethod_var;
extern const RuntimeMethod* XRSessionExtensions_DefaultInstallAsync_m325129405_RuntimeMethod_var;
extern const RuntimeMethod* XRSessionExtensions_GetAvailabilityAsync_m1573784747_RuntimeMethod_var;
extern const RuntimeMethod* XRSessionExtensions_InstallAsync_m658298074_RuntimeMethod_var;
extern const uint32_t AttachReferencePointDelegate_BeginInvoke_m455971734_MetadataUsageId;
extern const uint32_t CameraImageConversionParams_Equals_m237957486_MetadataUsageId;
extern const uint32_t CameraImageConversionParams_Equals_m3483019339_MetadataUsageId;
extern const uint32_t CameraImageConversionParams_GetHashCode_m3192672850_MetadataUsageId;
extern const uint32_t CameraImageConversionParams_ToString_m86635840_MetadataUsageId;
extern const uint32_t CameraImage_Convert_m2059105726_MetadataUsageId;
extern const uint32_t CameraImage_Dispose_m1566295269_MetadataUsageId;
extern const uint32_t CameraImage_Equals_m3039677800_MetadataUsageId;
extern const uint32_t CameraImage_GetConvertedDataSize_m1842015692_MetadataUsageId;
extern const uint32_t CameraImage_GetHashCode_m1730928199_MetadataUsageId;
extern const uint32_t CameraImage_OnAsyncConversionComplete_m926397238_MetadataUsageId;
extern const uint32_t CameraImage_ToString_m1993371729_MetadataUsageId;
extern const uint32_t CameraImage_ValidateConversionParamsAndThrow_m1179966680_MetadataUsageId;
extern const uint32_t CameraImage_ValidateNativeHandleAndThrow_m654558893_MetadataUsageId;
extern const uint32_t CameraImage__cctor_m3767963604_MetadataUsageId;
extern const uint32_t CameraImage_get_valid_m1506925116_MetadataUsageId;
extern const uint32_t OnImageRequestCompleteDelegate_BeginInvoke_m1021759379_MetadataUsageId;
extern const uint32_t TryGetColorCorrectionDelegate_BeginInvoke_m1810176191_MetadataUsageId;
extern const uint32_t XRCameraExtensions_ActivateExtensions_m882509077_MetadataUsageId;
extern const uint32_t XRCameraExtensions_RegisterCameraImageApi_m4107023354_MetadataUsageId;
extern const uint32_t XRCameraExtensions_RegisterIsPermissionGrantedHandler_m23889859_MetadataUsageId;
extern const uint32_t XRCameraExtensions_SetDefaultDelegates_m571765574_MetadataUsageId;
extern const uint32_t XRCameraExtensions_TryGetColorCorrection_m3844756087_MetadataUsageId;
extern const uint32_t XRCameraExtensions_TryGetLatestImage_m4279998480_MetadataUsageId;
extern const uint32_t XRCameraExtensions__cctor_m3236015190_MetadataUsageId;
extern const uint32_t XRPlaneExtensions_ActivateExtensions_m2242243429_MetadataUsageId;
extern const uint32_t XRPlaneExtensions_GetTrackingState_m2696238282_MetadataUsageId;
extern const uint32_t XRPlaneExtensions_RegisterGetTrackingStateHandler_m3719762041_MetadataUsageId;
extern const uint32_t XRPlaneExtensions_SetDefaultDelegates_m3956413843_MetadataUsageId;
extern const uint32_t XRPlaneExtensions__cctor_m1656397022_MetadataUsageId;
extern const uint32_t XRReferencePointExtensions_ActivateExtensions_m2683210974_MetadataUsageId;
extern const uint32_t XRReferencePointExtensions_AttachReferencePoint_m42308643_MetadataUsageId;
extern const uint32_t XRReferencePointExtensions_DefaultAttachReferencePoint_m4195628539_MetadataUsageId;
extern const uint32_t XRReferencePointExtensions_RegisterAttachReferencePointHandler_m2848125376_MetadataUsageId;
extern const uint32_t XRReferencePointExtensions_SetDefaultDelegates_m4188249370_MetadataUsageId;
extern const uint32_t XRReferencePointExtensions__cctor_m3153365008_MetadataUsageId;
extern const uint32_t XRSessionExtensions_ActivateExtensions_m1327610782_MetadataUsageId;
extern const uint32_t XRSessionExtensions_DefaultGetAvailabilityAsync_m4160736096_MetadataUsageId;
extern const uint32_t XRSessionExtensions_DefaultInstallAsync_m325129405_MetadataUsageId;
extern const uint32_t XRSessionExtensions_GetAvailabilityAsync_m1573784747_MetadataUsageId;
extern const uint32_t XRSessionExtensions_InstallAsync_m658298074_MetadataUsageId;
extern const uint32_t XRSessionExtensions_RegisterGetAvailabilityAsyncHandler_m3177527582_MetadataUsageId;
extern const uint32_t XRSessionExtensions_SetDefaultDelegates_m2570236516_MetadataUsageId;
extern const uint32_t XRSessionExtensions__cctor_m298900539_MetadataUsageId;

struct ObjectU5BU5D_t2843939325;


#ifndef U3CMODULEU3E_T692745547_H
#define U3CMODULEU3E_T692745547_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_t692745547 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_T692745547_H
#ifndef RUNTIMEOBJECT_H
#define RUNTIMEOBJECT_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Object

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEOBJECT_H
struct Il2CppArrayBounds;
#ifndef RUNTIMEARRAY_H
#define RUNTIMEARRAY_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Array

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEARRAY_H
#ifndef DICTIONARY_2_T2760358902_H
#define DICTIONARY_2_T2760358902_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.Dictionary`2<System.String,System.Func`2<UnityEngine.Experimental.XR.XRCameraSubsystem,System.Boolean>>
struct  Dictionary_2_t2760358902  : public RuntimeObject
{
public:
	// System.Int32[] System.Collections.Generic.Dictionary`2::table
	Int32U5BU5D_t385246372* ___table_4;
	// System.Collections.Generic.Link[] System.Collections.Generic.Dictionary`2::linkSlots
	LinkU5BU5D_t964245573* ___linkSlots_5;
	// TKey[] System.Collections.Generic.Dictionary`2::keySlots
	StringU5BU5D_t1281789340* ___keySlots_6;
	// TValue[] System.Collections.Generic.Dictionary`2::valueSlots
	Func_2U5BU5D_t503537386* ___valueSlots_7;
	// System.Int32 System.Collections.Generic.Dictionary`2::touchedSlots
	int32_t ___touchedSlots_8;
	// System.Int32 System.Collections.Generic.Dictionary`2::emptySlot
	int32_t ___emptySlot_9;
	// System.Int32 System.Collections.Generic.Dictionary`2::count
	int32_t ___count_10;
	// System.Int32 System.Collections.Generic.Dictionary`2::threshold
	int32_t ___threshold_11;
	// System.Collections.Generic.IEqualityComparer`1<TKey> System.Collections.Generic.Dictionary`2::hcp
	RuntimeObject* ___hcp_12;
	// System.Runtime.Serialization.SerializationInfo System.Collections.Generic.Dictionary`2::serialization_info
	SerializationInfo_t950877179 * ___serialization_info_13;
	// System.Int32 System.Collections.Generic.Dictionary`2::generation
	int32_t ___generation_14;

public:
	inline static int32_t get_offset_of_table_4() { return static_cast<int32_t>(offsetof(Dictionary_2_t2760358902, ___table_4)); }
	inline Int32U5BU5D_t385246372* get_table_4() const { return ___table_4; }
	inline Int32U5BU5D_t385246372** get_address_of_table_4() { return &___table_4; }
	inline void set_table_4(Int32U5BU5D_t385246372* value)
	{
		___table_4 = value;
		Il2CppCodeGenWriteBarrier((&___table_4), value);
	}

	inline static int32_t get_offset_of_linkSlots_5() { return static_cast<int32_t>(offsetof(Dictionary_2_t2760358902, ___linkSlots_5)); }
	inline LinkU5BU5D_t964245573* get_linkSlots_5() const { return ___linkSlots_5; }
	inline LinkU5BU5D_t964245573** get_address_of_linkSlots_5() { return &___linkSlots_5; }
	inline void set_linkSlots_5(LinkU5BU5D_t964245573* value)
	{
		___linkSlots_5 = value;
		Il2CppCodeGenWriteBarrier((&___linkSlots_5), value);
	}

	inline static int32_t get_offset_of_keySlots_6() { return static_cast<int32_t>(offsetof(Dictionary_2_t2760358902, ___keySlots_6)); }
	inline StringU5BU5D_t1281789340* get_keySlots_6() const { return ___keySlots_6; }
	inline StringU5BU5D_t1281789340** get_address_of_keySlots_6() { return &___keySlots_6; }
	inline void set_keySlots_6(StringU5BU5D_t1281789340* value)
	{
		___keySlots_6 = value;
		Il2CppCodeGenWriteBarrier((&___keySlots_6), value);
	}

	inline static int32_t get_offset_of_valueSlots_7() { return static_cast<int32_t>(offsetof(Dictionary_2_t2760358902, ___valueSlots_7)); }
	inline Func_2U5BU5D_t503537386* get_valueSlots_7() const { return ___valueSlots_7; }
	inline Func_2U5BU5D_t503537386** get_address_of_valueSlots_7() { return &___valueSlots_7; }
	inline void set_valueSlots_7(Func_2U5BU5D_t503537386* value)
	{
		___valueSlots_7 = value;
		Il2CppCodeGenWriteBarrier((&___valueSlots_7), value);
	}

	inline static int32_t get_offset_of_touchedSlots_8() { return static_cast<int32_t>(offsetof(Dictionary_2_t2760358902, ___touchedSlots_8)); }
	inline int32_t get_touchedSlots_8() const { return ___touchedSlots_8; }
	inline int32_t* get_address_of_touchedSlots_8() { return &___touchedSlots_8; }
	inline void set_touchedSlots_8(int32_t value)
	{
		___touchedSlots_8 = value;
	}

	inline static int32_t get_offset_of_emptySlot_9() { return static_cast<int32_t>(offsetof(Dictionary_2_t2760358902, ___emptySlot_9)); }
	inline int32_t get_emptySlot_9() const { return ___emptySlot_9; }
	inline int32_t* get_address_of_emptySlot_9() { return &___emptySlot_9; }
	inline void set_emptySlot_9(int32_t value)
	{
		___emptySlot_9 = value;
	}

	inline static int32_t get_offset_of_count_10() { return static_cast<int32_t>(offsetof(Dictionary_2_t2760358902, ___count_10)); }
	inline int32_t get_count_10() const { return ___count_10; }
	inline int32_t* get_address_of_count_10() { return &___count_10; }
	inline void set_count_10(int32_t value)
	{
		___count_10 = value;
	}

	inline static int32_t get_offset_of_threshold_11() { return static_cast<int32_t>(offsetof(Dictionary_2_t2760358902, ___threshold_11)); }
	inline int32_t get_threshold_11() const { return ___threshold_11; }
	inline int32_t* get_address_of_threshold_11() { return &___threshold_11; }
	inline void set_threshold_11(int32_t value)
	{
		___threshold_11 = value;
	}

	inline static int32_t get_offset_of_hcp_12() { return static_cast<int32_t>(offsetof(Dictionary_2_t2760358902, ___hcp_12)); }
	inline RuntimeObject* get_hcp_12() const { return ___hcp_12; }
	inline RuntimeObject** get_address_of_hcp_12() { return &___hcp_12; }
	inline void set_hcp_12(RuntimeObject* value)
	{
		___hcp_12 = value;
		Il2CppCodeGenWriteBarrier((&___hcp_12), value);
	}

	inline static int32_t get_offset_of_serialization_info_13() { return static_cast<int32_t>(offsetof(Dictionary_2_t2760358902, ___serialization_info_13)); }
	inline SerializationInfo_t950877179 * get_serialization_info_13() const { return ___serialization_info_13; }
	inline SerializationInfo_t950877179 ** get_address_of_serialization_info_13() { return &___serialization_info_13; }
	inline void set_serialization_info_13(SerializationInfo_t950877179 * value)
	{
		___serialization_info_13 = value;
		Il2CppCodeGenWriteBarrier((&___serialization_info_13), value);
	}

	inline static int32_t get_offset_of_generation_14() { return static_cast<int32_t>(offsetof(Dictionary_2_t2760358902, ___generation_14)); }
	inline int32_t get_generation_14() const { return ___generation_14; }
	inline int32_t* get_address_of_generation_14() { return &___generation_14; }
	inline void set_generation_14(int32_t value)
	{
		___generation_14 = value;
	}
};

struct Dictionary_2_t2760358902_StaticFields
{
public:
	// System.Collections.Generic.Dictionary`2/Transform`1<TKey,TValue,System.Collections.DictionaryEntry> System.Collections.Generic.Dictionary`2::<>f__am$cacheB
	Transform_1_t3648916398 * ___U3CU3Ef__amU24cacheB_15;

public:
	inline static int32_t get_offset_of_U3CU3Ef__amU24cacheB_15() { return static_cast<int32_t>(offsetof(Dictionary_2_t2760358902_StaticFields, ___U3CU3Ef__amU24cacheB_15)); }
	inline Transform_1_t3648916398 * get_U3CU3Ef__amU24cacheB_15() const { return ___U3CU3Ef__amU24cacheB_15; }
	inline Transform_1_t3648916398 ** get_address_of_U3CU3Ef__amU24cacheB_15() { return &___U3CU3Ef__amU24cacheB_15; }
	inline void set_U3CU3Ef__amU24cacheB_15(Transform_1_t3648916398 * value)
	{
		___U3CU3Ef__amU24cacheB_15 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cacheB_15), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DICTIONARY_2_T2760358902_H
#ifndef DICTIONARY_2_T2706875346_H
#define DICTIONARY_2_T2706875346_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.Dictionary`2<System.String,System.Func`3<UnityEngine.Experimental.XR.XRPlaneSubsystem,UnityEngine.Experimental.XR.TrackableId,UnityEngine.Experimental.XR.TrackingState>>
struct  Dictionary_2_t2706875346  : public RuntimeObject
{
public:
	// System.Int32[] System.Collections.Generic.Dictionary`2::table
	Int32U5BU5D_t385246372* ___table_4;
	// System.Collections.Generic.Link[] System.Collections.Generic.Dictionary`2::linkSlots
	LinkU5BU5D_t964245573* ___linkSlots_5;
	// TKey[] System.Collections.Generic.Dictionary`2::keySlots
	StringU5BU5D_t1281789340* ___keySlots_6;
	// TValue[] System.Collections.Generic.Dictionary`2::valueSlots
	Func_3U5BU5D_t1903161374* ___valueSlots_7;
	// System.Int32 System.Collections.Generic.Dictionary`2::touchedSlots
	int32_t ___touchedSlots_8;
	// System.Int32 System.Collections.Generic.Dictionary`2::emptySlot
	int32_t ___emptySlot_9;
	// System.Int32 System.Collections.Generic.Dictionary`2::count
	int32_t ___count_10;
	// System.Int32 System.Collections.Generic.Dictionary`2::threshold
	int32_t ___threshold_11;
	// System.Collections.Generic.IEqualityComparer`1<TKey> System.Collections.Generic.Dictionary`2::hcp
	RuntimeObject* ___hcp_12;
	// System.Runtime.Serialization.SerializationInfo System.Collections.Generic.Dictionary`2::serialization_info
	SerializationInfo_t950877179 * ___serialization_info_13;
	// System.Int32 System.Collections.Generic.Dictionary`2::generation
	int32_t ___generation_14;

public:
	inline static int32_t get_offset_of_table_4() { return static_cast<int32_t>(offsetof(Dictionary_2_t2706875346, ___table_4)); }
	inline Int32U5BU5D_t385246372* get_table_4() const { return ___table_4; }
	inline Int32U5BU5D_t385246372** get_address_of_table_4() { return &___table_4; }
	inline void set_table_4(Int32U5BU5D_t385246372* value)
	{
		___table_4 = value;
		Il2CppCodeGenWriteBarrier((&___table_4), value);
	}

	inline static int32_t get_offset_of_linkSlots_5() { return static_cast<int32_t>(offsetof(Dictionary_2_t2706875346, ___linkSlots_5)); }
	inline LinkU5BU5D_t964245573* get_linkSlots_5() const { return ___linkSlots_5; }
	inline LinkU5BU5D_t964245573** get_address_of_linkSlots_5() { return &___linkSlots_5; }
	inline void set_linkSlots_5(LinkU5BU5D_t964245573* value)
	{
		___linkSlots_5 = value;
		Il2CppCodeGenWriteBarrier((&___linkSlots_5), value);
	}

	inline static int32_t get_offset_of_keySlots_6() { return static_cast<int32_t>(offsetof(Dictionary_2_t2706875346, ___keySlots_6)); }
	inline StringU5BU5D_t1281789340* get_keySlots_6() const { return ___keySlots_6; }
	inline StringU5BU5D_t1281789340** get_address_of_keySlots_6() { return &___keySlots_6; }
	inline void set_keySlots_6(StringU5BU5D_t1281789340* value)
	{
		___keySlots_6 = value;
		Il2CppCodeGenWriteBarrier((&___keySlots_6), value);
	}

	inline static int32_t get_offset_of_valueSlots_7() { return static_cast<int32_t>(offsetof(Dictionary_2_t2706875346, ___valueSlots_7)); }
	inline Func_3U5BU5D_t1903161374* get_valueSlots_7() const { return ___valueSlots_7; }
	inline Func_3U5BU5D_t1903161374** get_address_of_valueSlots_7() { return &___valueSlots_7; }
	inline void set_valueSlots_7(Func_3U5BU5D_t1903161374* value)
	{
		___valueSlots_7 = value;
		Il2CppCodeGenWriteBarrier((&___valueSlots_7), value);
	}

	inline static int32_t get_offset_of_touchedSlots_8() { return static_cast<int32_t>(offsetof(Dictionary_2_t2706875346, ___touchedSlots_8)); }
	inline int32_t get_touchedSlots_8() const { return ___touchedSlots_8; }
	inline int32_t* get_address_of_touchedSlots_8() { return &___touchedSlots_8; }
	inline void set_touchedSlots_8(int32_t value)
	{
		___touchedSlots_8 = value;
	}

	inline static int32_t get_offset_of_emptySlot_9() { return static_cast<int32_t>(offsetof(Dictionary_2_t2706875346, ___emptySlot_9)); }
	inline int32_t get_emptySlot_9() const { return ___emptySlot_9; }
	inline int32_t* get_address_of_emptySlot_9() { return &___emptySlot_9; }
	inline void set_emptySlot_9(int32_t value)
	{
		___emptySlot_9 = value;
	}

	inline static int32_t get_offset_of_count_10() { return static_cast<int32_t>(offsetof(Dictionary_2_t2706875346, ___count_10)); }
	inline int32_t get_count_10() const { return ___count_10; }
	inline int32_t* get_address_of_count_10() { return &___count_10; }
	inline void set_count_10(int32_t value)
	{
		___count_10 = value;
	}

	inline static int32_t get_offset_of_threshold_11() { return static_cast<int32_t>(offsetof(Dictionary_2_t2706875346, ___threshold_11)); }
	inline int32_t get_threshold_11() const { return ___threshold_11; }
	inline int32_t* get_address_of_threshold_11() { return &___threshold_11; }
	inline void set_threshold_11(int32_t value)
	{
		___threshold_11 = value;
	}

	inline static int32_t get_offset_of_hcp_12() { return static_cast<int32_t>(offsetof(Dictionary_2_t2706875346, ___hcp_12)); }
	inline RuntimeObject* get_hcp_12() const { return ___hcp_12; }
	inline RuntimeObject** get_address_of_hcp_12() { return &___hcp_12; }
	inline void set_hcp_12(RuntimeObject* value)
	{
		___hcp_12 = value;
		Il2CppCodeGenWriteBarrier((&___hcp_12), value);
	}

	inline static int32_t get_offset_of_serialization_info_13() { return static_cast<int32_t>(offsetof(Dictionary_2_t2706875346, ___serialization_info_13)); }
	inline SerializationInfo_t950877179 * get_serialization_info_13() const { return ___serialization_info_13; }
	inline SerializationInfo_t950877179 ** get_address_of_serialization_info_13() { return &___serialization_info_13; }
	inline void set_serialization_info_13(SerializationInfo_t950877179 * value)
	{
		___serialization_info_13 = value;
		Il2CppCodeGenWriteBarrier((&___serialization_info_13), value);
	}

	inline static int32_t get_offset_of_generation_14() { return static_cast<int32_t>(offsetof(Dictionary_2_t2706875346, ___generation_14)); }
	inline int32_t get_generation_14() const { return ___generation_14; }
	inline int32_t* get_address_of_generation_14() { return &___generation_14; }
	inline void set_generation_14(int32_t value)
	{
		___generation_14 = value;
	}
};

struct Dictionary_2_t2706875346_StaticFields
{
public:
	// System.Collections.Generic.Dictionary`2/Transform`1<TKey,TValue,System.Collections.DictionaryEntry> System.Collections.Generic.Dictionary`2::<>f__am$cacheB
	Transform_1_t753573090 * ___U3CU3Ef__amU24cacheB_15;

public:
	inline static int32_t get_offset_of_U3CU3Ef__amU24cacheB_15() { return static_cast<int32_t>(offsetof(Dictionary_2_t2706875346_StaticFields, ___U3CU3Ef__amU24cacheB_15)); }
	inline Transform_1_t753573090 * get_U3CU3Ef__amU24cacheB_15() const { return ___U3CU3Ef__amU24cacheB_15; }
	inline Transform_1_t753573090 ** get_address_of_U3CU3Ef__amU24cacheB_15() { return &___U3CU3Ef__amU24cacheB_15; }
	inline void set_U3CU3Ef__amU24cacheB_15(Transform_1_t753573090 * value)
	{
		___U3CU3Ef__amU24cacheB_15 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cacheB_15), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DICTIONARY_2_T2706875346_H
#ifndef DICTIONARY_2_T1871360775_H
#define DICTIONARY_2_T1871360775_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.Dictionary`2<System.String,UnityEngine.XR.ARExtensions.ICameraImageApi>
struct  Dictionary_2_t1871360775  : public RuntimeObject
{
public:
	// System.Int32[] System.Collections.Generic.Dictionary`2::table
	Int32U5BU5D_t385246372* ___table_4;
	// System.Collections.Generic.Link[] System.Collections.Generic.Dictionary`2::linkSlots
	LinkU5BU5D_t964245573* ___linkSlots_5;
	// TKey[] System.Collections.Generic.Dictionary`2::keySlots
	StringU5BU5D_t1281789340* ___keySlots_6;
	// TValue[] System.Collections.Generic.Dictionary`2::valueSlots
	ICameraImageApiU5BU5D_t3430906997* ___valueSlots_7;
	// System.Int32 System.Collections.Generic.Dictionary`2::touchedSlots
	int32_t ___touchedSlots_8;
	// System.Int32 System.Collections.Generic.Dictionary`2::emptySlot
	int32_t ___emptySlot_9;
	// System.Int32 System.Collections.Generic.Dictionary`2::count
	int32_t ___count_10;
	// System.Int32 System.Collections.Generic.Dictionary`2::threshold
	int32_t ___threshold_11;
	// System.Collections.Generic.IEqualityComparer`1<TKey> System.Collections.Generic.Dictionary`2::hcp
	RuntimeObject* ___hcp_12;
	// System.Runtime.Serialization.SerializationInfo System.Collections.Generic.Dictionary`2::serialization_info
	SerializationInfo_t950877179 * ___serialization_info_13;
	// System.Int32 System.Collections.Generic.Dictionary`2::generation
	int32_t ___generation_14;

public:
	inline static int32_t get_offset_of_table_4() { return static_cast<int32_t>(offsetof(Dictionary_2_t1871360775, ___table_4)); }
	inline Int32U5BU5D_t385246372* get_table_4() const { return ___table_4; }
	inline Int32U5BU5D_t385246372** get_address_of_table_4() { return &___table_4; }
	inline void set_table_4(Int32U5BU5D_t385246372* value)
	{
		___table_4 = value;
		Il2CppCodeGenWriteBarrier((&___table_4), value);
	}

	inline static int32_t get_offset_of_linkSlots_5() { return static_cast<int32_t>(offsetof(Dictionary_2_t1871360775, ___linkSlots_5)); }
	inline LinkU5BU5D_t964245573* get_linkSlots_5() const { return ___linkSlots_5; }
	inline LinkU5BU5D_t964245573** get_address_of_linkSlots_5() { return &___linkSlots_5; }
	inline void set_linkSlots_5(LinkU5BU5D_t964245573* value)
	{
		___linkSlots_5 = value;
		Il2CppCodeGenWriteBarrier((&___linkSlots_5), value);
	}

	inline static int32_t get_offset_of_keySlots_6() { return static_cast<int32_t>(offsetof(Dictionary_2_t1871360775, ___keySlots_6)); }
	inline StringU5BU5D_t1281789340* get_keySlots_6() const { return ___keySlots_6; }
	inline StringU5BU5D_t1281789340** get_address_of_keySlots_6() { return &___keySlots_6; }
	inline void set_keySlots_6(StringU5BU5D_t1281789340* value)
	{
		___keySlots_6 = value;
		Il2CppCodeGenWriteBarrier((&___keySlots_6), value);
	}

	inline static int32_t get_offset_of_valueSlots_7() { return static_cast<int32_t>(offsetof(Dictionary_2_t1871360775, ___valueSlots_7)); }
	inline ICameraImageApiU5BU5D_t3430906997* get_valueSlots_7() const { return ___valueSlots_7; }
	inline ICameraImageApiU5BU5D_t3430906997** get_address_of_valueSlots_7() { return &___valueSlots_7; }
	inline void set_valueSlots_7(ICameraImageApiU5BU5D_t3430906997* value)
	{
		___valueSlots_7 = value;
		Il2CppCodeGenWriteBarrier((&___valueSlots_7), value);
	}

	inline static int32_t get_offset_of_touchedSlots_8() { return static_cast<int32_t>(offsetof(Dictionary_2_t1871360775, ___touchedSlots_8)); }
	inline int32_t get_touchedSlots_8() const { return ___touchedSlots_8; }
	inline int32_t* get_address_of_touchedSlots_8() { return &___touchedSlots_8; }
	inline void set_touchedSlots_8(int32_t value)
	{
		___touchedSlots_8 = value;
	}

	inline static int32_t get_offset_of_emptySlot_9() { return static_cast<int32_t>(offsetof(Dictionary_2_t1871360775, ___emptySlot_9)); }
	inline int32_t get_emptySlot_9() const { return ___emptySlot_9; }
	inline int32_t* get_address_of_emptySlot_9() { return &___emptySlot_9; }
	inline void set_emptySlot_9(int32_t value)
	{
		___emptySlot_9 = value;
	}

	inline static int32_t get_offset_of_count_10() { return static_cast<int32_t>(offsetof(Dictionary_2_t1871360775, ___count_10)); }
	inline int32_t get_count_10() const { return ___count_10; }
	inline int32_t* get_address_of_count_10() { return &___count_10; }
	inline void set_count_10(int32_t value)
	{
		___count_10 = value;
	}

	inline static int32_t get_offset_of_threshold_11() { return static_cast<int32_t>(offsetof(Dictionary_2_t1871360775, ___threshold_11)); }
	inline int32_t get_threshold_11() const { return ___threshold_11; }
	inline int32_t* get_address_of_threshold_11() { return &___threshold_11; }
	inline void set_threshold_11(int32_t value)
	{
		___threshold_11 = value;
	}

	inline static int32_t get_offset_of_hcp_12() { return static_cast<int32_t>(offsetof(Dictionary_2_t1871360775, ___hcp_12)); }
	inline RuntimeObject* get_hcp_12() const { return ___hcp_12; }
	inline RuntimeObject** get_address_of_hcp_12() { return &___hcp_12; }
	inline void set_hcp_12(RuntimeObject* value)
	{
		___hcp_12 = value;
		Il2CppCodeGenWriteBarrier((&___hcp_12), value);
	}

	inline static int32_t get_offset_of_serialization_info_13() { return static_cast<int32_t>(offsetof(Dictionary_2_t1871360775, ___serialization_info_13)); }
	inline SerializationInfo_t950877179 * get_serialization_info_13() const { return ___serialization_info_13; }
	inline SerializationInfo_t950877179 ** get_address_of_serialization_info_13() { return &___serialization_info_13; }
	inline void set_serialization_info_13(SerializationInfo_t950877179 * value)
	{
		___serialization_info_13 = value;
		Il2CppCodeGenWriteBarrier((&___serialization_info_13), value);
	}

	inline static int32_t get_offset_of_generation_14() { return static_cast<int32_t>(offsetof(Dictionary_2_t1871360775, ___generation_14)); }
	inline int32_t get_generation_14() const { return ___generation_14; }
	inline int32_t* get_address_of_generation_14() { return &___generation_14; }
	inline void set_generation_14(int32_t value)
	{
		___generation_14 = value;
	}
};

struct Dictionary_2_t1871360775_StaticFields
{
public:
	// System.Collections.Generic.Dictionary`2/Transform`1<TKey,TValue,System.Collections.DictionaryEntry> System.Collections.Generic.Dictionary`2::<>f__am$cacheB
	Transform_1_t2281318713 * ___U3CU3Ef__amU24cacheB_15;

public:
	inline static int32_t get_offset_of_U3CU3Ef__amU24cacheB_15() { return static_cast<int32_t>(offsetof(Dictionary_2_t1871360775_StaticFields, ___U3CU3Ef__amU24cacheB_15)); }
	inline Transform_1_t2281318713 * get_U3CU3Ef__amU24cacheB_15() const { return ___U3CU3Ef__amU24cacheB_15; }
	inline Transform_1_t2281318713 ** get_address_of_U3CU3Ef__amU24cacheB_15() { return &___U3CU3Ef__amU24cacheB_15; }
	inline void set_U3CU3Ef__amU24cacheB_15(Transform_1_t2281318713 * value)
	{
		___U3CU3Ef__amU24cacheB_15 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cacheB_15), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DICTIONARY_2_T1871360775_H
#ifndef DICTIONARY_2_T820068610_H
#define DICTIONARY_2_T820068610_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.Dictionary`2<System.String,UnityEngine.XR.ARExtensions.XRCameraExtensions/TryGetColorCorrectionDelegate>
struct  Dictionary_2_t820068610  : public RuntimeObject
{
public:
	// System.Int32[] System.Collections.Generic.Dictionary`2::table
	Int32U5BU5D_t385246372* ___table_4;
	// System.Collections.Generic.Link[] System.Collections.Generic.Dictionary`2::linkSlots
	LinkU5BU5D_t964245573* ___linkSlots_5;
	// TKey[] System.Collections.Generic.Dictionary`2::keySlots
	StringU5BU5D_t1281789340* ___keySlots_6;
	// TValue[] System.Collections.Generic.Dictionary`2::valueSlots
	TryGetColorCorrectionDelegateU5BU5D_t310495278* ___valueSlots_7;
	// System.Int32 System.Collections.Generic.Dictionary`2::touchedSlots
	int32_t ___touchedSlots_8;
	// System.Int32 System.Collections.Generic.Dictionary`2::emptySlot
	int32_t ___emptySlot_9;
	// System.Int32 System.Collections.Generic.Dictionary`2::count
	int32_t ___count_10;
	// System.Int32 System.Collections.Generic.Dictionary`2::threshold
	int32_t ___threshold_11;
	// System.Collections.Generic.IEqualityComparer`1<TKey> System.Collections.Generic.Dictionary`2::hcp
	RuntimeObject* ___hcp_12;
	// System.Runtime.Serialization.SerializationInfo System.Collections.Generic.Dictionary`2::serialization_info
	SerializationInfo_t950877179 * ___serialization_info_13;
	// System.Int32 System.Collections.Generic.Dictionary`2::generation
	int32_t ___generation_14;

public:
	inline static int32_t get_offset_of_table_4() { return static_cast<int32_t>(offsetof(Dictionary_2_t820068610, ___table_4)); }
	inline Int32U5BU5D_t385246372* get_table_4() const { return ___table_4; }
	inline Int32U5BU5D_t385246372** get_address_of_table_4() { return &___table_4; }
	inline void set_table_4(Int32U5BU5D_t385246372* value)
	{
		___table_4 = value;
		Il2CppCodeGenWriteBarrier((&___table_4), value);
	}

	inline static int32_t get_offset_of_linkSlots_5() { return static_cast<int32_t>(offsetof(Dictionary_2_t820068610, ___linkSlots_5)); }
	inline LinkU5BU5D_t964245573* get_linkSlots_5() const { return ___linkSlots_5; }
	inline LinkU5BU5D_t964245573** get_address_of_linkSlots_5() { return &___linkSlots_5; }
	inline void set_linkSlots_5(LinkU5BU5D_t964245573* value)
	{
		___linkSlots_5 = value;
		Il2CppCodeGenWriteBarrier((&___linkSlots_5), value);
	}

	inline static int32_t get_offset_of_keySlots_6() { return static_cast<int32_t>(offsetof(Dictionary_2_t820068610, ___keySlots_6)); }
	inline StringU5BU5D_t1281789340* get_keySlots_6() const { return ___keySlots_6; }
	inline StringU5BU5D_t1281789340** get_address_of_keySlots_6() { return &___keySlots_6; }
	inline void set_keySlots_6(StringU5BU5D_t1281789340* value)
	{
		___keySlots_6 = value;
		Il2CppCodeGenWriteBarrier((&___keySlots_6), value);
	}

	inline static int32_t get_offset_of_valueSlots_7() { return static_cast<int32_t>(offsetof(Dictionary_2_t820068610, ___valueSlots_7)); }
	inline TryGetColorCorrectionDelegateU5BU5D_t310495278* get_valueSlots_7() const { return ___valueSlots_7; }
	inline TryGetColorCorrectionDelegateU5BU5D_t310495278** get_address_of_valueSlots_7() { return &___valueSlots_7; }
	inline void set_valueSlots_7(TryGetColorCorrectionDelegateU5BU5D_t310495278* value)
	{
		___valueSlots_7 = value;
		Il2CppCodeGenWriteBarrier((&___valueSlots_7), value);
	}

	inline static int32_t get_offset_of_touchedSlots_8() { return static_cast<int32_t>(offsetof(Dictionary_2_t820068610, ___touchedSlots_8)); }
	inline int32_t get_touchedSlots_8() const { return ___touchedSlots_8; }
	inline int32_t* get_address_of_touchedSlots_8() { return &___touchedSlots_8; }
	inline void set_touchedSlots_8(int32_t value)
	{
		___touchedSlots_8 = value;
	}

	inline static int32_t get_offset_of_emptySlot_9() { return static_cast<int32_t>(offsetof(Dictionary_2_t820068610, ___emptySlot_9)); }
	inline int32_t get_emptySlot_9() const { return ___emptySlot_9; }
	inline int32_t* get_address_of_emptySlot_9() { return &___emptySlot_9; }
	inline void set_emptySlot_9(int32_t value)
	{
		___emptySlot_9 = value;
	}

	inline static int32_t get_offset_of_count_10() { return static_cast<int32_t>(offsetof(Dictionary_2_t820068610, ___count_10)); }
	inline int32_t get_count_10() const { return ___count_10; }
	inline int32_t* get_address_of_count_10() { return &___count_10; }
	inline void set_count_10(int32_t value)
	{
		___count_10 = value;
	}

	inline static int32_t get_offset_of_threshold_11() { return static_cast<int32_t>(offsetof(Dictionary_2_t820068610, ___threshold_11)); }
	inline int32_t get_threshold_11() const { return ___threshold_11; }
	inline int32_t* get_address_of_threshold_11() { return &___threshold_11; }
	inline void set_threshold_11(int32_t value)
	{
		___threshold_11 = value;
	}

	inline static int32_t get_offset_of_hcp_12() { return static_cast<int32_t>(offsetof(Dictionary_2_t820068610, ___hcp_12)); }
	inline RuntimeObject* get_hcp_12() const { return ___hcp_12; }
	inline RuntimeObject** get_address_of_hcp_12() { return &___hcp_12; }
	inline void set_hcp_12(RuntimeObject* value)
	{
		___hcp_12 = value;
		Il2CppCodeGenWriteBarrier((&___hcp_12), value);
	}

	inline static int32_t get_offset_of_serialization_info_13() { return static_cast<int32_t>(offsetof(Dictionary_2_t820068610, ___serialization_info_13)); }
	inline SerializationInfo_t950877179 * get_serialization_info_13() const { return ___serialization_info_13; }
	inline SerializationInfo_t950877179 ** get_address_of_serialization_info_13() { return &___serialization_info_13; }
	inline void set_serialization_info_13(SerializationInfo_t950877179 * value)
	{
		___serialization_info_13 = value;
		Il2CppCodeGenWriteBarrier((&___serialization_info_13), value);
	}

	inline static int32_t get_offset_of_generation_14() { return static_cast<int32_t>(offsetof(Dictionary_2_t820068610, ___generation_14)); }
	inline int32_t get_generation_14() const { return ___generation_14; }
	inline int32_t* get_address_of_generation_14() { return &___generation_14; }
	inline void set_generation_14(int32_t value)
	{
		___generation_14 = value;
	}
};

struct Dictionary_2_t820068610_StaticFields
{
public:
	// System.Collections.Generic.Dictionary`2/Transform`1<TKey,TValue,System.Collections.DictionaryEntry> System.Collections.Generic.Dictionary`2::<>f__am$cacheB
	Transform_1_t3455874290 * ___U3CU3Ef__amU24cacheB_15;

public:
	inline static int32_t get_offset_of_U3CU3Ef__amU24cacheB_15() { return static_cast<int32_t>(offsetof(Dictionary_2_t820068610_StaticFields, ___U3CU3Ef__amU24cacheB_15)); }
	inline Transform_1_t3455874290 * get_U3CU3Ef__amU24cacheB_15() const { return ___U3CU3Ef__amU24cacheB_15; }
	inline Transform_1_t3455874290 ** get_address_of_U3CU3Ef__amU24cacheB_15() { return &___U3CU3Ef__amU24cacheB_15; }
	inline void set_U3CU3Ef__amU24cacheB_15(Transform_1_t3455874290 * value)
	{
		___U3CU3Ef__amU24cacheB_15 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cacheB_15), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DICTIONARY_2_T820068610_H
#ifndef DICTIONARY_2_T204178958_H
#define DICTIONARY_2_T204178958_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.Dictionary`2<System.String,UnityEngine.XR.ARExtensions.XRReferencePointExtensions/AttachReferencePointDelegate>
struct  Dictionary_2_t204178958  : public RuntimeObject
{
public:
	// System.Int32[] System.Collections.Generic.Dictionary`2::table
	Int32U5BU5D_t385246372* ___table_4;
	// System.Collections.Generic.Link[] System.Collections.Generic.Dictionary`2::linkSlots
	LinkU5BU5D_t964245573* ___linkSlots_5;
	// TKey[] System.Collections.Generic.Dictionary`2::keySlots
	StringU5BU5D_t1281789340* ___keySlots_6;
	// TValue[] System.Collections.Generic.Dictionary`2::valueSlots
	AttachReferencePointDelegateU5BU5D_t1752461682* ___valueSlots_7;
	// System.Int32 System.Collections.Generic.Dictionary`2::touchedSlots
	int32_t ___touchedSlots_8;
	// System.Int32 System.Collections.Generic.Dictionary`2::emptySlot
	int32_t ___emptySlot_9;
	// System.Int32 System.Collections.Generic.Dictionary`2::count
	int32_t ___count_10;
	// System.Int32 System.Collections.Generic.Dictionary`2::threshold
	int32_t ___threshold_11;
	// System.Collections.Generic.IEqualityComparer`1<TKey> System.Collections.Generic.Dictionary`2::hcp
	RuntimeObject* ___hcp_12;
	// System.Runtime.Serialization.SerializationInfo System.Collections.Generic.Dictionary`2::serialization_info
	SerializationInfo_t950877179 * ___serialization_info_13;
	// System.Int32 System.Collections.Generic.Dictionary`2::generation
	int32_t ___generation_14;

public:
	inline static int32_t get_offset_of_table_4() { return static_cast<int32_t>(offsetof(Dictionary_2_t204178958, ___table_4)); }
	inline Int32U5BU5D_t385246372* get_table_4() const { return ___table_4; }
	inline Int32U5BU5D_t385246372** get_address_of_table_4() { return &___table_4; }
	inline void set_table_4(Int32U5BU5D_t385246372* value)
	{
		___table_4 = value;
		Il2CppCodeGenWriteBarrier((&___table_4), value);
	}

	inline static int32_t get_offset_of_linkSlots_5() { return static_cast<int32_t>(offsetof(Dictionary_2_t204178958, ___linkSlots_5)); }
	inline LinkU5BU5D_t964245573* get_linkSlots_5() const { return ___linkSlots_5; }
	inline LinkU5BU5D_t964245573** get_address_of_linkSlots_5() { return &___linkSlots_5; }
	inline void set_linkSlots_5(LinkU5BU5D_t964245573* value)
	{
		___linkSlots_5 = value;
		Il2CppCodeGenWriteBarrier((&___linkSlots_5), value);
	}

	inline static int32_t get_offset_of_keySlots_6() { return static_cast<int32_t>(offsetof(Dictionary_2_t204178958, ___keySlots_6)); }
	inline StringU5BU5D_t1281789340* get_keySlots_6() const { return ___keySlots_6; }
	inline StringU5BU5D_t1281789340** get_address_of_keySlots_6() { return &___keySlots_6; }
	inline void set_keySlots_6(StringU5BU5D_t1281789340* value)
	{
		___keySlots_6 = value;
		Il2CppCodeGenWriteBarrier((&___keySlots_6), value);
	}

	inline static int32_t get_offset_of_valueSlots_7() { return static_cast<int32_t>(offsetof(Dictionary_2_t204178958, ___valueSlots_7)); }
	inline AttachReferencePointDelegateU5BU5D_t1752461682* get_valueSlots_7() const { return ___valueSlots_7; }
	inline AttachReferencePointDelegateU5BU5D_t1752461682** get_address_of_valueSlots_7() { return &___valueSlots_7; }
	inline void set_valueSlots_7(AttachReferencePointDelegateU5BU5D_t1752461682* value)
	{
		___valueSlots_7 = value;
		Il2CppCodeGenWriteBarrier((&___valueSlots_7), value);
	}

	inline static int32_t get_offset_of_touchedSlots_8() { return static_cast<int32_t>(offsetof(Dictionary_2_t204178958, ___touchedSlots_8)); }
	inline int32_t get_touchedSlots_8() const { return ___touchedSlots_8; }
	inline int32_t* get_address_of_touchedSlots_8() { return &___touchedSlots_8; }
	inline void set_touchedSlots_8(int32_t value)
	{
		___touchedSlots_8 = value;
	}

	inline static int32_t get_offset_of_emptySlot_9() { return static_cast<int32_t>(offsetof(Dictionary_2_t204178958, ___emptySlot_9)); }
	inline int32_t get_emptySlot_9() const { return ___emptySlot_9; }
	inline int32_t* get_address_of_emptySlot_9() { return &___emptySlot_9; }
	inline void set_emptySlot_9(int32_t value)
	{
		___emptySlot_9 = value;
	}

	inline static int32_t get_offset_of_count_10() { return static_cast<int32_t>(offsetof(Dictionary_2_t204178958, ___count_10)); }
	inline int32_t get_count_10() const { return ___count_10; }
	inline int32_t* get_address_of_count_10() { return &___count_10; }
	inline void set_count_10(int32_t value)
	{
		___count_10 = value;
	}

	inline static int32_t get_offset_of_threshold_11() { return static_cast<int32_t>(offsetof(Dictionary_2_t204178958, ___threshold_11)); }
	inline int32_t get_threshold_11() const { return ___threshold_11; }
	inline int32_t* get_address_of_threshold_11() { return &___threshold_11; }
	inline void set_threshold_11(int32_t value)
	{
		___threshold_11 = value;
	}

	inline static int32_t get_offset_of_hcp_12() { return static_cast<int32_t>(offsetof(Dictionary_2_t204178958, ___hcp_12)); }
	inline RuntimeObject* get_hcp_12() const { return ___hcp_12; }
	inline RuntimeObject** get_address_of_hcp_12() { return &___hcp_12; }
	inline void set_hcp_12(RuntimeObject* value)
	{
		___hcp_12 = value;
		Il2CppCodeGenWriteBarrier((&___hcp_12), value);
	}

	inline static int32_t get_offset_of_serialization_info_13() { return static_cast<int32_t>(offsetof(Dictionary_2_t204178958, ___serialization_info_13)); }
	inline SerializationInfo_t950877179 * get_serialization_info_13() const { return ___serialization_info_13; }
	inline SerializationInfo_t950877179 ** get_address_of_serialization_info_13() { return &___serialization_info_13; }
	inline void set_serialization_info_13(SerializationInfo_t950877179 * value)
	{
		___serialization_info_13 = value;
		Il2CppCodeGenWriteBarrier((&___serialization_info_13), value);
	}

	inline static int32_t get_offset_of_generation_14() { return static_cast<int32_t>(offsetof(Dictionary_2_t204178958, ___generation_14)); }
	inline int32_t get_generation_14() const { return ___generation_14; }
	inline int32_t* get_address_of_generation_14() { return &___generation_14; }
	inline void set_generation_14(int32_t value)
	{
		___generation_14 = value;
	}
};

struct Dictionary_2_t204178958_StaticFields
{
public:
	// System.Collections.Generic.Dictionary`2/Transform`1<TKey,TValue,System.Collections.DictionaryEntry> System.Collections.Generic.Dictionary`2::<>f__am$cacheB
	Transform_1_t602873398 * ___U3CU3Ef__amU24cacheB_15;

public:
	inline static int32_t get_offset_of_U3CU3Ef__amU24cacheB_15() { return static_cast<int32_t>(offsetof(Dictionary_2_t204178958_StaticFields, ___U3CU3Ef__amU24cacheB_15)); }
	inline Transform_1_t602873398 * get_U3CU3Ef__amU24cacheB_15() const { return ___U3CU3Ef__amU24cacheB_15; }
	inline Transform_1_t602873398 ** get_address_of_U3CU3Ef__amU24cacheB_15() { return &___U3CU3Ef__amU24cacheB_15; }
	inline void set_U3CU3Ef__amU24cacheB_15(Transform_1_t602873398 * value)
	{
		___U3CU3Ef__amU24cacheB_15 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cacheB_15), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DICTIONARY_2_T204178958_H
#ifndef DICTIONARY_2_T3245361703_H
#define DICTIONARY_2_T3245361703_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.Dictionary`2<System.String,UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionAvailability>>
struct  Dictionary_2_t3245361703  : public RuntimeObject
{
public:
	// System.Int32[] System.Collections.Generic.Dictionary`2::table
	Int32U5BU5D_t385246372* ___table_4;
	// System.Collections.Generic.Link[] System.Collections.Generic.Dictionary`2::linkSlots
	LinkU5BU5D_t964245573* ___linkSlots_5;
	// TKey[] System.Collections.Generic.Dictionary`2::keySlots
	StringU5BU5D_t1281789340* ___keySlots_6;
	// TValue[] System.Collections.Generic.Dictionary`2::valueSlots
	AsyncDelegate_1U5BU5D_t986318037* ___valueSlots_7;
	// System.Int32 System.Collections.Generic.Dictionary`2::touchedSlots
	int32_t ___touchedSlots_8;
	// System.Int32 System.Collections.Generic.Dictionary`2::emptySlot
	int32_t ___emptySlot_9;
	// System.Int32 System.Collections.Generic.Dictionary`2::count
	int32_t ___count_10;
	// System.Int32 System.Collections.Generic.Dictionary`2::threshold
	int32_t ___threshold_11;
	// System.Collections.Generic.IEqualityComparer`1<TKey> System.Collections.Generic.Dictionary`2::hcp
	RuntimeObject* ___hcp_12;
	// System.Runtime.Serialization.SerializationInfo System.Collections.Generic.Dictionary`2::serialization_info
	SerializationInfo_t950877179 * ___serialization_info_13;
	// System.Int32 System.Collections.Generic.Dictionary`2::generation
	int32_t ___generation_14;

public:
	inline static int32_t get_offset_of_table_4() { return static_cast<int32_t>(offsetof(Dictionary_2_t3245361703, ___table_4)); }
	inline Int32U5BU5D_t385246372* get_table_4() const { return ___table_4; }
	inline Int32U5BU5D_t385246372** get_address_of_table_4() { return &___table_4; }
	inline void set_table_4(Int32U5BU5D_t385246372* value)
	{
		___table_4 = value;
		Il2CppCodeGenWriteBarrier((&___table_4), value);
	}

	inline static int32_t get_offset_of_linkSlots_5() { return static_cast<int32_t>(offsetof(Dictionary_2_t3245361703, ___linkSlots_5)); }
	inline LinkU5BU5D_t964245573* get_linkSlots_5() const { return ___linkSlots_5; }
	inline LinkU5BU5D_t964245573** get_address_of_linkSlots_5() { return &___linkSlots_5; }
	inline void set_linkSlots_5(LinkU5BU5D_t964245573* value)
	{
		___linkSlots_5 = value;
		Il2CppCodeGenWriteBarrier((&___linkSlots_5), value);
	}

	inline static int32_t get_offset_of_keySlots_6() { return static_cast<int32_t>(offsetof(Dictionary_2_t3245361703, ___keySlots_6)); }
	inline StringU5BU5D_t1281789340* get_keySlots_6() const { return ___keySlots_6; }
	inline StringU5BU5D_t1281789340** get_address_of_keySlots_6() { return &___keySlots_6; }
	inline void set_keySlots_6(StringU5BU5D_t1281789340* value)
	{
		___keySlots_6 = value;
		Il2CppCodeGenWriteBarrier((&___keySlots_6), value);
	}

	inline static int32_t get_offset_of_valueSlots_7() { return static_cast<int32_t>(offsetof(Dictionary_2_t3245361703, ___valueSlots_7)); }
	inline AsyncDelegate_1U5BU5D_t986318037* get_valueSlots_7() const { return ___valueSlots_7; }
	inline AsyncDelegate_1U5BU5D_t986318037** get_address_of_valueSlots_7() { return &___valueSlots_7; }
	inline void set_valueSlots_7(AsyncDelegate_1U5BU5D_t986318037* value)
	{
		___valueSlots_7 = value;
		Il2CppCodeGenWriteBarrier((&___valueSlots_7), value);
	}

	inline static int32_t get_offset_of_touchedSlots_8() { return static_cast<int32_t>(offsetof(Dictionary_2_t3245361703, ___touchedSlots_8)); }
	inline int32_t get_touchedSlots_8() const { return ___touchedSlots_8; }
	inline int32_t* get_address_of_touchedSlots_8() { return &___touchedSlots_8; }
	inline void set_touchedSlots_8(int32_t value)
	{
		___touchedSlots_8 = value;
	}

	inline static int32_t get_offset_of_emptySlot_9() { return static_cast<int32_t>(offsetof(Dictionary_2_t3245361703, ___emptySlot_9)); }
	inline int32_t get_emptySlot_9() const { return ___emptySlot_9; }
	inline int32_t* get_address_of_emptySlot_9() { return &___emptySlot_9; }
	inline void set_emptySlot_9(int32_t value)
	{
		___emptySlot_9 = value;
	}

	inline static int32_t get_offset_of_count_10() { return static_cast<int32_t>(offsetof(Dictionary_2_t3245361703, ___count_10)); }
	inline int32_t get_count_10() const { return ___count_10; }
	inline int32_t* get_address_of_count_10() { return &___count_10; }
	inline void set_count_10(int32_t value)
	{
		___count_10 = value;
	}

	inline static int32_t get_offset_of_threshold_11() { return static_cast<int32_t>(offsetof(Dictionary_2_t3245361703, ___threshold_11)); }
	inline int32_t get_threshold_11() const { return ___threshold_11; }
	inline int32_t* get_address_of_threshold_11() { return &___threshold_11; }
	inline void set_threshold_11(int32_t value)
	{
		___threshold_11 = value;
	}

	inline static int32_t get_offset_of_hcp_12() { return static_cast<int32_t>(offsetof(Dictionary_2_t3245361703, ___hcp_12)); }
	inline RuntimeObject* get_hcp_12() const { return ___hcp_12; }
	inline RuntimeObject** get_address_of_hcp_12() { return &___hcp_12; }
	inline void set_hcp_12(RuntimeObject* value)
	{
		___hcp_12 = value;
		Il2CppCodeGenWriteBarrier((&___hcp_12), value);
	}

	inline static int32_t get_offset_of_serialization_info_13() { return static_cast<int32_t>(offsetof(Dictionary_2_t3245361703, ___serialization_info_13)); }
	inline SerializationInfo_t950877179 * get_serialization_info_13() const { return ___serialization_info_13; }
	inline SerializationInfo_t950877179 ** get_address_of_serialization_info_13() { return &___serialization_info_13; }
	inline void set_serialization_info_13(SerializationInfo_t950877179 * value)
	{
		___serialization_info_13 = value;
		Il2CppCodeGenWriteBarrier((&___serialization_info_13), value);
	}

	inline static int32_t get_offset_of_generation_14() { return static_cast<int32_t>(offsetof(Dictionary_2_t3245361703, ___generation_14)); }
	inline int32_t get_generation_14() const { return ___generation_14; }
	inline int32_t* get_address_of_generation_14() { return &___generation_14; }
	inline void set_generation_14(int32_t value)
	{
		___generation_14 = value;
	}
};

struct Dictionary_2_t3245361703_StaticFields
{
public:
	// System.Collections.Generic.Dictionary`2/Transform`1<TKey,TValue,System.Collections.DictionaryEntry> System.Collections.Generic.Dictionary`2::<>f__am$cacheB
	Transform_1_t4131697049 * ___U3CU3Ef__amU24cacheB_15;

public:
	inline static int32_t get_offset_of_U3CU3Ef__amU24cacheB_15() { return static_cast<int32_t>(offsetof(Dictionary_2_t3245361703_StaticFields, ___U3CU3Ef__amU24cacheB_15)); }
	inline Transform_1_t4131697049 * get_U3CU3Ef__amU24cacheB_15() const { return ___U3CU3Ef__amU24cacheB_15; }
	inline Transform_1_t4131697049 ** get_address_of_U3CU3Ef__amU24cacheB_15() { return &___U3CU3Ef__amU24cacheB_15; }
	inline void set_U3CU3Ef__amU24cacheB_15(Transform_1_t4131697049 * value)
	{
		___U3CU3Ef__amU24cacheB_15 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cacheB_15), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DICTIONARY_2_T3245361703_H
#ifndef DICTIONARY_2_T757416466_H
#define DICTIONARY_2_T757416466_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.Dictionary`2<System.String,UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionInstallationStatus>>
struct  Dictionary_2_t757416466  : public RuntimeObject
{
public:
	// System.Int32[] System.Collections.Generic.Dictionary`2::table
	Int32U5BU5D_t385246372* ___table_4;
	// System.Collections.Generic.Link[] System.Collections.Generic.Dictionary`2::linkSlots
	LinkU5BU5D_t964245573* ___linkSlots_5;
	// TKey[] System.Collections.Generic.Dictionary`2::keySlots
	StringU5BU5D_t1281789340* ___keySlots_6;
	// TValue[] System.Collections.Generic.Dictionary`2::valueSlots
	AsyncDelegate_1U5BU5D_t3002781918* ___valueSlots_7;
	// System.Int32 System.Collections.Generic.Dictionary`2::touchedSlots
	int32_t ___touchedSlots_8;
	// System.Int32 System.Collections.Generic.Dictionary`2::emptySlot
	int32_t ___emptySlot_9;
	// System.Int32 System.Collections.Generic.Dictionary`2::count
	int32_t ___count_10;
	// System.Int32 System.Collections.Generic.Dictionary`2::threshold
	int32_t ___threshold_11;
	// System.Collections.Generic.IEqualityComparer`1<TKey> System.Collections.Generic.Dictionary`2::hcp
	RuntimeObject* ___hcp_12;
	// System.Runtime.Serialization.SerializationInfo System.Collections.Generic.Dictionary`2::serialization_info
	SerializationInfo_t950877179 * ___serialization_info_13;
	// System.Int32 System.Collections.Generic.Dictionary`2::generation
	int32_t ___generation_14;

public:
	inline static int32_t get_offset_of_table_4() { return static_cast<int32_t>(offsetof(Dictionary_2_t757416466, ___table_4)); }
	inline Int32U5BU5D_t385246372* get_table_4() const { return ___table_4; }
	inline Int32U5BU5D_t385246372** get_address_of_table_4() { return &___table_4; }
	inline void set_table_4(Int32U5BU5D_t385246372* value)
	{
		___table_4 = value;
		Il2CppCodeGenWriteBarrier((&___table_4), value);
	}

	inline static int32_t get_offset_of_linkSlots_5() { return static_cast<int32_t>(offsetof(Dictionary_2_t757416466, ___linkSlots_5)); }
	inline LinkU5BU5D_t964245573* get_linkSlots_5() const { return ___linkSlots_5; }
	inline LinkU5BU5D_t964245573** get_address_of_linkSlots_5() { return &___linkSlots_5; }
	inline void set_linkSlots_5(LinkU5BU5D_t964245573* value)
	{
		___linkSlots_5 = value;
		Il2CppCodeGenWriteBarrier((&___linkSlots_5), value);
	}

	inline static int32_t get_offset_of_keySlots_6() { return static_cast<int32_t>(offsetof(Dictionary_2_t757416466, ___keySlots_6)); }
	inline StringU5BU5D_t1281789340* get_keySlots_6() const { return ___keySlots_6; }
	inline StringU5BU5D_t1281789340** get_address_of_keySlots_6() { return &___keySlots_6; }
	inline void set_keySlots_6(StringU5BU5D_t1281789340* value)
	{
		___keySlots_6 = value;
		Il2CppCodeGenWriteBarrier((&___keySlots_6), value);
	}

	inline static int32_t get_offset_of_valueSlots_7() { return static_cast<int32_t>(offsetof(Dictionary_2_t757416466, ___valueSlots_7)); }
	inline AsyncDelegate_1U5BU5D_t3002781918* get_valueSlots_7() const { return ___valueSlots_7; }
	inline AsyncDelegate_1U5BU5D_t3002781918** get_address_of_valueSlots_7() { return &___valueSlots_7; }
	inline void set_valueSlots_7(AsyncDelegate_1U5BU5D_t3002781918* value)
	{
		___valueSlots_7 = value;
		Il2CppCodeGenWriteBarrier((&___valueSlots_7), value);
	}

	inline static int32_t get_offset_of_touchedSlots_8() { return static_cast<int32_t>(offsetof(Dictionary_2_t757416466, ___touchedSlots_8)); }
	inline int32_t get_touchedSlots_8() const { return ___touchedSlots_8; }
	inline int32_t* get_address_of_touchedSlots_8() { return &___touchedSlots_8; }
	inline void set_touchedSlots_8(int32_t value)
	{
		___touchedSlots_8 = value;
	}

	inline static int32_t get_offset_of_emptySlot_9() { return static_cast<int32_t>(offsetof(Dictionary_2_t757416466, ___emptySlot_9)); }
	inline int32_t get_emptySlot_9() const { return ___emptySlot_9; }
	inline int32_t* get_address_of_emptySlot_9() { return &___emptySlot_9; }
	inline void set_emptySlot_9(int32_t value)
	{
		___emptySlot_9 = value;
	}

	inline static int32_t get_offset_of_count_10() { return static_cast<int32_t>(offsetof(Dictionary_2_t757416466, ___count_10)); }
	inline int32_t get_count_10() const { return ___count_10; }
	inline int32_t* get_address_of_count_10() { return &___count_10; }
	inline void set_count_10(int32_t value)
	{
		___count_10 = value;
	}

	inline static int32_t get_offset_of_threshold_11() { return static_cast<int32_t>(offsetof(Dictionary_2_t757416466, ___threshold_11)); }
	inline int32_t get_threshold_11() const { return ___threshold_11; }
	inline int32_t* get_address_of_threshold_11() { return &___threshold_11; }
	inline void set_threshold_11(int32_t value)
	{
		___threshold_11 = value;
	}

	inline static int32_t get_offset_of_hcp_12() { return static_cast<int32_t>(offsetof(Dictionary_2_t757416466, ___hcp_12)); }
	inline RuntimeObject* get_hcp_12() const { return ___hcp_12; }
	inline RuntimeObject** get_address_of_hcp_12() { return &___hcp_12; }
	inline void set_hcp_12(RuntimeObject* value)
	{
		___hcp_12 = value;
		Il2CppCodeGenWriteBarrier((&___hcp_12), value);
	}

	inline static int32_t get_offset_of_serialization_info_13() { return static_cast<int32_t>(offsetof(Dictionary_2_t757416466, ___serialization_info_13)); }
	inline SerializationInfo_t950877179 * get_serialization_info_13() const { return ___serialization_info_13; }
	inline SerializationInfo_t950877179 ** get_address_of_serialization_info_13() { return &___serialization_info_13; }
	inline void set_serialization_info_13(SerializationInfo_t950877179 * value)
	{
		___serialization_info_13 = value;
		Il2CppCodeGenWriteBarrier((&___serialization_info_13), value);
	}

	inline static int32_t get_offset_of_generation_14() { return static_cast<int32_t>(offsetof(Dictionary_2_t757416466, ___generation_14)); }
	inline int32_t get_generation_14() const { return ___generation_14; }
	inline int32_t* get_address_of_generation_14() { return &___generation_14; }
	inline void set_generation_14(int32_t value)
	{
		___generation_14 = value;
	}
};

struct Dictionary_2_t757416466_StaticFields
{
public:
	// System.Collections.Generic.Dictionary`2/Transform`1<TKey,TValue,System.Collections.DictionaryEntry> System.Collections.Generic.Dictionary`2::<>f__am$cacheB
	Transform_1_t1853193634 * ___U3CU3Ef__amU24cacheB_15;

public:
	inline static int32_t get_offset_of_U3CU3Ef__amU24cacheB_15() { return static_cast<int32_t>(offsetof(Dictionary_2_t757416466_StaticFields, ___U3CU3Ef__amU24cacheB_15)); }
	inline Transform_1_t1853193634 * get_U3CU3Ef__amU24cacheB_15() const { return ___U3CU3Ef__amU24cacheB_15; }
	inline Transform_1_t1853193634 ** get_address_of_U3CU3Ef__amU24cacheB_15() { return &___U3CU3Ef__amU24cacheB_15; }
	inline void set_U3CU3Ef__amU24cacheB_15(Transform_1_t1853193634 * value)
	{
		___U3CU3Ef__amU24cacheB_15 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cacheB_15), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DICTIONARY_2_T757416466_H
#ifndef EXCEPTION_T_H
#define EXCEPTION_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Exception
struct  Exception_t  : public RuntimeObject
{
public:
	// System.IntPtr[] System.Exception::trace_ips
	IntPtrU5BU5D_t4013366056* ___trace_ips_0;
	// System.Exception System.Exception::inner_exception
	Exception_t * ___inner_exception_1;
	// System.String System.Exception::message
	String_t* ___message_2;
	// System.String System.Exception::help_link
	String_t* ___help_link_3;
	// System.String System.Exception::class_name
	String_t* ___class_name_4;
	// System.String System.Exception::stack_trace
	String_t* ___stack_trace_5;
	// System.String System.Exception::_remoteStackTraceString
	String_t* ____remoteStackTraceString_6;
	// System.Int32 System.Exception::remote_stack_index
	int32_t ___remote_stack_index_7;
	// System.Int32 System.Exception::hresult
	int32_t ___hresult_8;
	// System.String System.Exception::source
	String_t* ___source_9;
	// System.Collections.IDictionary System.Exception::_data
	RuntimeObject* ____data_10;

public:
	inline static int32_t get_offset_of_trace_ips_0() { return static_cast<int32_t>(offsetof(Exception_t, ___trace_ips_0)); }
	inline IntPtrU5BU5D_t4013366056* get_trace_ips_0() const { return ___trace_ips_0; }
	inline IntPtrU5BU5D_t4013366056** get_address_of_trace_ips_0() { return &___trace_ips_0; }
	inline void set_trace_ips_0(IntPtrU5BU5D_t4013366056* value)
	{
		___trace_ips_0 = value;
		Il2CppCodeGenWriteBarrier((&___trace_ips_0), value);
	}

	inline static int32_t get_offset_of_inner_exception_1() { return static_cast<int32_t>(offsetof(Exception_t, ___inner_exception_1)); }
	inline Exception_t * get_inner_exception_1() const { return ___inner_exception_1; }
	inline Exception_t ** get_address_of_inner_exception_1() { return &___inner_exception_1; }
	inline void set_inner_exception_1(Exception_t * value)
	{
		___inner_exception_1 = value;
		Il2CppCodeGenWriteBarrier((&___inner_exception_1), value);
	}

	inline static int32_t get_offset_of_message_2() { return static_cast<int32_t>(offsetof(Exception_t, ___message_2)); }
	inline String_t* get_message_2() const { return ___message_2; }
	inline String_t** get_address_of_message_2() { return &___message_2; }
	inline void set_message_2(String_t* value)
	{
		___message_2 = value;
		Il2CppCodeGenWriteBarrier((&___message_2), value);
	}

	inline static int32_t get_offset_of_help_link_3() { return static_cast<int32_t>(offsetof(Exception_t, ___help_link_3)); }
	inline String_t* get_help_link_3() const { return ___help_link_3; }
	inline String_t** get_address_of_help_link_3() { return &___help_link_3; }
	inline void set_help_link_3(String_t* value)
	{
		___help_link_3 = value;
		Il2CppCodeGenWriteBarrier((&___help_link_3), value);
	}

	inline static int32_t get_offset_of_class_name_4() { return static_cast<int32_t>(offsetof(Exception_t, ___class_name_4)); }
	inline String_t* get_class_name_4() const { return ___class_name_4; }
	inline String_t** get_address_of_class_name_4() { return &___class_name_4; }
	inline void set_class_name_4(String_t* value)
	{
		___class_name_4 = value;
		Il2CppCodeGenWriteBarrier((&___class_name_4), value);
	}

	inline static int32_t get_offset_of_stack_trace_5() { return static_cast<int32_t>(offsetof(Exception_t, ___stack_trace_5)); }
	inline String_t* get_stack_trace_5() const { return ___stack_trace_5; }
	inline String_t** get_address_of_stack_trace_5() { return &___stack_trace_5; }
	inline void set_stack_trace_5(String_t* value)
	{
		___stack_trace_5 = value;
		Il2CppCodeGenWriteBarrier((&___stack_trace_5), value);
	}

	inline static int32_t get_offset_of__remoteStackTraceString_6() { return static_cast<int32_t>(offsetof(Exception_t, ____remoteStackTraceString_6)); }
	inline String_t* get__remoteStackTraceString_6() const { return ____remoteStackTraceString_6; }
	inline String_t** get_address_of__remoteStackTraceString_6() { return &____remoteStackTraceString_6; }
	inline void set__remoteStackTraceString_6(String_t* value)
	{
		____remoteStackTraceString_6 = value;
		Il2CppCodeGenWriteBarrier((&____remoteStackTraceString_6), value);
	}

	inline static int32_t get_offset_of_remote_stack_index_7() { return static_cast<int32_t>(offsetof(Exception_t, ___remote_stack_index_7)); }
	inline int32_t get_remote_stack_index_7() const { return ___remote_stack_index_7; }
	inline int32_t* get_address_of_remote_stack_index_7() { return &___remote_stack_index_7; }
	inline void set_remote_stack_index_7(int32_t value)
	{
		___remote_stack_index_7 = value;
	}

	inline static int32_t get_offset_of_hresult_8() { return static_cast<int32_t>(offsetof(Exception_t, ___hresult_8)); }
	inline int32_t get_hresult_8() const { return ___hresult_8; }
	inline int32_t* get_address_of_hresult_8() { return &___hresult_8; }
	inline void set_hresult_8(int32_t value)
	{
		___hresult_8 = value;
	}

	inline static int32_t get_offset_of_source_9() { return static_cast<int32_t>(offsetof(Exception_t, ___source_9)); }
	inline String_t* get_source_9() const { return ___source_9; }
	inline String_t** get_address_of_source_9() { return &___source_9; }
	inline void set_source_9(String_t* value)
	{
		___source_9 = value;
		Il2CppCodeGenWriteBarrier((&___source_9), value);
	}

	inline static int32_t get_offset_of__data_10() { return static_cast<int32_t>(offsetof(Exception_t, ____data_10)); }
	inline RuntimeObject* get__data_10() const { return ____data_10; }
	inline RuntimeObject** get_address_of__data_10() { return &____data_10; }
	inline void set__data_10(RuntimeObject* value)
	{
		____data_10 = value;
		Il2CppCodeGenWriteBarrier((&____data_10), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EXCEPTION_T_H
#ifndef STRING_T_H
#define STRING_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.String
struct  String_t  : public RuntimeObject
{
public:
	// System.Int32 System.String::length
	int32_t ___length_0;
	// System.Char System.String::start_char
	Il2CppChar ___start_char_1;

public:
	inline static int32_t get_offset_of_length_0() { return static_cast<int32_t>(offsetof(String_t, ___length_0)); }
	inline int32_t get_length_0() const { return ___length_0; }
	inline int32_t* get_address_of_length_0() { return &___length_0; }
	inline void set_length_0(int32_t value)
	{
		___length_0 = value;
	}

	inline static int32_t get_offset_of_start_char_1() { return static_cast<int32_t>(offsetof(String_t, ___start_char_1)); }
	inline Il2CppChar get_start_char_1() const { return ___start_char_1; }
	inline Il2CppChar* get_address_of_start_char_1() { return &___start_char_1; }
	inline void set_start_char_1(Il2CppChar value)
	{
		___start_char_1 = value;
	}
};

struct String_t_StaticFields
{
public:
	// System.String System.String::Empty
	String_t* ___Empty_2;
	// System.Char[] System.String::WhiteChars
	CharU5BU5D_t3528271667* ___WhiteChars_3;

public:
	inline static int32_t get_offset_of_Empty_2() { return static_cast<int32_t>(offsetof(String_t_StaticFields, ___Empty_2)); }
	inline String_t* get_Empty_2() const { return ___Empty_2; }
	inline String_t** get_address_of_Empty_2() { return &___Empty_2; }
	inline void set_Empty_2(String_t* value)
	{
		___Empty_2 = value;
		Il2CppCodeGenWriteBarrier((&___Empty_2), value);
	}

	inline static int32_t get_offset_of_WhiteChars_3() { return static_cast<int32_t>(offsetof(String_t_StaticFields, ___WhiteChars_3)); }
	inline CharU5BU5D_t3528271667* get_WhiteChars_3() const { return ___WhiteChars_3; }
	inline CharU5BU5D_t3528271667** get_address_of_WhiteChars_3() { return &___WhiteChars_3; }
	inline void set_WhiteChars_3(CharU5BU5D_t3528271667* value)
	{
		___WhiteChars_3 = value;
		Il2CppCodeGenWriteBarrier((&___WhiteChars_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // STRING_T_H
#ifndef VALUETYPE_T3640485471_H
#define VALUETYPE_T3640485471_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ValueType
struct  ValueType_t3640485471  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t3640485471_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t3640485471_marshaled_com
{
};
#endif // VALUETYPE_T3640485471_H
#ifndef CUSTOMYIELDINSTRUCTION_T1895667560_H
#define CUSTOMYIELDINSTRUCTION_T1895667560_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.CustomYieldInstruction
struct  CustomYieldInstruction_t1895667560  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CUSTOMYIELDINSTRUCTION_T1895667560_H
#ifndef REGISTRATIONHELPER_T1767884348_H
#define REGISTRATIONHELPER_T1767884348_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.ARExtensions.RegistrationHelper
struct  RegistrationHelper_t1767884348  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // REGISTRATIONHELPER_T1767884348_H
#ifndef SESSIONAVAILABILITYEXTENSIONS_T188051186_H
#define SESSIONAVAILABILITYEXTENSIONS_T188051186_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.ARExtensions.SessionAvailabilityExtensions
struct  SessionAvailabilityExtensions_t188051186  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SESSIONAVAILABILITYEXTENSIONS_T188051186_H
#ifndef XRCAMERAEXTENSIONS_T1293988219_H
#define XRCAMERAEXTENSIONS_T1293988219_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.ARExtensions.XRCameraExtensions
struct  XRCameraExtensions_t1293988219  : public RuntimeObject
{
public:

public:
};

struct XRCameraExtensions_t1293988219_StaticFields
{
public:
	// System.Func`2<UnityEngine.Experimental.XR.XRCameraSubsystem,System.Boolean> UnityEngine.XR.ARExtensions.XRCameraExtensions::s_IsPermissionGrantedDelegate
	Func_2_t2975102603 * ___s_IsPermissionGrantedDelegate_0;
	// UnityEngine.XR.ARExtensions.XRCameraExtensions/TryGetColorCorrectionDelegate UnityEngine.XR.ARExtensions.XRCameraExtensions::s_TryGetColorCorrectionDelegate
	TryGetColorCorrectionDelegate_t1034812311 * ___s_TryGetColorCorrectionDelegate_1;
	// UnityEngine.XR.ARExtensions.ICameraImageApi UnityEngine.XR.ARExtensions.XRCameraExtensions::s_AsyncCameraImageApi
	RuntimeObject* ___s_AsyncCameraImageApi_2;
	// UnityEngine.XR.ARExtensions.XRCameraExtensions/DefaultCameraImageApi UnityEngine.XR.ARExtensions.XRCameraExtensions::s_DefaultAsyncCameraImageApi
	DefaultCameraImageApi_t2442227313 * ___s_DefaultAsyncCameraImageApi_3;
	// System.Collections.Generic.Dictionary`2<System.String,System.Func`2<UnityEngine.Experimental.XR.XRCameraSubsystem,System.Boolean>> UnityEngine.XR.ARExtensions.XRCameraExtensions::s_IsPermissionGrantedDelegates
	Dictionary_2_t2760358902 * ___s_IsPermissionGrantedDelegates_4;
	// System.Collections.Generic.Dictionary`2<System.String,UnityEngine.XR.ARExtensions.XRCameraExtensions/TryGetColorCorrectionDelegate> UnityEngine.XR.ARExtensions.XRCameraExtensions::s_TryGetColorCorrectionDelegates
	Dictionary_2_t820068610 * ___s_TryGetColorCorrectionDelegates_5;
	// System.Collections.Generic.Dictionary`2<System.String,UnityEngine.XR.ARExtensions.ICameraImageApi> UnityEngine.XR.ARExtensions.XRCameraExtensions::s_CameraImageApis
	Dictionary_2_t1871360775 * ___s_CameraImageApis_6;
	// System.Func`2<UnityEngine.Experimental.XR.XRCameraSubsystem,System.Boolean> UnityEngine.XR.ARExtensions.XRCameraExtensions::<>f__mg$cache0
	Func_2_t2975102603 * ___U3CU3Ef__mgU24cache0_7;
	// UnityEngine.XR.ARExtensions.XRCameraExtensions/TryGetColorCorrectionDelegate UnityEngine.XR.ARExtensions.XRCameraExtensions::<>f__mg$cache1
	TryGetColorCorrectionDelegate_t1034812311 * ___U3CU3Ef__mgU24cache1_8;
	// System.Func`2<UnityEngine.Experimental.XR.XRCameraSubsystem,System.Boolean> UnityEngine.XR.ARExtensions.XRCameraExtensions::<>f__mg$cache2
	Func_2_t2975102603 * ___U3CU3Ef__mgU24cache2_9;
	// UnityEngine.XR.ARExtensions.XRCameraExtensions/TryGetColorCorrectionDelegate UnityEngine.XR.ARExtensions.XRCameraExtensions::<>f__mg$cache3
	TryGetColorCorrectionDelegate_t1034812311 * ___U3CU3Ef__mgU24cache3_10;

public:
	inline static int32_t get_offset_of_s_IsPermissionGrantedDelegate_0() { return static_cast<int32_t>(offsetof(XRCameraExtensions_t1293988219_StaticFields, ___s_IsPermissionGrantedDelegate_0)); }
	inline Func_2_t2975102603 * get_s_IsPermissionGrantedDelegate_0() const { return ___s_IsPermissionGrantedDelegate_0; }
	inline Func_2_t2975102603 ** get_address_of_s_IsPermissionGrantedDelegate_0() { return &___s_IsPermissionGrantedDelegate_0; }
	inline void set_s_IsPermissionGrantedDelegate_0(Func_2_t2975102603 * value)
	{
		___s_IsPermissionGrantedDelegate_0 = value;
		Il2CppCodeGenWriteBarrier((&___s_IsPermissionGrantedDelegate_0), value);
	}

	inline static int32_t get_offset_of_s_TryGetColorCorrectionDelegate_1() { return static_cast<int32_t>(offsetof(XRCameraExtensions_t1293988219_StaticFields, ___s_TryGetColorCorrectionDelegate_1)); }
	inline TryGetColorCorrectionDelegate_t1034812311 * get_s_TryGetColorCorrectionDelegate_1() const { return ___s_TryGetColorCorrectionDelegate_1; }
	inline TryGetColorCorrectionDelegate_t1034812311 ** get_address_of_s_TryGetColorCorrectionDelegate_1() { return &___s_TryGetColorCorrectionDelegate_1; }
	inline void set_s_TryGetColorCorrectionDelegate_1(TryGetColorCorrectionDelegate_t1034812311 * value)
	{
		___s_TryGetColorCorrectionDelegate_1 = value;
		Il2CppCodeGenWriteBarrier((&___s_TryGetColorCorrectionDelegate_1), value);
	}

	inline static int32_t get_offset_of_s_AsyncCameraImageApi_2() { return static_cast<int32_t>(offsetof(XRCameraExtensions_t1293988219_StaticFields, ___s_AsyncCameraImageApi_2)); }
	inline RuntimeObject* get_s_AsyncCameraImageApi_2() const { return ___s_AsyncCameraImageApi_2; }
	inline RuntimeObject** get_address_of_s_AsyncCameraImageApi_2() { return &___s_AsyncCameraImageApi_2; }
	inline void set_s_AsyncCameraImageApi_2(RuntimeObject* value)
	{
		___s_AsyncCameraImageApi_2 = value;
		Il2CppCodeGenWriteBarrier((&___s_AsyncCameraImageApi_2), value);
	}

	inline static int32_t get_offset_of_s_DefaultAsyncCameraImageApi_3() { return static_cast<int32_t>(offsetof(XRCameraExtensions_t1293988219_StaticFields, ___s_DefaultAsyncCameraImageApi_3)); }
	inline DefaultCameraImageApi_t2442227313 * get_s_DefaultAsyncCameraImageApi_3() const { return ___s_DefaultAsyncCameraImageApi_3; }
	inline DefaultCameraImageApi_t2442227313 ** get_address_of_s_DefaultAsyncCameraImageApi_3() { return &___s_DefaultAsyncCameraImageApi_3; }
	inline void set_s_DefaultAsyncCameraImageApi_3(DefaultCameraImageApi_t2442227313 * value)
	{
		___s_DefaultAsyncCameraImageApi_3 = value;
		Il2CppCodeGenWriteBarrier((&___s_DefaultAsyncCameraImageApi_3), value);
	}

	inline static int32_t get_offset_of_s_IsPermissionGrantedDelegates_4() { return static_cast<int32_t>(offsetof(XRCameraExtensions_t1293988219_StaticFields, ___s_IsPermissionGrantedDelegates_4)); }
	inline Dictionary_2_t2760358902 * get_s_IsPermissionGrantedDelegates_4() const { return ___s_IsPermissionGrantedDelegates_4; }
	inline Dictionary_2_t2760358902 ** get_address_of_s_IsPermissionGrantedDelegates_4() { return &___s_IsPermissionGrantedDelegates_4; }
	inline void set_s_IsPermissionGrantedDelegates_4(Dictionary_2_t2760358902 * value)
	{
		___s_IsPermissionGrantedDelegates_4 = value;
		Il2CppCodeGenWriteBarrier((&___s_IsPermissionGrantedDelegates_4), value);
	}

	inline static int32_t get_offset_of_s_TryGetColorCorrectionDelegates_5() { return static_cast<int32_t>(offsetof(XRCameraExtensions_t1293988219_StaticFields, ___s_TryGetColorCorrectionDelegates_5)); }
	inline Dictionary_2_t820068610 * get_s_TryGetColorCorrectionDelegates_5() const { return ___s_TryGetColorCorrectionDelegates_5; }
	inline Dictionary_2_t820068610 ** get_address_of_s_TryGetColorCorrectionDelegates_5() { return &___s_TryGetColorCorrectionDelegates_5; }
	inline void set_s_TryGetColorCorrectionDelegates_5(Dictionary_2_t820068610 * value)
	{
		___s_TryGetColorCorrectionDelegates_5 = value;
		Il2CppCodeGenWriteBarrier((&___s_TryGetColorCorrectionDelegates_5), value);
	}

	inline static int32_t get_offset_of_s_CameraImageApis_6() { return static_cast<int32_t>(offsetof(XRCameraExtensions_t1293988219_StaticFields, ___s_CameraImageApis_6)); }
	inline Dictionary_2_t1871360775 * get_s_CameraImageApis_6() const { return ___s_CameraImageApis_6; }
	inline Dictionary_2_t1871360775 ** get_address_of_s_CameraImageApis_6() { return &___s_CameraImageApis_6; }
	inline void set_s_CameraImageApis_6(Dictionary_2_t1871360775 * value)
	{
		___s_CameraImageApis_6 = value;
		Il2CppCodeGenWriteBarrier((&___s_CameraImageApis_6), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__mgU24cache0_7() { return static_cast<int32_t>(offsetof(XRCameraExtensions_t1293988219_StaticFields, ___U3CU3Ef__mgU24cache0_7)); }
	inline Func_2_t2975102603 * get_U3CU3Ef__mgU24cache0_7() const { return ___U3CU3Ef__mgU24cache0_7; }
	inline Func_2_t2975102603 ** get_address_of_U3CU3Ef__mgU24cache0_7() { return &___U3CU3Ef__mgU24cache0_7; }
	inline void set_U3CU3Ef__mgU24cache0_7(Func_2_t2975102603 * value)
	{
		___U3CU3Ef__mgU24cache0_7 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__mgU24cache0_7), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__mgU24cache1_8() { return static_cast<int32_t>(offsetof(XRCameraExtensions_t1293988219_StaticFields, ___U3CU3Ef__mgU24cache1_8)); }
	inline TryGetColorCorrectionDelegate_t1034812311 * get_U3CU3Ef__mgU24cache1_8() const { return ___U3CU3Ef__mgU24cache1_8; }
	inline TryGetColorCorrectionDelegate_t1034812311 ** get_address_of_U3CU3Ef__mgU24cache1_8() { return &___U3CU3Ef__mgU24cache1_8; }
	inline void set_U3CU3Ef__mgU24cache1_8(TryGetColorCorrectionDelegate_t1034812311 * value)
	{
		___U3CU3Ef__mgU24cache1_8 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__mgU24cache1_8), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__mgU24cache2_9() { return static_cast<int32_t>(offsetof(XRCameraExtensions_t1293988219_StaticFields, ___U3CU3Ef__mgU24cache2_9)); }
	inline Func_2_t2975102603 * get_U3CU3Ef__mgU24cache2_9() const { return ___U3CU3Ef__mgU24cache2_9; }
	inline Func_2_t2975102603 ** get_address_of_U3CU3Ef__mgU24cache2_9() { return &___U3CU3Ef__mgU24cache2_9; }
	inline void set_U3CU3Ef__mgU24cache2_9(Func_2_t2975102603 * value)
	{
		___U3CU3Ef__mgU24cache2_9 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__mgU24cache2_9), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__mgU24cache3_10() { return static_cast<int32_t>(offsetof(XRCameraExtensions_t1293988219_StaticFields, ___U3CU3Ef__mgU24cache3_10)); }
	inline TryGetColorCorrectionDelegate_t1034812311 * get_U3CU3Ef__mgU24cache3_10() const { return ___U3CU3Ef__mgU24cache3_10; }
	inline TryGetColorCorrectionDelegate_t1034812311 ** get_address_of_U3CU3Ef__mgU24cache3_10() { return &___U3CU3Ef__mgU24cache3_10; }
	inline void set_U3CU3Ef__mgU24cache3_10(TryGetColorCorrectionDelegate_t1034812311 * value)
	{
		___U3CU3Ef__mgU24cache3_10 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__mgU24cache3_10), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRCAMERAEXTENSIONS_T1293988219_H
#ifndef DEFAULTCAMERAIMAGEAPI_T2442227313_H
#define DEFAULTCAMERAIMAGEAPI_T2442227313_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.ARExtensions.XRCameraExtensions/DefaultCameraImageApi
struct  DefaultCameraImageApi_t2442227313  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEFAULTCAMERAIMAGEAPI_T2442227313_H
#ifndef XRPLANEEXTENSIONS_T1202600805_H
#define XRPLANEEXTENSIONS_T1202600805_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.ARExtensions.XRPlaneExtensions
struct  XRPlaneExtensions_t1202600805  : public RuntimeObject
{
public:

public:
};

struct XRPlaneExtensions_t1202600805_StaticFields
{
public:
	// System.Func`3<UnityEngine.Experimental.XR.XRPlaneSubsystem,UnityEngine.Experimental.XR.TrackableId,UnityEngine.Experimental.XR.TrackingState> UnityEngine.XR.ARExtensions.XRPlaneExtensions::s_GetTrackingStateDelegate
	Func_3_t2921619047 * ___s_GetTrackingStateDelegate_0;
	// System.Collections.Generic.Dictionary`2<System.String,System.Func`3<UnityEngine.Experimental.XR.XRPlaneSubsystem,UnityEngine.Experimental.XR.TrackableId,UnityEngine.Experimental.XR.TrackingState>> UnityEngine.XR.ARExtensions.XRPlaneExtensions::s_GetTrackingStateDelegates
	Dictionary_2_t2706875346 * ___s_GetTrackingStateDelegates_1;
	// System.Func`3<UnityEngine.Experimental.XR.XRPlaneSubsystem,UnityEngine.Experimental.XR.TrackableId,UnityEngine.Experimental.XR.TrackingState> UnityEngine.XR.ARExtensions.XRPlaneExtensions::<>f__mg$cache0
	Func_3_t2921619047 * ___U3CU3Ef__mgU24cache0_2;
	// System.Func`3<UnityEngine.Experimental.XR.XRPlaneSubsystem,UnityEngine.Experimental.XR.TrackableId,UnityEngine.Experimental.XR.TrackingState> UnityEngine.XR.ARExtensions.XRPlaneExtensions::<>f__mg$cache1
	Func_3_t2921619047 * ___U3CU3Ef__mgU24cache1_3;

public:
	inline static int32_t get_offset_of_s_GetTrackingStateDelegate_0() { return static_cast<int32_t>(offsetof(XRPlaneExtensions_t1202600805_StaticFields, ___s_GetTrackingStateDelegate_0)); }
	inline Func_3_t2921619047 * get_s_GetTrackingStateDelegate_0() const { return ___s_GetTrackingStateDelegate_0; }
	inline Func_3_t2921619047 ** get_address_of_s_GetTrackingStateDelegate_0() { return &___s_GetTrackingStateDelegate_0; }
	inline void set_s_GetTrackingStateDelegate_0(Func_3_t2921619047 * value)
	{
		___s_GetTrackingStateDelegate_0 = value;
		Il2CppCodeGenWriteBarrier((&___s_GetTrackingStateDelegate_0), value);
	}

	inline static int32_t get_offset_of_s_GetTrackingStateDelegates_1() { return static_cast<int32_t>(offsetof(XRPlaneExtensions_t1202600805_StaticFields, ___s_GetTrackingStateDelegates_1)); }
	inline Dictionary_2_t2706875346 * get_s_GetTrackingStateDelegates_1() const { return ___s_GetTrackingStateDelegates_1; }
	inline Dictionary_2_t2706875346 ** get_address_of_s_GetTrackingStateDelegates_1() { return &___s_GetTrackingStateDelegates_1; }
	inline void set_s_GetTrackingStateDelegates_1(Dictionary_2_t2706875346 * value)
	{
		___s_GetTrackingStateDelegates_1 = value;
		Il2CppCodeGenWriteBarrier((&___s_GetTrackingStateDelegates_1), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__mgU24cache0_2() { return static_cast<int32_t>(offsetof(XRPlaneExtensions_t1202600805_StaticFields, ___U3CU3Ef__mgU24cache0_2)); }
	inline Func_3_t2921619047 * get_U3CU3Ef__mgU24cache0_2() const { return ___U3CU3Ef__mgU24cache0_2; }
	inline Func_3_t2921619047 ** get_address_of_U3CU3Ef__mgU24cache0_2() { return &___U3CU3Ef__mgU24cache0_2; }
	inline void set_U3CU3Ef__mgU24cache0_2(Func_3_t2921619047 * value)
	{
		___U3CU3Ef__mgU24cache0_2 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__mgU24cache0_2), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__mgU24cache1_3() { return static_cast<int32_t>(offsetof(XRPlaneExtensions_t1202600805_StaticFields, ___U3CU3Ef__mgU24cache1_3)); }
	inline Func_3_t2921619047 * get_U3CU3Ef__mgU24cache1_3() const { return ___U3CU3Ef__mgU24cache1_3; }
	inline Func_3_t2921619047 ** get_address_of_U3CU3Ef__mgU24cache1_3() { return &___U3CU3Ef__mgU24cache1_3; }
	inline void set_U3CU3Ef__mgU24cache1_3(Func_3_t2921619047 * value)
	{
		___U3CU3Ef__mgU24cache1_3 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__mgU24cache1_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRPLANEEXTENSIONS_T1202600805_H
#ifndef XRREFERENCEPOINTEXTENSIONS_T125072412_H
#define XRREFERENCEPOINTEXTENSIONS_T125072412_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.ARExtensions.XRReferencePointExtensions
struct  XRReferencePointExtensions_t125072412  : public RuntimeObject
{
public:

public:
};

struct XRReferencePointExtensions_t125072412_StaticFields
{
public:
	// UnityEngine.XR.ARExtensions.XRReferencePointExtensions/AttachReferencePointDelegate UnityEngine.XR.ARExtensions.XRReferencePointExtensions::s_AttachReferencePointDelegate
	AttachReferencePointDelegate_t418922659 * ___s_AttachReferencePointDelegate_0;
	// System.Collections.Generic.Dictionary`2<System.String,UnityEngine.XR.ARExtensions.XRReferencePointExtensions/AttachReferencePointDelegate> UnityEngine.XR.ARExtensions.XRReferencePointExtensions::s_AttachReferencePointDelegates
	Dictionary_2_t204178958 * ___s_AttachReferencePointDelegates_1;
	// UnityEngine.XR.ARExtensions.XRReferencePointExtensions/AttachReferencePointDelegate UnityEngine.XR.ARExtensions.XRReferencePointExtensions::<>f__mg$cache0
	AttachReferencePointDelegate_t418922659 * ___U3CU3Ef__mgU24cache0_2;
	// UnityEngine.XR.ARExtensions.XRReferencePointExtensions/AttachReferencePointDelegate UnityEngine.XR.ARExtensions.XRReferencePointExtensions::<>f__mg$cache1
	AttachReferencePointDelegate_t418922659 * ___U3CU3Ef__mgU24cache1_3;

public:
	inline static int32_t get_offset_of_s_AttachReferencePointDelegate_0() { return static_cast<int32_t>(offsetof(XRReferencePointExtensions_t125072412_StaticFields, ___s_AttachReferencePointDelegate_0)); }
	inline AttachReferencePointDelegate_t418922659 * get_s_AttachReferencePointDelegate_0() const { return ___s_AttachReferencePointDelegate_0; }
	inline AttachReferencePointDelegate_t418922659 ** get_address_of_s_AttachReferencePointDelegate_0() { return &___s_AttachReferencePointDelegate_0; }
	inline void set_s_AttachReferencePointDelegate_0(AttachReferencePointDelegate_t418922659 * value)
	{
		___s_AttachReferencePointDelegate_0 = value;
		Il2CppCodeGenWriteBarrier((&___s_AttachReferencePointDelegate_0), value);
	}

	inline static int32_t get_offset_of_s_AttachReferencePointDelegates_1() { return static_cast<int32_t>(offsetof(XRReferencePointExtensions_t125072412_StaticFields, ___s_AttachReferencePointDelegates_1)); }
	inline Dictionary_2_t204178958 * get_s_AttachReferencePointDelegates_1() const { return ___s_AttachReferencePointDelegates_1; }
	inline Dictionary_2_t204178958 ** get_address_of_s_AttachReferencePointDelegates_1() { return &___s_AttachReferencePointDelegates_1; }
	inline void set_s_AttachReferencePointDelegates_1(Dictionary_2_t204178958 * value)
	{
		___s_AttachReferencePointDelegates_1 = value;
		Il2CppCodeGenWriteBarrier((&___s_AttachReferencePointDelegates_1), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__mgU24cache0_2() { return static_cast<int32_t>(offsetof(XRReferencePointExtensions_t125072412_StaticFields, ___U3CU3Ef__mgU24cache0_2)); }
	inline AttachReferencePointDelegate_t418922659 * get_U3CU3Ef__mgU24cache0_2() const { return ___U3CU3Ef__mgU24cache0_2; }
	inline AttachReferencePointDelegate_t418922659 ** get_address_of_U3CU3Ef__mgU24cache0_2() { return &___U3CU3Ef__mgU24cache0_2; }
	inline void set_U3CU3Ef__mgU24cache0_2(AttachReferencePointDelegate_t418922659 * value)
	{
		___U3CU3Ef__mgU24cache0_2 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__mgU24cache0_2), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__mgU24cache1_3() { return static_cast<int32_t>(offsetof(XRReferencePointExtensions_t125072412_StaticFields, ___U3CU3Ef__mgU24cache1_3)); }
	inline AttachReferencePointDelegate_t418922659 * get_U3CU3Ef__mgU24cache1_3() const { return ___U3CU3Ef__mgU24cache1_3; }
	inline AttachReferencePointDelegate_t418922659 ** get_address_of_U3CU3Ef__mgU24cache1_3() { return &___U3CU3Ef__mgU24cache1_3; }
	inline void set_U3CU3Ef__mgU24cache1_3(AttachReferencePointDelegate_t418922659 * value)
	{
		___U3CU3Ef__mgU24cache1_3 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__mgU24cache1_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRREFERENCEPOINTEXTENSIONS_T125072412_H
#ifndef XRSESSIONEXTENSIONS_T411788579_H
#define XRSESSIONEXTENSIONS_T411788579_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.ARExtensions.XRSessionExtensions
struct  XRSessionExtensions_t411788579  : public RuntimeObject
{
public:

public:
};

struct XRSessionExtensions_t411788579_StaticFields
{
public:
	// UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionInstallationStatus> UnityEngine.XR.ARExtensions.XRSessionExtensions::s_InstallAsyncDelegate
	AsyncDelegate_1_t972160167 * ___s_InstallAsyncDelegate_0;
	// UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionAvailability> UnityEngine.XR.ARExtensions.XRSessionExtensions::s_GetAvailabilityAsyncDelegate
	AsyncDelegate_1_t3460105404 * ___s_GetAvailabilityAsyncDelegate_1;
	// System.Collections.Generic.Dictionary`2<System.String,UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionInstallationStatus>> UnityEngine.XR.ARExtensions.XRSessionExtensions::s_InstallAsyncDelegates
	Dictionary_2_t757416466 * ___s_InstallAsyncDelegates_2;
	// System.Collections.Generic.Dictionary`2<System.String,UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionAvailability>> UnityEngine.XR.ARExtensions.XRSessionExtensions::s_GetAvailabilityAsyncDelegates
	Dictionary_2_t3245361703 * ___s_GetAvailabilityAsyncDelegates_3;
	// UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionInstallationStatus> UnityEngine.XR.ARExtensions.XRSessionExtensions::<>f__mg$cache0
	AsyncDelegate_1_t972160167 * ___U3CU3Ef__mgU24cache0_4;
	// UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionAvailability> UnityEngine.XR.ARExtensions.XRSessionExtensions::<>f__mg$cache1
	AsyncDelegate_1_t3460105404 * ___U3CU3Ef__mgU24cache1_5;
	// UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionInstallationStatus> UnityEngine.XR.ARExtensions.XRSessionExtensions::<>f__mg$cache2
	AsyncDelegate_1_t972160167 * ___U3CU3Ef__mgU24cache2_6;
	// UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionAvailability> UnityEngine.XR.ARExtensions.XRSessionExtensions::<>f__mg$cache3
	AsyncDelegate_1_t3460105404 * ___U3CU3Ef__mgU24cache3_7;

public:
	inline static int32_t get_offset_of_s_InstallAsyncDelegate_0() { return static_cast<int32_t>(offsetof(XRSessionExtensions_t411788579_StaticFields, ___s_InstallAsyncDelegate_0)); }
	inline AsyncDelegate_1_t972160167 * get_s_InstallAsyncDelegate_0() const { return ___s_InstallAsyncDelegate_0; }
	inline AsyncDelegate_1_t972160167 ** get_address_of_s_InstallAsyncDelegate_0() { return &___s_InstallAsyncDelegate_0; }
	inline void set_s_InstallAsyncDelegate_0(AsyncDelegate_1_t972160167 * value)
	{
		___s_InstallAsyncDelegate_0 = value;
		Il2CppCodeGenWriteBarrier((&___s_InstallAsyncDelegate_0), value);
	}

	inline static int32_t get_offset_of_s_GetAvailabilityAsyncDelegate_1() { return static_cast<int32_t>(offsetof(XRSessionExtensions_t411788579_StaticFields, ___s_GetAvailabilityAsyncDelegate_1)); }
	inline AsyncDelegate_1_t3460105404 * get_s_GetAvailabilityAsyncDelegate_1() const { return ___s_GetAvailabilityAsyncDelegate_1; }
	inline AsyncDelegate_1_t3460105404 ** get_address_of_s_GetAvailabilityAsyncDelegate_1() { return &___s_GetAvailabilityAsyncDelegate_1; }
	inline void set_s_GetAvailabilityAsyncDelegate_1(AsyncDelegate_1_t3460105404 * value)
	{
		___s_GetAvailabilityAsyncDelegate_1 = value;
		Il2CppCodeGenWriteBarrier((&___s_GetAvailabilityAsyncDelegate_1), value);
	}

	inline static int32_t get_offset_of_s_InstallAsyncDelegates_2() { return static_cast<int32_t>(offsetof(XRSessionExtensions_t411788579_StaticFields, ___s_InstallAsyncDelegates_2)); }
	inline Dictionary_2_t757416466 * get_s_InstallAsyncDelegates_2() const { return ___s_InstallAsyncDelegates_2; }
	inline Dictionary_2_t757416466 ** get_address_of_s_InstallAsyncDelegates_2() { return &___s_InstallAsyncDelegates_2; }
	inline void set_s_InstallAsyncDelegates_2(Dictionary_2_t757416466 * value)
	{
		___s_InstallAsyncDelegates_2 = value;
		Il2CppCodeGenWriteBarrier((&___s_InstallAsyncDelegates_2), value);
	}

	inline static int32_t get_offset_of_s_GetAvailabilityAsyncDelegates_3() { return static_cast<int32_t>(offsetof(XRSessionExtensions_t411788579_StaticFields, ___s_GetAvailabilityAsyncDelegates_3)); }
	inline Dictionary_2_t3245361703 * get_s_GetAvailabilityAsyncDelegates_3() const { return ___s_GetAvailabilityAsyncDelegates_3; }
	inline Dictionary_2_t3245361703 ** get_address_of_s_GetAvailabilityAsyncDelegates_3() { return &___s_GetAvailabilityAsyncDelegates_3; }
	inline void set_s_GetAvailabilityAsyncDelegates_3(Dictionary_2_t3245361703 * value)
	{
		___s_GetAvailabilityAsyncDelegates_3 = value;
		Il2CppCodeGenWriteBarrier((&___s_GetAvailabilityAsyncDelegates_3), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__mgU24cache0_4() { return static_cast<int32_t>(offsetof(XRSessionExtensions_t411788579_StaticFields, ___U3CU3Ef__mgU24cache0_4)); }
	inline AsyncDelegate_1_t972160167 * get_U3CU3Ef__mgU24cache0_4() const { return ___U3CU3Ef__mgU24cache0_4; }
	inline AsyncDelegate_1_t972160167 ** get_address_of_U3CU3Ef__mgU24cache0_4() { return &___U3CU3Ef__mgU24cache0_4; }
	inline void set_U3CU3Ef__mgU24cache0_4(AsyncDelegate_1_t972160167 * value)
	{
		___U3CU3Ef__mgU24cache0_4 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__mgU24cache0_4), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__mgU24cache1_5() { return static_cast<int32_t>(offsetof(XRSessionExtensions_t411788579_StaticFields, ___U3CU3Ef__mgU24cache1_5)); }
	inline AsyncDelegate_1_t3460105404 * get_U3CU3Ef__mgU24cache1_5() const { return ___U3CU3Ef__mgU24cache1_5; }
	inline AsyncDelegate_1_t3460105404 ** get_address_of_U3CU3Ef__mgU24cache1_5() { return &___U3CU3Ef__mgU24cache1_5; }
	inline void set_U3CU3Ef__mgU24cache1_5(AsyncDelegate_1_t3460105404 * value)
	{
		___U3CU3Ef__mgU24cache1_5 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__mgU24cache1_5), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__mgU24cache2_6() { return static_cast<int32_t>(offsetof(XRSessionExtensions_t411788579_StaticFields, ___U3CU3Ef__mgU24cache2_6)); }
	inline AsyncDelegate_1_t972160167 * get_U3CU3Ef__mgU24cache2_6() const { return ___U3CU3Ef__mgU24cache2_6; }
	inline AsyncDelegate_1_t972160167 ** get_address_of_U3CU3Ef__mgU24cache2_6() { return &___U3CU3Ef__mgU24cache2_6; }
	inline void set_U3CU3Ef__mgU24cache2_6(AsyncDelegate_1_t972160167 * value)
	{
		___U3CU3Ef__mgU24cache2_6 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__mgU24cache2_6), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__mgU24cache3_7() { return static_cast<int32_t>(offsetof(XRSessionExtensions_t411788579_StaticFields, ___U3CU3Ef__mgU24cache3_7)); }
	inline AsyncDelegate_1_t3460105404 * get_U3CU3Ef__mgU24cache3_7() const { return ___U3CU3Ef__mgU24cache3_7; }
	inline AsyncDelegate_1_t3460105404 ** get_address_of_U3CU3Ef__mgU24cache3_7() { return &___U3CU3Ef__mgU24cache3_7; }
	inline void set_U3CU3Ef__mgU24cache3_7(AsyncDelegate_1_t3460105404 * value)
	{
		___U3CU3Ef__mgU24cache3_7 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__mgU24cache3_7), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRSESSIONEXTENSIONS_T411788579_H
#ifndef BOOLEAN_T97287965_H
#define BOOLEAN_T97287965_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Boolean
struct  Boolean_t97287965 
{
public:
	// System.Boolean System.Boolean::m_value
	bool ___m_value_2;

public:
	inline static int32_t get_offset_of_m_value_2() { return static_cast<int32_t>(offsetof(Boolean_t97287965, ___m_value_2)); }
	inline bool get_m_value_2() const { return ___m_value_2; }
	inline bool* get_address_of_m_value_2() { return &___m_value_2; }
	inline void set_m_value_2(bool value)
	{
		___m_value_2 = value;
	}
};

struct Boolean_t97287965_StaticFields
{
public:
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_0;
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_1;

public:
	inline static int32_t get_offset_of_FalseString_0() { return static_cast<int32_t>(offsetof(Boolean_t97287965_StaticFields, ___FalseString_0)); }
	inline String_t* get_FalseString_0() const { return ___FalseString_0; }
	inline String_t** get_address_of_FalseString_0() { return &___FalseString_0; }
	inline void set_FalseString_0(String_t* value)
	{
		___FalseString_0 = value;
		Il2CppCodeGenWriteBarrier((&___FalseString_0), value);
	}

	inline static int32_t get_offset_of_TrueString_1() { return static_cast<int32_t>(offsetof(Boolean_t97287965_StaticFields, ___TrueString_1)); }
	inline String_t* get_TrueString_1() const { return ___TrueString_1; }
	inline String_t** get_address_of_TrueString_1() { return &___TrueString_1; }
	inline void set_TrueString_1(String_t* value)
	{
		___TrueString_1 = value;
		Il2CppCodeGenWriteBarrier((&___TrueString_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BOOLEAN_T97287965_H
#ifndef DOUBLE_T594665363_H
#define DOUBLE_T594665363_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Double
struct  Double_t594665363 
{
public:
	// System.Double System.Double::m_value
	double ___m_value_13;

public:
	inline static int32_t get_offset_of_m_value_13() { return static_cast<int32_t>(offsetof(Double_t594665363, ___m_value_13)); }
	inline double get_m_value_13() const { return ___m_value_13; }
	inline double* get_address_of_m_value_13() { return &___m_value_13; }
	inline void set_m_value_13(double value)
	{
		___m_value_13 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DOUBLE_T594665363_H
#ifndef ENUM_T4135868527_H
#define ENUM_T4135868527_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Enum
struct  Enum_t4135868527  : public ValueType_t3640485471
{
public:

public:
};

struct Enum_t4135868527_StaticFields
{
public:
	// System.Char[] System.Enum::split_char
	CharU5BU5D_t3528271667* ___split_char_0;

public:
	inline static int32_t get_offset_of_split_char_0() { return static_cast<int32_t>(offsetof(Enum_t4135868527_StaticFields, ___split_char_0)); }
	inline CharU5BU5D_t3528271667* get_split_char_0() const { return ___split_char_0; }
	inline CharU5BU5D_t3528271667** get_address_of_split_char_0() { return &___split_char_0; }
	inline void set_split_char_0(CharU5BU5D_t3528271667* value)
	{
		___split_char_0 = value;
		Il2CppCodeGenWriteBarrier((&___split_char_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t4135868527_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t4135868527_marshaled_com
{
};
#endif // ENUM_T4135868527_H
#ifndef INT32_T2950945753_H
#define INT32_T2950945753_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Int32
struct  Int32_t2950945753 
{
public:
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_2;

public:
	inline static int32_t get_offset_of_m_value_2() { return static_cast<int32_t>(offsetof(Int32_t2950945753, ___m_value_2)); }
	inline int32_t get_m_value_2() const { return ___m_value_2; }
	inline int32_t* get_address_of_m_value_2() { return &___m_value_2; }
	inline void set_m_value_2(int32_t value)
	{
		___m_value_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INT32_T2950945753_H
#ifndef INTPTR_T_H
#define INTPTR_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTPTR_T_H
#ifndef GCHANDLE_T3351438187_H
#define GCHANDLE_T3351438187_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.InteropServices.GCHandle
struct  GCHandle_t3351438187 
{
public:
	// System.Int32 System.Runtime.InteropServices.GCHandle::handle
	int32_t ___handle_0;

public:
	inline static int32_t get_offset_of_handle_0() { return static_cast<int32_t>(offsetof(GCHandle_t3351438187, ___handle_0)); }
	inline int32_t get_handle_0() const { return ___handle_0; }
	inline int32_t* get_address_of_handle_0() { return &___handle_0; }
	inline void set_handle_0(int32_t value)
	{
		___handle_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GCHANDLE_T3351438187_H
#ifndef SYSTEMEXCEPTION_T176217640_H
#define SYSTEMEXCEPTION_T176217640_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.SystemException
struct  SystemException_t176217640  : public Exception_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SYSTEMEXCEPTION_T176217640_H
#ifndef VOID_T1185182177_H
#define VOID_T1185182177_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Void
struct  Void_t1185182177 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VOID_T1185182177_H
#ifndef COLOR_T2555686324_H
#define COLOR_T2555686324_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Color
struct  Color_t2555686324 
{
public:
	// System.Single UnityEngine.Color::r
	float ___r_0;
	// System.Single UnityEngine.Color::g
	float ___g_1;
	// System.Single UnityEngine.Color::b
	float ___b_2;
	// System.Single UnityEngine.Color::a
	float ___a_3;

public:
	inline static int32_t get_offset_of_r_0() { return static_cast<int32_t>(offsetof(Color_t2555686324, ___r_0)); }
	inline float get_r_0() const { return ___r_0; }
	inline float* get_address_of_r_0() { return &___r_0; }
	inline void set_r_0(float value)
	{
		___r_0 = value;
	}

	inline static int32_t get_offset_of_g_1() { return static_cast<int32_t>(offsetof(Color_t2555686324, ___g_1)); }
	inline float get_g_1() const { return ___g_1; }
	inline float* get_address_of_g_1() { return &___g_1; }
	inline void set_g_1(float value)
	{
		___g_1 = value;
	}

	inline static int32_t get_offset_of_b_2() { return static_cast<int32_t>(offsetof(Color_t2555686324, ___b_2)); }
	inline float get_b_2() const { return ___b_2; }
	inline float* get_address_of_b_2() { return &___b_2; }
	inline void set_b_2(float value)
	{
		___b_2 = value;
	}

	inline static int32_t get_offset_of_a_3() { return static_cast<int32_t>(offsetof(Color_t2555686324, ___a_3)); }
	inline float get_a_3() const { return ___a_3; }
	inline float* get_address_of_a_3() { return &___a_3; }
	inline void set_a_3(float value)
	{
		___a_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COLOR_T2555686324_H
#ifndef TRACKABLEID_T1251031970_H
#define TRACKABLEID_T1251031970_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.TrackableId
struct  TrackableId_t1251031970 
{
public:
	// System.UInt64 UnityEngine.Experimental.XR.TrackableId::m_SubId1
	uint64_t ___m_SubId1_1;
	// System.UInt64 UnityEngine.Experimental.XR.TrackableId::m_SubId2
	uint64_t ___m_SubId2_2;

public:
	inline static int32_t get_offset_of_m_SubId1_1() { return static_cast<int32_t>(offsetof(TrackableId_t1251031970, ___m_SubId1_1)); }
	inline uint64_t get_m_SubId1_1() const { return ___m_SubId1_1; }
	inline uint64_t* get_address_of_m_SubId1_1() { return &___m_SubId1_1; }
	inline void set_m_SubId1_1(uint64_t value)
	{
		___m_SubId1_1 = value;
	}

	inline static int32_t get_offset_of_m_SubId2_2() { return static_cast<int32_t>(offsetof(TrackableId_t1251031970, ___m_SubId2_2)); }
	inline uint64_t get_m_SubId2_2() const { return ___m_SubId2_2; }
	inline uint64_t* get_address_of_m_SubId2_2() { return &___m_SubId2_2; }
	inline void set_m_SubId2_2(uint64_t value)
	{
		___m_SubId2_2 = value;
	}
};

struct TrackableId_t1251031970_StaticFields
{
public:
	// UnityEngine.Experimental.XR.TrackableId UnityEngine.Experimental.XR.TrackableId::s_InvalidId
	TrackableId_t1251031970  ___s_InvalidId_0;

public:
	inline static int32_t get_offset_of_s_InvalidId_0() { return static_cast<int32_t>(offsetof(TrackableId_t1251031970_StaticFields, ___s_InvalidId_0)); }
	inline TrackableId_t1251031970  get_s_InvalidId_0() const { return ___s_InvalidId_0; }
	inline TrackableId_t1251031970 * get_address_of_s_InvalidId_0() { return &___s_InvalidId_0; }
	inline void set_s_InvalidId_0(TrackableId_t1251031970  value)
	{
		___s_InvalidId_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TRACKABLEID_T1251031970_H
#ifndef QUATERNION_T2301928331_H
#define QUATERNION_T2301928331_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Quaternion
struct  Quaternion_t2301928331 
{
public:
	// System.Single UnityEngine.Quaternion::x
	float ___x_0;
	// System.Single UnityEngine.Quaternion::y
	float ___y_1;
	// System.Single UnityEngine.Quaternion::z
	float ___z_2;
	// System.Single UnityEngine.Quaternion::w
	float ___w_3;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(Quaternion_t2301928331, ___x_0)); }
	inline float get_x_0() const { return ___x_0; }
	inline float* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(float value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(Quaternion_t2301928331, ___y_1)); }
	inline float get_y_1() const { return ___y_1; }
	inline float* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(float value)
	{
		___y_1 = value;
	}

	inline static int32_t get_offset_of_z_2() { return static_cast<int32_t>(offsetof(Quaternion_t2301928331, ___z_2)); }
	inline float get_z_2() const { return ___z_2; }
	inline float* get_address_of_z_2() { return &___z_2; }
	inline void set_z_2(float value)
	{
		___z_2 = value;
	}

	inline static int32_t get_offset_of_w_3() { return static_cast<int32_t>(offsetof(Quaternion_t2301928331, ___w_3)); }
	inline float get_w_3() const { return ___w_3; }
	inline float* get_address_of_w_3() { return &___w_3; }
	inline void set_w_3(float value)
	{
		___w_3 = value;
	}
};

struct Quaternion_t2301928331_StaticFields
{
public:
	// UnityEngine.Quaternion UnityEngine.Quaternion::identityQuaternion
	Quaternion_t2301928331  ___identityQuaternion_4;

public:
	inline static int32_t get_offset_of_identityQuaternion_4() { return static_cast<int32_t>(offsetof(Quaternion_t2301928331_StaticFields, ___identityQuaternion_4)); }
	inline Quaternion_t2301928331  get_identityQuaternion_4() const { return ___identityQuaternion_4; }
	inline Quaternion_t2301928331 * get_address_of_identityQuaternion_4() { return &___identityQuaternion_4; }
	inline void set_identityQuaternion_4(Quaternion_t2301928331  value)
	{
		___identityQuaternion_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // QUATERNION_T2301928331_H
#ifndef RECTINT_T1875739471_H
#define RECTINT_T1875739471_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.RectInt
struct  RectInt_t1875739471 
{
public:
	// System.Int32 UnityEngine.RectInt::m_XMin
	int32_t ___m_XMin_0;
	// System.Int32 UnityEngine.RectInt::m_YMin
	int32_t ___m_YMin_1;
	// System.Int32 UnityEngine.RectInt::m_Width
	int32_t ___m_Width_2;
	// System.Int32 UnityEngine.RectInt::m_Height
	int32_t ___m_Height_3;

public:
	inline static int32_t get_offset_of_m_XMin_0() { return static_cast<int32_t>(offsetof(RectInt_t1875739471, ___m_XMin_0)); }
	inline int32_t get_m_XMin_0() const { return ___m_XMin_0; }
	inline int32_t* get_address_of_m_XMin_0() { return &___m_XMin_0; }
	inline void set_m_XMin_0(int32_t value)
	{
		___m_XMin_0 = value;
	}

	inline static int32_t get_offset_of_m_YMin_1() { return static_cast<int32_t>(offsetof(RectInt_t1875739471, ___m_YMin_1)); }
	inline int32_t get_m_YMin_1() const { return ___m_YMin_1; }
	inline int32_t* get_address_of_m_YMin_1() { return &___m_YMin_1; }
	inline void set_m_YMin_1(int32_t value)
	{
		___m_YMin_1 = value;
	}

	inline static int32_t get_offset_of_m_Width_2() { return static_cast<int32_t>(offsetof(RectInt_t1875739471, ___m_Width_2)); }
	inline int32_t get_m_Width_2() const { return ___m_Width_2; }
	inline int32_t* get_address_of_m_Width_2() { return &___m_Width_2; }
	inline void set_m_Width_2(int32_t value)
	{
		___m_Width_2 = value;
	}

	inline static int32_t get_offset_of_m_Height_3() { return static_cast<int32_t>(offsetof(RectInt_t1875739471, ___m_Height_3)); }
	inline int32_t get_m_Height_3() const { return ___m_Height_3; }
	inline int32_t* get_address_of_m_Height_3() { return &___m_Height_3; }
	inline void set_m_Height_3(int32_t value)
	{
		___m_Height_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RECTINT_T1875739471_H
#ifndef VECTOR2INT_T3469998543_H
#define VECTOR2INT_T3469998543_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Vector2Int
struct  Vector2Int_t3469998543 
{
public:
	// System.Int32 UnityEngine.Vector2Int::m_X
	int32_t ___m_X_0;
	// System.Int32 UnityEngine.Vector2Int::m_Y
	int32_t ___m_Y_1;

public:
	inline static int32_t get_offset_of_m_X_0() { return static_cast<int32_t>(offsetof(Vector2Int_t3469998543, ___m_X_0)); }
	inline int32_t get_m_X_0() const { return ___m_X_0; }
	inline int32_t* get_address_of_m_X_0() { return &___m_X_0; }
	inline void set_m_X_0(int32_t value)
	{
		___m_X_0 = value;
	}

	inline static int32_t get_offset_of_m_Y_1() { return static_cast<int32_t>(offsetof(Vector2Int_t3469998543, ___m_Y_1)); }
	inline int32_t get_m_Y_1() const { return ___m_Y_1; }
	inline int32_t* get_address_of_m_Y_1() { return &___m_Y_1; }
	inline void set_m_Y_1(int32_t value)
	{
		___m_Y_1 = value;
	}
};

struct Vector2Int_t3469998543_StaticFields
{
public:
	// UnityEngine.Vector2Int UnityEngine.Vector2Int::s_Zero
	Vector2Int_t3469998543  ___s_Zero_2;
	// UnityEngine.Vector2Int UnityEngine.Vector2Int::s_One
	Vector2Int_t3469998543  ___s_One_3;
	// UnityEngine.Vector2Int UnityEngine.Vector2Int::s_Up
	Vector2Int_t3469998543  ___s_Up_4;
	// UnityEngine.Vector2Int UnityEngine.Vector2Int::s_Down
	Vector2Int_t3469998543  ___s_Down_5;
	// UnityEngine.Vector2Int UnityEngine.Vector2Int::s_Left
	Vector2Int_t3469998543  ___s_Left_6;
	// UnityEngine.Vector2Int UnityEngine.Vector2Int::s_Right
	Vector2Int_t3469998543  ___s_Right_7;

public:
	inline static int32_t get_offset_of_s_Zero_2() { return static_cast<int32_t>(offsetof(Vector2Int_t3469998543_StaticFields, ___s_Zero_2)); }
	inline Vector2Int_t3469998543  get_s_Zero_2() const { return ___s_Zero_2; }
	inline Vector2Int_t3469998543 * get_address_of_s_Zero_2() { return &___s_Zero_2; }
	inline void set_s_Zero_2(Vector2Int_t3469998543  value)
	{
		___s_Zero_2 = value;
	}

	inline static int32_t get_offset_of_s_One_3() { return static_cast<int32_t>(offsetof(Vector2Int_t3469998543_StaticFields, ___s_One_3)); }
	inline Vector2Int_t3469998543  get_s_One_3() const { return ___s_One_3; }
	inline Vector2Int_t3469998543 * get_address_of_s_One_3() { return &___s_One_3; }
	inline void set_s_One_3(Vector2Int_t3469998543  value)
	{
		___s_One_3 = value;
	}

	inline static int32_t get_offset_of_s_Up_4() { return static_cast<int32_t>(offsetof(Vector2Int_t3469998543_StaticFields, ___s_Up_4)); }
	inline Vector2Int_t3469998543  get_s_Up_4() const { return ___s_Up_4; }
	inline Vector2Int_t3469998543 * get_address_of_s_Up_4() { return &___s_Up_4; }
	inline void set_s_Up_4(Vector2Int_t3469998543  value)
	{
		___s_Up_4 = value;
	}

	inline static int32_t get_offset_of_s_Down_5() { return static_cast<int32_t>(offsetof(Vector2Int_t3469998543_StaticFields, ___s_Down_5)); }
	inline Vector2Int_t3469998543  get_s_Down_5() const { return ___s_Down_5; }
	inline Vector2Int_t3469998543 * get_address_of_s_Down_5() { return &___s_Down_5; }
	inline void set_s_Down_5(Vector2Int_t3469998543  value)
	{
		___s_Down_5 = value;
	}

	inline static int32_t get_offset_of_s_Left_6() { return static_cast<int32_t>(offsetof(Vector2Int_t3469998543_StaticFields, ___s_Left_6)); }
	inline Vector2Int_t3469998543  get_s_Left_6() const { return ___s_Left_6; }
	inline Vector2Int_t3469998543 * get_address_of_s_Left_6() { return &___s_Left_6; }
	inline void set_s_Left_6(Vector2Int_t3469998543  value)
	{
		___s_Left_6 = value;
	}

	inline static int32_t get_offset_of_s_Right_7() { return static_cast<int32_t>(offsetof(Vector2Int_t3469998543_StaticFields, ___s_Right_7)); }
	inline Vector2Int_t3469998543  get_s_Right_7() const { return ___s_Right_7; }
	inline Vector2Int_t3469998543 * get_address_of_s_Right_7() { return &___s_Right_7; }
	inline void set_s_Right_7(Vector2Int_t3469998543  value)
	{
		___s_Right_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VECTOR2INT_T3469998543_H
#ifndef VECTOR3_T3722313464_H
#define VECTOR3_T3722313464_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Vector3
struct  Vector3_t3722313464 
{
public:
	// System.Single UnityEngine.Vector3::x
	float ___x_2;
	// System.Single UnityEngine.Vector3::y
	float ___y_3;
	// System.Single UnityEngine.Vector3::z
	float ___z_4;

public:
	inline static int32_t get_offset_of_x_2() { return static_cast<int32_t>(offsetof(Vector3_t3722313464, ___x_2)); }
	inline float get_x_2() const { return ___x_2; }
	inline float* get_address_of_x_2() { return &___x_2; }
	inline void set_x_2(float value)
	{
		___x_2 = value;
	}

	inline static int32_t get_offset_of_y_3() { return static_cast<int32_t>(offsetof(Vector3_t3722313464, ___y_3)); }
	inline float get_y_3() const { return ___y_3; }
	inline float* get_address_of_y_3() { return &___y_3; }
	inline void set_y_3(float value)
	{
		___y_3 = value;
	}

	inline static int32_t get_offset_of_z_4() { return static_cast<int32_t>(offsetof(Vector3_t3722313464, ___z_4)); }
	inline float get_z_4() const { return ___z_4; }
	inline float* get_address_of_z_4() { return &___z_4; }
	inline void set_z_4(float value)
	{
		___z_4 = value;
	}
};

struct Vector3_t3722313464_StaticFields
{
public:
	// UnityEngine.Vector3 UnityEngine.Vector3::zeroVector
	Vector3_t3722313464  ___zeroVector_5;
	// UnityEngine.Vector3 UnityEngine.Vector3::oneVector
	Vector3_t3722313464  ___oneVector_6;
	// UnityEngine.Vector3 UnityEngine.Vector3::upVector
	Vector3_t3722313464  ___upVector_7;
	// UnityEngine.Vector3 UnityEngine.Vector3::downVector
	Vector3_t3722313464  ___downVector_8;
	// UnityEngine.Vector3 UnityEngine.Vector3::leftVector
	Vector3_t3722313464  ___leftVector_9;
	// UnityEngine.Vector3 UnityEngine.Vector3::rightVector
	Vector3_t3722313464  ___rightVector_10;
	// UnityEngine.Vector3 UnityEngine.Vector3::forwardVector
	Vector3_t3722313464  ___forwardVector_11;
	// UnityEngine.Vector3 UnityEngine.Vector3::backVector
	Vector3_t3722313464  ___backVector_12;
	// UnityEngine.Vector3 UnityEngine.Vector3::positiveInfinityVector
	Vector3_t3722313464  ___positiveInfinityVector_13;
	// UnityEngine.Vector3 UnityEngine.Vector3::negativeInfinityVector
	Vector3_t3722313464  ___negativeInfinityVector_14;

public:
	inline static int32_t get_offset_of_zeroVector_5() { return static_cast<int32_t>(offsetof(Vector3_t3722313464_StaticFields, ___zeroVector_5)); }
	inline Vector3_t3722313464  get_zeroVector_5() const { return ___zeroVector_5; }
	inline Vector3_t3722313464 * get_address_of_zeroVector_5() { return &___zeroVector_5; }
	inline void set_zeroVector_5(Vector3_t3722313464  value)
	{
		___zeroVector_5 = value;
	}

	inline static int32_t get_offset_of_oneVector_6() { return static_cast<int32_t>(offsetof(Vector3_t3722313464_StaticFields, ___oneVector_6)); }
	inline Vector3_t3722313464  get_oneVector_6() const { return ___oneVector_6; }
	inline Vector3_t3722313464 * get_address_of_oneVector_6() { return &___oneVector_6; }
	inline void set_oneVector_6(Vector3_t3722313464  value)
	{
		___oneVector_6 = value;
	}

	inline static int32_t get_offset_of_upVector_7() { return static_cast<int32_t>(offsetof(Vector3_t3722313464_StaticFields, ___upVector_7)); }
	inline Vector3_t3722313464  get_upVector_7() const { return ___upVector_7; }
	inline Vector3_t3722313464 * get_address_of_upVector_7() { return &___upVector_7; }
	inline void set_upVector_7(Vector3_t3722313464  value)
	{
		___upVector_7 = value;
	}

	inline static int32_t get_offset_of_downVector_8() { return static_cast<int32_t>(offsetof(Vector3_t3722313464_StaticFields, ___downVector_8)); }
	inline Vector3_t3722313464  get_downVector_8() const { return ___downVector_8; }
	inline Vector3_t3722313464 * get_address_of_downVector_8() { return &___downVector_8; }
	inline void set_downVector_8(Vector3_t3722313464  value)
	{
		___downVector_8 = value;
	}

	inline static int32_t get_offset_of_leftVector_9() { return static_cast<int32_t>(offsetof(Vector3_t3722313464_StaticFields, ___leftVector_9)); }
	inline Vector3_t3722313464  get_leftVector_9() const { return ___leftVector_9; }
	inline Vector3_t3722313464 * get_address_of_leftVector_9() { return &___leftVector_9; }
	inline void set_leftVector_9(Vector3_t3722313464  value)
	{
		___leftVector_9 = value;
	}

	inline static int32_t get_offset_of_rightVector_10() { return static_cast<int32_t>(offsetof(Vector3_t3722313464_StaticFields, ___rightVector_10)); }
	inline Vector3_t3722313464  get_rightVector_10() const { return ___rightVector_10; }
	inline Vector3_t3722313464 * get_address_of_rightVector_10() { return &___rightVector_10; }
	inline void set_rightVector_10(Vector3_t3722313464  value)
	{
		___rightVector_10 = value;
	}

	inline static int32_t get_offset_of_forwardVector_11() { return static_cast<int32_t>(offsetof(Vector3_t3722313464_StaticFields, ___forwardVector_11)); }
	inline Vector3_t3722313464  get_forwardVector_11() const { return ___forwardVector_11; }
	inline Vector3_t3722313464 * get_address_of_forwardVector_11() { return &___forwardVector_11; }
	inline void set_forwardVector_11(Vector3_t3722313464  value)
	{
		___forwardVector_11 = value;
	}

	inline static int32_t get_offset_of_backVector_12() { return static_cast<int32_t>(offsetof(Vector3_t3722313464_StaticFields, ___backVector_12)); }
	inline Vector3_t3722313464  get_backVector_12() const { return ___backVector_12; }
	inline Vector3_t3722313464 * get_address_of_backVector_12() { return &___backVector_12; }
	inline void set_backVector_12(Vector3_t3722313464  value)
	{
		___backVector_12 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_13() { return static_cast<int32_t>(offsetof(Vector3_t3722313464_StaticFields, ___positiveInfinityVector_13)); }
	inline Vector3_t3722313464  get_positiveInfinityVector_13() const { return ___positiveInfinityVector_13; }
	inline Vector3_t3722313464 * get_address_of_positiveInfinityVector_13() { return &___positiveInfinityVector_13; }
	inline void set_positiveInfinityVector_13(Vector3_t3722313464  value)
	{
		___positiveInfinityVector_13 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_14() { return static_cast<int32_t>(offsetof(Vector3_t3722313464_StaticFields, ___negativeInfinityVector_14)); }
	inline Vector3_t3722313464  get_negativeInfinityVector_14() const { return ___negativeInfinityVector_14; }
	inline Vector3_t3722313464 * get_address_of_negativeInfinityVector_14() { return &___negativeInfinityVector_14; }
	inline void set_negativeInfinityVector_14(Vector3_t3722313464  value)
	{
		___negativeInfinityVector_14 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VECTOR3_T3722313464_H
#ifndef ARGUMENTEXCEPTION_T132251570_H
#define ARGUMENTEXCEPTION_T132251570_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ArgumentException
struct  ArgumentException_t132251570  : public SystemException_t176217640
{
public:
	// System.String System.ArgumentException::param_name
	String_t* ___param_name_12;

public:
	inline static int32_t get_offset_of_param_name_12() { return static_cast<int32_t>(offsetof(ArgumentException_t132251570, ___param_name_12)); }
	inline String_t* get_param_name_12() const { return ___param_name_12; }
	inline String_t** get_address_of_param_name_12() { return &___param_name_12; }
	inline void set_param_name_12(String_t* value)
	{
		___param_name_12 = value;
		Il2CppCodeGenWriteBarrier((&___param_name_12), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ARGUMENTEXCEPTION_T132251570_H
#ifndef DELEGATE_T1188392813_H
#define DELEGATE_T1188392813_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Delegate
struct  Delegate_t1188392813  : public RuntimeObject
{
public:
	// System.IntPtr System.Delegate::method_ptr
	Il2CppMethodPointer ___method_ptr_0;
	// System.IntPtr System.Delegate::invoke_impl
	intptr_t ___invoke_impl_1;
	// System.Object System.Delegate::m_target
	RuntimeObject * ___m_target_2;
	// System.IntPtr System.Delegate::method
	intptr_t ___method_3;
	// System.IntPtr System.Delegate::delegate_trampoline
	intptr_t ___delegate_trampoline_4;
	// System.IntPtr System.Delegate::method_code
	intptr_t ___method_code_5;
	// System.Reflection.MethodInfo System.Delegate::method_info
	MethodInfo_t * ___method_info_6;
	// System.Reflection.MethodInfo System.Delegate::original_method_info
	MethodInfo_t * ___original_method_info_7;
	// System.DelegateData System.Delegate::data
	DelegateData_t1677132599 * ___data_8;

public:
	inline static int32_t get_offset_of_method_ptr_0() { return static_cast<int32_t>(offsetof(Delegate_t1188392813, ___method_ptr_0)); }
	inline Il2CppMethodPointer get_method_ptr_0() const { return ___method_ptr_0; }
	inline Il2CppMethodPointer* get_address_of_method_ptr_0() { return &___method_ptr_0; }
	inline void set_method_ptr_0(Il2CppMethodPointer value)
	{
		___method_ptr_0 = value;
	}

	inline static int32_t get_offset_of_invoke_impl_1() { return static_cast<int32_t>(offsetof(Delegate_t1188392813, ___invoke_impl_1)); }
	inline intptr_t get_invoke_impl_1() const { return ___invoke_impl_1; }
	inline intptr_t* get_address_of_invoke_impl_1() { return &___invoke_impl_1; }
	inline void set_invoke_impl_1(intptr_t value)
	{
		___invoke_impl_1 = value;
	}

	inline static int32_t get_offset_of_m_target_2() { return static_cast<int32_t>(offsetof(Delegate_t1188392813, ___m_target_2)); }
	inline RuntimeObject * get_m_target_2() const { return ___m_target_2; }
	inline RuntimeObject ** get_address_of_m_target_2() { return &___m_target_2; }
	inline void set_m_target_2(RuntimeObject * value)
	{
		___m_target_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_target_2), value);
	}

	inline static int32_t get_offset_of_method_3() { return static_cast<int32_t>(offsetof(Delegate_t1188392813, ___method_3)); }
	inline intptr_t get_method_3() const { return ___method_3; }
	inline intptr_t* get_address_of_method_3() { return &___method_3; }
	inline void set_method_3(intptr_t value)
	{
		___method_3 = value;
	}

	inline static int32_t get_offset_of_delegate_trampoline_4() { return static_cast<int32_t>(offsetof(Delegate_t1188392813, ___delegate_trampoline_4)); }
	inline intptr_t get_delegate_trampoline_4() const { return ___delegate_trampoline_4; }
	inline intptr_t* get_address_of_delegate_trampoline_4() { return &___delegate_trampoline_4; }
	inline void set_delegate_trampoline_4(intptr_t value)
	{
		___delegate_trampoline_4 = value;
	}

	inline static int32_t get_offset_of_method_code_5() { return static_cast<int32_t>(offsetof(Delegate_t1188392813, ___method_code_5)); }
	inline intptr_t get_method_code_5() const { return ___method_code_5; }
	inline intptr_t* get_address_of_method_code_5() { return &___method_code_5; }
	inline void set_method_code_5(intptr_t value)
	{
		___method_code_5 = value;
	}

	inline static int32_t get_offset_of_method_info_6() { return static_cast<int32_t>(offsetof(Delegate_t1188392813, ___method_info_6)); }
	inline MethodInfo_t * get_method_info_6() const { return ___method_info_6; }
	inline MethodInfo_t ** get_address_of_method_info_6() { return &___method_info_6; }
	inline void set_method_info_6(MethodInfo_t * value)
	{
		___method_info_6 = value;
		Il2CppCodeGenWriteBarrier((&___method_info_6), value);
	}

	inline static int32_t get_offset_of_original_method_info_7() { return static_cast<int32_t>(offsetof(Delegate_t1188392813, ___original_method_info_7)); }
	inline MethodInfo_t * get_original_method_info_7() const { return ___original_method_info_7; }
	inline MethodInfo_t ** get_address_of_original_method_info_7() { return &___original_method_info_7; }
	inline void set_original_method_info_7(MethodInfo_t * value)
	{
		___original_method_info_7 = value;
		Il2CppCodeGenWriteBarrier((&___original_method_info_7), value);
	}

	inline static int32_t get_offset_of_data_8() { return static_cast<int32_t>(offsetof(Delegate_t1188392813, ___data_8)); }
	inline DelegateData_t1677132599 * get_data_8() const { return ___data_8; }
	inline DelegateData_t1677132599 ** get_address_of_data_8() { return &___data_8; }
	inline void set_data_8(DelegateData_t1677132599 * value)
	{
		___data_8 = value;
		Il2CppCodeGenWriteBarrier((&___data_8), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DELEGATE_T1188392813_H
#ifndef INVALIDOPERATIONEXCEPTION_T56020091_H
#define INVALIDOPERATIONEXCEPTION_T56020091_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.InvalidOperationException
struct  InvalidOperationException_t56020091  : public SystemException_t176217640
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INVALIDOPERATIONEXCEPTION_T56020091_H
#ifndef ALLOCATOR_T2786602303_H
#define ALLOCATOR_T2786602303_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Unity.Collections.Allocator
struct  Allocator_t2786602303 
{
public:
	// System.Int32 Unity.Collections.Allocator::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(Allocator_t2786602303, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ALLOCATOR_T2786602303_H
#ifndef SUBSYSTEM_T89723475_H
#define SUBSYSTEM_T89723475_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.Subsystem
struct  Subsystem_t89723475  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Experimental.Subsystem::m_Ptr
	intptr_t ___m_Ptr_0;
	// UnityEngine.Experimental.ISubsystemDescriptor UnityEngine.Experimental.Subsystem::m_subsystemDescriptor
	RuntimeObject* ___m_subsystemDescriptor_1;

public:
	inline static int32_t get_offset_of_m_Ptr_0() { return static_cast<int32_t>(offsetof(Subsystem_t89723475, ___m_Ptr_0)); }
	inline intptr_t get_m_Ptr_0() const { return ___m_Ptr_0; }
	inline intptr_t* get_address_of_m_Ptr_0() { return &___m_Ptr_0; }
	inline void set_m_Ptr_0(intptr_t value)
	{
		___m_Ptr_0 = value;
	}

	inline static int32_t get_offset_of_m_subsystemDescriptor_1() { return static_cast<int32_t>(offsetof(Subsystem_t89723475, ___m_subsystemDescriptor_1)); }
	inline RuntimeObject* get_m_subsystemDescriptor_1() const { return ___m_subsystemDescriptor_1; }
	inline RuntimeObject** get_address_of_m_subsystemDescriptor_1() { return &___m_subsystemDescriptor_1; }
	inline void set_m_subsystemDescriptor_1(RuntimeObject* value)
	{
		___m_subsystemDescriptor_1 = value;
		Il2CppCodeGenWriteBarrier((&___m_subsystemDescriptor_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Experimental.Subsystem
struct Subsystem_t89723475_marshaled_pinvoke
{
	intptr_t ___m_Ptr_0;
	RuntimeObject* ___m_subsystemDescriptor_1;
};
// Native definition for COM marshalling of UnityEngine.Experimental.Subsystem
struct Subsystem_t89723475_marshaled_com
{
	intptr_t ___m_Ptr_0;
	RuntimeObject* ___m_subsystemDescriptor_1;
};
#endif // SUBSYSTEM_T89723475_H
#ifndef SUBSYSTEMDESCRIPTORBASE_T2374447182_H
#define SUBSYSTEMDESCRIPTORBASE_T2374447182_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.SubsystemDescriptorBase
struct  SubsystemDescriptorBase_t2374447182  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Experimental.SubsystemDescriptorBase::m_Ptr
	intptr_t ___m_Ptr_0;

public:
	inline static int32_t get_offset_of_m_Ptr_0() { return static_cast<int32_t>(offsetof(SubsystemDescriptorBase_t2374447182, ___m_Ptr_0)); }
	inline intptr_t get_m_Ptr_0() const { return ___m_Ptr_0; }
	inline intptr_t* get_address_of_m_Ptr_0() { return &___m_Ptr_0; }
	inline void set_m_Ptr_0(intptr_t value)
	{
		___m_Ptr_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Experimental.SubsystemDescriptorBase
struct SubsystemDescriptorBase_t2374447182_marshaled_pinvoke
{
	intptr_t ___m_Ptr_0;
};
// Native definition for COM marshalling of UnityEngine.Experimental.SubsystemDescriptorBase
struct SubsystemDescriptorBase_t2374447182_marshaled_com
{
	intptr_t ___m_Ptr_0;
};
#endif // SUBSYSTEMDESCRIPTORBASE_T2374447182_H
#ifndef TRACKINGSTATE_T1935085052_H
#define TRACKINGSTATE_T1935085052_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.TrackingState
struct  TrackingState_t1935085052 
{
public:
	// System.Int32 UnityEngine.Experimental.XR.TrackingState::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(TrackingState_t1935085052, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TRACKINGSTATE_T1935085052_H
#ifndef POSE_T545244865_H
#define POSE_T545244865_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Pose
struct  Pose_t545244865 
{
public:
	// UnityEngine.Vector3 UnityEngine.Pose::position
	Vector3_t3722313464  ___position_0;
	// UnityEngine.Quaternion UnityEngine.Pose::rotation
	Quaternion_t2301928331  ___rotation_1;

public:
	inline static int32_t get_offset_of_position_0() { return static_cast<int32_t>(offsetof(Pose_t545244865, ___position_0)); }
	inline Vector3_t3722313464  get_position_0() const { return ___position_0; }
	inline Vector3_t3722313464 * get_address_of_position_0() { return &___position_0; }
	inline void set_position_0(Vector3_t3722313464  value)
	{
		___position_0 = value;
	}

	inline static int32_t get_offset_of_rotation_1() { return static_cast<int32_t>(offsetof(Pose_t545244865, ___rotation_1)); }
	inline Quaternion_t2301928331  get_rotation_1() const { return ___rotation_1; }
	inline Quaternion_t2301928331 * get_address_of_rotation_1() { return &___rotation_1; }
	inline void set_rotation_1(Quaternion_t2301928331  value)
	{
		___rotation_1 = value;
	}
};

struct Pose_t545244865_StaticFields
{
public:
	// UnityEngine.Pose UnityEngine.Pose::k_Identity
	Pose_t545244865  ___k_Identity_2;

public:
	inline static int32_t get_offset_of_k_Identity_2() { return static_cast<int32_t>(offsetof(Pose_t545244865_StaticFields, ___k_Identity_2)); }
	inline Pose_t545244865  get_k_Identity_2() const { return ___k_Identity_2; }
	inline Pose_t545244865 * get_address_of_k_Identity_2() { return &___k_Identity_2; }
	inline void set_k_Identity_2(Pose_t545244865  value)
	{
		___k_Identity_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSE_T545244865_H
#ifndef TEXTUREFORMAT_T2701165832_H
#define TEXTUREFORMAT_T2701165832_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.TextureFormat
struct  TextureFormat_t2701165832 
{
public:
	// System.Int32 UnityEngine.TextureFormat::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(TextureFormat_t2701165832, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TEXTUREFORMAT_T2701165832_H
#ifndef ASYNCCAMERAIMAGECONVERSIONSTATUS_T11558803_H
#define ASYNCCAMERAIMAGECONVERSIONSTATUS_T11558803_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.ARExtensions.AsyncCameraImageConversionStatus
struct  AsyncCameraImageConversionStatus_t11558803 
{
public:
	// System.Int32 UnityEngine.XR.ARExtensions.AsyncCameraImageConversionStatus::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(AsyncCameraImageConversionStatus_t11558803, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ASYNCCAMERAIMAGECONVERSIONSTATUS_T11558803_H
#ifndef CAMERAIMAGEFORMAT_T1966699832_H
#define CAMERAIMAGEFORMAT_T1966699832_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.ARExtensions.CameraImageFormat
struct  CameraImageFormat_t1966699832 
{
public:
	// System.Int32 UnityEngine.XR.ARExtensions.CameraImageFormat::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(CameraImageFormat_t1966699832, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CAMERAIMAGEFORMAT_T1966699832_H
#ifndef CAMERAIMAGETRANSFORMATION_T164605461_H
#define CAMERAIMAGETRANSFORMATION_T164605461_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.ARExtensions.CameraImageTransformation
struct  CameraImageTransformation_t164605461 
{
public:
	// System.Int32 UnityEngine.XR.ARExtensions.CameraImageTransformation::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(CameraImageTransformation_t164605461, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CAMERAIMAGETRANSFORMATION_T164605461_H
#ifndef SESSIONAVAILABILITY_T4252731961_H
#define SESSIONAVAILABILITY_T4252731961_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.ARExtensions.SessionAvailability
struct  SessionAvailability_t4252731961 
{
public:
	// System.Int32 UnityEngine.XR.ARExtensions.SessionAvailability::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(SessionAvailability_t4252731961, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SESSIONAVAILABILITY_T4252731961_H
#ifndef SESSIONINSTALLATIONSTATUS_T1764786724_H
#define SESSIONINSTALLATIONSTATUS_T1764786724_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.ARExtensions.SessionInstallationStatus
struct  SessionInstallationStatus_t1764786724 
{
public:
	// System.Int32 UnityEngine.XR.ARExtensions.SessionInstallationStatus::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(SessionInstallationStatus_t1764786724, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SESSIONINSTALLATIONSTATUS_T1764786724_H
#ifndef ARGUMENTNULLEXCEPTION_T1615371798_H
#define ARGUMENTNULLEXCEPTION_T1615371798_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ArgumentNullException
struct  ArgumentNullException_t1615371798  : public ArgumentException_t132251570
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ARGUMENTNULLEXCEPTION_T1615371798_H
#ifndef ARGUMENTOUTOFRANGEEXCEPTION_T777629997_H
#define ARGUMENTOUTOFRANGEEXCEPTION_T777629997_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ArgumentOutOfRangeException
struct  ArgumentOutOfRangeException_t777629997  : public ArgumentException_t132251570
{
public:
	// System.Object System.ArgumentOutOfRangeException::actual_value
	RuntimeObject * ___actual_value_13;

public:
	inline static int32_t get_offset_of_actual_value_13() { return static_cast<int32_t>(offsetof(ArgumentOutOfRangeException_t777629997, ___actual_value_13)); }
	inline RuntimeObject * get_actual_value_13() const { return ___actual_value_13; }
	inline RuntimeObject ** get_address_of_actual_value_13() { return &___actual_value_13; }
	inline void set_actual_value_13(RuntimeObject * value)
	{
		___actual_value_13 = value;
		Il2CppCodeGenWriteBarrier((&___actual_value_13), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ARGUMENTOUTOFRANGEEXCEPTION_T777629997_H
#ifndef MULTICASTDELEGATE_T_H
#define MULTICASTDELEGATE_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.MulticastDelegate
struct  MulticastDelegate_t  : public Delegate_t1188392813
{
public:
	// System.MulticastDelegate System.MulticastDelegate::prev
	MulticastDelegate_t * ___prev_9;
	// System.MulticastDelegate System.MulticastDelegate::kpm_next
	MulticastDelegate_t * ___kpm_next_10;

public:
	inline static int32_t get_offset_of_prev_9() { return static_cast<int32_t>(offsetof(MulticastDelegate_t, ___prev_9)); }
	inline MulticastDelegate_t * get_prev_9() const { return ___prev_9; }
	inline MulticastDelegate_t ** get_address_of_prev_9() { return &___prev_9; }
	inline void set_prev_9(MulticastDelegate_t * value)
	{
		___prev_9 = value;
		Il2CppCodeGenWriteBarrier((&___prev_9), value);
	}

	inline static int32_t get_offset_of_kpm_next_10() { return static_cast<int32_t>(offsetof(MulticastDelegate_t, ___kpm_next_10)); }
	inline MulticastDelegate_t * get_kpm_next_10() const { return ___kpm_next_10; }
	inline MulticastDelegate_t ** get_address_of_kpm_next_10() { return &___kpm_next_10; }
	inline void set_kpm_next_10(MulticastDelegate_t * value)
	{
		___kpm_next_10 = value;
		Il2CppCodeGenWriteBarrier((&___kpm_next_10), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MULTICASTDELEGATE_T_H
#ifndef NATIVEARRAY_1_T1421029094_H
#define NATIVEARRAY_1_T1421029094_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Unity.Collections.NativeArray`1<System.Byte>
struct  NativeArray_1_t1421029094 
{
public:
	// System.Void* Unity.Collections.NativeArray`1::m_Buffer
	void* ___m_Buffer_0;
	// System.Int32 Unity.Collections.NativeArray`1::m_Length
	int32_t ___m_Length_1;
	// Unity.Collections.Allocator Unity.Collections.NativeArray`1::m_AllocatorLabel
	int32_t ___m_AllocatorLabel_2;

public:
	inline static int32_t get_offset_of_m_Buffer_0() { return static_cast<int32_t>(offsetof(NativeArray_1_t1421029094, ___m_Buffer_0)); }
	inline void* get_m_Buffer_0() const { return ___m_Buffer_0; }
	inline void** get_address_of_m_Buffer_0() { return &___m_Buffer_0; }
	inline void set_m_Buffer_0(void* value)
	{
		___m_Buffer_0 = value;
	}

	inline static int32_t get_offset_of_m_Length_1() { return static_cast<int32_t>(offsetof(NativeArray_1_t1421029094, ___m_Length_1)); }
	inline int32_t get_m_Length_1() const { return ___m_Length_1; }
	inline int32_t* get_address_of_m_Length_1() { return &___m_Length_1; }
	inline void set_m_Length_1(int32_t value)
	{
		___m_Length_1 = value;
	}

	inline static int32_t get_offset_of_m_AllocatorLabel_2() { return static_cast<int32_t>(offsetof(NativeArray_1_t1421029094, ___m_AllocatorLabel_2)); }
	inline int32_t get_m_AllocatorLabel_2() const { return ___m_AllocatorLabel_2; }
	inline int32_t* get_address_of_m_AllocatorLabel_2() { return &___m_AllocatorLabel_2; }
	inline void set_m_AllocatorLabel_2(int32_t value)
	{
		___m_AllocatorLabel_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NATIVEARRAY_1_T1421029094_H
#ifndef SUBSYSTEMDESCRIPTOR_1_T1932951644_H
#define SUBSYSTEMDESCRIPTOR_1_T1932951644_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.SubsystemDescriptor`1<UnityEngine.Experimental.XR.XRCameraSubsystem>
struct  SubsystemDescriptor_1_t1932951644  : public SubsystemDescriptorBase_t2374447182
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SUBSYSTEMDESCRIPTOR_1_T1932951644_H
#ifndef SUBSYSTEMDESCRIPTOR_1_T4292266728_H
#define SUBSYSTEMDESCRIPTOR_1_T4292266728_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.SubsystemDescriptor`1<UnityEngine.Experimental.XR.XRPlaneSubsystem>
struct  SubsystemDescriptor_1_t4292266728  : public SubsystemDescriptorBase_t2374447182
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SUBSYSTEMDESCRIPTOR_1_T4292266728_H
#ifndef SUBSYSTEMDESCRIPTOR_1_T2448998858_H
#define SUBSYSTEMDESCRIPTOR_1_T2448998858_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.SubsystemDescriptor`1<UnityEngine.Experimental.XR.XRReferencePointSubsystem>
struct  SubsystemDescriptor_1_t2448998858  : public SubsystemDescriptorBase_t2374447182
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SUBSYSTEMDESCRIPTOR_1_T2448998858_H
#ifndef SUBSYSTEMDESCRIPTOR_1_T1353494744_H
#define SUBSYSTEMDESCRIPTOR_1_T1353494744_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.SubsystemDescriptor`1<UnityEngine.Experimental.XR.XRSessionSubsystem>
struct  SubsystemDescriptor_1_t1353494744  : public SubsystemDescriptorBase_t2374447182
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SUBSYSTEMDESCRIPTOR_1_T1353494744_H
#ifndef SUBSYSTEM_1_T588646725_H
#define SUBSYSTEM_1_T588646725_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.Subsystem`1<UnityEngine.Experimental.XR.XRCameraSubsystemDescriptor>
struct  Subsystem_1_t588646725  : public Subsystem_t89723475
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SUBSYSTEM_1_T588646725_H
#ifndef SUBSYSTEM_1_T1428396990_H
#define SUBSYSTEM_1_T1428396990_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.Subsystem`1<UnityEngine.Experimental.XR.XRPlaneSubsystemDescriptor>
struct  Subsystem_1_t1428396990  : public Subsystem_t89723475
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SUBSYSTEM_1_T1428396990_H
#ifndef SUBSYSTEM_1_T2853778384_H
#define SUBSYSTEM_1_T2853778384_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.Subsystem`1<UnityEngine.Experimental.XR.XRReferencePointSubsystemDescriptor>
struct  Subsystem_1_t2853778384  : public Subsystem_t89723475
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SUBSYSTEM_1_T2853778384_H
#ifndef SUBSYSTEM_1_T2383066733_H
#define SUBSYSTEM_1_T2383066733_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.Subsystem`1<UnityEngine.Experimental.XR.XRSessionSubsystemDescriptor>
struct  Subsystem_1_t2383066733  : public Subsystem_t89723475
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SUBSYSTEM_1_T2383066733_H
#ifndef CAMERAIMAGE_T2783787914_H
#define CAMERAIMAGE_T2783787914_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.ARExtensions.CameraImage
struct  CameraImage_t2783787914 
{
public:
	// UnityEngine.Vector2Int UnityEngine.XR.ARExtensions.CameraImage::<dimensions>k__BackingField
	Vector2Int_t3469998543  ___U3CdimensionsU3Ek__BackingField_0;
	// System.Int32 UnityEngine.XR.ARExtensions.CameraImage::<planeCount>k__BackingField
	int32_t ___U3CplaneCountU3Ek__BackingField_1;
	// UnityEngine.XR.ARExtensions.CameraImageFormat UnityEngine.XR.ARExtensions.CameraImage::<format>k__BackingField
	int32_t ___U3CformatU3Ek__BackingField_2;
	// System.Double UnityEngine.XR.ARExtensions.CameraImage::<timestamp>k__BackingField
	double ___U3CtimestampU3Ek__BackingField_3;
	// System.Int32 UnityEngine.XR.ARExtensions.CameraImage::m_NativeHandle
	int32_t ___m_NativeHandle_4;
	// UnityEngine.XR.ARExtensions.ICameraImageApi UnityEngine.XR.ARExtensions.CameraImage::m_CameraImageApi
	RuntimeObject* ___m_CameraImageApi_5;

public:
	inline static int32_t get_offset_of_U3CdimensionsU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(CameraImage_t2783787914, ___U3CdimensionsU3Ek__BackingField_0)); }
	inline Vector2Int_t3469998543  get_U3CdimensionsU3Ek__BackingField_0() const { return ___U3CdimensionsU3Ek__BackingField_0; }
	inline Vector2Int_t3469998543 * get_address_of_U3CdimensionsU3Ek__BackingField_0() { return &___U3CdimensionsU3Ek__BackingField_0; }
	inline void set_U3CdimensionsU3Ek__BackingField_0(Vector2Int_t3469998543  value)
	{
		___U3CdimensionsU3Ek__BackingField_0 = value;
	}

	inline static int32_t get_offset_of_U3CplaneCountU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(CameraImage_t2783787914, ___U3CplaneCountU3Ek__BackingField_1)); }
	inline int32_t get_U3CplaneCountU3Ek__BackingField_1() const { return ___U3CplaneCountU3Ek__BackingField_1; }
	inline int32_t* get_address_of_U3CplaneCountU3Ek__BackingField_1() { return &___U3CplaneCountU3Ek__BackingField_1; }
	inline void set_U3CplaneCountU3Ek__BackingField_1(int32_t value)
	{
		___U3CplaneCountU3Ek__BackingField_1 = value;
	}

	inline static int32_t get_offset_of_U3CformatU3Ek__BackingField_2() { return static_cast<int32_t>(offsetof(CameraImage_t2783787914, ___U3CformatU3Ek__BackingField_2)); }
	inline int32_t get_U3CformatU3Ek__BackingField_2() const { return ___U3CformatU3Ek__BackingField_2; }
	inline int32_t* get_address_of_U3CformatU3Ek__BackingField_2() { return &___U3CformatU3Ek__BackingField_2; }
	inline void set_U3CformatU3Ek__BackingField_2(int32_t value)
	{
		___U3CformatU3Ek__BackingField_2 = value;
	}

	inline static int32_t get_offset_of_U3CtimestampU3Ek__BackingField_3() { return static_cast<int32_t>(offsetof(CameraImage_t2783787914, ___U3CtimestampU3Ek__BackingField_3)); }
	inline double get_U3CtimestampU3Ek__BackingField_3() const { return ___U3CtimestampU3Ek__BackingField_3; }
	inline double* get_address_of_U3CtimestampU3Ek__BackingField_3() { return &___U3CtimestampU3Ek__BackingField_3; }
	inline void set_U3CtimestampU3Ek__BackingField_3(double value)
	{
		___U3CtimestampU3Ek__BackingField_3 = value;
	}

	inline static int32_t get_offset_of_m_NativeHandle_4() { return static_cast<int32_t>(offsetof(CameraImage_t2783787914, ___m_NativeHandle_4)); }
	inline int32_t get_m_NativeHandle_4() const { return ___m_NativeHandle_4; }
	inline int32_t* get_address_of_m_NativeHandle_4() { return &___m_NativeHandle_4; }
	inline void set_m_NativeHandle_4(int32_t value)
	{
		___m_NativeHandle_4 = value;
	}

	inline static int32_t get_offset_of_m_CameraImageApi_5() { return static_cast<int32_t>(offsetof(CameraImage_t2783787914, ___m_CameraImageApi_5)); }
	inline RuntimeObject* get_m_CameraImageApi_5() const { return ___m_CameraImageApi_5; }
	inline RuntimeObject** get_address_of_m_CameraImageApi_5() { return &___m_CameraImageApi_5; }
	inline void set_m_CameraImageApi_5(RuntimeObject* value)
	{
		___m_CameraImageApi_5 = value;
		Il2CppCodeGenWriteBarrier((&___m_CameraImageApi_5), value);
	}
};

struct CameraImage_t2783787914_StaticFields
{
public:
	// UnityEngine.XR.ARExtensions.XRCameraExtensions/OnImageRequestCompleteDelegate UnityEngine.XR.ARExtensions.CameraImage::s_OnAsyncConversionComplete
	OnImageRequestCompleteDelegate_t4025953918 * ___s_OnAsyncConversionComplete_6;

public:
	inline static int32_t get_offset_of_s_OnAsyncConversionComplete_6() { return static_cast<int32_t>(offsetof(CameraImage_t2783787914_StaticFields, ___s_OnAsyncConversionComplete_6)); }
	inline OnImageRequestCompleteDelegate_t4025953918 * get_s_OnAsyncConversionComplete_6() const { return ___s_OnAsyncConversionComplete_6; }
	inline OnImageRequestCompleteDelegate_t4025953918 ** get_address_of_s_OnAsyncConversionComplete_6() { return &___s_OnAsyncConversionComplete_6; }
	inline void set_s_OnAsyncConversionComplete_6(OnImageRequestCompleteDelegate_t4025953918 * value)
	{
		___s_OnAsyncConversionComplete_6 = value;
		Il2CppCodeGenWriteBarrier((&___s_OnAsyncConversionComplete_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.XR.ARExtensions.CameraImage
struct CameraImage_t2783787914_marshaled_pinvoke
{
	Vector2Int_t3469998543  ___U3CdimensionsU3Ek__BackingField_0;
	int32_t ___U3CplaneCountU3Ek__BackingField_1;
	int32_t ___U3CformatU3Ek__BackingField_2;
	double ___U3CtimestampU3Ek__BackingField_3;
	int32_t ___m_NativeHandle_4;
	RuntimeObject* ___m_CameraImageApi_5;
};
// Native definition for COM marshalling of UnityEngine.XR.ARExtensions.CameraImage
struct CameraImage_t2783787914_marshaled_com
{
	Vector2Int_t3469998543  ___U3CdimensionsU3Ek__BackingField_0;
	int32_t ___U3CplaneCountU3Ek__BackingField_1;
	int32_t ___U3CformatU3Ek__BackingField_2;
	double ___U3CtimestampU3Ek__BackingField_3;
	int32_t ___m_NativeHandle_4;
	RuntimeObject* ___m_CameraImageApi_5;
};
#endif // CAMERAIMAGE_T2783787914_H
#ifndef CAMERAIMAGECONVERSIONPARAMS_T1109674340_H
#define CAMERAIMAGECONVERSIONPARAMS_T1109674340_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.ARExtensions.CameraImageConversionParams
struct  CameraImageConversionParams_t1109674340 
{
public:
	// UnityEngine.RectInt UnityEngine.XR.ARExtensions.CameraImageConversionParams::m_InputRect
	RectInt_t1875739471  ___m_InputRect_0;
	// UnityEngine.Vector2Int UnityEngine.XR.ARExtensions.CameraImageConversionParams::m_OutputDimensions
	Vector2Int_t3469998543  ___m_OutputDimensions_1;
	// UnityEngine.TextureFormat UnityEngine.XR.ARExtensions.CameraImageConversionParams::m_Format
	int32_t ___m_Format_2;
	// UnityEngine.XR.ARExtensions.CameraImageTransformation UnityEngine.XR.ARExtensions.CameraImageConversionParams::m_Transformation
	int32_t ___m_Transformation_3;

public:
	inline static int32_t get_offset_of_m_InputRect_0() { return static_cast<int32_t>(offsetof(CameraImageConversionParams_t1109674340, ___m_InputRect_0)); }
	inline RectInt_t1875739471  get_m_InputRect_0() const { return ___m_InputRect_0; }
	inline RectInt_t1875739471 * get_address_of_m_InputRect_0() { return &___m_InputRect_0; }
	inline void set_m_InputRect_0(RectInt_t1875739471  value)
	{
		___m_InputRect_0 = value;
	}

	inline static int32_t get_offset_of_m_OutputDimensions_1() { return static_cast<int32_t>(offsetof(CameraImageConversionParams_t1109674340, ___m_OutputDimensions_1)); }
	inline Vector2Int_t3469998543  get_m_OutputDimensions_1() const { return ___m_OutputDimensions_1; }
	inline Vector2Int_t3469998543 * get_address_of_m_OutputDimensions_1() { return &___m_OutputDimensions_1; }
	inline void set_m_OutputDimensions_1(Vector2Int_t3469998543  value)
	{
		___m_OutputDimensions_1 = value;
	}

	inline static int32_t get_offset_of_m_Format_2() { return static_cast<int32_t>(offsetof(CameraImageConversionParams_t1109674340, ___m_Format_2)); }
	inline int32_t get_m_Format_2() const { return ___m_Format_2; }
	inline int32_t* get_address_of_m_Format_2() { return &___m_Format_2; }
	inline void set_m_Format_2(int32_t value)
	{
		___m_Format_2 = value;
	}

	inline static int32_t get_offset_of_m_Transformation_3() { return static_cast<int32_t>(offsetof(CameraImageConversionParams_t1109674340, ___m_Transformation_3)); }
	inline int32_t get_m_Transformation_3() const { return ___m_Transformation_3; }
	inline int32_t* get_address_of_m_Transformation_3() { return &___m_Transformation_3; }
	inline void set_m_Transformation_3(int32_t value)
	{
		___m_Transformation_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CAMERAIMAGECONVERSIONPARAMS_T1109674340_H
#ifndef PROMISE_1_T3923167537_H
#define PROMISE_1_T3923167537_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.ARExtensions.Promise`1<UnityEngine.XR.ARExtensions.SessionAvailability>
struct  Promise_1_t3923167537  : public CustomYieldInstruction_t1895667560
{
public:
	// T UnityEngine.XR.ARExtensions.Promise`1::<result>k__BackingField
	int32_t ___U3CresultU3Ek__BackingField_0;
	// System.Boolean UnityEngine.XR.ARExtensions.Promise`1::m_Complete
	bool ___m_Complete_1;

public:
	inline static int32_t get_offset_of_U3CresultU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(Promise_1_t3923167537, ___U3CresultU3Ek__BackingField_0)); }
	inline int32_t get_U3CresultU3Ek__BackingField_0() const { return ___U3CresultU3Ek__BackingField_0; }
	inline int32_t* get_address_of_U3CresultU3Ek__BackingField_0() { return &___U3CresultU3Ek__BackingField_0; }
	inline void set_U3CresultU3Ek__BackingField_0(int32_t value)
	{
		___U3CresultU3Ek__BackingField_0 = value;
	}

	inline static int32_t get_offset_of_m_Complete_1() { return static_cast<int32_t>(offsetof(Promise_1_t3923167537, ___m_Complete_1)); }
	inline bool get_m_Complete_1() const { return ___m_Complete_1; }
	inline bool* get_address_of_m_Complete_1() { return &___m_Complete_1; }
	inline void set_m_Complete_1(bool value)
	{
		___m_Complete_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PROMISE_1_T3923167537_H
#ifndef PROMISE_1_T1435222300_H
#define PROMISE_1_T1435222300_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.ARExtensions.Promise`1<UnityEngine.XR.ARExtensions.SessionInstallationStatus>
struct  Promise_1_t1435222300  : public CustomYieldInstruction_t1895667560
{
public:
	// T UnityEngine.XR.ARExtensions.Promise`1::<result>k__BackingField
	int32_t ___U3CresultU3Ek__BackingField_0;
	// System.Boolean UnityEngine.XR.ARExtensions.Promise`1::m_Complete
	bool ___m_Complete_1;

public:
	inline static int32_t get_offset_of_U3CresultU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(Promise_1_t1435222300, ___U3CresultU3Ek__BackingField_0)); }
	inline int32_t get_U3CresultU3Ek__BackingField_0() const { return ___U3CresultU3Ek__BackingField_0; }
	inline int32_t* get_address_of_U3CresultU3Ek__BackingField_0() { return &___U3CresultU3Ek__BackingField_0; }
	inline void set_U3CresultU3Ek__BackingField_0(int32_t value)
	{
		___U3CresultU3Ek__BackingField_0 = value;
	}

	inline static int32_t get_offset_of_m_Complete_1() { return static_cast<int32_t>(offsetof(Promise_1_t1435222300, ___m_Complete_1)); }
	inline bool get_m_Complete_1() const { return ___m_Complete_1; }
	inline bool* get_address_of_m_Complete_1() { return &___m_Complete_1; }
	inline void set_m_Complete_1(bool value)
	{
		___m_Complete_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PROMISE_1_T1435222300_H
#ifndef ACTION_3_T3607487754_H
#define ACTION_3_T3607487754_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Action`3<UnityEngine.XR.ARExtensions.AsyncCameraImageConversionStatus,UnityEngine.XR.ARExtensions.CameraImageConversionParams,Unity.Collections.NativeArray`1<System.Byte>>
struct  Action_3_t3607487754  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ACTION_3_T3607487754_H
#ifndef ASYNCCALLBACK_T3962456242_H
#define ASYNCCALLBACK_T3962456242_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.AsyncCallback
struct  AsyncCallback_t3962456242  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ASYNCCALLBACK_T3962456242_H
#ifndef FUNC_2_T2975102603_H
#define FUNC_2_T2975102603_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Func`2<UnityEngine.Experimental.XR.XRCameraSubsystem,System.Boolean>
struct  Func_2_t2975102603  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FUNC_2_T2975102603_H
#ifndef FUNC_3_T2921619047_H
#define FUNC_3_T2921619047_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Func`3<UnityEngine.Experimental.XR.XRPlaneSubsystem,UnityEngine.Experimental.XR.TrackableId,UnityEngine.Experimental.XR.TrackingState>
struct  Func_3_t2921619047  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FUNC_3_T2921619047_H
#ifndef XRCAMERASUBSYSTEM_T4195795144_H
#define XRCAMERASUBSYSTEM_T4195795144_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.XRCameraSubsystem
struct  XRCameraSubsystem_t4195795144  : public Subsystem_1_t588646725
{
public:
	// System.Action`1<UnityEngine.Experimental.XR.FrameReceivedEventArgs> UnityEngine.Experimental.XR.XRCameraSubsystem::FrameReceived
	Action_1_t2760547698 * ___FrameReceived_2;

public:
	inline static int32_t get_offset_of_FrameReceived_2() { return static_cast<int32_t>(offsetof(XRCameraSubsystem_t4195795144, ___FrameReceived_2)); }
	inline Action_1_t2760547698 * get_FrameReceived_2() const { return ___FrameReceived_2; }
	inline Action_1_t2760547698 ** get_address_of_FrameReceived_2() { return &___FrameReceived_2; }
	inline void set_FrameReceived_2(Action_1_t2760547698 * value)
	{
		___FrameReceived_2 = value;
		Il2CppCodeGenWriteBarrier((&___FrameReceived_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRCAMERASUBSYSTEM_T4195795144_H
#ifndef XRCAMERASUBSYSTEMDESCRIPTOR_T3689383335_H
#define XRCAMERASUBSYSTEMDESCRIPTOR_T3689383335_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.XRCameraSubsystemDescriptor
struct  XRCameraSubsystemDescriptor_t3689383335  : public SubsystemDescriptor_1_t1932951644
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRCAMERASUBSYSTEMDESCRIPTOR_T3689383335_H
#ifndef XRPLANESUBSYSTEM_T2260142932_H
#define XRPLANESUBSYSTEM_T2260142932_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.XRPlaneSubsystem
struct  XRPlaneSubsystem_t2260142932  : public Subsystem_1_t1428396990
{
public:
	// System.Action`1<UnityEngine.Experimental.XR.PlaneAddedEventArgs> UnityEngine.Experimental.XR.XRPlaneSubsystem::PlaneAdded
	Action_1_t2722643320 * ___PlaneAdded_2;
	// System.Action`1<UnityEngine.Experimental.XR.PlaneUpdatedEventArgs> UnityEngine.Experimental.XR.XRPlaneSubsystem::PlaneUpdated
	Action_1_t521953446 * ___PlaneUpdated_3;
	// System.Action`1<UnityEngine.Experimental.XR.PlaneRemovedEventArgs> UnityEngine.Experimental.XR.XRPlaneSubsystem::PlaneRemoved
	Action_1_t1739597377 * ___PlaneRemoved_4;

public:
	inline static int32_t get_offset_of_PlaneAdded_2() { return static_cast<int32_t>(offsetof(XRPlaneSubsystem_t2260142932, ___PlaneAdded_2)); }
	inline Action_1_t2722643320 * get_PlaneAdded_2() const { return ___PlaneAdded_2; }
	inline Action_1_t2722643320 ** get_address_of_PlaneAdded_2() { return &___PlaneAdded_2; }
	inline void set_PlaneAdded_2(Action_1_t2722643320 * value)
	{
		___PlaneAdded_2 = value;
		Il2CppCodeGenWriteBarrier((&___PlaneAdded_2), value);
	}

	inline static int32_t get_offset_of_PlaneUpdated_3() { return static_cast<int32_t>(offsetof(XRPlaneSubsystem_t2260142932, ___PlaneUpdated_3)); }
	inline Action_1_t521953446 * get_PlaneUpdated_3() const { return ___PlaneUpdated_3; }
	inline Action_1_t521953446 ** get_address_of_PlaneUpdated_3() { return &___PlaneUpdated_3; }
	inline void set_PlaneUpdated_3(Action_1_t521953446 * value)
	{
		___PlaneUpdated_3 = value;
		Il2CppCodeGenWriteBarrier((&___PlaneUpdated_3), value);
	}

	inline static int32_t get_offset_of_PlaneRemoved_4() { return static_cast<int32_t>(offsetof(XRPlaneSubsystem_t2260142932, ___PlaneRemoved_4)); }
	inline Action_1_t1739597377 * get_PlaneRemoved_4() const { return ___PlaneRemoved_4; }
	inline Action_1_t1739597377 ** get_address_of_PlaneRemoved_4() { return &___PlaneRemoved_4; }
	inline void set_PlaneRemoved_4(Action_1_t1739597377 * value)
	{
		___PlaneRemoved_4 = value;
		Il2CppCodeGenWriteBarrier((&___PlaneRemoved_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRPLANESUBSYSTEM_T2260142932_H
#ifndef XRPLANESUBSYSTEMDESCRIPTOR_T234166304_H
#define XRPLANESUBSYSTEMDESCRIPTOR_T234166304_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.XRPlaneSubsystemDescriptor
struct  XRPlaneSubsystemDescriptor_t234166304  : public SubsystemDescriptor_1_t4292266728
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRPLANESUBSYSTEMDESCRIPTOR_T234166304_H
#ifndef XRREFERENCEPOINTSUBSYSTEM_T416875062_H
#define XRREFERENCEPOINTSUBSYSTEM_T416875062_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.XRReferencePointSubsystem
struct  XRReferencePointSubsystem_t416875062  : public Subsystem_1_t2853778384
{
public:
	// System.Action`1<UnityEngine.Experimental.XR.ReferencePointUpdatedEventArgs> UnityEngine.Experimental.XR.XRReferencePointSubsystem::ReferencePointUpdated
	Action_1_t2218980328 * ___ReferencePointUpdated_2;

public:
	inline static int32_t get_offset_of_ReferencePointUpdated_2() { return static_cast<int32_t>(offsetof(XRReferencePointSubsystem_t416875062, ___ReferencePointUpdated_2)); }
	inline Action_1_t2218980328 * get_ReferencePointUpdated_2() const { return ___ReferencePointUpdated_2; }
	inline Action_1_t2218980328 ** get_address_of_ReferencePointUpdated_2() { return &___ReferencePointUpdated_2; }
	inline void set_ReferencePointUpdated_2(Action_1_t2218980328 * value)
	{
		___ReferencePointUpdated_2 = value;
		Il2CppCodeGenWriteBarrier((&___ReferencePointUpdated_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRREFERENCEPOINTSUBSYSTEM_T416875062_H
#ifndef XRREFERENCEPOINTSUBSYSTEMDESCRIPTOR_T1659547698_H
#define XRREFERENCEPOINTSUBSYSTEMDESCRIPTOR_T1659547698_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.XRReferencePointSubsystemDescriptor
struct  XRReferencePointSubsystemDescriptor_t1659547698  : public SubsystemDescriptor_1_t2448998858
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRREFERENCEPOINTSUBSYSTEMDESCRIPTOR_T1659547698_H
#ifndef XRSESSIONSUBSYSTEM_T3616338244_H
#define XRSESSIONSUBSYSTEM_T3616338244_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.XRSessionSubsystem
struct  XRSessionSubsystem_t3616338244  : public Subsystem_1_t2383066733
{
public:
	// System.Action`1<UnityEngine.Experimental.XR.SessionTrackingStateChangedEventArgs> UnityEngine.Experimental.XR.XRSessionSubsystem::TrackingStateChanged
	Action_1_t2515503250 * ___TrackingStateChanged_2;

public:
	inline static int32_t get_offset_of_TrackingStateChanged_2() { return static_cast<int32_t>(offsetof(XRSessionSubsystem_t3616338244, ___TrackingStateChanged_2)); }
	inline Action_1_t2515503250 * get_TrackingStateChanged_2() const { return ___TrackingStateChanged_2; }
	inline Action_1_t2515503250 ** get_address_of_TrackingStateChanged_2() { return &___TrackingStateChanged_2; }
	inline void set_TrackingStateChanged_2(Action_1_t2515503250 * value)
	{
		___TrackingStateChanged_2 = value;
		Il2CppCodeGenWriteBarrier((&___TrackingStateChanged_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRSESSIONSUBSYSTEM_T3616338244_H
#ifndef XRSESSIONSUBSYSTEMDESCRIPTOR_T1188836047_H
#define XRSESSIONSUBSYSTEMDESCRIPTOR_T1188836047_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.XR.XRSessionSubsystemDescriptor
struct  XRSessionSubsystemDescriptor_t1188836047  : public SubsystemDescriptor_1_t1353494744
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRSESSIONSUBSYSTEMDESCRIPTOR_T1188836047_H
#ifndef ONIMAGEREQUESTCOMPLETEDELEGATE_T4025953918_H
#define ONIMAGEREQUESTCOMPLETEDELEGATE_T4025953918_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.ARExtensions.XRCameraExtensions/OnImageRequestCompleteDelegate
struct  OnImageRequestCompleteDelegate_t4025953918  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ONIMAGEREQUESTCOMPLETEDELEGATE_T4025953918_H
#ifndef TRYGETCOLORCORRECTIONDELEGATE_T1034812311_H
#define TRYGETCOLORCORRECTIONDELEGATE_T1034812311_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.ARExtensions.XRCameraExtensions/TryGetColorCorrectionDelegate
struct  TryGetColorCorrectionDelegate_t1034812311  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TRYGETCOLORCORRECTIONDELEGATE_T1034812311_H
#ifndef ATTACHREFERENCEPOINTDELEGATE_T418922659_H
#define ATTACHREFERENCEPOINTDELEGATE_T418922659_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.ARExtensions.XRReferencePointExtensions/AttachReferencePointDelegate
struct  AttachReferencePointDelegate_t418922659  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ATTACHREFERENCEPOINTDELEGATE_T418922659_H
#ifndef ASYNCDELEGATE_1_T3460105404_H
#define ASYNCDELEGATE_1_T3460105404_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionAvailability>
struct  AsyncDelegate_1_t3460105404  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ASYNCDELEGATE_1_T3460105404_H
#ifndef ASYNCDELEGATE_1_T972160167_H
#define ASYNCDELEGATE_1_T972160167_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionInstallationStatus>
struct  AsyncDelegate_1_t972160167  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ASYNCDELEGATE_1_T972160167_H
// System.Object[]
struct ObjectU5BU5D_t2843939325  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) RuntimeObject * m_Items[1];

public:
	inline RuntimeObject * GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline RuntimeObject ** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, RuntimeObject * value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier(m_Items + index, value);
	}
	inline RuntimeObject * GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline RuntimeObject ** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, RuntimeObject * value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier(m_Items + index, value);
	}
};


// Unity.Collections.NativeArray`1<!!0> Unity.Collections.LowLevel.Unsafe.NativeArrayUnsafeUtility::ConvertExistingDataToNativeArray<System.Byte>(System.Void*,System.Int32,Unity.Collections.Allocator)
extern "C" IL2CPP_METHOD_ATTR NativeArray_1_t1421029094  NativeArrayUnsafeUtility_ConvertExistingDataToNativeArray_TisByte_t1134296376_m990237749_gshared (RuntimeObject * __this /* static, unused */, void* p0, int32_t p1, int32_t p2, const RuntimeMethod* method);
// System.Void System.Action`3<UnityEngine.XR.ARExtensions.AsyncCameraImageConversionStatus,UnityEngine.XR.ARExtensions.CameraImageConversionParams,Unity.Collections.NativeArray`1<System.Byte>>::Invoke(!0,!1,!2)
extern "C" IL2CPP_METHOD_ATTR void Action_3_Invoke_m609172159_gshared (Action_3_t3607487754 * __this, int32_t p0, CameraImageConversionParams_t1109674340  p1, NativeArray_1_t1421029094  p2, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2<System.Object,System.Object>::.ctor()
extern "C" IL2CPP_METHOD_ATTR void Dictionary_2__ctor_m518943619_gshared (Dictionary_2_t132545152 * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2<System.Object,System.Object>::set_Item(!0,!1)
extern "C" IL2CPP_METHOD_ATTR void Dictionary_2_set_Item_m3474379962_gshared (Dictionary_2_t132545152 * __this, RuntimeObject * p0, RuntimeObject * p1, const RuntimeMethod* method);
// !0 UnityEngine.Experimental.Subsystem`1<System.Object>::get_SubsystemDescriptor()
extern "C" IL2CPP_METHOD_ATTR RuntimeObject * Subsystem_1_get_SubsystemDescriptor_m2291515923_gshared (Subsystem_1_t4274336850 * __this, const RuntimeMethod* method);
// System.Void System.Func`2<System.Object,System.Boolean>::.ctor(System.Object,System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR void Func_2__ctor_m3104565095_gshared (Func_2_t3759279471 * __this, RuntimeObject * p0, intptr_t p1, const RuntimeMethod* method);
// TValue UnityEngine.XR.ARExtensions.RegistrationHelper::GetValueOrDefault<System.Object,System.Object>(System.Collections.Generic.Dictionary`2<TKey,TValue>,TKey,TValue)
extern "C" IL2CPP_METHOD_ATTR RuntimeObject * RegistrationHelper_GetValueOrDefault_TisRuntimeObject_TisRuntimeObject_m2689764471_gshared (RuntimeObject * __this /* static, unused */, Dictionary_2_t132545152 * ___dictionary0, RuntimeObject * ___key1, RuntimeObject * ___defaultValue2, const RuntimeMethod* method);
// !2 System.Func`3<System.Object,UnityEngine.Experimental.XR.TrackableId,UnityEngine.Experimental.XR.TrackingState>::Invoke(!0,!1)
extern "C" IL2CPP_METHOD_ATTR int32_t Func_3_Invoke_m50126256_gshared (Func_3_t2197716167 * __this, RuntimeObject * p0, TrackableId_t1251031970  p1, const RuntimeMethod* method);
// System.Void System.Func`3<System.Object,UnityEngine.Experimental.XR.TrackableId,UnityEngine.Experimental.XR.TrackingState>::.ctor(System.Object,System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR void Func_3__ctor_m1590389318_gshared (Func_3_t2197716167 * __this, RuntimeObject * p0, intptr_t p1, const RuntimeMethod* method);
// UnityEngine.XR.ARExtensions.Promise`1<T> UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionAvailability>::Invoke(UnityEngine.Experimental.XR.XRSessionSubsystem)
extern "C" IL2CPP_METHOD_ATTR Promise_1_t3923167537 * AsyncDelegate_1_Invoke_m1924773735_gshared (AsyncDelegate_1_t3460105404 * __this, XRSessionSubsystem_t3616338244 * p0, const RuntimeMethod* method);
// UnityEngine.XR.ARExtensions.Promise`1<T> UnityEngine.XR.ARExtensions.Promise`1<UnityEngine.XR.ARExtensions.SessionAvailability>::CreateResolvedPromise(T)
extern "C" IL2CPP_METHOD_ATTR Promise_1_t3923167537 * Promise_1_CreateResolvedPromise_m420313478_gshared (RuntimeObject * __this /* static, unused */, int32_t p0, const RuntimeMethod* method);
// UnityEngine.XR.ARExtensions.Promise`1<T> UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionInstallationStatus>::Invoke(UnityEngine.Experimental.XR.XRSessionSubsystem)
extern "C" IL2CPP_METHOD_ATTR Promise_1_t1435222300 * AsyncDelegate_1_Invoke_m723727912_gshared (AsyncDelegate_1_t972160167 * __this, XRSessionSubsystem_t3616338244 * p0, const RuntimeMethod* method);
// UnityEngine.XR.ARExtensions.Promise`1<T> UnityEngine.XR.ARExtensions.Promise`1<UnityEngine.XR.ARExtensions.SessionInstallationStatus>::CreateResolvedPromise(T)
extern "C" IL2CPP_METHOD_ATTR Promise_1_t1435222300 * Promise_1_CreateResolvedPromise_m3838876404_gshared (RuntimeObject * __this /* static, unused */, int32_t p0, const RuntimeMethod* method);
// System.Void UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionInstallationStatus>::.ctor(System.Object,System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR void AsyncDelegate_1__ctor_m2374002471_gshared (AsyncDelegate_1_t972160167 * __this, RuntimeObject * p0, intptr_t p1, const RuntimeMethod* method);
// System.Void UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionAvailability>::.ctor(System.Object,System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR void AsyncDelegate_1__ctor_m1054827699_gshared (AsyncDelegate_1_t3460105404 * __this, RuntimeObject * p0, intptr_t p1, const RuntimeMethod* method);

// System.Void UnityEngine.XR.ARExtensions.CameraImage::OnAsyncConversionComplete(UnityEngine.XR.ARExtensions.AsyncCameraImageConversionStatus,UnityEngine.XR.ARExtensions.CameraImageConversionParams,System.IntPtr,System.Int32,System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR void CameraImage_OnAsyncConversionComplete_m926397238 (RuntimeObject * __this /* static, unused */, int32_t ___status0, CameraImageConversionParams_t1109674340  ___conversionParams1, intptr_t ___dataPtr2, int32_t ___dataLength3, intptr_t ___context4, const RuntimeMethod* method);
// System.Void UnityEngine.XR.ARExtensions.XRCameraExtensions/OnImageRequestCompleteDelegate::.ctor(System.Object,System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR void OnImageRequestCompleteDelegate__ctor_m979042311 (OnImageRequestCompleteDelegate_t4025953918 * __this, RuntimeObject * ___object0, intptr_t ___method1, const RuntimeMethod* method);
// System.Void UnityEngine.XR.ARExtensions.CameraImage::set_dimensions(UnityEngine.Vector2Int)
extern "C" IL2CPP_METHOD_ATTR void CameraImage_set_dimensions_m3621924320 (CameraImage_t2783787914 * __this, Vector2Int_t3469998543  ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.XR.ARExtensions.CameraImage::set_planeCount(System.Int32)
extern "C" IL2CPP_METHOD_ATTR void CameraImage_set_planeCount_m2171489124 (CameraImage_t2783787914 * __this, int32_t ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.XR.ARExtensions.CameraImage::set_timestamp(System.Double)
extern "C" IL2CPP_METHOD_ATTR void CameraImage_set_timestamp_m2915797604 (CameraImage_t2783787914 * __this, double ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.XR.ARExtensions.CameraImage::set_format(UnityEngine.XR.ARExtensions.CameraImageFormat)
extern "C" IL2CPP_METHOD_ATTR void CameraImage_set_format_m1974516519 (CameraImage_t2783787914 * __this, int32_t ___value0, const RuntimeMethod* method);
// System.Void UnityEngine.XR.ARExtensions.CameraImage::.ctor(UnityEngine.XR.ARExtensions.ICameraImageApi,System.Int32,UnityEngine.Vector2Int,System.Int32,System.Double,UnityEngine.XR.ARExtensions.CameraImageFormat)
extern "C" IL2CPP_METHOD_ATTR void CameraImage__ctor_m1119229678 (CameraImage_t2783787914 * __this, RuntimeObject* ___cameraImageApi0, int32_t ___nativeHandle1, Vector2Int_t3469998543  ___dimensions2, int32_t ___planeCount3, double ___timestamp4, int32_t ___format5, const RuntimeMethod* method);
// UnityEngine.Vector2Int UnityEngine.XR.ARExtensions.CameraImage::get_dimensions()
extern "C" IL2CPP_METHOD_ATTR Vector2Int_t3469998543  CameraImage_get_dimensions_m4235814331 (CameraImage_t2783787914 * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.Vector2Int::get_x()
extern "C" IL2CPP_METHOD_ATTR int32_t Vector2Int_get_x_m64542184 (Vector2Int_t3469998543 * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.XR.ARExtensions.CameraImage::get_width()
extern "C" IL2CPP_METHOD_ATTR int32_t CameraImage_get_width_m3669078563 (CameraImage_t2783787914 * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.Vector2Int::get_y()
extern "C" IL2CPP_METHOD_ATTR int32_t Vector2Int_get_y_m64542185 (Vector2Int_t3469998543 * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.XR.ARExtensions.CameraImage::get_height()
extern "C" IL2CPP_METHOD_ATTR int32_t CameraImage_get_height_m1383532788 (CameraImage_t2783787914 * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.XR.ARExtensions.CameraImage::get_planeCount()
extern "C" IL2CPP_METHOD_ATTR int32_t CameraImage_get_planeCount_m208301076 (CameraImage_t2783787914 * __this, const RuntimeMethod* method);
// UnityEngine.XR.ARExtensions.CameraImageFormat UnityEngine.XR.ARExtensions.CameraImage::get_format()
extern "C" IL2CPP_METHOD_ATTR int32_t CameraImage_get_format_m2457822911 (CameraImage_t2783787914 * __this, const RuntimeMethod* method);
// System.Double UnityEngine.XR.ARExtensions.CameraImage::get_timestamp()
extern "C" IL2CPP_METHOD_ATTR double CameraImage_get_timestamp_m1267159734 (CameraImage_t2783787914 * __this, const RuntimeMethod* method);
// System.Boolean UnityEngine.XR.ARExtensions.CameraImage::get_valid()
extern "C" IL2CPP_METHOD_ATTR bool CameraImage_get_valid_m1506925116 (CameraImage_t2783787914 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.XR.ARExtensions.CameraImage::ValidateNativeHandleAndThrow()
extern "C" IL2CPP_METHOD_ATTR void CameraImage_ValidateNativeHandleAndThrow_m654558893 (CameraImage_t2783787914 * __this, const RuntimeMethod* method);
// System.String System.String::Format(System.String,System.Object,System.Object)
extern "C" IL2CPP_METHOD_ATTR String_t* String_Format_m2556382932 (RuntimeObject * __this /* static, unused */, String_t* p0, RuntimeObject * p1, RuntimeObject * p2, const RuntimeMethod* method);
// System.Void System.ArgumentOutOfRangeException::.ctor(System.String,System.String)
extern "C" IL2CPP_METHOD_ATTR void ArgumentOutOfRangeException__ctor_m282481429 (ArgumentOutOfRangeException_t777629997 * __this, String_t* p0, String_t* p1, const RuntimeMethod* method);
// System.Boolean UnityEngine.XR.ARExtensions.CameraImage::FormatSupported(UnityEngine.TextureFormat)
extern "C" IL2CPP_METHOD_ATTR bool CameraImage_FormatSupported_m2095457754 (RuntimeObject * __this /* static, unused */, int32_t ___format0, const RuntimeMethod* method);
// System.Void System.ArgumentException::.ctor(System.String,System.String)
extern "C" IL2CPP_METHOD_ATTR void ArgumentException__ctor_m1216717135 (ArgumentException_t132251570 * __this, String_t* p0, String_t* p1, const RuntimeMethod* method);
// System.Void System.InvalidOperationException::.ctor(System.String)
extern "C" IL2CPP_METHOD_ATTR void InvalidOperationException__ctor_m237278729 (InvalidOperationException_t56020091 * __this, String_t* p0, const RuntimeMethod* method);
// System.Int32 UnityEngine.XR.ARExtensions.CameraImage::GetConvertedDataSize(UnityEngine.Vector2Int,UnityEngine.TextureFormat)
extern "C" IL2CPP_METHOD_ATTR int32_t CameraImage_GetConvertedDataSize_m1842015692 (CameraImage_t2783787914 * __this, Vector2Int_t3469998543  ___dimensions0, int32_t ___format1, const RuntimeMethod* method);
// UnityEngine.Vector2Int UnityEngine.XR.ARExtensions.CameraImageConversionParams::get_outputDimensions()
extern "C" IL2CPP_METHOD_ATTR Vector2Int_t3469998543  CameraImageConversionParams_get_outputDimensions_m158549880 (CameraImageConversionParams_t1109674340 * __this, const RuntimeMethod* method);
// UnityEngine.TextureFormat UnityEngine.XR.ARExtensions.CameraImageConversionParams::get_outputFormat()
extern "C" IL2CPP_METHOD_ATTR int32_t CameraImageConversionParams_get_outputFormat_m780098116 (CameraImageConversionParams_t1109674340 * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.XR.ARExtensions.CameraImage::GetConvertedDataSize(UnityEngine.XR.ARExtensions.CameraImageConversionParams)
extern "C" IL2CPP_METHOD_ATTR int32_t CameraImage_GetConvertedDataSize_m850245283 (CameraImage_t2783787914 * __this, CameraImageConversionParams_t1109674340  ___conversionParams0, const RuntimeMethod* method);
// System.Void UnityEngine.XR.ARExtensions.CameraImage::ValidateConversionParamsAndThrow(UnityEngine.XR.ARExtensions.CameraImageConversionParams)
extern "C" IL2CPP_METHOD_ATTR void CameraImage_ValidateConversionParamsAndThrow_m1179966680 (CameraImage_t2783787914 * __this, CameraImageConversionParams_t1109674340  ___conversionParams0, const RuntimeMethod* method);
// System.Void UnityEngine.XR.ARExtensions.CameraImage::Convert(UnityEngine.XR.ARExtensions.CameraImageConversionParams,System.IntPtr,System.Int32)
extern "C" IL2CPP_METHOD_ATTR void CameraImage_Convert_m2059105726 (CameraImage_t2783787914 * __this, CameraImageConversionParams_t1109674340  ___conversionParams0, intptr_t ___destinationBuffer1, int32_t ___bufferLength2, const RuntimeMethod* method);
// System.Runtime.InteropServices.GCHandle System.Runtime.InteropServices.GCHandle::FromIntPtr(System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR GCHandle_t3351438187  GCHandle_FromIntPtr_m3880792486 (RuntimeObject * __this /* static, unused */, intptr_t p0, const RuntimeMethod* method);
// System.Object System.Runtime.InteropServices.GCHandle::get_Target()
extern "C" IL2CPP_METHOD_ATTR RuntimeObject * GCHandle_get_Target_m1824973883 (GCHandle_t3351438187 * __this, const RuntimeMethod* method);
// System.Void* System.IntPtr::op_Explicit(System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR void* IntPtr_op_Explicit_m2520637223 (RuntimeObject * __this /* static, unused */, intptr_t p0, const RuntimeMethod* method);
// Unity.Collections.NativeArray`1<!!0> Unity.Collections.LowLevel.Unsafe.NativeArrayUnsafeUtility::ConvertExistingDataToNativeArray<System.Byte>(System.Void*,System.Int32,Unity.Collections.Allocator)
inline NativeArray_1_t1421029094  NativeArrayUnsafeUtility_ConvertExistingDataToNativeArray_TisByte_t1134296376_m990237749 (RuntimeObject * __this /* static, unused */, void* p0, int32_t p1, int32_t p2, const RuntimeMethod* method)
{
	return ((  NativeArray_1_t1421029094  (*) (RuntimeObject * /* static, unused */, void*, int32_t, int32_t, const RuntimeMethod*))NativeArrayUnsafeUtility_ConvertExistingDataToNativeArray_TisByte_t1134296376_m990237749_gshared)(__this /* static, unused */, p0, p1, p2, method);
}
// System.Void System.Action`3<UnityEngine.XR.ARExtensions.AsyncCameraImageConversionStatus,UnityEngine.XR.ARExtensions.CameraImageConversionParams,Unity.Collections.NativeArray`1<System.Byte>>::Invoke(!0,!1,!2)
inline void Action_3_Invoke_m609172159 (Action_3_t3607487754 * __this, int32_t p0, CameraImageConversionParams_t1109674340  p1, NativeArray_1_t1421029094  p2, const RuntimeMethod* method)
{
	((  void (*) (Action_3_t3607487754 *, int32_t, CameraImageConversionParams_t1109674340 , NativeArray_1_t1421029094 , const RuntimeMethod*))Action_3_Invoke_m609172159_gshared)(__this, p0, p1, p2, method);
}
// System.Void System.Runtime.InteropServices.GCHandle::Free()
extern "C" IL2CPP_METHOD_ATTR void GCHandle_Free_m1457699368 (GCHandle_t3351438187 * __this, const RuntimeMethod* method);
// UnityEngine.RectInt UnityEngine.XR.ARExtensions.CameraImageConversionParams::get_inputRect()
extern "C" IL2CPP_METHOD_ATTR RectInt_t1875739471  CameraImageConversionParams_get_inputRect_m2276433308 (CameraImageConversionParams_t1109674340 * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.RectInt::get_x()
extern "C" IL2CPP_METHOD_ATTR int32_t RectInt_get_x_m1197757818 (RectInt_t1875739471 * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.RectInt::get_width()
extern "C" IL2CPP_METHOD_ATTR int32_t RectInt_get_width_m521919353 (RectInt_t1875739471 * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.RectInt::get_y()
extern "C" IL2CPP_METHOD_ATTR int32_t RectInt_get_y_m1197692282 (RectInt_t1875739471 * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.RectInt::get_height()
extern "C" IL2CPP_METHOD_ATTR int32_t RectInt_get_height_m3077408641 (RectInt_t1875739471 * __this, const RuntimeMethod* method);
// System.String System.String::Format(System.String,System.Object[])
extern "C" IL2CPP_METHOD_ATTR String_t* String_Format_m630303134 (RuntimeObject * __this /* static, unused */, String_t* p0, ObjectU5BU5D_t2843939325* p1, const RuntimeMethod* method);
// System.Void UnityEngine.XR.ARExtensions.CameraImage::Dispose()
extern "C" IL2CPP_METHOD_ATTR void CameraImage_Dispose_m1566295269 (CameraImage_t2783787914 * __this, const RuntimeMethod* method);
// System.Int32 System.Int32::GetHashCode()
extern "C" IL2CPP_METHOD_ATTR int32_t Int32_GetHashCode_m1876651407 (int32_t* __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.XR.ARExtensions.CameraImage::GetHashCode()
extern "C" IL2CPP_METHOD_ATTR int32_t CameraImage_GetHashCode_m1730928199 (CameraImage_t2783787914 * __this, const RuntimeMethod* method);
// System.Boolean UnityEngine.XR.ARExtensions.CameraImage::Equals(UnityEngine.XR.ARExtensions.CameraImage)
extern "C" IL2CPP_METHOD_ATTR bool CameraImage_Equals_m3715424145 (CameraImage_t2783787914 * __this, CameraImage_t2783787914  ___other0, const RuntimeMethod* method);
// System.Boolean UnityEngine.XR.ARExtensions.CameraImage::Equals(System.Object)
extern "C" IL2CPP_METHOD_ATTR bool CameraImage_Equals_m3039677800 (CameraImage_t2783787914 * __this, RuntimeObject * ___obj0, const RuntimeMethod* method);
// System.String UnityEngine.XR.ARExtensions.CameraImage::ToString()
extern "C" IL2CPP_METHOD_ATTR String_t* CameraImage_ToString_m1993371729 (CameraImage_t2783787914 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.RectInt::.ctor(System.Int32,System.Int32,System.Int32,System.Int32)
extern "C" IL2CPP_METHOD_ATTR void RectInt__ctor_m1117080735 (RectInt_t1875739471 * __this, int32_t p0, int32_t p1, int32_t p2, int32_t p3, const RuntimeMethod* method);
// System.Void UnityEngine.Vector2Int::.ctor(System.Int32,System.Int32)
extern "C" IL2CPP_METHOD_ATTR void Vector2Int__ctor_m3872920888 (Vector2Int_t3469998543 * __this, int32_t p0, int32_t p1, const RuntimeMethod* method);
// System.Void UnityEngine.XR.ARExtensions.CameraImageConversionParams::.ctor(UnityEngine.XR.ARExtensions.CameraImage,UnityEngine.TextureFormat,UnityEngine.XR.ARExtensions.CameraImageTransformation)
extern "C" IL2CPP_METHOD_ATTR void CameraImageConversionParams__ctor_m3134443660 (CameraImageConversionParams_t1109674340 * __this, CameraImage_t2783787914  ___image0, int32_t ___format1, int32_t ___transformation2, const RuntimeMethod* method);
// UnityEngine.XR.ARExtensions.CameraImageTransformation UnityEngine.XR.ARExtensions.CameraImageConversionParams::get_transformation()
extern "C" IL2CPP_METHOD_ATTR int32_t CameraImageConversionParams_get_transformation_m4113259575 (CameraImageConversionParams_t1109674340 * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.Vector2Int::GetHashCode()
extern "C" IL2CPP_METHOD_ATTR int32_t Vector2Int_GetHashCode_m386852117 (Vector2Int_t3469998543 * __this, const RuntimeMethod* method);
// System.Int32 UnityEngine.XR.ARExtensions.CameraImageConversionParams::GetHashCode()
extern "C" IL2CPP_METHOD_ATTR int32_t CameraImageConversionParams_GetHashCode_m3192672850 (CameraImageConversionParams_t1109674340 * __this, const RuntimeMethod* method);
// System.Boolean UnityEngine.XR.ARExtensions.CameraImageConversionParams::Equals(UnityEngine.XR.ARExtensions.CameraImageConversionParams)
extern "C" IL2CPP_METHOD_ATTR bool CameraImageConversionParams_Equals_m237957486 (CameraImageConversionParams_t1109674340 * __this, CameraImageConversionParams_t1109674340  ___other0, const RuntimeMethod* method);
// System.Boolean UnityEngine.XR.ARExtensions.CameraImageConversionParams::Equals(System.Object)
extern "C" IL2CPP_METHOD_ATTR bool CameraImageConversionParams_Equals_m3483019339 (CameraImageConversionParams_t1109674340 * __this, RuntimeObject * ___obj0, const RuntimeMethod* method);
// System.String UnityEngine.XR.ARExtensions.CameraImageConversionParams::ToString()
extern "C" IL2CPP_METHOD_ATTR String_t* CameraImageConversionParams_ToString_m86635840 (CameraImageConversionParams_t1109674340 * __this, const RuntimeMethod* method);
// System.Boolean UnityEngine.Vector2Int::Equals(UnityEngine.Vector2Int)
extern "C" IL2CPP_METHOD_ATTR bool Vector2Int_Equals_m4037425851 (Vector2Int_t3469998543 * __this, Vector2Int_t3469998543  p0, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2<System.String,System.Func`2<UnityEngine.Experimental.XR.XRCameraSubsystem,System.Boolean>>::.ctor()
inline void Dictionary_2__ctor_m555241001 (Dictionary_2_t2760358902 * __this, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_t2760358902 *, const RuntimeMethod*))Dictionary_2__ctor_m518943619_gshared)(__this, method);
}
// System.Void System.Collections.Generic.Dictionary`2<System.String,UnityEngine.XR.ARExtensions.XRCameraExtensions/TryGetColorCorrectionDelegate>::.ctor()
inline void Dictionary_2__ctor_m1771204320 (Dictionary_2_t820068610 * __this, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_t820068610 *, const RuntimeMethod*))Dictionary_2__ctor_m518943619_gshared)(__this, method);
}
// System.Void System.Collections.Generic.Dictionary`2<System.String,UnityEngine.XR.ARExtensions.ICameraImageApi>::.ctor()
inline void Dictionary_2__ctor_m3075159066 (Dictionary_2_t1871360775 * __this, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_t1871360775 *, const RuntimeMethod*))Dictionary_2__ctor_m518943619_gshared)(__this, method);
}
// System.Void UnityEngine.XR.ARExtensions.XRCameraExtensions/DefaultCameraImageApi::.ctor()
extern "C" IL2CPP_METHOD_ATTR void DefaultCameraImageApi__ctor_m1806158594 (DefaultCameraImageApi_t2442227313 * __this, const RuntimeMethod* method);
// System.Void UnityEngine.XR.ARExtensions.XRCameraExtensions::SetDefaultDelegates()
extern "C" IL2CPP_METHOD_ATTR void XRCameraExtensions_SetDefaultDelegates_m571765574 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2<System.String,System.Func`2<UnityEngine.Experimental.XR.XRCameraSubsystem,System.Boolean>>::set_Item(!0,!1)
inline void Dictionary_2_set_Item_m3849172357 (Dictionary_2_t2760358902 * __this, String_t* p0, Func_2_t2975102603 * p1, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_t2760358902 *, String_t*, Func_2_t2975102603 *, const RuntimeMethod*))Dictionary_2_set_Item_m3474379962_gshared)(__this, p0, p1, method);
}
// System.Void System.Collections.Generic.Dictionary`2<System.String,UnityEngine.XR.ARExtensions.ICameraImageApi>::set_Item(!0,!1)
inline void Dictionary_2_set_Item_m253421643 (Dictionary_2_t1871360775 * __this, String_t* p0, RuntimeObject* p1, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_t1871360775 *, String_t*, RuntimeObject*, const RuntimeMethod*))Dictionary_2_set_Item_m3474379962_gshared)(__this, p0, p1, method);
}
// System.Void System.ArgumentNullException::.ctor(System.String)
extern "C" IL2CPP_METHOD_ATTR void ArgumentNullException__ctor_m1170824041 (ArgumentNullException_t1615371798 * __this, String_t* p0, const RuntimeMethod* method);
// System.Boolean UnityEngine.XR.ARExtensions.XRCameraExtensions/TryGetColorCorrectionDelegate::Invoke(UnityEngine.Experimental.XR.XRCameraSubsystem,UnityEngine.Color&)
extern "C" IL2CPP_METHOD_ATTR bool TryGetColorCorrectionDelegate_Invoke_m442821292 (TryGetColorCorrectionDelegate_t1034812311 * __this, XRCameraSubsystem_t4195795144 * ___cameraSubsystems0, Color_t2555686324 * ___color1, const RuntimeMethod* method);
// !0 UnityEngine.Experimental.Subsystem`1<UnityEngine.Experimental.XR.XRCameraSubsystemDescriptor>::get_SubsystemDescriptor()
inline XRCameraSubsystemDescriptor_t3689383335 * Subsystem_1_get_SubsystemDescriptor_m441071667 (Subsystem_1_t588646725 * __this, const RuntimeMethod* method)
{
	return ((  XRCameraSubsystemDescriptor_t3689383335 * (*) (Subsystem_1_t588646725 *, const RuntimeMethod*))Subsystem_1_get_SubsystemDescriptor_m2291515923_gshared)(__this, method);
}
// System.String UnityEngine.Experimental.SubsystemDescriptorBase::get_id()
extern "C" IL2CPP_METHOD_ATTR String_t* SubsystemDescriptorBase_get_id_m893539935 (SubsystemDescriptorBase_t2374447182 * __this, const RuntimeMethod* method);
// System.Void System.Func`2<UnityEngine.Experimental.XR.XRCameraSubsystem,System.Boolean>::.ctor(System.Object,System.IntPtr)
inline void Func_2__ctor_m2608148365 (Func_2_t2975102603 * __this, RuntimeObject * p0, intptr_t p1, const RuntimeMethod* method)
{
	((  void (*) (Func_2_t2975102603 *, RuntimeObject *, intptr_t, const RuntimeMethod*))Func_2__ctor_m3104565095_gshared)(__this, p0, p1, method);
}
// TValue UnityEngine.XR.ARExtensions.RegistrationHelper::GetValueOrDefault<System.String,System.Func`2<UnityEngine.Experimental.XR.XRCameraSubsystem,System.Boolean>>(System.Collections.Generic.Dictionary`2<TKey,TValue>,TKey,TValue)
inline Func_2_t2975102603 * RegistrationHelper_GetValueOrDefault_TisString_t_TisFunc_2_t2975102603_m2306524290 (RuntimeObject * __this /* static, unused */, Dictionary_2_t2760358902 * ___dictionary0, String_t* ___key1, Func_2_t2975102603 * ___defaultValue2, const RuntimeMethod* method)
{
	return ((  Func_2_t2975102603 * (*) (RuntimeObject * /* static, unused */, Dictionary_2_t2760358902 *, String_t*, Func_2_t2975102603 *, const RuntimeMethod*))RegistrationHelper_GetValueOrDefault_TisRuntimeObject_TisRuntimeObject_m2689764471_gshared)(__this /* static, unused */, ___dictionary0, ___key1, ___defaultValue2, method);
}
// System.Void UnityEngine.XR.ARExtensions.XRCameraExtensions/TryGetColorCorrectionDelegate::.ctor(System.Object,System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR void TryGetColorCorrectionDelegate__ctor_m3211817899 (TryGetColorCorrectionDelegate_t1034812311 * __this, RuntimeObject * ___object0, intptr_t ___method1, const RuntimeMethod* method);
// TValue UnityEngine.XR.ARExtensions.RegistrationHelper::GetValueOrDefault<System.String,UnityEngine.XR.ARExtensions.XRCameraExtensions/TryGetColorCorrectionDelegate>(System.Collections.Generic.Dictionary`2<TKey,TValue>,TKey,TValue)
inline TryGetColorCorrectionDelegate_t1034812311 * RegistrationHelper_GetValueOrDefault_TisString_t_TisTryGetColorCorrectionDelegate_t1034812311_m3517983076 (RuntimeObject * __this /* static, unused */, Dictionary_2_t820068610 * ___dictionary0, String_t* ___key1, TryGetColorCorrectionDelegate_t1034812311 * ___defaultValue2, const RuntimeMethod* method)
{
	return ((  TryGetColorCorrectionDelegate_t1034812311 * (*) (RuntimeObject * /* static, unused */, Dictionary_2_t820068610 *, String_t*, TryGetColorCorrectionDelegate_t1034812311 *, const RuntimeMethod*))RegistrationHelper_GetValueOrDefault_TisRuntimeObject_TisRuntimeObject_m2689764471_gshared)(__this /* static, unused */, ___dictionary0, ___key1, ___defaultValue2, method);
}
// TValue UnityEngine.XR.ARExtensions.RegistrationHelper::GetValueOrDefault<System.String,UnityEngine.XR.ARExtensions.ICameraImageApi>(System.Collections.Generic.Dictionary`2<TKey,TValue>,TKey,TValue)
inline RuntimeObject* RegistrationHelper_GetValueOrDefault_TisString_t_TisICameraImageApi_t2086104476_m2420324886 (RuntimeObject * __this /* static, unused */, Dictionary_2_t1871360775 * ___dictionary0, String_t* ___key1, RuntimeObject* ___defaultValue2, const RuntimeMethod* method)
{
	return ((  RuntimeObject* (*) (RuntimeObject * /* static, unused */, Dictionary_2_t1871360775 *, String_t*, RuntimeObject*, const RuntimeMethod*))RegistrationHelper_GetValueOrDefault_TisRuntimeObject_TisRuntimeObject_m2689764471_gshared)(__this /* static, unused */, ___dictionary0, ___key1, ___defaultValue2, method);
}
// System.Void System.Object::.ctor()
extern "C" IL2CPP_METHOD_ATTR void Object__ctor_m297566312 (RuntimeObject * __this, const RuntimeMethod* method);
// System.Void UnityEngine.XR.ARExtensions.XRCameraExtensions/OnImageRequestCompleteDelegate::Invoke(UnityEngine.XR.ARExtensions.AsyncCameraImageConversionStatus,UnityEngine.XR.ARExtensions.CameraImageConversionParams,System.IntPtr,System.Int32,System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR void OnImageRequestCompleteDelegate_Invoke_m2486581279 (OnImageRequestCompleteDelegate_t4025953918 * __this, int32_t ___status0, CameraImageConversionParams_t1109674340  ___conversionParams1, intptr_t ___dataPtr2, int32_t ___dataLength3, intptr_t ___context4, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2<System.String,System.Func`3<UnityEngine.Experimental.XR.XRPlaneSubsystem,UnityEngine.Experimental.XR.TrackableId,UnityEngine.Experimental.XR.TrackingState>>::.ctor()
inline void Dictionary_2__ctor_m2975023327 (Dictionary_2_t2706875346 * __this, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_t2706875346 *, const RuntimeMethod*))Dictionary_2__ctor_m518943619_gshared)(__this, method);
}
// System.Void UnityEngine.XR.ARExtensions.XRPlaneExtensions::SetDefaultDelegates()
extern "C" IL2CPP_METHOD_ATTR void XRPlaneExtensions_SetDefaultDelegates_m3956413843 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2<System.String,System.Func`3<UnityEngine.Experimental.XR.XRPlaneSubsystem,UnityEngine.Experimental.XR.TrackableId,UnityEngine.Experimental.XR.TrackingState>>::set_Item(!0,!1)
inline void Dictionary_2_set_Item_m3827254201 (Dictionary_2_t2706875346 * __this, String_t* p0, Func_3_t2921619047 * p1, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_t2706875346 *, String_t*, Func_3_t2921619047 *, const RuntimeMethod*))Dictionary_2_set_Item_m3474379962_gshared)(__this, p0, p1, method);
}
// !2 System.Func`3<UnityEngine.Experimental.XR.XRPlaneSubsystem,UnityEngine.Experimental.XR.TrackableId,UnityEngine.Experimental.XR.TrackingState>::Invoke(!0,!1)
inline int32_t Func_3_Invoke_m2530530313 (Func_3_t2921619047 * __this, XRPlaneSubsystem_t2260142932 * p0, TrackableId_t1251031970  p1, const RuntimeMethod* method)
{
	return ((  int32_t (*) (Func_3_t2921619047 *, XRPlaneSubsystem_t2260142932 *, TrackableId_t1251031970 , const RuntimeMethod*))Func_3_Invoke_m50126256_gshared)(__this, p0, p1, method);
}
// !0 UnityEngine.Experimental.Subsystem`1<UnityEngine.Experimental.XR.XRPlaneSubsystemDescriptor>::get_SubsystemDescriptor()
inline XRPlaneSubsystemDescriptor_t234166304 * Subsystem_1_get_SubsystemDescriptor_m2169025228 (Subsystem_1_t1428396990 * __this, const RuntimeMethod* method)
{
	return ((  XRPlaneSubsystemDescriptor_t234166304 * (*) (Subsystem_1_t1428396990 *, const RuntimeMethod*))Subsystem_1_get_SubsystemDescriptor_m2291515923_gshared)(__this, method);
}
// System.Void System.Func`3<UnityEngine.Experimental.XR.XRPlaneSubsystem,UnityEngine.Experimental.XR.TrackableId,UnityEngine.Experimental.XR.TrackingState>::.ctor(System.Object,System.IntPtr)
inline void Func_3__ctor_m1014428649 (Func_3_t2921619047 * __this, RuntimeObject * p0, intptr_t p1, const RuntimeMethod* method)
{
	((  void (*) (Func_3_t2921619047 *, RuntimeObject *, intptr_t, const RuntimeMethod*))Func_3__ctor_m1590389318_gshared)(__this, p0, p1, method);
}
// TValue UnityEngine.XR.ARExtensions.RegistrationHelper::GetValueOrDefault<System.String,System.Func`3<UnityEngine.Experimental.XR.XRPlaneSubsystem,UnityEngine.Experimental.XR.TrackableId,UnityEngine.Experimental.XR.TrackingState>>(System.Collections.Generic.Dictionary`2<TKey,TValue>,TKey,TValue)
inline Func_3_t2921619047 * RegistrationHelper_GetValueOrDefault_TisString_t_TisFunc_3_t2921619047_m1497402927 (RuntimeObject * __this /* static, unused */, Dictionary_2_t2706875346 * ___dictionary0, String_t* ___key1, Func_3_t2921619047 * ___defaultValue2, const RuntimeMethod* method)
{
	return ((  Func_3_t2921619047 * (*) (RuntimeObject * /* static, unused */, Dictionary_2_t2706875346 *, String_t*, Func_3_t2921619047 *, const RuntimeMethod*))RegistrationHelper_GetValueOrDefault_TisRuntimeObject_TisRuntimeObject_m2689764471_gshared)(__this /* static, unused */, ___dictionary0, ___key1, ___defaultValue2, method);
}
// System.Void System.Collections.Generic.Dictionary`2<System.String,UnityEngine.XR.ARExtensions.XRReferencePointExtensions/AttachReferencePointDelegate>::.ctor()
inline void Dictionary_2__ctor_m49728138 (Dictionary_2_t204178958 * __this, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_t204178958 *, const RuntimeMethod*))Dictionary_2__ctor_m518943619_gshared)(__this, method);
}
// System.Void UnityEngine.XR.ARExtensions.XRReferencePointExtensions::SetDefaultDelegates()
extern "C" IL2CPP_METHOD_ATTR void XRReferencePointExtensions_SetDefaultDelegates_m4188249370 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2<System.String,UnityEngine.XR.ARExtensions.XRReferencePointExtensions/AttachReferencePointDelegate>::set_Item(!0,!1)
inline void Dictionary_2_set_Item_m3033294665 (Dictionary_2_t204178958 * __this, String_t* p0, AttachReferencePointDelegate_t418922659 * p1, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_t204178958 *, String_t*, AttachReferencePointDelegate_t418922659 *, const RuntimeMethod*))Dictionary_2_set_Item_m3474379962_gshared)(__this, p0, p1, method);
}
// UnityEngine.Experimental.XR.TrackableId UnityEngine.XR.ARExtensions.XRReferencePointExtensions/AttachReferencePointDelegate::Invoke(UnityEngine.Experimental.XR.XRReferencePointSubsystem,UnityEngine.Experimental.XR.TrackableId,UnityEngine.Pose)
extern "C" IL2CPP_METHOD_ATTR TrackableId_t1251031970  AttachReferencePointDelegate_Invoke_m3134245136 (AttachReferencePointDelegate_t418922659 * __this, XRReferencePointSubsystem_t416875062 * ___referencePointSubsystem0, TrackableId_t1251031970  ___trackableId1, Pose_t545244865  ___pose2, const RuntimeMethod* method);
// UnityEngine.Experimental.XR.TrackableId UnityEngine.Experimental.XR.TrackableId::get_InvalidId()
extern "C" IL2CPP_METHOD_ATTR TrackableId_t1251031970  TrackableId_get_InvalidId_m4062814271 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method);
// !0 UnityEngine.Experimental.Subsystem`1<UnityEngine.Experimental.XR.XRReferencePointSubsystemDescriptor>::get_SubsystemDescriptor()
inline XRReferencePointSubsystemDescriptor_t1659547698 * Subsystem_1_get_SubsystemDescriptor_m3649074082 (Subsystem_1_t2853778384 * __this, const RuntimeMethod* method)
{
	return ((  XRReferencePointSubsystemDescriptor_t1659547698 * (*) (Subsystem_1_t2853778384 *, const RuntimeMethod*))Subsystem_1_get_SubsystemDescriptor_m2291515923_gshared)(__this, method);
}
// System.Void UnityEngine.XR.ARExtensions.XRReferencePointExtensions/AttachReferencePointDelegate::.ctor(System.Object,System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR void AttachReferencePointDelegate__ctor_m3040356846 (AttachReferencePointDelegate_t418922659 * __this, RuntimeObject * ___object0, intptr_t ___method1, const RuntimeMethod* method);
// TValue UnityEngine.XR.ARExtensions.RegistrationHelper::GetValueOrDefault<System.String,UnityEngine.XR.ARExtensions.XRReferencePointExtensions/AttachReferencePointDelegate>(System.Collections.Generic.Dictionary`2<TKey,TValue>,TKey,TValue)
inline AttachReferencePointDelegate_t418922659 * RegistrationHelper_GetValueOrDefault_TisString_t_TisAttachReferencePointDelegate_t418922659_m850717648 (RuntimeObject * __this /* static, unused */, Dictionary_2_t204178958 * ___dictionary0, String_t* ___key1, AttachReferencePointDelegate_t418922659 * ___defaultValue2, const RuntimeMethod* method)
{
	return ((  AttachReferencePointDelegate_t418922659 * (*) (RuntimeObject * /* static, unused */, Dictionary_2_t204178958 *, String_t*, AttachReferencePointDelegate_t418922659 *, const RuntimeMethod*))RegistrationHelper_GetValueOrDefault_TisRuntimeObject_TisRuntimeObject_m2689764471_gshared)(__this /* static, unused */, ___dictionary0, ___key1, ___defaultValue2, method);
}
// System.Void System.Collections.Generic.Dictionary`2<System.String,UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionInstallationStatus>>::.ctor()
inline void Dictionary_2__ctor_m1921437841 (Dictionary_2_t757416466 * __this, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_t757416466 *, const RuntimeMethod*))Dictionary_2__ctor_m518943619_gshared)(__this, method);
}
// System.Void System.Collections.Generic.Dictionary`2<System.String,UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionAvailability>>::.ctor()
inline void Dictionary_2__ctor_m383910843 (Dictionary_2_t3245361703 * __this, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_t3245361703 *, const RuntimeMethod*))Dictionary_2__ctor_m518943619_gshared)(__this, method);
}
// System.Void UnityEngine.XR.ARExtensions.XRSessionExtensions::SetDefaultDelegates()
extern "C" IL2CPP_METHOD_ATTR void XRSessionExtensions_SetDefaultDelegates_m2570236516 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2<System.String,UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionAvailability>>::set_Item(!0,!1)
inline void Dictionary_2_set_Item_m2124544062 (Dictionary_2_t3245361703 * __this, String_t* p0, AsyncDelegate_1_t3460105404 * p1, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_t3245361703 *, String_t*, AsyncDelegate_1_t3460105404 *, const RuntimeMethod*))Dictionary_2_set_Item_m3474379962_gshared)(__this, p0, p1, method);
}
// UnityEngine.XR.ARExtensions.Promise`1<T> UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionAvailability>::Invoke(UnityEngine.Experimental.XR.XRSessionSubsystem)
inline Promise_1_t3923167537 * AsyncDelegate_1_Invoke_m1924773735 (AsyncDelegate_1_t3460105404 * __this, XRSessionSubsystem_t3616338244 * p0, const RuntimeMethod* method)
{
	return ((  Promise_1_t3923167537 * (*) (AsyncDelegate_1_t3460105404 *, XRSessionSubsystem_t3616338244 *, const RuntimeMethod*))AsyncDelegate_1_Invoke_m1924773735_gshared)(__this, p0, method);
}
// UnityEngine.XR.ARExtensions.Promise`1<T> UnityEngine.XR.ARExtensions.Promise`1<UnityEngine.XR.ARExtensions.SessionAvailability>::CreateResolvedPromise(T)
inline Promise_1_t3923167537 * Promise_1_CreateResolvedPromise_m420313478 (RuntimeObject * __this /* static, unused */, int32_t p0, const RuntimeMethod* method)
{
	return ((  Promise_1_t3923167537 * (*) (RuntimeObject * /* static, unused */, int32_t, const RuntimeMethod*))Promise_1_CreateResolvedPromise_m420313478_gshared)(__this /* static, unused */, p0, method);
}
// UnityEngine.XR.ARExtensions.Promise`1<T> UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionInstallationStatus>::Invoke(UnityEngine.Experimental.XR.XRSessionSubsystem)
inline Promise_1_t1435222300 * AsyncDelegate_1_Invoke_m723727912 (AsyncDelegate_1_t972160167 * __this, XRSessionSubsystem_t3616338244 * p0, const RuntimeMethod* method)
{
	return ((  Promise_1_t1435222300 * (*) (AsyncDelegate_1_t972160167 *, XRSessionSubsystem_t3616338244 *, const RuntimeMethod*))AsyncDelegate_1_Invoke_m723727912_gshared)(__this, p0, method);
}
// UnityEngine.XR.ARExtensions.Promise`1<T> UnityEngine.XR.ARExtensions.Promise`1<UnityEngine.XR.ARExtensions.SessionInstallationStatus>::CreateResolvedPromise(T)
inline Promise_1_t1435222300 * Promise_1_CreateResolvedPromise_m3838876404 (RuntimeObject * __this /* static, unused */, int32_t p0, const RuntimeMethod* method)
{
	return ((  Promise_1_t1435222300 * (*) (RuntimeObject * /* static, unused */, int32_t, const RuntimeMethod*))Promise_1_CreateResolvedPromise_m3838876404_gshared)(__this /* static, unused */, p0, method);
}
// !0 UnityEngine.Experimental.Subsystem`1<UnityEngine.Experimental.XR.XRSessionSubsystemDescriptor>::get_SubsystemDescriptor()
inline XRSessionSubsystemDescriptor_t1188836047 * Subsystem_1_get_SubsystemDescriptor_m1208900687 (Subsystem_1_t2383066733 * __this, const RuntimeMethod* method)
{
	return ((  XRSessionSubsystemDescriptor_t1188836047 * (*) (Subsystem_1_t2383066733 *, const RuntimeMethod*))Subsystem_1_get_SubsystemDescriptor_m2291515923_gshared)(__this, method);
}
// System.Void UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionInstallationStatus>::.ctor(System.Object,System.IntPtr)
inline void AsyncDelegate_1__ctor_m2374002471 (AsyncDelegate_1_t972160167 * __this, RuntimeObject * p0, intptr_t p1, const RuntimeMethod* method)
{
	((  void (*) (AsyncDelegate_1_t972160167 *, RuntimeObject *, intptr_t, const RuntimeMethod*))AsyncDelegate_1__ctor_m2374002471_gshared)(__this, p0, p1, method);
}
// TValue UnityEngine.XR.ARExtensions.RegistrationHelper::GetValueOrDefault<System.String,UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionInstallationStatus>>(System.Collections.Generic.Dictionary`2<TKey,TValue>,TKey,TValue)
inline AsyncDelegate_1_t972160167 * RegistrationHelper_GetValueOrDefault_TisString_t_TisAsyncDelegate_1_t972160167_m3126187069 (RuntimeObject * __this /* static, unused */, Dictionary_2_t757416466 * ___dictionary0, String_t* ___key1, AsyncDelegate_1_t972160167 * ___defaultValue2, const RuntimeMethod* method)
{
	return ((  AsyncDelegate_1_t972160167 * (*) (RuntimeObject * /* static, unused */, Dictionary_2_t757416466 *, String_t*, AsyncDelegate_1_t972160167 *, const RuntimeMethod*))RegistrationHelper_GetValueOrDefault_TisRuntimeObject_TisRuntimeObject_m2689764471_gshared)(__this /* static, unused */, ___dictionary0, ___key1, ___defaultValue2, method);
}
// System.Void UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionAvailability>::.ctor(System.Object,System.IntPtr)
inline void AsyncDelegate_1__ctor_m1054827699 (AsyncDelegate_1_t3460105404 * __this, RuntimeObject * p0, intptr_t p1, const RuntimeMethod* method)
{
	((  void (*) (AsyncDelegate_1_t3460105404 *, RuntimeObject *, intptr_t, const RuntimeMethod*))AsyncDelegate_1__ctor_m1054827699_gshared)(__this, p0, p1, method);
}
// TValue UnityEngine.XR.ARExtensions.RegistrationHelper::GetValueOrDefault<System.String,UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionAvailability>>(System.Collections.Generic.Dictionary`2<TKey,TValue>,TKey,TValue)
inline AsyncDelegate_1_t3460105404 * RegistrationHelper_GetValueOrDefault_TisString_t_TisAsyncDelegate_1_t3460105404_m3679850741 (RuntimeObject * __this /* static, unused */, Dictionary_2_t3245361703 * ___dictionary0, String_t* ___key1, AsyncDelegate_1_t3460105404 * ___defaultValue2, const RuntimeMethod* method)
{
	return ((  AsyncDelegate_1_t3460105404 * (*) (RuntimeObject * /* static, unused */, Dictionary_2_t3245361703 *, String_t*, AsyncDelegate_1_t3460105404 *, const RuntimeMethod*))RegistrationHelper_GetValueOrDefault_TisRuntimeObject_TisRuntimeObject_m2689764471_gshared)(__this /* static, unused */, ___dictionary0, ___key1, ___defaultValue2, method);
}
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: UnityEngine.XR.ARExtensions.CameraImage
extern "C" void CameraImage_t2783787914_marshal_pinvoke(const CameraImage_t2783787914& unmarshaled, CameraImage_t2783787914_marshaled_pinvoke& marshaled)
{
	Exception_t* ___m_CameraImageApi_5Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_CameraImageApi' of type 'CameraImage': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_CameraImageApi_5Exception, NULL, NULL);
}
extern "C" void CameraImage_t2783787914_marshal_pinvoke_back(const CameraImage_t2783787914_marshaled_pinvoke& marshaled, CameraImage_t2783787914& unmarshaled)
{
	Exception_t* ___m_CameraImageApi_5Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_CameraImageApi' of type 'CameraImage': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_CameraImageApi_5Exception, NULL, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.XR.ARExtensions.CameraImage
extern "C" void CameraImage_t2783787914_marshal_pinvoke_cleanup(CameraImage_t2783787914_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: UnityEngine.XR.ARExtensions.CameraImage
extern "C" void CameraImage_t2783787914_marshal_com(const CameraImage_t2783787914& unmarshaled, CameraImage_t2783787914_marshaled_com& marshaled)
{
	Exception_t* ___m_CameraImageApi_5Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_CameraImageApi' of type 'CameraImage': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_CameraImageApi_5Exception, NULL, NULL);
}
extern "C" void CameraImage_t2783787914_marshal_com_back(const CameraImage_t2783787914_marshaled_com& marshaled, CameraImage_t2783787914& unmarshaled)
{
	Exception_t* ___m_CameraImageApi_5Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'm_CameraImageApi' of type 'CameraImage': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___m_CameraImageApi_5Exception, NULL, NULL);
}
// Conversion method for clean up from marshalling of: UnityEngine.XR.ARExtensions.CameraImage
extern "C" void CameraImage_t2783787914_marshal_com_cleanup(CameraImage_t2783787914_marshaled_com& marshaled)
{
}
extern "C" void DEFAULT_CALL ReversePInvokeWrapper_CameraImage_OnAsyncConversionComplete_m926397238(int32_t ___status0, CameraImageConversionParams_t1109674340  ___conversionParams1, intptr_t ___dataPtr2, int32_t ___dataLength3, intptr_t ___context4)
{
	il2cpp::vm::ScopedThreadAttacher _vmThreadHelper;

	// Managed method invocation
	CameraImage_OnAsyncConversionComplete_m926397238(NULL, ___status0, ___conversionParams1, ___dataPtr2, ___dataLength3, ___context4, NULL);

}
// System.Void UnityEngine.XR.ARExtensions.CameraImage::.cctor()
extern "C" IL2CPP_METHOD_ATTR void CameraImage__cctor_m3767963604 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CameraImage__cctor_m3767963604_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		intptr_t L_0 = (intptr_t)CameraImage_OnAsyncConversionComplete_m926397238_RuntimeMethod_var;
		OnImageRequestCompleteDelegate_t4025953918 * L_1 = (OnImageRequestCompleteDelegate_t4025953918 *)il2cpp_codegen_object_new(OnImageRequestCompleteDelegate_t4025953918_il2cpp_TypeInfo_var);
		OnImageRequestCompleteDelegate__ctor_m979042311(L_1, NULL, (intptr_t)L_0, /*hidden argument*/NULL);
		((CameraImage_t2783787914_StaticFields*)il2cpp_codegen_static_fields_for(CameraImage_t2783787914_il2cpp_TypeInfo_var))->set_s_OnAsyncConversionComplete_6(L_1);
		return;
	}
}
// System.Void UnityEngine.XR.ARExtensions.CameraImage::.ctor(UnityEngine.XR.ARExtensions.ICameraImageApi,System.Int32,UnityEngine.Vector2Int,System.Int32,System.Double,UnityEngine.XR.ARExtensions.CameraImageFormat)
extern "C" IL2CPP_METHOD_ATTR void CameraImage__ctor_m1119229678 (CameraImage_t2783787914 * __this, RuntimeObject* ___cameraImageApi0, int32_t ___nativeHandle1, Vector2Int_t3469998543  ___dimensions2, int32_t ___planeCount3, double ___timestamp4, int32_t ___format5, const RuntimeMethod* method)
{
	{
		RuntimeObject* L_0 = ___cameraImageApi0;
		__this->set_m_CameraImageApi_5(L_0);
		int32_t L_1 = ___nativeHandle1;
		__this->set_m_NativeHandle_4(L_1);
		Vector2Int_t3469998543  L_2 = ___dimensions2;
		CameraImage_set_dimensions_m3621924320((CameraImage_t2783787914 *)__this, L_2, /*hidden argument*/NULL);
		int32_t L_3 = ___planeCount3;
		CameraImage_set_planeCount_m2171489124((CameraImage_t2783787914 *)__this, L_3, /*hidden argument*/NULL);
		double L_4 = ___timestamp4;
		CameraImage_set_timestamp_m2915797604((CameraImage_t2783787914 *)__this, L_4, /*hidden argument*/NULL);
		int32_t L_5 = ___format5;
		CameraImage_set_format_m1974516519((CameraImage_t2783787914 *)__this, L_5, /*hidden argument*/NULL);
		return;
	}
}
extern "C"  void CameraImage__ctor_m1119229678_AdjustorThunk (RuntimeObject * __this, RuntimeObject* ___cameraImageApi0, int32_t ___nativeHandle1, Vector2Int_t3469998543  ___dimensions2, int32_t ___planeCount3, double ___timestamp4, int32_t ___format5, const RuntimeMethod* method)
{
	CameraImage_t2783787914 * _thisAdjusted = reinterpret_cast<CameraImage_t2783787914 *>(__this + 1);
	CameraImage__ctor_m1119229678(_thisAdjusted, ___cameraImageApi0, ___nativeHandle1, ___dimensions2, ___planeCount3, ___timestamp4, ___format5, method);
}
// UnityEngine.Vector2Int UnityEngine.XR.ARExtensions.CameraImage::get_dimensions()
extern "C" IL2CPP_METHOD_ATTR Vector2Int_t3469998543  CameraImage_get_dimensions_m4235814331 (CameraImage_t2783787914 * __this, const RuntimeMethod* method)
{
	{
		Vector2Int_t3469998543  L_0 = __this->get_U3CdimensionsU3Ek__BackingField_0();
		return L_0;
	}
}
extern "C"  Vector2Int_t3469998543  CameraImage_get_dimensions_m4235814331_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	CameraImage_t2783787914 * _thisAdjusted = reinterpret_cast<CameraImage_t2783787914 *>(__this + 1);
	return CameraImage_get_dimensions_m4235814331(_thisAdjusted, method);
}
// System.Void UnityEngine.XR.ARExtensions.CameraImage::set_dimensions(UnityEngine.Vector2Int)
extern "C" IL2CPP_METHOD_ATTR void CameraImage_set_dimensions_m3621924320 (CameraImage_t2783787914 * __this, Vector2Int_t3469998543  ___value0, const RuntimeMethod* method)
{
	{
		Vector2Int_t3469998543  L_0 = ___value0;
		__this->set_U3CdimensionsU3Ek__BackingField_0(L_0);
		return;
	}
}
extern "C"  void CameraImage_set_dimensions_m3621924320_AdjustorThunk (RuntimeObject * __this, Vector2Int_t3469998543  ___value0, const RuntimeMethod* method)
{
	CameraImage_t2783787914 * _thisAdjusted = reinterpret_cast<CameraImage_t2783787914 *>(__this + 1);
	CameraImage_set_dimensions_m3621924320(_thisAdjusted, ___value0, method);
}
// System.Int32 UnityEngine.XR.ARExtensions.CameraImage::get_width()
extern "C" IL2CPP_METHOD_ATTR int32_t CameraImage_get_width_m3669078563 (CameraImage_t2783787914 * __this, const RuntimeMethod* method)
{
	Vector2Int_t3469998543  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		Vector2Int_t3469998543  L_0 = CameraImage_get_dimensions_m4235814331((CameraImage_t2783787914 *)__this, /*hidden argument*/NULL);
		V_0 = L_0;
		int32_t L_1 = Vector2Int_get_x_m64542184((Vector2Int_t3469998543 *)(&V_0), /*hidden argument*/NULL);
		return L_1;
	}
}
extern "C"  int32_t CameraImage_get_width_m3669078563_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	CameraImage_t2783787914 * _thisAdjusted = reinterpret_cast<CameraImage_t2783787914 *>(__this + 1);
	return CameraImage_get_width_m3669078563(_thisAdjusted, method);
}
// System.Int32 UnityEngine.XR.ARExtensions.CameraImage::get_height()
extern "C" IL2CPP_METHOD_ATTR int32_t CameraImage_get_height_m1383532788 (CameraImage_t2783787914 * __this, const RuntimeMethod* method)
{
	Vector2Int_t3469998543  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		Vector2Int_t3469998543  L_0 = CameraImage_get_dimensions_m4235814331((CameraImage_t2783787914 *)__this, /*hidden argument*/NULL);
		V_0 = L_0;
		int32_t L_1 = Vector2Int_get_y_m64542185((Vector2Int_t3469998543 *)(&V_0), /*hidden argument*/NULL);
		return L_1;
	}
}
extern "C"  int32_t CameraImage_get_height_m1383532788_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	CameraImage_t2783787914 * _thisAdjusted = reinterpret_cast<CameraImage_t2783787914 *>(__this + 1);
	return CameraImage_get_height_m1383532788(_thisAdjusted, method);
}
// System.Int32 UnityEngine.XR.ARExtensions.CameraImage::get_planeCount()
extern "C" IL2CPP_METHOD_ATTR int32_t CameraImage_get_planeCount_m208301076 (CameraImage_t2783787914 * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get_U3CplaneCountU3Ek__BackingField_1();
		return L_0;
	}
}
extern "C"  int32_t CameraImage_get_planeCount_m208301076_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	CameraImage_t2783787914 * _thisAdjusted = reinterpret_cast<CameraImage_t2783787914 *>(__this + 1);
	return CameraImage_get_planeCount_m208301076(_thisAdjusted, method);
}
// System.Void UnityEngine.XR.ARExtensions.CameraImage::set_planeCount(System.Int32)
extern "C" IL2CPP_METHOD_ATTR void CameraImage_set_planeCount_m2171489124 (CameraImage_t2783787914 * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		int32_t L_0 = ___value0;
		__this->set_U3CplaneCountU3Ek__BackingField_1(L_0);
		return;
	}
}
extern "C"  void CameraImage_set_planeCount_m2171489124_AdjustorThunk (RuntimeObject * __this, int32_t ___value0, const RuntimeMethod* method)
{
	CameraImage_t2783787914 * _thisAdjusted = reinterpret_cast<CameraImage_t2783787914 *>(__this + 1);
	CameraImage_set_planeCount_m2171489124(_thisAdjusted, ___value0, method);
}
// UnityEngine.XR.ARExtensions.CameraImageFormat UnityEngine.XR.ARExtensions.CameraImage::get_format()
extern "C" IL2CPP_METHOD_ATTR int32_t CameraImage_get_format_m2457822911 (CameraImage_t2783787914 * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get_U3CformatU3Ek__BackingField_2();
		return L_0;
	}
}
extern "C"  int32_t CameraImage_get_format_m2457822911_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	CameraImage_t2783787914 * _thisAdjusted = reinterpret_cast<CameraImage_t2783787914 *>(__this + 1);
	return CameraImage_get_format_m2457822911(_thisAdjusted, method);
}
// System.Void UnityEngine.XR.ARExtensions.CameraImage::set_format(UnityEngine.XR.ARExtensions.CameraImageFormat)
extern "C" IL2CPP_METHOD_ATTR void CameraImage_set_format_m1974516519 (CameraImage_t2783787914 * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		int32_t L_0 = ___value0;
		__this->set_U3CformatU3Ek__BackingField_2(L_0);
		return;
	}
}
extern "C"  void CameraImage_set_format_m1974516519_AdjustorThunk (RuntimeObject * __this, int32_t ___value0, const RuntimeMethod* method)
{
	CameraImage_t2783787914 * _thisAdjusted = reinterpret_cast<CameraImage_t2783787914 *>(__this + 1);
	CameraImage_set_format_m1974516519(_thisAdjusted, ___value0, method);
}
// System.Double UnityEngine.XR.ARExtensions.CameraImage::get_timestamp()
extern "C" IL2CPP_METHOD_ATTR double CameraImage_get_timestamp_m1267159734 (CameraImage_t2783787914 * __this, const RuntimeMethod* method)
{
	{
		double L_0 = __this->get_U3CtimestampU3Ek__BackingField_3();
		return L_0;
	}
}
extern "C"  double CameraImage_get_timestamp_m1267159734_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	CameraImage_t2783787914 * _thisAdjusted = reinterpret_cast<CameraImage_t2783787914 *>(__this + 1);
	return CameraImage_get_timestamp_m1267159734(_thisAdjusted, method);
}
// System.Void UnityEngine.XR.ARExtensions.CameraImage::set_timestamp(System.Double)
extern "C" IL2CPP_METHOD_ATTR void CameraImage_set_timestamp_m2915797604 (CameraImage_t2783787914 * __this, double ___value0, const RuntimeMethod* method)
{
	{
		double L_0 = ___value0;
		__this->set_U3CtimestampU3Ek__BackingField_3(L_0);
		return;
	}
}
extern "C"  void CameraImage_set_timestamp_m2915797604_AdjustorThunk (RuntimeObject * __this, double ___value0, const RuntimeMethod* method)
{
	CameraImage_t2783787914 * _thisAdjusted = reinterpret_cast<CameraImage_t2783787914 *>(__this + 1);
	CameraImage_set_timestamp_m2915797604(_thisAdjusted, ___value0, method);
}
// System.Boolean UnityEngine.XR.ARExtensions.CameraImage::get_valid()
extern "C" IL2CPP_METHOD_ATTR bool CameraImage_get_valid_m1506925116 (CameraImage_t2783787914 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CameraImage_get_valid_m1506925116_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		RuntimeObject* L_0 = __this->get_m_CameraImageApi_5();
		if (L_0)
		{
			goto IL_000d;
		}
	}
	{
		return (bool)0;
	}

IL_000d:
	{
		RuntimeObject* L_1 = __this->get_m_CameraImageApi_5();
		int32_t L_2 = __this->get_m_NativeHandle_4();
		NullCheck(L_1);
		bool L_3 = InterfaceFuncInvoker1< bool, int32_t >::Invoke(2 /* System.Boolean UnityEngine.XR.ARExtensions.ICameraImageApi::NativeHandleValid(System.Int32) */, ICameraImageApi_t2086104476_il2cpp_TypeInfo_var, L_1, L_2);
		return L_3;
	}
}
extern "C"  bool CameraImage_get_valid_m1506925116_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	CameraImage_t2783787914 * _thisAdjusted = reinterpret_cast<CameraImage_t2783787914 *>(__this + 1);
	return CameraImage_get_valid_m1506925116(_thisAdjusted, method);
}
// System.Boolean UnityEngine.XR.ARExtensions.CameraImage::FormatSupported(UnityEngine.TextureFormat)
extern "C" IL2CPP_METHOD_ATTR bool CameraImage_FormatSupported_m2095457754 (RuntimeObject * __this /* static, unused */, int32_t ___format0, const RuntimeMethod* method)
{
	{
		int32_t L_0 = ___format0;
		switch (((int32_t)il2cpp_codegen_subtract((int32_t)L_0, (int32_t)1)))
		{
			case 0:
			{
				goto IL_0031;
			}
			case 1:
			{
				goto IL_001c;
			}
			case 2:
			{
				goto IL_0031;
			}
			case 3:
			{
				goto IL_0031;
			}
			case 4:
			{
				goto IL_0031;
			}
		}
	}

IL_001c:
	{
		int32_t L_1 = ___format0;
		if ((((int32_t)L_1) == ((int32_t)((int32_t)14))))
		{
			goto IL_0031;
		}
	}
	{
		int32_t L_2 = ___format0;
		if ((((int32_t)L_2) == ((int32_t)((int32_t)63))))
		{
			goto IL_0031;
		}
	}
	{
		goto IL_0033;
	}

IL_0031:
	{
		return (bool)1;
	}

IL_0033:
	{
		return (bool)0;
	}
}
// System.Int32 UnityEngine.XR.ARExtensions.CameraImage::GetConvertedDataSize(UnityEngine.Vector2Int,UnityEngine.TextureFormat)
extern "C" IL2CPP_METHOD_ATTR int32_t CameraImage_GetConvertedDataSize_m1842015692 (CameraImage_t2783787914 * __this, Vector2Int_t3469998543  ___dimensions0, int32_t ___format1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CameraImage_GetConvertedDataSize_m1842015692_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Vector2Int_t3469998543  V_0;
	memset(&V_0, 0, sizeof(V_0));
	Vector2Int_t3469998543  V_1;
	memset(&V_1, 0, sizeof(V_1));
	Vector2Int_t3469998543  V_2;
	memset(&V_2, 0, sizeof(V_2));
	Vector2Int_t3469998543  V_3;
	memset(&V_3, 0, sizeof(V_3));
	int32_t V_4 = 0;
	{
		CameraImage_ValidateNativeHandleAndThrow_m654558893((CameraImage_t2783787914 *)__this, /*hidden argument*/NULL);
		int32_t L_0 = Vector2Int_get_x_m64542184((Vector2Int_t3469998543 *)(&___dimensions0), /*hidden argument*/NULL);
		Vector2Int_t3469998543  L_1 = CameraImage_get_dimensions_m4235814331((CameraImage_t2783787914 *)__this, /*hidden argument*/NULL);
		V_0 = L_1;
		int32_t L_2 = Vector2Int_get_x_m64542184((Vector2Int_t3469998543 *)(&V_0), /*hidden argument*/NULL);
		if ((((int32_t)L_0) <= ((int32_t)L_2)))
		{
			goto IL_0054;
		}
	}
	{
		int32_t L_3 = Vector2Int_get_x_m64542184((Vector2Int_t3469998543 *)(&___dimensions0), /*hidden argument*/NULL);
		int32_t L_4 = L_3;
		RuntimeObject * L_5 = Box(Int32_t2950945753_il2cpp_TypeInfo_var, &L_4);
		Vector2Int_t3469998543  L_6 = CameraImage_get_dimensions_m4235814331((CameraImage_t2783787914 *)__this, /*hidden argument*/NULL);
		V_1 = L_6;
		int32_t L_7 = Vector2Int_get_x_m64542184((Vector2Int_t3469998543 *)(&V_1), /*hidden argument*/NULL);
		int32_t L_8 = L_7;
		RuntimeObject * L_9 = Box(Int32_t2950945753_il2cpp_TypeInfo_var, &L_8);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_10 = String_Format_m2556382932(NULL /*static, unused*/, _stringLiteral2494539934, L_5, L_9, /*hidden argument*/NULL);
		ArgumentOutOfRangeException_t777629997 * L_11 = (ArgumentOutOfRangeException_t777629997 *)il2cpp_codegen_object_new(ArgumentOutOfRangeException_t777629997_il2cpp_TypeInfo_var);
		ArgumentOutOfRangeException__ctor_m282481429(L_11, _stringLiteral1910834845, L_10, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_11, NULL, CameraImage_GetConvertedDataSize_m1842015692_RuntimeMethod_var);
	}

IL_0054:
	{
		int32_t L_12 = Vector2Int_get_y_m64542185((Vector2Int_t3469998543 *)(&___dimensions0), /*hidden argument*/NULL);
		Vector2Int_t3469998543  L_13 = CameraImage_get_dimensions_m4235814331((CameraImage_t2783787914 *)__this, /*hidden argument*/NULL);
		V_2 = L_13;
		int32_t L_14 = Vector2Int_get_y_m64542185((Vector2Int_t3469998543 *)(&V_2), /*hidden argument*/NULL);
		if ((((int32_t)L_12) <= ((int32_t)L_14)))
		{
			goto IL_00a2;
		}
	}
	{
		int32_t L_15 = Vector2Int_get_y_m64542185((Vector2Int_t3469998543 *)(&___dimensions0), /*hidden argument*/NULL);
		int32_t L_16 = L_15;
		RuntimeObject * L_17 = Box(Int32_t2950945753_il2cpp_TypeInfo_var, &L_16);
		Vector2Int_t3469998543  L_18 = CameraImage_get_dimensions_m4235814331((CameraImage_t2783787914 *)__this, /*hidden argument*/NULL);
		V_3 = L_18;
		int32_t L_19 = Vector2Int_get_y_m64542185((Vector2Int_t3469998543 *)(&V_3), /*hidden argument*/NULL);
		int32_t L_20 = L_19;
		RuntimeObject * L_21 = Box(Int32_t2950945753_il2cpp_TypeInfo_var, &L_20);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_22 = String_Format_m2556382932(NULL /*static, unused*/, _stringLiteral176405713, L_17, L_21, /*hidden argument*/NULL);
		ArgumentOutOfRangeException_t777629997 * L_23 = (ArgumentOutOfRangeException_t777629997 *)il2cpp_codegen_object_new(ArgumentOutOfRangeException_t777629997_il2cpp_TypeInfo_var);
		ArgumentOutOfRangeException__ctor_m282481429(L_23, _stringLiteral452723731, L_22, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_23, NULL, CameraImage_GetConvertedDataSize_m1842015692_RuntimeMethod_var);
	}

IL_00a2:
	{
		int32_t L_24 = ___format1;
		IL2CPP_RUNTIME_CLASS_INIT(CameraImage_t2783787914_il2cpp_TypeInfo_var);
		bool L_25 = CameraImage_FormatSupported_m2095457754(NULL /*static, unused*/, L_24, /*hidden argument*/NULL);
		if (L_25)
		{
			goto IL_00bd;
		}
	}
	{
		ArgumentException_t132251570 * L_26 = (ArgumentException_t132251570 *)il2cpp_codegen_object_new(ArgumentException_t132251570_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m1216717135(L_26, _stringLiteral2063443799, _stringLiteral446157247, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_26, NULL, CameraImage_GetConvertedDataSize_m1842015692_RuntimeMethod_var);
	}

IL_00bd:
	{
		RuntimeObject* L_27 = __this->get_m_CameraImageApi_5();
		int32_t L_28 = __this->get_m_NativeHandle_4();
		Vector2Int_t3469998543  L_29 = ___dimensions0;
		int32_t L_30 = ___format1;
		NullCheck(L_27);
		bool L_31 = InterfaceFuncInvoker4< bool, int32_t, Vector2Int_t3469998543 , int32_t, int32_t* >::Invoke(3 /* System.Boolean UnityEngine.XR.ARExtensions.ICameraImageApi::TryGetConvertedDataSize(System.Int32,UnityEngine.Vector2Int,UnityEngine.TextureFormat,System.Int32&) */, ICameraImageApi_t2086104476_il2cpp_TypeInfo_var, L_27, L_28, L_29, L_30, (int32_t*)(&V_4));
		if (L_31)
		{
			goto IL_00e2;
		}
	}
	{
		InvalidOperationException_t56020091 * L_32 = (InvalidOperationException_t56020091 *)il2cpp_codegen_object_new(InvalidOperationException_t56020091_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m237278729(L_32, _stringLiteral3461447331, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_32, NULL, CameraImage_GetConvertedDataSize_m1842015692_RuntimeMethod_var);
	}

IL_00e2:
	{
		int32_t L_33 = V_4;
		return L_33;
	}
}
extern "C"  int32_t CameraImage_GetConvertedDataSize_m1842015692_AdjustorThunk (RuntimeObject * __this, Vector2Int_t3469998543  ___dimensions0, int32_t ___format1, const RuntimeMethod* method)
{
	CameraImage_t2783787914 * _thisAdjusted = reinterpret_cast<CameraImage_t2783787914 *>(__this + 1);
	return CameraImage_GetConvertedDataSize_m1842015692(_thisAdjusted, ___dimensions0, ___format1, method);
}
// System.Int32 UnityEngine.XR.ARExtensions.CameraImage::GetConvertedDataSize(UnityEngine.XR.ARExtensions.CameraImageConversionParams)
extern "C" IL2CPP_METHOD_ATTR int32_t CameraImage_GetConvertedDataSize_m850245283 (CameraImage_t2783787914 * __this, CameraImageConversionParams_t1109674340  ___conversionParams0, const RuntimeMethod* method)
{
	{
		Vector2Int_t3469998543  L_0 = CameraImageConversionParams_get_outputDimensions_m158549880((CameraImageConversionParams_t1109674340 *)(&___conversionParams0), /*hidden argument*/NULL);
		int32_t L_1 = CameraImageConversionParams_get_outputFormat_m780098116((CameraImageConversionParams_t1109674340 *)(&___conversionParams0), /*hidden argument*/NULL);
		int32_t L_2 = CameraImage_GetConvertedDataSize_m1842015692((CameraImage_t2783787914 *)__this, L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
extern "C"  int32_t CameraImage_GetConvertedDataSize_m850245283_AdjustorThunk (RuntimeObject * __this, CameraImageConversionParams_t1109674340  ___conversionParams0, const RuntimeMethod* method)
{
	CameraImage_t2783787914 * _thisAdjusted = reinterpret_cast<CameraImage_t2783787914 *>(__this + 1);
	return CameraImage_GetConvertedDataSize_m850245283(_thisAdjusted, ___conversionParams0, method);
}
// System.Void UnityEngine.XR.ARExtensions.CameraImage::Convert(UnityEngine.XR.ARExtensions.CameraImageConversionParams,System.IntPtr,System.Int32)
extern "C" IL2CPP_METHOD_ATTR void CameraImage_Convert_m2059105726 (CameraImage_t2783787914 * __this, CameraImageConversionParams_t1109674340  ___conversionParams0, intptr_t ___destinationBuffer1, int32_t ___bufferLength2, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CameraImage_Convert_m2059105726_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	{
		CameraImage_ValidateNativeHandleAndThrow_m654558893((CameraImage_t2783787914 *)__this, /*hidden argument*/NULL);
		CameraImageConversionParams_t1109674340  L_0 = ___conversionParams0;
		CameraImage_ValidateConversionParamsAndThrow_m1179966680((CameraImage_t2783787914 *)__this, L_0, /*hidden argument*/NULL);
		CameraImageConversionParams_t1109674340  L_1 = ___conversionParams0;
		int32_t L_2 = CameraImage_GetConvertedDataSize_m850245283((CameraImage_t2783787914 *)__this, L_1, /*hidden argument*/NULL);
		V_0 = L_2;
		int32_t L_3 = ___bufferLength2;
		int32_t L_4 = V_0;
		if ((((int32_t)L_3) >= ((int32_t)L_4)))
		{
			goto IL_0038;
		}
	}
	{
		int32_t L_5 = V_0;
		int32_t L_6 = L_5;
		RuntimeObject * L_7 = Box(Int32_t2950945753_il2cpp_TypeInfo_var, &L_6);
		int32_t L_8 = ___bufferLength2;
		int32_t L_9 = L_8;
		RuntimeObject * L_10 = Box(Int32_t2950945753_il2cpp_TypeInfo_var, &L_9);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_11 = String_Format_m2556382932(NULL /*static, unused*/, _stringLiteral863398240, L_7, L_10, /*hidden argument*/NULL);
		InvalidOperationException_t56020091 * L_12 = (InvalidOperationException_t56020091 *)il2cpp_codegen_object_new(InvalidOperationException_t56020091_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m237278729(L_12, L_11, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_12, NULL, CameraImage_Convert_m2059105726_RuntimeMethod_var);
	}

IL_0038:
	{
		RuntimeObject* L_13 = __this->get_m_CameraImageApi_5();
		int32_t L_14 = __this->get_m_NativeHandle_4();
		CameraImageConversionParams_t1109674340  L_15 = ___conversionParams0;
		intptr_t L_16 = ___destinationBuffer1;
		int32_t L_17 = ___bufferLength2;
		NullCheck(L_13);
		bool L_18 = InterfaceFuncInvoker4< bool, int32_t, CameraImageConversionParams_t1109674340 , intptr_t, int32_t >::Invoke(4 /* System.Boolean UnityEngine.XR.ARExtensions.ICameraImageApi::TryConvert(System.Int32,UnityEngine.XR.ARExtensions.CameraImageConversionParams,System.IntPtr,System.Int32) */, ICameraImageApi_t2086104476_il2cpp_TypeInfo_var, L_13, L_14, L_15, (intptr_t)L_16, L_17);
		if (L_18)
		{
			goto IL_005c;
		}
	}
	{
		InvalidOperationException_t56020091 * L_19 = (InvalidOperationException_t56020091 *)il2cpp_codegen_object_new(InvalidOperationException_t56020091_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m237278729(L_19, _stringLiteral772053088, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_19, NULL, CameraImage_Convert_m2059105726_RuntimeMethod_var);
	}

IL_005c:
	{
		return;
	}
}
extern "C"  void CameraImage_Convert_m2059105726_AdjustorThunk (RuntimeObject * __this, CameraImageConversionParams_t1109674340  ___conversionParams0, intptr_t ___destinationBuffer1, int32_t ___bufferLength2, const RuntimeMethod* method)
{
	CameraImage_t2783787914 * _thisAdjusted = reinterpret_cast<CameraImage_t2783787914 *>(__this + 1);
	CameraImage_Convert_m2059105726(_thisAdjusted, ___conversionParams0, ___destinationBuffer1, ___bufferLength2, method);
}
// System.Void UnityEngine.XR.ARExtensions.CameraImage::OnAsyncConversionComplete(UnityEngine.XR.ARExtensions.AsyncCameraImageConversionStatus,UnityEngine.XR.ARExtensions.CameraImageConversionParams,System.IntPtr,System.Int32,System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR void CameraImage_OnAsyncConversionComplete_m926397238 (RuntimeObject * __this /* static, unused */, int32_t ___status0, CameraImageConversionParams_t1109674340  ___conversionParams1, intptr_t ___dataPtr2, int32_t ___dataLength3, intptr_t ___context4, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CameraImage_OnAsyncConversionComplete_m926397238_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	GCHandle_t3351438187  V_0;
	memset(&V_0, 0, sizeof(V_0));
	Action_3_t3607487754 * V_1 = NULL;
	NativeArray_1_t1421029094  V_2;
	memset(&V_2, 0, sizeof(V_2));
	{
		intptr_t L_0 = ___context4;
		GCHandle_t3351438187  L_1 = GCHandle_FromIntPtr_m3880792486(NULL /*static, unused*/, (intptr_t)L_0, /*hidden argument*/NULL);
		V_0 = L_1;
		RuntimeObject * L_2 = GCHandle_get_Target_m1824973883((GCHandle_t3351438187 *)(&V_0), /*hidden argument*/NULL);
		V_1 = ((Action_3_t3607487754 *)CastclassSealed((RuntimeObject*)L_2, Action_3_t3607487754_il2cpp_TypeInfo_var));
		Action_3_t3607487754 * L_3 = V_1;
		if (!L_3)
		{
			goto IL_0032;
		}
	}
	{
		intptr_t L_4 = ___dataPtr2;
		void* L_5 = IntPtr_op_Explicit_m2520637223(NULL /*static, unused*/, (intptr_t)L_4, /*hidden argument*/NULL);
		int32_t L_6 = ___dataLength3;
		NativeArray_1_t1421029094  L_7 = NativeArrayUnsafeUtility_ConvertExistingDataToNativeArray_TisByte_t1134296376_m990237749(NULL /*static, unused*/, (void*)(void*)L_5, L_6, 1, /*hidden argument*/NativeArrayUnsafeUtility_ConvertExistingDataToNativeArray_TisByte_t1134296376_m990237749_RuntimeMethod_var);
		V_2 = L_7;
		Action_3_t3607487754 * L_8 = V_1;
		int32_t L_9 = ___status0;
		CameraImageConversionParams_t1109674340  L_10 = ___conversionParams1;
		NativeArray_1_t1421029094  L_11 = V_2;
		NullCheck(L_8);
		Action_3_Invoke_m609172159(L_8, L_9, L_10, L_11, /*hidden argument*/Action_3_Invoke_m609172159_RuntimeMethod_var);
	}

IL_0032:
	{
		GCHandle_Free_m1457699368((GCHandle_t3351438187 *)(&V_0), /*hidden argument*/NULL);
		return;
	}
}
// System.Void UnityEngine.XR.ARExtensions.CameraImage::ValidateNativeHandleAndThrow()
extern "C" IL2CPP_METHOD_ATTR void CameraImage_ValidateNativeHandleAndThrow_m654558893 (CameraImage_t2783787914 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CameraImage_ValidateNativeHandleAndThrow_m654558893_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		bool L_0 = CameraImage_get_valid_m1506925116((CameraImage_t2783787914 *)__this, /*hidden argument*/NULL);
		if (L_0)
		{
			goto IL_0016;
		}
	}
	{
		InvalidOperationException_t56020091 * L_1 = (InvalidOperationException_t56020091 *)il2cpp_codegen_object_new(InvalidOperationException_t56020091_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m237278729(L_1, _stringLiteral3461447331, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1, NULL, CameraImage_ValidateNativeHandleAndThrow_m654558893_RuntimeMethod_var);
	}

IL_0016:
	{
		return;
	}
}
extern "C"  void CameraImage_ValidateNativeHandleAndThrow_m654558893_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	CameraImage_t2783787914 * _thisAdjusted = reinterpret_cast<CameraImage_t2783787914 *>(__this + 1);
	CameraImage_ValidateNativeHandleAndThrow_m654558893(_thisAdjusted, method);
}
// System.Void UnityEngine.XR.ARExtensions.CameraImage::ValidateConversionParamsAndThrow(UnityEngine.XR.ARExtensions.CameraImageConversionParams)
extern "C" IL2CPP_METHOD_ATTR void CameraImage_ValidateConversionParamsAndThrow_m1179966680 (CameraImage_t2783787914 * __this, CameraImageConversionParams_t1109674340  ___conversionParams0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CameraImage_ValidateConversionParamsAndThrow_m1179966680_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	RectInt_t1875739471  V_0;
	memset(&V_0, 0, sizeof(V_0));
	RectInt_t1875739471  V_1;
	memset(&V_1, 0, sizeof(V_1));
	RectInt_t1875739471  V_2;
	memset(&V_2, 0, sizeof(V_2));
	RectInt_t1875739471  V_3;
	memset(&V_3, 0, sizeof(V_3));
	Vector2Int_t3469998543  V_4;
	memset(&V_4, 0, sizeof(V_4));
	RectInt_t1875739471  V_5;
	memset(&V_5, 0, sizeof(V_5));
	Vector2Int_t3469998543  V_6;
	memset(&V_6, 0, sizeof(V_6));
	RectInt_t1875739471  V_7;
	memset(&V_7, 0, sizeof(V_7));
	Vector2Int_t3469998543  V_8;
	memset(&V_8, 0, sizeof(V_8));
	Vector2Int_t3469998543  V_9;
	memset(&V_9, 0, sizeof(V_9));
	RectInt_t1875739471  V_10;
	memset(&V_10, 0, sizeof(V_10));
	RectInt_t1875739471  V_11;
	memset(&V_11, 0, sizeof(V_11));
	{
		RectInt_t1875739471  L_0 = CameraImageConversionParams_get_inputRect_m2276433308((CameraImageConversionParams_t1109674340 *)(&___conversionParams0), /*hidden argument*/NULL);
		V_0 = L_0;
		int32_t L_1 = RectInt_get_x_m1197757818((RectInt_t1875739471 *)(&V_0), /*hidden argument*/NULL);
		RectInt_t1875739471  L_2 = CameraImageConversionParams_get_inputRect_m2276433308((CameraImageConversionParams_t1109674340 *)(&___conversionParams0), /*hidden argument*/NULL);
		V_1 = L_2;
		int32_t L_3 = RectInt_get_width_m521919353((RectInt_t1875739471 *)(&V_1), /*hidden argument*/NULL);
		int32_t L_4 = CameraImage_get_width_m3669078563((CameraImage_t2783787914 *)__this, /*hidden argument*/NULL);
		if ((((int32_t)((int32_t)il2cpp_codegen_add((int32_t)L_1, (int32_t)L_3))) > ((int32_t)L_4)))
		{
			goto IL_0054;
		}
	}
	{
		RectInt_t1875739471  L_5 = CameraImageConversionParams_get_inputRect_m2276433308((CameraImageConversionParams_t1109674340 *)(&___conversionParams0), /*hidden argument*/NULL);
		V_2 = L_5;
		int32_t L_6 = RectInt_get_y_m1197692282((RectInt_t1875739471 *)(&V_2), /*hidden argument*/NULL);
		RectInt_t1875739471  L_7 = CameraImageConversionParams_get_inputRect_m2276433308((CameraImageConversionParams_t1109674340 *)(&___conversionParams0), /*hidden argument*/NULL);
		V_3 = L_7;
		int32_t L_8 = RectInt_get_height_m3077408641((RectInt_t1875739471 *)(&V_3), /*hidden argument*/NULL);
		int32_t L_9 = CameraImage_get_height_m1383532788((CameraImage_t2783787914 *)__this, /*hidden argument*/NULL);
		if ((((int32_t)((int32_t)il2cpp_codegen_add((int32_t)L_6, (int32_t)L_8))) <= ((int32_t)L_9)))
		{
			goto IL_0064;
		}
	}

IL_0054:
	{
		ArgumentOutOfRangeException_t777629997 * L_10 = (ArgumentOutOfRangeException_t777629997 *)il2cpp_codegen_object_new(ArgumentOutOfRangeException_t777629997_il2cpp_TypeInfo_var);
		ArgumentOutOfRangeException__ctor_m282481429(L_10, _stringLiteral2514532075, _stringLiteral3838339713, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_10, NULL, CameraImage_ValidateConversionParamsAndThrow_m1179966680_RuntimeMethod_var);
	}

IL_0064:
	{
		Vector2Int_t3469998543  L_11 = CameraImageConversionParams_get_outputDimensions_m158549880((CameraImageConversionParams_t1109674340 *)(&___conversionParams0), /*hidden argument*/NULL);
		V_4 = L_11;
		int32_t L_12 = Vector2Int_get_x_m64542184((Vector2Int_t3469998543 *)(&V_4), /*hidden argument*/NULL);
		RectInt_t1875739471  L_13 = CameraImageConversionParams_get_inputRect_m2276433308((CameraImageConversionParams_t1109674340 *)(&___conversionParams0), /*hidden argument*/NULL);
		V_5 = L_13;
		int32_t L_14 = RectInt_get_width_m521919353((RectInt_t1875739471 *)(&V_5), /*hidden argument*/NULL);
		if ((((int32_t)L_12) > ((int32_t)L_14)))
		{
			goto IL_00ae;
		}
	}
	{
		Vector2Int_t3469998543  L_15 = CameraImageConversionParams_get_outputDimensions_m158549880((CameraImageConversionParams_t1109674340 *)(&___conversionParams0), /*hidden argument*/NULL);
		V_6 = L_15;
		int32_t L_16 = Vector2Int_get_y_m64542185((Vector2Int_t3469998543 *)(&V_6), /*hidden argument*/NULL);
		RectInt_t1875739471  L_17 = CameraImageConversionParams_get_inputRect_m2276433308((CameraImageConversionParams_t1109674340 *)(&___conversionParams0), /*hidden argument*/NULL);
		V_7 = L_17;
		int32_t L_18 = RectInt_get_height_m3077408641((RectInt_t1875739471 *)(&V_7), /*hidden argument*/NULL);
		if ((((int32_t)L_16) <= ((int32_t)L_18)))
		{
			goto IL_0124;
		}
	}

IL_00ae:
	{
		ObjectU5BU5D_t2843939325* L_19 = (ObjectU5BU5D_t2843939325*)SZArrayNew(ObjectU5BU5D_t2843939325_il2cpp_TypeInfo_var, (uint32_t)4);
		ObjectU5BU5D_t2843939325* L_20 = L_19;
		Vector2Int_t3469998543  L_21 = CameraImageConversionParams_get_outputDimensions_m158549880((CameraImageConversionParams_t1109674340 *)(&___conversionParams0), /*hidden argument*/NULL);
		V_8 = L_21;
		int32_t L_22 = Vector2Int_get_x_m64542184((Vector2Int_t3469998543 *)(&V_8), /*hidden argument*/NULL);
		int32_t L_23 = L_22;
		RuntimeObject * L_24 = Box(Int32_t2950945753_il2cpp_TypeInfo_var, &L_23);
		NullCheck(L_20);
		ArrayElementTypeCheck (L_20, L_24);
		(L_20)->SetAt(static_cast<il2cpp_array_size_t>(0), (RuntimeObject *)L_24);
		ObjectU5BU5D_t2843939325* L_25 = L_20;
		Vector2Int_t3469998543  L_26 = CameraImageConversionParams_get_outputDimensions_m158549880((CameraImageConversionParams_t1109674340 *)(&___conversionParams0), /*hidden argument*/NULL);
		V_9 = L_26;
		int32_t L_27 = Vector2Int_get_y_m64542185((Vector2Int_t3469998543 *)(&V_9), /*hidden argument*/NULL);
		int32_t L_28 = L_27;
		RuntimeObject * L_29 = Box(Int32_t2950945753_il2cpp_TypeInfo_var, &L_28);
		NullCheck(L_25);
		ArrayElementTypeCheck (L_25, L_29);
		(L_25)->SetAt(static_cast<il2cpp_array_size_t>(1), (RuntimeObject *)L_29);
		ObjectU5BU5D_t2843939325* L_30 = L_25;
		RectInt_t1875739471  L_31 = CameraImageConversionParams_get_inputRect_m2276433308((CameraImageConversionParams_t1109674340 *)(&___conversionParams0), /*hidden argument*/NULL);
		V_10 = L_31;
		int32_t L_32 = RectInt_get_width_m521919353((RectInt_t1875739471 *)(&V_10), /*hidden argument*/NULL);
		int32_t L_33 = L_32;
		RuntimeObject * L_34 = Box(Int32_t2950945753_il2cpp_TypeInfo_var, &L_33);
		NullCheck(L_30);
		ArrayElementTypeCheck (L_30, L_34);
		(L_30)->SetAt(static_cast<il2cpp_array_size_t>(2), (RuntimeObject *)L_34);
		ObjectU5BU5D_t2843939325* L_35 = L_30;
		RectInt_t1875739471  L_36 = CameraImageConversionParams_get_inputRect_m2276433308((CameraImageConversionParams_t1109674340 *)(&___conversionParams0), /*hidden argument*/NULL);
		V_11 = L_36;
		int32_t L_37 = RectInt_get_height_m3077408641((RectInt_t1875739471 *)(&V_11), /*hidden argument*/NULL);
		int32_t L_38 = L_37;
		RuntimeObject * L_39 = Box(Int32_t2950945753_il2cpp_TypeInfo_var, &L_38);
		NullCheck(L_35);
		ArrayElementTypeCheck (L_35, L_39);
		(L_35)->SetAt(static_cast<il2cpp_array_size_t>(3), (RuntimeObject *)L_39);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_40 = String_Format_m630303134(NULL /*static, unused*/, _stringLiteral2209503435, L_35, /*hidden argument*/NULL);
		InvalidOperationException_t56020091 * L_41 = (InvalidOperationException_t56020091 *)il2cpp_codegen_object_new(InvalidOperationException_t56020091_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m237278729(L_41, L_40, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_41, NULL, CameraImage_ValidateConversionParamsAndThrow_m1179966680_RuntimeMethod_var);
	}

IL_0124:
	{
		int32_t L_42 = CameraImageConversionParams_get_outputFormat_m780098116((CameraImageConversionParams_t1109674340 *)(&___conversionParams0), /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(CameraImage_t2783787914_il2cpp_TypeInfo_var);
		bool L_43 = CameraImage_FormatSupported_m2095457754(NULL /*static, unused*/, L_42, /*hidden argument*/NULL);
		if (L_43)
		{
			goto IL_0145;
		}
	}
	{
		ArgumentException_t132251570 * L_44 = (ArgumentException_t132251570 *)il2cpp_codegen_object_new(ArgumentException_t132251570_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m1216717135(L_44, _stringLiteral613811463, _stringLiteral3045809767, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_44, NULL, CameraImage_ValidateConversionParamsAndThrow_m1179966680_RuntimeMethod_var);
	}

IL_0145:
	{
		return;
	}
}
extern "C"  void CameraImage_ValidateConversionParamsAndThrow_m1179966680_AdjustorThunk (RuntimeObject * __this, CameraImageConversionParams_t1109674340  ___conversionParams0, const RuntimeMethod* method)
{
	CameraImage_t2783787914 * _thisAdjusted = reinterpret_cast<CameraImage_t2783787914 *>(__this + 1);
	CameraImage_ValidateConversionParamsAndThrow_m1179966680(_thisAdjusted, ___conversionParams0, method);
}
// System.Void UnityEngine.XR.ARExtensions.CameraImage::Dispose()
extern "C" IL2CPP_METHOD_ATTR void CameraImage_Dispose_m1566295269 (CameraImage_t2783787914 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CameraImage_Dispose_m1566295269_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		RuntimeObject* L_0 = __this->get_m_CameraImageApi_5();
		if (!L_0)
		{
			goto IL_0016;
		}
	}
	{
		int32_t L_1 = __this->get_m_NativeHandle_4();
		if (L_1)
		{
			goto IL_0017;
		}
	}

IL_0016:
	{
		return;
	}

IL_0017:
	{
		RuntimeObject* L_2 = __this->get_m_CameraImageApi_5();
		int32_t L_3 = __this->get_m_NativeHandle_4();
		NullCheck(L_2);
		InterfaceActionInvoker1< int32_t >::Invoke(0 /* System.Void UnityEngine.XR.ARExtensions.ICameraImageApi::DisposeImage(System.Int32) */, ICameraImageApi_t2086104476_il2cpp_TypeInfo_var, L_2, L_3);
		__this->set_m_NativeHandle_4(0);
		__this->set_m_CameraImageApi_5((RuntimeObject*)NULL);
		return;
	}
}
extern "C"  void CameraImage_Dispose_m1566295269_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	CameraImage_t2783787914 * _thisAdjusted = reinterpret_cast<CameraImage_t2783787914 *>(__this + 1);
	CameraImage_Dispose_m1566295269(_thisAdjusted, method);
}
// System.Int32 UnityEngine.XR.ARExtensions.CameraImage::GetHashCode()
extern "C" IL2CPP_METHOD_ATTR int32_t CameraImage_GetHashCode_m1730928199 (CameraImage_t2783787914 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CameraImage_GetHashCode_m1730928199_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	int32_t V_4 = 0;
	{
		int32_t L_0 = CameraImage_get_width_m3669078563((CameraImage_t2783787914 *)__this, /*hidden argument*/NULL);
		V_1 = L_0;
		int32_t L_1 = Int32_GetHashCode_m1876651407((int32_t*)(&V_1), /*hidden argument*/NULL);
		V_0 = L_1;
		int32_t L_2 = V_0;
		int32_t L_3 = CameraImage_get_height_m1383532788((CameraImage_t2783787914 *)__this, /*hidden argument*/NULL);
		V_2 = L_3;
		int32_t L_4 = Int32_GetHashCode_m1876651407((int32_t*)(&V_2), /*hidden argument*/NULL);
		V_0 = ((int32_t)il2cpp_codegen_add((int32_t)((int32_t)il2cpp_codegen_multiply((int32_t)L_2, (int32_t)((int32_t)486187739))), (int32_t)L_4));
		int32_t L_5 = V_0;
		int32_t L_6 = CameraImage_get_planeCount_m208301076((CameraImage_t2783787914 *)__this, /*hidden argument*/NULL);
		V_3 = L_6;
		int32_t L_7 = Int32_GetHashCode_m1876651407((int32_t*)(&V_3), /*hidden argument*/NULL);
		V_0 = ((int32_t)il2cpp_codegen_add((int32_t)((int32_t)il2cpp_codegen_multiply((int32_t)L_5, (int32_t)((int32_t)486187739))), (int32_t)L_7));
		int32_t L_8 = V_0;
		int32_t* L_9 = __this->get_address_of_m_NativeHandle_4();
		int32_t L_10 = Int32_GetHashCode_m1876651407((int32_t*)L_9, /*hidden argument*/NULL);
		V_0 = ((int32_t)il2cpp_codegen_add((int32_t)((int32_t)il2cpp_codegen_multiply((int32_t)L_8, (int32_t)((int32_t)486187739))), (int32_t)L_10));
		int32_t L_11 = V_0;
		int32_t L_12 = CameraImage_get_format_m2457822911((CameraImage_t2783787914 *)__this, /*hidden argument*/NULL);
		V_4 = L_12;
		RuntimeObject * L_13 = Box(CameraImageFormat_t1966699832_il2cpp_TypeInfo_var, (&V_4));
		NullCheck(L_13);
		int32_t L_14 = VirtFuncInvoker0< int32_t >::Invoke(2 /* System.Int32 System.Object::GetHashCode() */, L_13);
		V_4 = *(int32_t*)UnBox(L_13);
		V_0 = ((int32_t)il2cpp_codegen_add((int32_t)((int32_t)il2cpp_codegen_multiply((int32_t)L_11, (int32_t)((int32_t)486187739))), (int32_t)L_14));
		RuntimeObject* L_15 = __this->get_m_CameraImageApi_5();
		if (!L_15)
		{
			goto IL_00a6;
		}
	}
	{
		int32_t L_16 = V_0;
		RuntimeObject* L_17 = __this->get_m_CameraImageApi_5();
		NullCheck(L_17);
		int32_t L_18 = VirtFuncInvoker0< int32_t >::Invoke(2 /* System.Int32 System.Object::GetHashCode() */, L_17);
		V_0 = ((int32_t)il2cpp_codegen_add((int32_t)((int32_t)il2cpp_codegen_multiply((int32_t)L_16, (int32_t)((int32_t)486187739))), (int32_t)L_18));
	}

IL_00a6:
	{
		int32_t L_19 = V_0;
		return L_19;
	}
}
extern "C"  int32_t CameraImage_GetHashCode_m1730928199_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	CameraImage_t2783787914 * _thisAdjusted = reinterpret_cast<CameraImage_t2783787914 *>(__this + 1);
	return CameraImage_GetHashCode_m1730928199(_thisAdjusted, method);
}
// System.Boolean UnityEngine.XR.ARExtensions.CameraImage::Equals(System.Object)
extern "C" IL2CPP_METHOD_ATTR bool CameraImage_Equals_m3039677800 (CameraImage_t2783787914 * __this, RuntimeObject * ___obj0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CameraImage_Equals_m3039677800_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		RuntimeObject * L_0 = ___obj0;
		if (((RuntimeObject *)IsInstSealed((RuntimeObject*)L_0, CameraImage_t2783787914_il2cpp_TypeInfo_var)))
		{
			goto IL_000d;
		}
	}
	{
		return (bool)0;
	}

IL_000d:
	{
		RuntimeObject * L_1 = ___obj0;
		bool L_2 = CameraImage_Equals_m3715424145((CameraImage_t2783787914 *)__this, ((*(CameraImage_t2783787914 *)((CameraImage_t2783787914 *)UnBox(L_1, CameraImage_t2783787914_il2cpp_TypeInfo_var)))), /*hidden argument*/NULL);
		return L_2;
	}
}
extern "C"  bool CameraImage_Equals_m3039677800_AdjustorThunk (RuntimeObject * __this, RuntimeObject * ___obj0, const RuntimeMethod* method)
{
	CameraImage_t2783787914 * _thisAdjusted = reinterpret_cast<CameraImage_t2783787914 *>(__this + 1);
	return CameraImage_Equals_m3039677800(_thisAdjusted, ___obj0, method);
}
// System.String UnityEngine.XR.ARExtensions.CameraImage::ToString()
extern "C" IL2CPP_METHOD_ATTR String_t* CameraImage_ToString_m1993371729 (CameraImage_t2783787914 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CameraImage_ToString_m1993371729_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ObjectU5BU5D_t2843939325* L_0 = (ObjectU5BU5D_t2843939325*)SZArrayNew(ObjectU5BU5D_t2843939325_il2cpp_TypeInfo_var, (uint32_t)4);
		ObjectU5BU5D_t2843939325* L_1 = L_0;
		int32_t L_2 = CameraImage_get_width_m3669078563((CameraImage_t2783787914 *)__this, /*hidden argument*/NULL);
		int32_t L_3 = L_2;
		RuntimeObject * L_4 = Box(Int32_t2950945753_il2cpp_TypeInfo_var, &L_3);
		NullCheck(L_1);
		ArrayElementTypeCheck (L_1, L_4);
		(L_1)->SetAt(static_cast<il2cpp_array_size_t>(0), (RuntimeObject *)L_4);
		ObjectU5BU5D_t2843939325* L_5 = L_1;
		int32_t L_6 = CameraImage_get_height_m1383532788((CameraImage_t2783787914 *)__this, /*hidden argument*/NULL);
		int32_t L_7 = L_6;
		RuntimeObject * L_8 = Box(Int32_t2950945753_il2cpp_TypeInfo_var, &L_7);
		NullCheck(L_5);
		ArrayElementTypeCheck (L_5, L_8);
		(L_5)->SetAt(static_cast<il2cpp_array_size_t>(1), (RuntimeObject *)L_8);
		ObjectU5BU5D_t2843939325* L_9 = L_5;
		int32_t L_10 = CameraImage_get_planeCount_m208301076((CameraImage_t2783787914 *)__this, /*hidden argument*/NULL);
		int32_t L_11 = L_10;
		RuntimeObject * L_12 = Box(Int32_t2950945753_il2cpp_TypeInfo_var, &L_11);
		NullCheck(L_9);
		ArrayElementTypeCheck (L_9, L_12);
		(L_9)->SetAt(static_cast<il2cpp_array_size_t>(2), (RuntimeObject *)L_12);
		ObjectU5BU5D_t2843939325* L_13 = L_9;
		int32_t L_14 = CameraImage_get_format_m2457822911((CameraImage_t2783787914 *)__this, /*hidden argument*/NULL);
		int32_t L_15 = L_14;
		RuntimeObject * L_16 = Box(CameraImageFormat_t1966699832_il2cpp_TypeInfo_var, &L_15);
		NullCheck(L_13);
		ArrayElementTypeCheck (L_13, L_16);
		(L_13)->SetAt(static_cast<il2cpp_array_size_t>(3), (RuntimeObject *)L_16);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_17 = String_Format_m630303134(NULL /*static, unused*/, _stringLiteral1910914709, L_13, /*hidden argument*/NULL);
		return L_17;
	}
}
extern "C"  String_t* CameraImage_ToString_m1993371729_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	CameraImage_t2783787914 * _thisAdjusted = reinterpret_cast<CameraImage_t2783787914 *>(__this + 1);
	return CameraImage_ToString_m1993371729(_thisAdjusted, method);
}
// System.Boolean UnityEngine.XR.ARExtensions.CameraImage::Equals(UnityEngine.XR.ARExtensions.CameraImage)
extern "C" IL2CPP_METHOD_ATTR bool CameraImage_Equals_m3715424145 (CameraImage_t2783787914 * __this, CameraImage_t2783787914  ___other0, const RuntimeMethod* method)
{
	int32_t G_B7_0 = 0;
	{
		int32_t L_0 = CameraImage_get_width_m3669078563((CameraImage_t2783787914 *)__this, /*hidden argument*/NULL);
		int32_t L_1 = CameraImage_get_width_m3669078563((CameraImage_t2783787914 *)(&___other0), /*hidden argument*/NULL);
		if ((!(((uint32_t)L_0) == ((uint32_t)L_1))))
		{
			goto IL_006b;
		}
	}
	{
		int32_t L_2 = CameraImage_get_height_m1383532788((CameraImage_t2783787914 *)__this, /*hidden argument*/NULL);
		int32_t L_3 = CameraImage_get_height_m1383532788((CameraImage_t2783787914 *)(&___other0), /*hidden argument*/NULL);
		if ((!(((uint32_t)L_2) == ((uint32_t)L_3))))
		{
			goto IL_006b;
		}
	}
	{
		int32_t L_4 = CameraImage_get_planeCount_m208301076((CameraImage_t2783787914 *)__this, /*hidden argument*/NULL);
		int32_t L_5 = CameraImage_get_planeCount_m208301076((CameraImage_t2783787914 *)(&___other0), /*hidden argument*/NULL);
		if ((!(((uint32_t)L_4) == ((uint32_t)L_5))))
		{
			goto IL_006b;
		}
	}
	{
		int32_t L_6 = CameraImage_get_format_m2457822911((CameraImage_t2783787914 *)__this, /*hidden argument*/NULL);
		int32_t L_7 = CameraImage_get_format_m2457822911((CameraImage_t2783787914 *)(&___other0), /*hidden argument*/NULL);
		if ((!(((uint32_t)L_6) == ((uint32_t)L_7))))
		{
			goto IL_006b;
		}
	}
	{
		int32_t L_8 = __this->get_m_NativeHandle_4();
		int32_t L_9 = (&___other0)->get_m_NativeHandle_4();
		if ((!(((uint32_t)L_8) == ((uint32_t)L_9))))
		{
			goto IL_006b;
		}
	}
	{
		RuntimeObject* L_10 = __this->get_m_CameraImageApi_5();
		RuntimeObject* L_11 = (&___other0)->get_m_CameraImageApi_5();
		G_B7_0 = ((((RuntimeObject*)(RuntimeObject*)L_10) == ((RuntimeObject*)(RuntimeObject*)L_11))? 1 : 0);
		goto IL_006c;
	}

IL_006b:
	{
		G_B7_0 = 0;
	}

IL_006c:
	{
		return (bool)G_B7_0;
	}
}
extern "C"  bool CameraImage_Equals_m3715424145_AdjustorThunk (RuntimeObject * __this, CameraImage_t2783787914  ___other0, const RuntimeMethod* method)
{
	CameraImage_t2783787914 * _thisAdjusted = reinterpret_cast<CameraImage_t2783787914 *>(__this + 1);
	return CameraImage_Equals_m3715424145(_thisAdjusted, ___other0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.XR.ARExtensions.CameraImageConversionParams::.ctor(UnityEngine.XR.ARExtensions.CameraImage,UnityEngine.TextureFormat,UnityEngine.XR.ARExtensions.CameraImageTransformation)
extern "C" IL2CPP_METHOD_ATTR void CameraImageConversionParams__ctor_m3134443660 (CameraImageConversionParams_t1109674340 * __this, CameraImage_t2783787914  ___image0, int32_t ___format1, int32_t ___transformation2, const RuntimeMethod* method)
{
	{
		int32_t L_0 = CameraImage_get_width_m3669078563((CameraImage_t2783787914 *)(&___image0), /*hidden argument*/NULL);
		int32_t L_1 = CameraImage_get_height_m1383532788((CameraImage_t2783787914 *)(&___image0), /*hidden argument*/NULL);
		RectInt_t1875739471  L_2;
		memset(&L_2, 0, sizeof(L_2));
		RectInt__ctor_m1117080735((&L_2), 0, 0, L_0, L_1, /*hidden argument*/NULL);
		__this->set_m_InputRect_0(L_2);
		int32_t L_3 = CameraImage_get_width_m3669078563((CameraImage_t2783787914 *)(&___image0), /*hidden argument*/NULL);
		int32_t L_4 = CameraImage_get_height_m1383532788((CameraImage_t2783787914 *)(&___image0), /*hidden argument*/NULL);
		Vector2Int_t3469998543  L_5;
		memset(&L_5, 0, sizeof(L_5));
		Vector2Int__ctor_m3872920888((&L_5), L_3, L_4, /*hidden argument*/NULL);
		__this->set_m_OutputDimensions_1(L_5);
		int32_t L_6 = ___format1;
		__this->set_m_Format_2(L_6);
		int32_t L_7 = ___transformation2;
		__this->set_m_Transformation_3(L_7);
		return;
	}
}
extern "C"  void CameraImageConversionParams__ctor_m3134443660_AdjustorThunk (RuntimeObject * __this, CameraImage_t2783787914  ___image0, int32_t ___format1, int32_t ___transformation2, const RuntimeMethod* method)
{
	CameraImageConversionParams_t1109674340 * _thisAdjusted = reinterpret_cast<CameraImageConversionParams_t1109674340 *>(__this + 1);
	CameraImageConversionParams__ctor_m3134443660(_thisAdjusted, ___image0, ___format1, ___transformation2, method);
}
// UnityEngine.RectInt UnityEngine.XR.ARExtensions.CameraImageConversionParams::get_inputRect()
extern "C" IL2CPP_METHOD_ATTR RectInt_t1875739471  CameraImageConversionParams_get_inputRect_m2276433308 (CameraImageConversionParams_t1109674340 * __this, const RuntimeMethod* method)
{
	{
		RectInt_t1875739471  L_0 = __this->get_m_InputRect_0();
		return L_0;
	}
}
extern "C"  RectInt_t1875739471  CameraImageConversionParams_get_inputRect_m2276433308_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	CameraImageConversionParams_t1109674340 * _thisAdjusted = reinterpret_cast<CameraImageConversionParams_t1109674340 *>(__this + 1);
	return CameraImageConversionParams_get_inputRect_m2276433308(_thisAdjusted, method);
}
// UnityEngine.Vector2Int UnityEngine.XR.ARExtensions.CameraImageConversionParams::get_outputDimensions()
extern "C" IL2CPP_METHOD_ATTR Vector2Int_t3469998543  CameraImageConversionParams_get_outputDimensions_m158549880 (CameraImageConversionParams_t1109674340 * __this, const RuntimeMethod* method)
{
	{
		Vector2Int_t3469998543  L_0 = __this->get_m_OutputDimensions_1();
		return L_0;
	}
}
extern "C"  Vector2Int_t3469998543  CameraImageConversionParams_get_outputDimensions_m158549880_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	CameraImageConversionParams_t1109674340 * _thisAdjusted = reinterpret_cast<CameraImageConversionParams_t1109674340 *>(__this + 1);
	return CameraImageConversionParams_get_outputDimensions_m158549880(_thisAdjusted, method);
}
// UnityEngine.TextureFormat UnityEngine.XR.ARExtensions.CameraImageConversionParams::get_outputFormat()
extern "C" IL2CPP_METHOD_ATTR int32_t CameraImageConversionParams_get_outputFormat_m780098116 (CameraImageConversionParams_t1109674340 * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get_m_Format_2();
		return L_0;
	}
}
extern "C"  int32_t CameraImageConversionParams_get_outputFormat_m780098116_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	CameraImageConversionParams_t1109674340 * _thisAdjusted = reinterpret_cast<CameraImageConversionParams_t1109674340 *>(__this + 1);
	return CameraImageConversionParams_get_outputFormat_m780098116(_thisAdjusted, method);
}
// UnityEngine.XR.ARExtensions.CameraImageTransformation UnityEngine.XR.ARExtensions.CameraImageConversionParams::get_transformation()
extern "C" IL2CPP_METHOD_ATTR int32_t CameraImageConversionParams_get_transformation_m4113259575 (CameraImageConversionParams_t1109674340 * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get_m_Transformation_3();
		return L_0;
	}
}
extern "C"  int32_t CameraImageConversionParams_get_transformation_m4113259575_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	CameraImageConversionParams_t1109674340 * _thisAdjusted = reinterpret_cast<CameraImageConversionParams_t1109674340 *>(__this + 1);
	return CameraImageConversionParams_get_transformation_m4113259575(_thisAdjusted, method);
}
// System.Int32 UnityEngine.XR.ARExtensions.CameraImageConversionParams::GetHashCode()
extern "C" IL2CPP_METHOD_ATTR int32_t CameraImageConversionParams_GetHashCode_m3192672850 (CameraImageConversionParams_t1109674340 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CameraImageConversionParams_GetHashCode_m3192672850_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	RectInt_t1875739471  V_1;
	memset(&V_1, 0, sizeof(V_1));
	Vector2Int_t3469998543  V_2;
	memset(&V_2, 0, sizeof(V_2));
	int32_t V_3 = 0;
	int32_t V_4 = 0;
	{
		RectInt_t1875739471  L_0 = CameraImageConversionParams_get_inputRect_m2276433308((CameraImageConversionParams_t1109674340 *)__this, /*hidden argument*/NULL);
		V_1 = L_0;
		RuntimeObject * L_1 = Box(RectInt_t1875739471_il2cpp_TypeInfo_var, (&V_1));
		NullCheck(L_1);
		int32_t L_2 = VirtFuncInvoker0< int32_t >::Invoke(2 /* System.Int32 System.Object::GetHashCode() */, L_1);
		V_1 = *(RectInt_t1875739471 *)UnBox(L_1);
		V_0 = L_2;
		int32_t L_3 = V_0;
		Vector2Int_t3469998543  L_4 = CameraImageConversionParams_get_outputDimensions_m158549880((CameraImageConversionParams_t1109674340 *)__this, /*hidden argument*/NULL);
		V_2 = L_4;
		int32_t L_5 = Vector2Int_GetHashCode_m386852117((Vector2Int_t3469998543 *)(&V_2), /*hidden argument*/NULL);
		V_0 = ((int32_t)il2cpp_codegen_add((int32_t)((int32_t)il2cpp_codegen_multiply((int32_t)L_3, (int32_t)((int32_t)486187739))), (int32_t)L_5));
		int32_t L_6 = V_0;
		int32_t L_7 = CameraImageConversionParams_get_outputFormat_m780098116((CameraImageConversionParams_t1109674340 *)__this, /*hidden argument*/NULL);
		V_3 = L_7;
		RuntimeObject * L_8 = Box(TextureFormat_t2701165832_il2cpp_TypeInfo_var, (&V_3));
		NullCheck(L_8);
		int32_t L_9 = VirtFuncInvoker0< int32_t >::Invoke(2 /* System.Int32 System.Object::GetHashCode() */, L_8);
		V_3 = *(int32_t*)UnBox(L_8);
		V_0 = ((int32_t)il2cpp_codegen_add((int32_t)((int32_t)il2cpp_codegen_multiply((int32_t)L_6, (int32_t)((int32_t)486187739))), (int32_t)L_9));
		int32_t L_10 = V_0;
		int32_t L_11 = CameraImageConversionParams_get_transformation_m4113259575((CameraImageConversionParams_t1109674340 *)__this, /*hidden argument*/NULL);
		V_4 = L_11;
		RuntimeObject * L_12 = Box(CameraImageTransformation_t164605461_il2cpp_TypeInfo_var, (&V_4));
		NullCheck(L_12);
		int32_t L_13 = VirtFuncInvoker0< int32_t >::Invoke(2 /* System.Int32 System.Object::GetHashCode() */, L_12);
		V_4 = *(int32_t*)UnBox(L_12);
		V_0 = ((int32_t)il2cpp_codegen_add((int32_t)((int32_t)il2cpp_codegen_multiply((int32_t)L_10, (int32_t)((int32_t)486187739))), (int32_t)L_13));
		int32_t L_14 = V_0;
		return L_14;
	}
}
extern "C"  int32_t CameraImageConversionParams_GetHashCode_m3192672850_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	CameraImageConversionParams_t1109674340 * _thisAdjusted = reinterpret_cast<CameraImageConversionParams_t1109674340 *>(__this + 1);
	return CameraImageConversionParams_GetHashCode_m3192672850(_thisAdjusted, method);
}
// System.Boolean UnityEngine.XR.ARExtensions.CameraImageConversionParams::Equals(System.Object)
extern "C" IL2CPP_METHOD_ATTR bool CameraImageConversionParams_Equals_m3483019339 (CameraImageConversionParams_t1109674340 * __this, RuntimeObject * ___obj0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CameraImageConversionParams_Equals_m3483019339_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		RuntimeObject * L_0 = ___obj0;
		if (((RuntimeObject *)IsInstSealed((RuntimeObject*)L_0, CameraImageConversionParams_t1109674340_il2cpp_TypeInfo_var)))
		{
			goto IL_000d;
		}
	}
	{
		return (bool)0;
	}

IL_000d:
	{
		RuntimeObject * L_1 = ___obj0;
		bool L_2 = CameraImageConversionParams_Equals_m237957486((CameraImageConversionParams_t1109674340 *)__this, ((*(CameraImageConversionParams_t1109674340 *)((CameraImageConversionParams_t1109674340 *)UnBox(L_1, CameraImageConversionParams_t1109674340_il2cpp_TypeInfo_var)))), /*hidden argument*/NULL);
		return L_2;
	}
}
extern "C"  bool CameraImageConversionParams_Equals_m3483019339_AdjustorThunk (RuntimeObject * __this, RuntimeObject * ___obj0, const RuntimeMethod* method)
{
	CameraImageConversionParams_t1109674340 * _thisAdjusted = reinterpret_cast<CameraImageConversionParams_t1109674340 *>(__this + 1);
	return CameraImageConversionParams_Equals_m3483019339(_thisAdjusted, ___obj0, method);
}
// System.String UnityEngine.XR.ARExtensions.CameraImageConversionParams::ToString()
extern "C" IL2CPP_METHOD_ATTR String_t* CameraImageConversionParams_ToString_m86635840 (CameraImageConversionParams_t1109674340 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CameraImageConversionParams_ToString_m86635840_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ObjectU5BU5D_t2843939325* L_0 = (ObjectU5BU5D_t2843939325*)SZArrayNew(ObjectU5BU5D_t2843939325_il2cpp_TypeInfo_var, (uint32_t)4);
		ObjectU5BU5D_t2843939325* L_1 = L_0;
		RectInt_t1875739471  L_2 = CameraImageConversionParams_get_inputRect_m2276433308((CameraImageConversionParams_t1109674340 *)__this, /*hidden argument*/NULL);
		RectInt_t1875739471  L_3 = L_2;
		RuntimeObject * L_4 = Box(RectInt_t1875739471_il2cpp_TypeInfo_var, &L_3);
		NullCheck(L_1);
		ArrayElementTypeCheck (L_1, L_4);
		(L_1)->SetAt(static_cast<il2cpp_array_size_t>(0), (RuntimeObject *)L_4);
		ObjectU5BU5D_t2843939325* L_5 = L_1;
		Vector2Int_t3469998543  L_6 = CameraImageConversionParams_get_outputDimensions_m158549880((CameraImageConversionParams_t1109674340 *)__this, /*hidden argument*/NULL);
		Vector2Int_t3469998543  L_7 = L_6;
		RuntimeObject * L_8 = Box(Vector2Int_t3469998543_il2cpp_TypeInfo_var, &L_7);
		NullCheck(L_5);
		ArrayElementTypeCheck (L_5, L_8);
		(L_5)->SetAt(static_cast<il2cpp_array_size_t>(1), (RuntimeObject *)L_8);
		ObjectU5BU5D_t2843939325* L_9 = L_5;
		int32_t L_10 = CameraImageConversionParams_get_outputFormat_m780098116((CameraImageConversionParams_t1109674340 *)__this, /*hidden argument*/NULL);
		int32_t L_11 = L_10;
		RuntimeObject * L_12 = Box(TextureFormat_t2701165832_il2cpp_TypeInfo_var, &L_11);
		NullCheck(L_9);
		ArrayElementTypeCheck (L_9, L_12);
		(L_9)->SetAt(static_cast<il2cpp_array_size_t>(2), (RuntimeObject *)L_12);
		ObjectU5BU5D_t2843939325* L_13 = L_9;
		int32_t L_14 = CameraImageConversionParams_get_transformation_m4113259575((CameraImageConversionParams_t1109674340 *)__this, /*hidden argument*/NULL);
		int32_t L_15 = L_14;
		RuntimeObject * L_16 = Box(CameraImageTransformation_t164605461_il2cpp_TypeInfo_var, &L_15);
		NullCheck(L_13);
		ArrayElementTypeCheck (L_13, L_16);
		(L_13)->SetAt(static_cast<il2cpp_array_size_t>(3), (RuntimeObject *)L_16);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_17 = String_Format_m630303134(NULL /*static, unused*/, _stringLiteral4081819098, L_13, /*hidden argument*/NULL);
		return L_17;
	}
}
extern "C"  String_t* CameraImageConversionParams_ToString_m86635840_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	CameraImageConversionParams_t1109674340 * _thisAdjusted = reinterpret_cast<CameraImageConversionParams_t1109674340 *>(__this + 1);
	return CameraImageConversionParams_ToString_m86635840(_thisAdjusted, method);
}
// System.Boolean UnityEngine.XR.ARExtensions.CameraImageConversionParams::Equals(UnityEngine.XR.ARExtensions.CameraImageConversionParams)
extern "C" IL2CPP_METHOD_ATTR bool CameraImageConversionParams_Equals_m237957486 (CameraImageConversionParams_t1109674340 * __this, CameraImageConversionParams_t1109674340  ___other0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CameraImageConversionParams_Equals_m237957486_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	RectInt_t1875739471  V_0;
	memset(&V_0, 0, sizeof(V_0));
	Vector2Int_t3469998543  V_1;
	memset(&V_1, 0, sizeof(V_1));
	int32_t G_B5_0 = 0;
	{
		RectInt_t1875739471  L_0 = CameraImageConversionParams_get_inputRect_m2276433308((CameraImageConversionParams_t1109674340 *)__this, /*hidden argument*/NULL);
		V_0 = L_0;
		RectInt_t1875739471  L_1 = CameraImageConversionParams_get_inputRect_m2276433308((CameraImageConversionParams_t1109674340 *)(&___other0), /*hidden argument*/NULL);
		RectInt_t1875739471  L_2 = L_1;
		RuntimeObject * L_3 = Box(RectInt_t1875739471_il2cpp_TypeInfo_var, &L_2);
		RuntimeObject * L_4 = Box(RectInt_t1875739471_il2cpp_TypeInfo_var, (&V_0));
		NullCheck(L_4);
		bool L_5 = VirtFuncInvoker1< bool, RuntimeObject * >::Invoke(0 /* System.Boolean System.Object::Equals(System.Object) */, L_4, L_3);
		V_0 = *(RectInt_t1875739471 *)UnBox(L_4);
		if (!L_5)
		{
			goto IL_0062;
		}
	}
	{
		Vector2Int_t3469998543  L_6 = CameraImageConversionParams_get_outputDimensions_m158549880((CameraImageConversionParams_t1109674340 *)__this, /*hidden argument*/NULL);
		V_1 = L_6;
		Vector2Int_t3469998543  L_7 = CameraImageConversionParams_get_outputDimensions_m158549880((CameraImageConversionParams_t1109674340 *)(&___other0), /*hidden argument*/NULL);
		bool L_8 = Vector2Int_Equals_m4037425851((Vector2Int_t3469998543 *)(&V_1), L_7, /*hidden argument*/NULL);
		if (!L_8)
		{
			goto IL_0062;
		}
	}
	{
		int32_t L_9 = CameraImageConversionParams_get_outputFormat_m780098116((CameraImageConversionParams_t1109674340 *)__this, /*hidden argument*/NULL);
		int32_t L_10 = CameraImageConversionParams_get_outputFormat_m780098116((CameraImageConversionParams_t1109674340 *)(&___other0), /*hidden argument*/NULL);
		if ((!(((uint32_t)L_9) == ((uint32_t)L_10))))
		{
			goto IL_0062;
		}
	}
	{
		int32_t L_11 = CameraImageConversionParams_get_transformation_m4113259575((CameraImageConversionParams_t1109674340 *)__this, /*hidden argument*/NULL);
		int32_t L_12 = CameraImageConversionParams_get_transformation_m4113259575((CameraImageConversionParams_t1109674340 *)(&___other0), /*hidden argument*/NULL);
		G_B5_0 = ((((int32_t)L_11) == ((int32_t)L_12))? 1 : 0);
		goto IL_0063;
	}

IL_0062:
	{
		G_B5_0 = 0;
	}

IL_0063:
	{
		return (bool)G_B5_0;
	}
}
extern "C"  bool CameraImageConversionParams_Equals_m237957486_AdjustorThunk (RuntimeObject * __this, CameraImageConversionParams_t1109674340  ___other0, const RuntimeMethod* method)
{
	CameraImageConversionParams_t1109674340 * _thisAdjusted = reinterpret_cast<CameraImageConversionParams_t1109674340 *>(__this + 1);
	return CameraImageConversionParams_Equals_m237957486(_thisAdjusted, ___other0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Boolean UnityEngine.XR.ARExtensions.SessionAvailabilityExtensions::IsSupported(UnityEngine.XR.ARExtensions.SessionAvailability)
extern "C" IL2CPP_METHOD_ATTR bool SessionAvailabilityExtensions_IsSupported_m449853241 (RuntimeObject * __this /* static, unused */, int32_t ___availability0, const RuntimeMethod* method)
{
	{
		int32_t L_0 = ___availability0;
		return (bool)((((int32_t)((((int32_t)((int32_t)((int32_t)L_0&(int32_t)2))) == ((int32_t)0))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
// System.Boolean UnityEngine.XR.ARExtensions.SessionAvailabilityExtensions::IsInstalled(UnityEngine.XR.ARExtensions.SessionAvailability)
extern "C" IL2CPP_METHOD_ATTR bool SessionAvailabilityExtensions_IsInstalled_m1398198835 (RuntimeObject * __this /* static, unused */, int32_t ___availability0, const RuntimeMethod* method)
{
	{
		int32_t L_0 = ___availability0;
		return (bool)((((int32_t)((((int32_t)((int32_t)((int32_t)L_0&(int32_t)4))) == ((int32_t)0))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.XR.ARExtensions.XRCameraExtensions::.cctor()
extern "C" IL2CPP_METHOD_ATTR void XRCameraExtensions__cctor_m3236015190 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRCameraExtensions__cctor_m3236015190_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Dictionary_2_t2760358902 * L_0 = (Dictionary_2_t2760358902 *)il2cpp_codegen_object_new(Dictionary_2_t2760358902_il2cpp_TypeInfo_var);
		Dictionary_2__ctor_m555241001(L_0, /*hidden argument*/Dictionary_2__ctor_m555241001_RuntimeMethod_var);
		((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->set_s_IsPermissionGrantedDelegates_4(L_0);
		Dictionary_2_t820068610 * L_1 = (Dictionary_2_t820068610 *)il2cpp_codegen_object_new(Dictionary_2_t820068610_il2cpp_TypeInfo_var);
		Dictionary_2__ctor_m1771204320(L_1, /*hidden argument*/Dictionary_2__ctor_m1771204320_RuntimeMethod_var);
		((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->set_s_TryGetColorCorrectionDelegates_5(L_1);
		Dictionary_2_t1871360775 * L_2 = (Dictionary_2_t1871360775 *)il2cpp_codegen_object_new(Dictionary_2_t1871360775_il2cpp_TypeInfo_var);
		Dictionary_2__ctor_m3075159066(L_2, /*hidden argument*/Dictionary_2__ctor_m3075159066_RuntimeMethod_var);
		((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->set_s_CameraImageApis_6(L_2);
		DefaultCameraImageApi_t2442227313 * L_3 = (DefaultCameraImageApi_t2442227313 *)il2cpp_codegen_object_new(DefaultCameraImageApi_t2442227313_il2cpp_TypeInfo_var);
		DefaultCameraImageApi__ctor_m1806158594(L_3, /*hidden argument*/NULL);
		((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->set_s_DefaultAsyncCameraImageApi_3(L_3);
		XRCameraExtensions_SetDefaultDelegates_m571765574(NULL /*static, unused*/, /*hidden argument*/NULL);
		return;
	}
}
// System.Void UnityEngine.XR.ARExtensions.XRCameraExtensions::RegisterIsPermissionGrantedHandler(System.String,System.Func`2<UnityEngine.Experimental.XR.XRCameraSubsystem,System.Boolean>)
extern "C" IL2CPP_METHOD_ATTR void XRCameraExtensions_RegisterIsPermissionGrantedHandler_m23889859 (RuntimeObject * __this /* static, unused */, String_t* ___subsystemId0, Func_2_t2975102603 * ___handler1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRCameraExtensions_RegisterIsPermissionGrantedHandler_m23889859_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var);
		Dictionary_2_t2760358902 * L_0 = ((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->get_s_IsPermissionGrantedDelegates_4();
		String_t* L_1 = ___subsystemId0;
		Func_2_t2975102603 * L_2 = ___handler1;
		NullCheck(L_0);
		Dictionary_2_set_Item_m3849172357(L_0, L_1, L_2, /*hidden argument*/Dictionary_2_set_Item_m3849172357_RuntimeMethod_var);
		return;
	}
}
// System.Void UnityEngine.XR.ARExtensions.XRCameraExtensions::RegisterCameraImageApi(System.String,UnityEngine.XR.ARExtensions.ICameraImageApi)
extern "C" IL2CPP_METHOD_ATTR void XRCameraExtensions_RegisterCameraImageApi_m4107023354 (RuntimeObject * __this /* static, unused */, String_t* ___subsystemId0, RuntimeObject* ___api1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRCameraExtensions_RegisterCameraImageApi_m4107023354_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var);
		Dictionary_2_t1871360775 * L_0 = ((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->get_s_CameraImageApis_6();
		String_t* L_1 = ___subsystemId0;
		RuntimeObject* L_2 = ___api1;
		NullCheck(L_0);
		Dictionary_2_set_Item_m253421643(L_0, L_1, L_2, /*hidden argument*/Dictionary_2_set_Item_m253421643_RuntimeMethod_var);
		return;
	}
}
// System.Boolean UnityEngine.XR.ARExtensions.XRCameraExtensions::TryGetColorCorrection(UnityEngine.Experimental.XR.XRCameraSubsystem,UnityEngine.Color&)
extern "C" IL2CPP_METHOD_ATTR bool XRCameraExtensions_TryGetColorCorrection_m3844756087 (RuntimeObject * __this /* static, unused */, XRCameraSubsystem_t4195795144 * ___cameraSubsystem0, Color_t2555686324 * ___color1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRCameraExtensions_TryGetColorCorrection_m3844756087_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		XRCameraSubsystem_t4195795144 * L_0 = ___cameraSubsystem0;
		if (L_0)
		{
			goto IL_0011;
		}
	}
	{
		ArgumentNullException_t1615371798 * L_1 = (ArgumentNullException_t1615371798 *)il2cpp_codegen_object_new(ArgumentNullException_t1615371798_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m1170824041(L_1, _stringLiteral1165407477, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1, NULL, XRCameraExtensions_TryGetColorCorrection_m3844756087_RuntimeMethod_var);
	}

IL_0011:
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var);
		TryGetColorCorrectionDelegate_t1034812311 * L_2 = ((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->get_s_TryGetColorCorrectionDelegate_1();
		XRCameraSubsystem_t4195795144 * L_3 = ___cameraSubsystem0;
		Color_t2555686324 * L_4 = ___color1;
		NullCheck(L_2);
		bool L_5 = TryGetColorCorrectionDelegate_Invoke_m442821292(L_2, L_3, (Color_t2555686324 *)L_4, /*hidden argument*/NULL);
		return L_5;
	}
}
// System.Boolean UnityEngine.XR.ARExtensions.XRCameraExtensions::TryGetLatestImage(UnityEngine.Experimental.XR.XRCameraSubsystem,UnityEngine.XR.ARExtensions.CameraImage&)
extern "C" IL2CPP_METHOD_ATTR bool XRCameraExtensions_TryGetLatestImage_m4279998480 (RuntimeObject * __this /* static, unused */, XRCameraSubsystem_t4195795144 * ___cameraSubsystem0, CameraImage_t2783787914 * ___cameraImage1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRCameraExtensions_TryGetLatestImage_m4279998480_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	Vector2Int_t3469998543  V_1;
	memset(&V_1, 0, sizeof(V_1));
	int32_t V_2 = 0;
	double V_3 = 0.0;
	int32_t V_4 = 0;
	CameraImage_t2783787914  V_5;
	memset(&V_5, 0, sizeof(V_5));
	{
		XRCameraSubsystem_t4195795144 * L_0 = ___cameraSubsystem0;
		if (L_0)
		{
			goto IL_0011;
		}
	}
	{
		ArgumentNullException_t1615371798 * L_1 = (ArgumentNullException_t1615371798 *)il2cpp_codegen_object_new(ArgumentNullException_t1615371798_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m1170824041(L_1, _stringLiteral1165407477, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1, NULL, XRCameraExtensions_TryGetLatestImage_m4279998480_RuntimeMethod_var);
	}

IL_0011:
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var);
		RuntimeObject* L_2 = ((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->get_s_AsyncCameraImageApi_2();
		NullCheck(L_2);
		bool L_3 = InterfaceFuncInvoker5< bool, int32_t*, Vector2Int_t3469998543 *, int32_t*, double*, int32_t* >::Invoke(1 /* System.Boolean UnityEngine.XR.ARExtensions.ICameraImageApi::TryAcquireLatestImage(System.Int32&,UnityEngine.Vector2Int&,System.Int32&,System.Double&,UnityEngine.XR.ARExtensions.CameraImageFormat&) */, ICameraImageApi_t2086104476_il2cpp_TypeInfo_var, L_2, (int32_t*)(&V_0), (Vector2Int_t3469998543 *)(&V_1), (int32_t*)(&V_2), (double*)(&V_3), (int32_t*)(&V_4));
		if (!L_3)
		{
			goto IL_003d;
		}
	}
	{
		CameraImage_t2783787914 * L_4 = ___cameraImage1;
		IL2CPP_RUNTIME_CLASS_INIT(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var);
		RuntimeObject* L_5 = ((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->get_s_AsyncCameraImageApi_2();
		int32_t L_6 = V_0;
		Vector2Int_t3469998543  L_7 = V_1;
		int32_t L_8 = V_2;
		double L_9 = V_3;
		int32_t L_10 = V_4;
		CameraImage__ctor_m1119229678((CameraImage_t2783787914 *)L_4, L_5, L_6, L_7, L_8, L_9, L_10, /*hidden argument*/NULL);
		return (bool)1;
	}

IL_003d:
	{
		CameraImage_t2783787914 * L_11 = ___cameraImage1;
		il2cpp_codegen_initobj((&V_5), sizeof(CameraImage_t2783787914 ));
		CameraImage_t2783787914  L_12 = V_5;
		*(CameraImage_t2783787914 *)L_11 = L_12;
		return (bool)0;
	}
}
// System.Void UnityEngine.XR.ARExtensions.XRCameraExtensions::ActivateExtensions(UnityEngine.Experimental.XR.XRCameraSubsystem)
extern "C" IL2CPP_METHOD_ATTR void XRCameraExtensions_ActivateExtensions_m882509077 (RuntimeObject * __this /* static, unused */, XRCameraSubsystem_t4195795144 * ___cameraSubsystem0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRCameraExtensions_ActivateExtensions_m882509077_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	String_t* V_0 = NULL;
	String_t* G_B4_0 = NULL;
	Dictionary_2_t2760358902 * G_B4_1 = NULL;
	String_t* G_B3_0 = NULL;
	Dictionary_2_t2760358902 * G_B3_1 = NULL;
	String_t* G_B6_0 = NULL;
	Dictionary_2_t820068610 * G_B6_1 = NULL;
	String_t* G_B5_0 = NULL;
	Dictionary_2_t820068610 * G_B5_1 = NULL;
	{
		XRCameraSubsystem_t4195795144 * L_0 = ___cameraSubsystem0;
		if (L_0)
		{
			goto IL_0010;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var);
		XRCameraExtensions_SetDefaultDelegates_m571765574(NULL /*static, unused*/, /*hidden argument*/NULL);
		goto IL_008b;
	}

IL_0010:
	{
		XRCameraSubsystem_t4195795144 * L_1 = ___cameraSubsystem0;
		NullCheck(L_1);
		XRCameraSubsystemDescriptor_t3689383335 * L_2 = Subsystem_1_get_SubsystemDescriptor_m441071667(L_1, /*hidden argument*/Subsystem_1_get_SubsystemDescriptor_m441071667_RuntimeMethod_var);
		NullCheck(L_2);
		String_t* L_3 = SubsystemDescriptorBase_get_id_m893539935(L_2, /*hidden argument*/NULL);
		V_0 = L_3;
		IL2CPP_RUNTIME_CLASS_INIT(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var);
		Dictionary_2_t2760358902 * L_4 = ((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->get_s_IsPermissionGrantedDelegates_4();
		String_t* L_5 = V_0;
		Func_2_t2975102603 * L_6 = ((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->get_U3CU3Ef__mgU24cache0_7();
		G_B3_0 = L_5;
		G_B3_1 = L_4;
		if (L_6)
		{
			G_B4_0 = L_5;
			G_B4_1 = L_4;
			goto IL_003a;
		}
	}
	{
		intptr_t L_7 = (intptr_t)XRCameraExtensions_DefaultIsPermissionGranted_m2477879696_RuntimeMethod_var;
		Func_2_t2975102603 * L_8 = (Func_2_t2975102603 *)il2cpp_codegen_object_new(Func_2_t2975102603_il2cpp_TypeInfo_var);
		Func_2__ctor_m2608148365(L_8, NULL, (intptr_t)L_7, /*hidden argument*/Func_2__ctor_m2608148365_RuntimeMethod_var);
		IL2CPP_RUNTIME_CLASS_INIT(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var);
		((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->set_U3CU3Ef__mgU24cache0_7(L_8);
		G_B4_0 = G_B3_0;
		G_B4_1 = G_B3_1;
	}

IL_003a:
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var);
		Func_2_t2975102603 * L_9 = ((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->get_U3CU3Ef__mgU24cache0_7();
		Func_2_t2975102603 * L_10 = RegistrationHelper_GetValueOrDefault_TisString_t_TisFunc_2_t2975102603_m2306524290(NULL /*static, unused*/, G_B4_1, G_B4_0, L_9, /*hidden argument*/RegistrationHelper_GetValueOrDefault_TisString_t_TisFunc_2_t2975102603_m2306524290_RuntimeMethod_var);
		((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->set_s_IsPermissionGrantedDelegate_0(L_10);
		Dictionary_2_t820068610 * L_11 = ((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->get_s_TryGetColorCorrectionDelegates_5();
		String_t* L_12 = V_0;
		TryGetColorCorrectionDelegate_t1034812311 * L_13 = ((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->get_U3CU3Ef__mgU24cache1_8();
		G_B5_0 = L_12;
		G_B5_1 = L_11;
		if (L_13)
		{
			G_B6_0 = L_12;
			G_B6_1 = L_11;
			goto IL_0067;
		}
	}
	{
		intptr_t L_14 = (intptr_t)XRCameraExtensions_DefaultTryGetColorCorrection_m4288959349_RuntimeMethod_var;
		TryGetColorCorrectionDelegate_t1034812311 * L_15 = (TryGetColorCorrectionDelegate_t1034812311 *)il2cpp_codegen_object_new(TryGetColorCorrectionDelegate_t1034812311_il2cpp_TypeInfo_var);
		TryGetColorCorrectionDelegate__ctor_m3211817899(L_15, NULL, (intptr_t)L_14, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var);
		((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->set_U3CU3Ef__mgU24cache1_8(L_15);
		G_B6_0 = G_B5_0;
		G_B6_1 = G_B5_1;
	}

IL_0067:
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var);
		TryGetColorCorrectionDelegate_t1034812311 * L_16 = ((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->get_U3CU3Ef__mgU24cache1_8();
		TryGetColorCorrectionDelegate_t1034812311 * L_17 = RegistrationHelper_GetValueOrDefault_TisString_t_TisTryGetColorCorrectionDelegate_t1034812311_m3517983076(NULL /*static, unused*/, G_B6_1, G_B6_0, L_16, /*hidden argument*/RegistrationHelper_GetValueOrDefault_TisString_t_TisTryGetColorCorrectionDelegate_t1034812311_m3517983076_RuntimeMethod_var);
		((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->set_s_TryGetColorCorrectionDelegate_1(L_17);
		Dictionary_2_t1871360775 * L_18 = ((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->get_s_CameraImageApis_6();
		String_t* L_19 = V_0;
		DefaultCameraImageApi_t2442227313 * L_20 = ((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->get_s_DefaultAsyncCameraImageApi_3();
		RuntimeObject* L_21 = RegistrationHelper_GetValueOrDefault_TisString_t_TisICameraImageApi_t2086104476_m2420324886(NULL /*static, unused*/, L_18, L_19, L_20, /*hidden argument*/RegistrationHelper_GetValueOrDefault_TisString_t_TisICameraImageApi_t2086104476_m2420324886_RuntimeMethod_var);
		((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->set_s_AsyncCameraImageApi_2(L_21);
	}

IL_008b:
	{
		return;
	}
}
// System.Boolean UnityEngine.XR.ARExtensions.XRCameraExtensions::DefaultIsPermissionGranted(UnityEngine.Experimental.XR.XRCameraSubsystem)
extern "C" IL2CPP_METHOD_ATTR bool XRCameraExtensions_DefaultIsPermissionGranted_m2477879696 (RuntimeObject * __this /* static, unused */, XRCameraSubsystem_t4195795144 * ___cameraSubsystem0, const RuntimeMethod* method)
{
	{
		return (bool)1;
	}
}
// System.Boolean UnityEngine.XR.ARExtensions.XRCameraExtensions::DefaultTryGetColorCorrection(UnityEngine.Experimental.XR.XRCameraSubsystem,UnityEngine.Color&)
extern "C" IL2CPP_METHOD_ATTR bool XRCameraExtensions_DefaultTryGetColorCorrection_m4288959349 (RuntimeObject * __this /* static, unused */, XRCameraSubsystem_t4195795144 * ___cameraSubsystem0, Color_t2555686324 * ___color1, const RuntimeMethod* method)
{
	Color_t2555686324  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		Color_t2555686324 * L_0 = ___color1;
		il2cpp_codegen_initobj((&V_0), sizeof(Color_t2555686324 ));
		Color_t2555686324  L_1 = V_0;
		*(Color_t2555686324 *)L_0 = L_1;
		return (bool)0;
	}
}
// System.Void UnityEngine.XR.ARExtensions.XRCameraExtensions::SetDefaultDelegates()
extern "C" IL2CPP_METHOD_ATTR void XRCameraExtensions_SetDefaultDelegates_m571765574 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRCameraExtensions_SetDefaultDelegates_m571765574_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var);
		Func_2_t2975102603 * L_0 = ((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->get_U3CU3Ef__mgU24cache2_9();
		if (L_0)
		{
			goto IL_0018;
		}
	}
	{
		intptr_t L_1 = (intptr_t)XRCameraExtensions_DefaultIsPermissionGranted_m2477879696_RuntimeMethod_var;
		Func_2_t2975102603 * L_2 = (Func_2_t2975102603 *)il2cpp_codegen_object_new(Func_2_t2975102603_il2cpp_TypeInfo_var);
		Func_2__ctor_m2608148365(L_2, NULL, (intptr_t)L_1, /*hidden argument*/Func_2__ctor_m2608148365_RuntimeMethod_var);
		IL2CPP_RUNTIME_CLASS_INIT(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var);
		((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->set_U3CU3Ef__mgU24cache2_9(L_2);
	}

IL_0018:
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var);
		Func_2_t2975102603 * L_3 = ((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->get_U3CU3Ef__mgU24cache2_9();
		((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->set_s_IsPermissionGrantedDelegate_0(L_3);
		TryGetColorCorrectionDelegate_t1034812311 * L_4 = ((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->get_U3CU3Ef__mgU24cache3_10();
		if (L_4)
		{
			goto IL_003a;
		}
	}
	{
		intptr_t L_5 = (intptr_t)XRCameraExtensions_DefaultTryGetColorCorrection_m4288959349_RuntimeMethod_var;
		TryGetColorCorrectionDelegate_t1034812311 * L_6 = (TryGetColorCorrectionDelegate_t1034812311 *)il2cpp_codegen_object_new(TryGetColorCorrectionDelegate_t1034812311_il2cpp_TypeInfo_var);
		TryGetColorCorrectionDelegate__ctor_m3211817899(L_6, NULL, (intptr_t)L_5, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var);
		((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->set_U3CU3Ef__mgU24cache3_10(L_6);
	}

IL_003a:
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var);
		TryGetColorCorrectionDelegate_t1034812311 * L_7 = ((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->get_U3CU3Ef__mgU24cache3_10();
		((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->set_s_TryGetColorCorrectionDelegate_1(L_7);
		DefaultCameraImageApi_t2442227313 * L_8 = ((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->get_s_DefaultAsyncCameraImageApi_3();
		((XRCameraExtensions_t1293988219_StaticFields*)il2cpp_codegen_static_fields_for(XRCameraExtensions_t1293988219_il2cpp_TypeInfo_var))->set_s_AsyncCameraImageApi_2(L_8);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.XR.ARExtensions.XRCameraExtensions/DefaultCameraImageApi::.ctor()
extern "C" IL2CPP_METHOD_ATTR void DefaultCameraImageApi__ctor_m1806158594 (DefaultCameraImageApi_t2442227313 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m297566312(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void UnityEngine.XR.ARExtensions.XRCameraExtensions/DefaultCameraImageApi::DisposeImage(System.Int32)
extern "C" IL2CPP_METHOD_ATTR void DefaultCameraImageApi_DisposeImage_m3853201272 (DefaultCameraImageApi_t2442227313 * __this, int32_t ___nativeHandle0, const RuntimeMethod* method)
{
	{
		return;
	}
}
// System.Boolean UnityEngine.XR.ARExtensions.XRCameraExtensions/DefaultCameraImageApi::TryAcquireLatestImage(System.Int32&,UnityEngine.Vector2Int&,System.Int32&,System.Double&,UnityEngine.XR.ARExtensions.CameraImageFormat&)
extern "C" IL2CPP_METHOD_ATTR bool DefaultCameraImageApi_TryAcquireLatestImage_m549042636 (DefaultCameraImageApi_t2442227313 * __this, int32_t* ___nativeHandle0, Vector2Int_t3469998543 * ___dimensions1, int32_t* ___planeCount2, double* ___timestamp3, int32_t* ___format4, const RuntimeMethod* method)
{
	Vector2Int_t3469998543  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		int32_t* L_0 = ___nativeHandle0;
		*((int32_t*)L_0) = (int32_t)0;
		Vector2Int_t3469998543 * L_1 = ___dimensions1;
		il2cpp_codegen_initobj((&V_0), sizeof(Vector2Int_t3469998543 ));
		Vector2Int_t3469998543  L_2 = V_0;
		*(Vector2Int_t3469998543 *)L_1 = L_2;
		int32_t* L_3 = ___planeCount2;
		*((int32_t*)L_3) = (int32_t)0;
		double* L_4 = ___timestamp3;
		*((double*)L_4) = (double)(0.0);
		int32_t* L_5 = ___format4;
		*((int32_t*)L_5) = (int32_t)0;
		return (bool)0;
	}
}
// System.Boolean UnityEngine.XR.ARExtensions.XRCameraExtensions/DefaultCameraImageApi::NativeHandleValid(System.Int32)
extern "C" IL2CPP_METHOD_ATTR bool DefaultCameraImageApi_NativeHandleValid_m2282301508 (DefaultCameraImageApi_t2442227313 * __this, int32_t ___nativeHandle0, const RuntimeMethod* method)
{
	{
		return (bool)0;
	}
}
// System.Boolean UnityEngine.XR.ARExtensions.XRCameraExtensions/DefaultCameraImageApi::TryGetConvertedDataSize(System.Int32,UnityEngine.Vector2Int,UnityEngine.TextureFormat,System.Int32&)
extern "C" IL2CPP_METHOD_ATTR bool DefaultCameraImageApi_TryGetConvertedDataSize_m3340262224 (DefaultCameraImageApi_t2442227313 * __this, int32_t ___nativeHandle0, Vector2Int_t3469998543  ___dimensions1, int32_t ___format2, int32_t* ___size3, const RuntimeMethod* method)
{
	{
		int32_t* L_0 = ___size3;
		*((int32_t*)L_0) = (int32_t)0;
		return (bool)0;
	}
}
// System.Boolean UnityEngine.XR.ARExtensions.XRCameraExtensions/DefaultCameraImageApi::TryConvert(System.Int32,UnityEngine.XR.ARExtensions.CameraImageConversionParams,System.IntPtr,System.Int32)
extern "C" IL2CPP_METHOD_ATTR bool DefaultCameraImageApi_TryConvert_m1281645091 (DefaultCameraImageApi_t2442227313 * __this, int32_t ___nativeHandle0, CameraImageConversionParams_t1109674340  ___conversionParams1, intptr_t ___destinationBuffer2, int32_t ___bufferLength3, const RuntimeMethod* method)
{
	{
		return (bool)0;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
extern "C"  void DelegatePInvokeWrapper_OnImageRequestCompleteDelegate_t4025953918 (OnImageRequestCompleteDelegate_t4025953918 * __this, int32_t ___status0, CameraImageConversionParams_t1109674340  ___conversionParams1, intptr_t ___dataPtr2, int32_t ___dataLength3, intptr_t ___context4, const RuntimeMethod* method)
{
	typedef void (DEFAULT_CALL *PInvokeFunc)(int32_t, CameraImageConversionParams_t1109674340 , intptr_t, int32_t, intptr_t);
	PInvokeFunc il2cppPInvokeFunc = reinterpret_cast<PInvokeFunc>(il2cpp_codegen_get_method_pointer(((RuntimeDelegate*)__this)->method));

	// Native function invocation
	il2cppPInvokeFunc(___status0, ___conversionParams1, ___dataPtr2, ___dataLength3, ___context4);

}
// System.Void UnityEngine.XR.ARExtensions.XRCameraExtensions/OnImageRequestCompleteDelegate::.ctor(System.Object,System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR void OnImageRequestCompleteDelegate__ctor_m979042311 (OnImageRequestCompleteDelegate_t4025953918 * __this, RuntimeObject * ___object0, intptr_t ___method1, const RuntimeMethod* method)
{
	__this->set_method_ptr_0(il2cpp_codegen_get_method_pointer((RuntimeMethod*)___method1));
	__this->set_method_3(___method1);
	__this->set_m_target_2(___object0);
}
// System.Void UnityEngine.XR.ARExtensions.XRCameraExtensions/OnImageRequestCompleteDelegate::Invoke(UnityEngine.XR.ARExtensions.AsyncCameraImageConversionStatus,UnityEngine.XR.ARExtensions.CameraImageConversionParams,System.IntPtr,System.Int32,System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR void OnImageRequestCompleteDelegate_Invoke_m2486581279 (OnImageRequestCompleteDelegate_t4025953918 * __this, int32_t ___status0, CameraImageConversionParams_t1109674340  ___conversionParams1, intptr_t ___dataPtr2, int32_t ___dataLength3, intptr_t ___context4, const RuntimeMethod* method)
{
	if(__this->get_prev_9() != NULL)
	{
		OnImageRequestCompleteDelegate_Invoke_m2486581279((OnImageRequestCompleteDelegate_t4025953918 *)__this->get_prev_9(), ___status0, ___conversionParams1, ___dataPtr2, ___dataLength3, ___context4, method);
	}
	Il2CppMethodPointer targetMethodPointer = __this->get_method_ptr_0();
	RuntimeMethod* targetMethod = (RuntimeMethod*)(__this->get_method_3());
	RuntimeObject* targetThis = __this->get_m_target_2();
	il2cpp_codegen_raise_execution_engine_exception_if_method_is_not_found(targetMethod);
	bool ___methodIsStatic = MethodIsStatic(targetMethod);
	if (___methodIsStatic)
	{
		if (il2cpp_codegen_method_parameter_count(targetMethod) == 5)
		{
			// open
			{
				typedef void (*FunctionPointerType) (RuntimeObject *, int32_t, CameraImageConversionParams_t1109674340 , intptr_t, int32_t, intptr_t, const RuntimeMethod*);
				((FunctionPointerType)targetMethodPointer)(NULL, ___status0, ___conversionParams1, ___dataPtr2, ___dataLength3, ___context4, targetMethod);
			}
		}
		else
		{
			// closed
			{
				typedef void (*FunctionPointerType) (RuntimeObject *, void*, int32_t, CameraImageConversionParams_t1109674340 , intptr_t, int32_t, intptr_t, const RuntimeMethod*);
				((FunctionPointerType)targetMethodPointer)(NULL, targetThis, ___status0, ___conversionParams1, ___dataPtr2, ___dataLength3, ___context4, targetMethod);
			}
		}
	}
	else
	{
		{
			// closed
			if (il2cpp_codegen_method_is_virtual(targetMethod) && !il2cpp_codegen_object_is_of_sealed_type(targetThis) && il2cpp_codegen_delegate_has_invoker((Il2CppDelegate*)__this))
			{
				if (il2cpp_codegen_method_is_generic_instance(targetMethod))
				{
					if (il2cpp_codegen_method_is_interface_method(targetMethod))
						GenericInterfaceActionInvoker5< int32_t, CameraImageConversionParams_t1109674340 , intptr_t, int32_t, intptr_t >::Invoke(targetMethod, targetThis, ___status0, ___conversionParams1, ___dataPtr2, ___dataLength3, ___context4);
					else
						GenericVirtActionInvoker5< int32_t, CameraImageConversionParams_t1109674340 , intptr_t, int32_t, intptr_t >::Invoke(targetMethod, targetThis, ___status0, ___conversionParams1, ___dataPtr2, ___dataLength3, ___context4);
				}
				else
				{
					if (il2cpp_codegen_method_is_interface_method(targetMethod))
						InterfaceActionInvoker5< int32_t, CameraImageConversionParams_t1109674340 , intptr_t, int32_t, intptr_t >::Invoke(il2cpp_codegen_method_get_slot(targetMethod), il2cpp_codegen_method_get_declaring_type(targetMethod), targetThis, ___status0, ___conversionParams1, ___dataPtr2, ___dataLength3, ___context4);
					else
						VirtActionInvoker5< int32_t, CameraImageConversionParams_t1109674340 , intptr_t, int32_t, intptr_t >::Invoke(il2cpp_codegen_method_get_slot(targetMethod), targetThis, ___status0, ___conversionParams1, ___dataPtr2, ___dataLength3, ___context4);
				}
			}
			else
			{
				typedef void (*FunctionPointerType) (void*, int32_t, CameraImageConversionParams_t1109674340 , intptr_t, int32_t, intptr_t, const RuntimeMethod*);
				((FunctionPointerType)targetMethodPointer)(targetThis, ___status0, ___conversionParams1, ___dataPtr2, ___dataLength3, ___context4, targetMethod);
			}
		}
	}
}
// System.IAsyncResult UnityEngine.XR.ARExtensions.XRCameraExtensions/OnImageRequestCompleteDelegate::BeginInvoke(UnityEngine.XR.ARExtensions.AsyncCameraImageConversionStatus,UnityEngine.XR.ARExtensions.CameraImageConversionParams,System.IntPtr,System.Int32,System.IntPtr,System.AsyncCallback,System.Object)
extern "C" IL2CPP_METHOD_ATTR RuntimeObject* OnImageRequestCompleteDelegate_BeginInvoke_m1021759379 (OnImageRequestCompleteDelegate_t4025953918 * __this, int32_t ___status0, CameraImageConversionParams_t1109674340  ___conversionParams1, intptr_t ___dataPtr2, int32_t ___dataLength3, intptr_t ___context4, AsyncCallback_t3962456242 * ___callback5, RuntimeObject * ___object6, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (OnImageRequestCompleteDelegate_BeginInvoke_m1021759379_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	void *__d_args[6] = {0};
	__d_args[0] = Box(AsyncCameraImageConversionStatus_t11558803_il2cpp_TypeInfo_var, &___status0);
	__d_args[1] = Box(CameraImageConversionParams_t1109674340_il2cpp_TypeInfo_var, &___conversionParams1);
	__d_args[2] = Box(IntPtr_t_il2cpp_TypeInfo_var, &___dataPtr2);
	__d_args[3] = Box(Int32_t2950945753_il2cpp_TypeInfo_var, &___dataLength3);
	__d_args[4] = Box(IntPtr_t_il2cpp_TypeInfo_var, &___context4);
	return (RuntimeObject*)il2cpp_codegen_delegate_begin_invoke((RuntimeDelegate*)__this, __d_args, (RuntimeDelegate*)___callback5, (RuntimeObject*)___object6);
}
// System.Void UnityEngine.XR.ARExtensions.XRCameraExtensions/OnImageRequestCompleteDelegate::EndInvoke(System.IAsyncResult)
extern "C" IL2CPP_METHOD_ATTR void OnImageRequestCompleteDelegate_EndInvoke_m2731507256 (OnImageRequestCompleteDelegate_t4025953918 * __this, RuntimeObject* ___result0, const RuntimeMethod* method)
{
	il2cpp_codegen_delegate_end_invoke((Il2CppAsyncResult*) ___result0, 0);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.XR.ARExtensions.XRCameraExtensions/TryGetColorCorrectionDelegate::.ctor(System.Object,System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR void TryGetColorCorrectionDelegate__ctor_m3211817899 (TryGetColorCorrectionDelegate_t1034812311 * __this, RuntimeObject * ___object0, intptr_t ___method1, const RuntimeMethod* method)
{
	__this->set_method_ptr_0(il2cpp_codegen_get_method_pointer((RuntimeMethod*)___method1));
	__this->set_method_3(___method1);
	__this->set_m_target_2(___object0);
}
// System.Boolean UnityEngine.XR.ARExtensions.XRCameraExtensions/TryGetColorCorrectionDelegate::Invoke(UnityEngine.Experimental.XR.XRCameraSubsystem,UnityEngine.Color&)
extern "C" IL2CPP_METHOD_ATTR bool TryGetColorCorrectionDelegate_Invoke_m442821292 (TryGetColorCorrectionDelegate_t1034812311 * __this, XRCameraSubsystem_t4195795144 * ___cameraSubsystems0, Color_t2555686324 * ___color1, const RuntimeMethod* method)
{
	bool result = false;
	if(__this->get_prev_9() != NULL)
	{
		TryGetColorCorrectionDelegate_Invoke_m442821292((TryGetColorCorrectionDelegate_t1034812311 *)__this->get_prev_9(), ___cameraSubsystems0, ___color1, method);
	}
	Il2CppMethodPointer targetMethodPointer = __this->get_method_ptr_0();
	RuntimeMethod* targetMethod = (RuntimeMethod*)(__this->get_method_3());
	RuntimeObject* targetThis = __this->get_m_target_2();
	il2cpp_codegen_raise_execution_engine_exception_if_method_is_not_found(targetMethod);
	bool ___methodIsStatic = MethodIsStatic(targetMethod);
	if (___methodIsStatic)
	{
		if (il2cpp_codegen_method_parameter_count(targetMethod) == 2)
		{
			// open
			{
				typedef bool (*FunctionPointerType) (RuntimeObject *, XRCameraSubsystem_t4195795144 *, Color_t2555686324 *, const RuntimeMethod*);
				result = ((FunctionPointerType)targetMethodPointer)(NULL, ___cameraSubsystems0, ___color1, targetMethod);
			}
		}
		else
		{
			// closed
			{
				typedef bool (*FunctionPointerType) (RuntimeObject *, void*, XRCameraSubsystem_t4195795144 *, Color_t2555686324 *, const RuntimeMethod*);
				result = ((FunctionPointerType)targetMethodPointer)(NULL, targetThis, ___cameraSubsystems0, ___color1, targetMethod);
			}
		}
	}
	else
	{
		if (il2cpp_codegen_method_parameter_count(targetMethod) == 2)
		{
			// closed
			if (il2cpp_codegen_method_is_virtual(targetMethod) && !il2cpp_codegen_object_is_of_sealed_type(targetThis) && il2cpp_codegen_delegate_has_invoker((Il2CppDelegate*)__this))
			{
				if (il2cpp_codegen_method_is_generic_instance(targetMethod))
				{
					if (il2cpp_codegen_method_is_interface_method(targetMethod))
						result = GenericInterfaceFuncInvoker2< bool, XRCameraSubsystem_t4195795144 *, Color_t2555686324 * >::Invoke(targetMethod, targetThis, ___cameraSubsystems0, ___color1);
					else
						result = GenericVirtFuncInvoker2< bool, XRCameraSubsystem_t4195795144 *, Color_t2555686324 * >::Invoke(targetMethod, targetThis, ___cameraSubsystems0, ___color1);
				}
				else
				{
					if (il2cpp_codegen_method_is_interface_method(targetMethod))
						result = InterfaceFuncInvoker2< bool, XRCameraSubsystem_t4195795144 *, Color_t2555686324 * >::Invoke(il2cpp_codegen_method_get_slot(targetMethod), il2cpp_codegen_method_get_declaring_type(targetMethod), targetThis, ___cameraSubsystems0, ___color1);
					else
						result = VirtFuncInvoker2< bool, XRCameraSubsystem_t4195795144 *, Color_t2555686324 * >::Invoke(il2cpp_codegen_method_get_slot(targetMethod), targetThis, ___cameraSubsystems0, ___color1);
				}
			}
			else
			{
				typedef bool (*FunctionPointerType) (void*, XRCameraSubsystem_t4195795144 *, Color_t2555686324 *, const RuntimeMethod*);
				result = ((FunctionPointerType)targetMethodPointer)(targetThis, ___cameraSubsystems0, ___color1, targetMethod);
			}
		}
		else
		{
			// open
			if (il2cpp_codegen_method_is_virtual(targetMethod) && !il2cpp_codegen_object_is_of_sealed_type(targetThis) && il2cpp_codegen_delegate_has_invoker((Il2CppDelegate*)__this))
			{
				if (il2cpp_codegen_method_is_generic_instance(targetMethod))
				{
					if (il2cpp_codegen_method_is_interface_method(targetMethod))
						result = GenericInterfaceFuncInvoker1< bool, Color_t2555686324 * >::Invoke(targetMethod, ___cameraSubsystems0, ___color1);
					else
						result = GenericVirtFuncInvoker1< bool, Color_t2555686324 * >::Invoke(targetMethod, ___cameraSubsystems0, ___color1);
				}
				else
				{
					if (il2cpp_codegen_method_is_interface_method(targetMethod))
						result = InterfaceFuncInvoker1< bool, Color_t2555686324 * >::Invoke(il2cpp_codegen_method_get_slot(targetMethod), il2cpp_codegen_method_get_declaring_type(targetMethod), ___cameraSubsystems0, ___color1);
					else
						result = VirtFuncInvoker1< bool, Color_t2555686324 * >::Invoke(il2cpp_codegen_method_get_slot(targetMethod), ___cameraSubsystems0, ___color1);
				}
			}
			else
			{
				typedef bool (*FunctionPointerType) (XRCameraSubsystem_t4195795144 *, Color_t2555686324 *, const RuntimeMethod*);
				result = ((FunctionPointerType)targetMethodPointer)(___cameraSubsystems0, ___color1, targetMethod);
			}
		}
	}
	return result;
}
// System.IAsyncResult UnityEngine.XR.ARExtensions.XRCameraExtensions/TryGetColorCorrectionDelegate::BeginInvoke(UnityEngine.Experimental.XR.XRCameraSubsystem,UnityEngine.Color&,System.AsyncCallback,System.Object)
extern "C" IL2CPP_METHOD_ATTR RuntimeObject* TryGetColorCorrectionDelegate_BeginInvoke_m1810176191 (TryGetColorCorrectionDelegate_t1034812311 * __this, XRCameraSubsystem_t4195795144 * ___cameraSubsystems0, Color_t2555686324 * ___color1, AsyncCallback_t3962456242 * ___callback2, RuntimeObject * ___object3, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TryGetColorCorrectionDelegate_BeginInvoke_m1810176191_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	void *__d_args[3] = {0};
	__d_args[0] = ___cameraSubsystems0;
	__d_args[1] = Box(Color_t2555686324_il2cpp_TypeInfo_var, &*___color1);
	return (RuntimeObject*)il2cpp_codegen_delegate_begin_invoke((RuntimeDelegate*)__this, __d_args, (RuntimeDelegate*)___callback2, (RuntimeObject*)___object3);
}
// System.Boolean UnityEngine.XR.ARExtensions.XRCameraExtensions/TryGetColorCorrectionDelegate::EndInvoke(UnityEngine.Color&,System.IAsyncResult)
extern "C" IL2CPP_METHOD_ATTR bool TryGetColorCorrectionDelegate_EndInvoke_m4215197378 (TryGetColorCorrectionDelegate_t1034812311 * __this, Color_t2555686324 * ___color0, RuntimeObject* ___result1, const RuntimeMethod* method)
{
	void* ___out_args[] = {
	___color0,
	};
	RuntimeObject *__result = il2cpp_codegen_delegate_end_invoke((Il2CppAsyncResult*) ___result1, ___out_args);
	return *(bool*)UnBox ((RuntimeObject*)__result);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.XR.ARExtensions.XRPlaneExtensions::.cctor()
extern "C" IL2CPP_METHOD_ATTR void XRPlaneExtensions__cctor_m1656397022 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRPlaneExtensions__cctor_m1656397022_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Dictionary_2_t2706875346 * L_0 = (Dictionary_2_t2706875346 *)il2cpp_codegen_object_new(Dictionary_2_t2706875346_il2cpp_TypeInfo_var);
		Dictionary_2__ctor_m2975023327(L_0, /*hidden argument*/Dictionary_2__ctor_m2975023327_RuntimeMethod_var);
		((XRPlaneExtensions_t1202600805_StaticFields*)il2cpp_codegen_static_fields_for(XRPlaneExtensions_t1202600805_il2cpp_TypeInfo_var))->set_s_GetTrackingStateDelegates_1(L_0);
		XRPlaneExtensions_SetDefaultDelegates_m3956413843(NULL /*static, unused*/, /*hidden argument*/NULL);
		return;
	}
}
// System.Void UnityEngine.XR.ARExtensions.XRPlaneExtensions::RegisterGetTrackingStateHandler(System.String,System.Func`3<UnityEngine.Experimental.XR.XRPlaneSubsystem,UnityEngine.Experimental.XR.TrackableId,UnityEngine.Experimental.XR.TrackingState>)
extern "C" IL2CPP_METHOD_ATTR void XRPlaneExtensions_RegisterGetTrackingStateHandler_m3719762041 (RuntimeObject * __this /* static, unused */, String_t* ___subsystemId0, Func_3_t2921619047 * ___handler1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRPlaneExtensions_RegisterGetTrackingStateHandler_m3719762041_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRPlaneExtensions_t1202600805_il2cpp_TypeInfo_var);
		Dictionary_2_t2706875346 * L_0 = ((XRPlaneExtensions_t1202600805_StaticFields*)il2cpp_codegen_static_fields_for(XRPlaneExtensions_t1202600805_il2cpp_TypeInfo_var))->get_s_GetTrackingStateDelegates_1();
		String_t* L_1 = ___subsystemId0;
		Func_3_t2921619047 * L_2 = ___handler1;
		NullCheck(L_0);
		Dictionary_2_set_Item_m3827254201(L_0, L_1, L_2, /*hidden argument*/Dictionary_2_set_Item_m3827254201_RuntimeMethod_var);
		return;
	}
}
// UnityEngine.Experimental.XR.TrackingState UnityEngine.XR.ARExtensions.XRPlaneExtensions::GetTrackingState(UnityEngine.Experimental.XR.XRPlaneSubsystem,UnityEngine.Experimental.XR.TrackableId)
extern "C" IL2CPP_METHOD_ATTR int32_t XRPlaneExtensions_GetTrackingState_m2696238282 (RuntimeObject * __this /* static, unused */, XRPlaneSubsystem_t2260142932 * ___planeSubsystem0, TrackableId_t1251031970  ___planeId1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRPlaneExtensions_GetTrackingState_m2696238282_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		XRPlaneSubsystem_t2260142932 * L_0 = ___planeSubsystem0;
		if (L_0)
		{
			goto IL_0011;
		}
	}
	{
		ArgumentNullException_t1615371798 * L_1 = (ArgumentNullException_t1615371798 *)il2cpp_codegen_object_new(ArgumentNullException_t1615371798_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m1170824041(L_1, _stringLiteral2235816782, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1, NULL, XRPlaneExtensions_GetTrackingState_m2696238282_RuntimeMethod_var);
	}

IL_0011:
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRPlaneExtensions_t1202600805_il2cpp_TypeInfo_var);
		Func_3_t2921619047 * L_2 = ((XRPlaneExtensions_t1202600805_StaticFields*)il2cpp_codegen_static_fields_for(XRPlaneExtensions_t1202600805_il2cpp_TypeInfo_var))->get_s_GetTrackingStateDelegate_0();
		XRPlaneSubsystem_t2260142932 * L_3 = ___planeSubsystem0;
		TrackableId_t1251031970  L_4 = ___planeId1;
		NullCheck(L_2);
		int32_t L_5 = Func_3_Invoke_m2530530313(L_2, L_3, L_4, /*hidden argument*/Func_3_Invoke_m2530530313_RuntimeMethod_var);
		return L_5;
	}
}
// UnityEngine.Experimental.XR.TrackingState UnityEngine.XR.ARExtensions.XRPlaneExtensions::DefaultGetTrackingState(UnityEngine.Experimental.XR.XRPlaneSubsystem,UnityEngine.Experimental.XR.TrackableId)
extern "C" IL2CPP_METHOD_ATTR int32_t XRPlaneExtensions_DefaultGetTrackingState_m2407700671 (RuntimeObject * __this /* static, unused */, XRPlaneSubsystem_t2260142932 * ___planeSubsystem0, TrackableId_t1251031970  ___planeId1, const RuntimeMethod* method)
{
	{
		return (int32_t)(0);
	}
}
// System.Void UnityEngine.XR.ARExtensions.XRPlaneExtensions::ActivateExtensions(UnityEngine.Experimental.XR.XRPlaneSubsystem)
extern "C" IL2CPP_METHOD_ATTR void XRPlaneExtensions_ActivateExtensions_m2242243429 (RuntimeObject * __this /* static, unused */, XRPlaneSubsystem_t2260142932 * ___planeSubsystem0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRPlaneExtensions_ActivateExtensions_m2242243429_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	String_t* V_0 = NULL;
	String_t* G_B4_0 = NULL;
	Dictionary_2_t2706875346 * G_B4_1 = NULL;
	String_t* G_B3_0 = NULL;
	Dictionary_2_t2706875346 * G_B3_1 = NULL;
	{
		XRPlaneSubsystem_t2260142932 * L_0 = ___planeSubsystem0;
		if (L_0)
		{
			goto IL_0010;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRPlaneExtensions_t1202600805_il2cpp_TypeInfo_var);
		XRPlaneExtensions_SetDefaultDelegates_m3956413843(NULL /*static, unused*/, /*hidden argument*/NULL);
		goto IL_0049;
	}

IL_0010:
	{
		XRPlaneSubsystem_t2260142932 * L_1 = ___planeSubsystem0;
		NullCheck(L_1);
		XRPlaneSubsystemDescriptor_t234166304 * L_2 = Subsystem_1_get_SubsystemDescriptor_m2169025228(L_1, /*hidden argument*/Subsystem_1_get_SubsystemDescriptor_m2169025228_RuntimeMethod_var);
		NullCheck(L_2);
		String_t* L_3 = SubsystemDescriptorBase_get_id_m893539935(L_2, /*hidden argument*/NULL);
		V_0 = L_3;
		IL2CPP_RUNTIME_CLASS_INIT(XRPlaneExtensions_t1202600805_il2cpp_TypeInfo_var);
		Dictionary_2_t2706875346 * L_4 = ((XRPlaneExtensions_t1202600805_StaticFields*)il2cpp_codegen_static_fields_for(XRPlaneExtensions_t1202600805_il2cpp_TypeInfo_var))->get_s_GetTrackingStateDelegates_1();
		String_t* L_5 = V_0;
		Func_3_t2921619047 * L_6 = ((XRPlaneExtensions_t1202600805_StaticFields*)il2cpp_codegen_static_fields_for(XRPlaneExtensions_t1202600805_il2cpp_TypeInfo_var))->get_U3CU3Ef__mgU24cache0_2();
		G_B3_0 = L_5;
		G_B3_1 = L_4;
		if (L_6)
		{
			G_B4_0 = L_5;
			G_B4_1 = L_4;
			goto IL_003a;
		}
	}
	{
		intptr_t L_7 = (intptr_t)XRPlaneExtensions_DefaultGetTrackingState_m2407700671_RuntimeMethod_var;
		Func_3_t2921619047 * L_8 = (Func_3_t2921619047 *)il2cpp_codegen_object_new(Func_3_t2921619047_il2cpp_TypeInfo_var);
		Func_3__ctor_m1014428649(L_8, NULL, (intptr_t)L_7, /*hidden argument*/Func_3__ctor_m1014428649_RuntimeMethod_var);
		IL2CPP_RUNTIME_CLASS_INIT(XRPlaneExtensions_t1202600805_il2cpp_TypeInfo_var);
		((XRPlaneExtensions_t1202600805_StaticFields*)il2cpp_codegen_static_fields_for(XRPlaneExtensions_t1202600805_il2cpp_TypeInfo_var))->set_U3CU3Ef__mgU24cache0_2(L_8);
		G_B4_0 = G_B3_0;
		G_B4_1 = G_B3_1;
	}

IL_003a:
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRPlaneExtensions_t1202600805_il2cpp_TypeInfo_var);
		Func_3_t2921619047 * L_9 = ((XRPlaneExtensions_t1202600805_StaticFields*)il2cpp_codegen_static_fields_for(XRPlaneExtensions_t1202600805_il2cpp_TypeInfo_var))->get_U3CU3Ef__mgU24cache0_2();
		Func_3_t2921619047 * L_10 = RegistrationHelper_GetValueOrDefault_TisString_t_TisFunc_3_t2921619047_m1497402927(NULL /*static, unused*/, G_B4_1, G_B4_0, L_9, /*hidden argument*/RegistrationHelper_GetValueOrDefault_TisString_t_TisFunc_3_t2921619047_m1497402927_RuntimeMethod_var);
		((XRPlaneExtensions_t1202600805_StaticFields*)il2cpp_codegen_static_fields_for(XRPlaneExtensions_t1202600805_il2cpp_TypeInfo_var))->set_s_GetTrackingStateDelegate_0(L_10);
	}

IL_0049:
	{
		return;
	}
}
// System.Void UnityEngine.XR.ARExtensions.XRPlaneExtensions::SetDefaultDelegates()
extern "C" IL2CPP_METHOD_ATTR void XRPlaneExtensions_SetDefaultDelegates_m3956413843 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRPlaneExtensions_SetDefaultDelegates_m3956413843_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRPlaneExtensions_t1202600805_il2cpp_TypeInfo_var);
		Func_3_t2921619047 * L_0 = ((XRPlaneExtensions_t1202600805_StaticFields*)il2cpp_codegen_static_fields_for(XRPlaneExtensions_t1202600805_il2cpp_TypeInfo_var))->get_U3CU3Ef__mgU24cache1_3();
		if (L_0)
		{
			goto IL_0018;
		}
	}
	{
		intptr_t L_1 = (intptr_t)XRPlaneExtensions_DefaultGetTrackingState_m2407700671_RuntimeMethod_var;
		Func_3_t2921619047 * L_2 = (Func_3_t2921619047 *)il2cpp_codegen_object_new(Func_3_t2921619047_il2cpp_TypeInfo_var);
		Func_3__ctor_m1014428649(L_2, NULL, (intptr_t)L_1, /*hidden argument*/Func_3__ctor_m1014428649_RuntimeMethod_var);
		IL2CPP_RUNTIME_CLASS_INIT(XRPlaneExtensions_t1202600805_il2cpp_TypeInfo_var);
		((XRPlaneExtensions_t1202600805_StaticFields*)il2cpp_codegen_static_fields_for(XRPlaneExtensions_t1202600805_il2cpp_TypeInfo_var))->set_U3CU3Ef__mgU24cache1_3(L_2);
	}

IL_0018:
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRPlaneExtensions_t1202600805_il2cpp_TypeInfo_var);
		Func_3_t2921619047 * L_3 = ((XRPlaneExtensions_t1202600805_StaticFields*)il2cpp_codegen_static_fields_for(XRPlaneExtensions_t1202600805_il2cpp_TypeInfo_var))->get_U3CU3Ef__mgU24cache1_3();
		((XRPlaneExtensions_t1202600805_StaticFields*)il2cpp_codegen_static_fields_for(XRPlaneExtensions_t1202600805_il2cpp_TypeInfo_var))->set_s_GetTrackingStateDelegate_0(L_3);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.XR.ARExtensions.XRReferencePointExtensions::.cctor()
extern "C" IL2CPP_METHOD_ATTR void XRReferencePointExtensions__cctor_m3153365008 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRReferencePointExtensions__cctor_m3153365008_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Dictionary_2_t204178958 * L_0 = (Dictionary_2_t204178958 *)il2cpp_codegen_object_new(Dictionary_2_t204178958_il2cpp_TypeInfo_var);
		Dictionary_2__ctor_m49728138(L_0, /*hidden argument*/Dictionary_2__ctor_m49728138_RuntimeMethod_var);
		((XRReferencePointExtensions_t125072412_StaticFields*)il2cpp_codegen_static_fields_for(XRReferencePointExtensions_t125072412_il2cpp_TypeInfo_var))->set_s_AttachReferencePointDelegates_1(L_0);
		XRReferencePointExtensions_SetDefaultDelegates_m4188249370(NULL /*static, unused*/, /*hidden argument*/NULL);
		return;
	}
}
// System.Void UnityEngine.XR.ARExtensions.XRReferencePointExtensions::RegisterAttachReferencePointHandler(System.String,UnityEngine.XR.ARExtensions.XRReferencePointExtensions/AttachReferencePointDelegate)
extern "C" IL2CPP_METHOD_ATTR void XRReferencePointExtensions_RegisterAttachReferencePointHandler_m2848125376 (RuntimeObject * __this /* static, unused */, String_t* ___subsystemId0, AttachReferencePointDelegate_t418922659 * ___handler1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRReferencePointExtensions_RegisterAttachReferencePointHandler_m2848125376_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRReferencePointExtensions_t125072412_il2cpp_TypeInfo_var);
		Dictionary_2_t204178958 * L_0 = ((XRReferencePointExtensions_t125072412_StaticFields*)il2cpp_codegen_static_fields_for(XRReferencePointExtensions_t125072412_il2cpp_TypeInfo_var))->get_s_AttachReferencePointDelegates_1();
		String_t* L_1 = ___subsystemId0;
		AttachReferencePointDelegate_t418922659 * L_2 = ___handler1;
		NullCheck(L_0);
		Dictionary_2_set_Item_m3033294665(L_0, L_1, L_2, /*hidden argument*/Dictionary_2_set_Item_m3033294665_RuntimeMethod_var);
		return;
	}
}
// UnityEngine.Experimental.XR.TrackableId UnityEngine.XR.ARExtensions.XRReferencePointExtensions::AttachReferencePoint(UnityEngine.Experimental.XR.XRReferencePointSubsystem,UnityEngine.Experimental.XR.TrackableId,UnityEngine.Pose)
extern "C" IL2CPP_METHOD_ATTR TrackableId_t1251031970  XRReferencePointExtensions_AttachReferencePoint_m42308643 (RuntimeObject * __this /* static, unused */, XRReferencePointSubsystem_t416875062 * ___referencePointSubsystem0, TrackableId_t1251031970  ___trackableId1, Pose_t545244865  ___pose2, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRReferencePointExtensions_AttachReferencePoint_m42308643_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		XRReferencePointSubsystem_t416875062 * L_0 = ___referencePointSubsystem0;
		if (L_0)
		{
			goto IL_0011;
		}
	}
	{
		ArgumentNullException_t1615371798 * L_1 = (ArgumentNullException_t1615371798 *)il2cpp_codegen_object_new(ArgumentNullException_t1615371798_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m1170824041(L_1, _stringLiteral834956432, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1, NULL, XRReferencePointExtensions_AttachReferencePoint_m42308643_RuntimeMethod_var);
	}

IL_0011:
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRReferencePointExtensions_t125072412_il2cpp_TypeInfo_var);
		AttachReferencePointDelegate_t418922659 * L_2 = ((XRReferencePointExtensions_t125072412_StaticFields*)il2cpp_codegen_static_fields_for(XRReferencePointExtensions_t125072412_il2cpp_TypeInfo_var))->get_s_AttachReferencePointDelegate_0();
		XRReferencePointSubsystem_t416875062 * L_3 = ___referencePointSubsystem0;
		TrackableId_t1251031970  L_4 = ___trackableId1;
		Pose_t545244865  L_5 = ___pose2;
		NullCheck(L_2);
		TrackableId_t1251031970  L_6 = AttachReferencePointDelegate_Invoke_m3134245136(L_2, L_3, L_4, L_5, /*hidden argument*/NULL);
		return L_6;
	}
}
// UnityEngine.Experimental.XR.TrackableId UnityEngine.XR.ARExtensions.XRReferencePointExtensions::DefaultAttachReferencePoint(UnityEngine.Experimental.XR.XRReferencePointSubsystem,UnityEngine.Experimental.XR.TrackableId,UnityEngine.Pose)
extern "C" IL2CPP_METHOD_ATTR TrackableId_t1251031970  XRReferencePointExtensions_DefaultAttachReferencePoint_m4195628539 (RuntimeObject * __this /* static, unused */, XRReferencePointSubsystem_t416875062 * ___referencePointSubsystem0, TrackableId_t1251031970  ___trackableId1, Pose_t545244865  ___pose2, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRReferencePointExtensions_DefaultAttachReferencePoint_m4195628539_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(TrackableId_t1251031970_il2cpp_TypeInfo_var);
		TrackableId_t1251031970  L_0 = TrackableId_get_InvalidId_m4062814271(NULL /*static, unused*/, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Void UnityEngine.XR.ARExtensions.XRReferencePointExtensions::ActivateExtensions(UnityEngine.Experimental.XR.XRReferencePointSubsystem)
extern "C" IL2CPP_METHOD_ATTR void XRReferencePointExtensions_ActivateExtensions_m2683210974 (RuntimeObject * __this /* static, unused */, XRReferencePointSubsystem_t416875062 * ___referencePointSubsystem0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRReferencePointExtensions_ActivateExtensions_m2683210974_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	String_t* V_0 = NULL;
	String_t* G_B4_0 = NULL;
	Dictionary_2_t204178958 * G_B4_1 = NULL;
	String_t* G_B3_0 = NULL;
	Dictionary_2_t204178958 * G_B3_1 = NULL;
	{
		XRReferencePointSubsystem_t416875062 * L_0 = ___referencePointSubsystem0;
		if (L_0)
		{
			goto IL_0010;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRReferencePointExtensions_t125072412_il2cpp_TypeInfo_var);
		XRReferencePointExtensions_SetDefaultDelegates_m4188249370(NULL /*static, unused*/, /*hidden argument*/NULL);
		goto IL_0049;
	}

IL_0010:
	{
		XRReferencePointSubsystem_t416875062 * L_1 = ___referencePointSubsystem0;
		NullCheck(L_1);
		XRReferencePointSubsystemDescriptor_t1659547698 * L_2 = Subsystem_1_get_SubsystemDescriptor_m3649074082(L_1, /*hidden argument*/Subsystem_1_get_SubsystemDescriptor_m3649074082_RuntimeMethod_var);
		NullCheck(L_2);
		String_t* L_3 = SubsystemDescriptorBase_get_id_m893539935(L_2, /*hidden argument*/NULL);
		V_0 = L_3;
		IL2CPP_RUNTIME_CLASS_INIT(XRReferencePointExtensions_t125072412_il2cpp_TypeInfo_var);
		Dictionary_2_t204178958 * L_4 = ((XRReferencePointExtensions_t125072412_StaticFields*)il2cpp_codegen_static_fields_for(XRReferencePointExtensions_t125072412_il2cpp_TypeInfo_var))->get_s_AttachReferencePointDelegates_1();
		String_t* L_5 = V_0;
		AttachReferencePointDelegate_t418922659 * L_6 = ((XRReferencePointExtensions_t125072412_StaticFields*)il2cpp_codegen_static_fields_for(XRReferencePointExtensions_t125072412_il2cpp_TypeInfo_var))->get_U3CU3Ef__mgU24cache0_2();
		G_B3_0 = L_5;
		G_B3_1 = L_4;
		if (L_6)
		{
			G_B4_0 = L_5;
			G_B4_1 = L_4;
			goto IL_003a;
		}
	}
	{
		intptr_t L_7 = (intptr_t)XRReferencePointExtensions_DefaultAttachReferencePoint_m4195628539_RuntimeMethod_var;
		AttachReferencePointDelegate_t418922659 * L_8 = (AttachReferencePointDelegate_t418922659 *)il2cpp_codegen_object_new(AttachReferencePointDelegate_t418922659_il2cpp_TypeInfo_var);
		AttachReferencePointDelegate__ctor_m3040356846(L_8, NULL, (intptr_t)L_7, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(XRReferencePointExtensions_t125072412_il2cpp_TypeInfo_var);
		((XRReferencePointExtensions_t125072412_StaticFields*)il2cpp_codegen_static_fields_for(XRReferencePointExtensions_t125072412_il2cpp_TypeInfo_var))->set_U3CU3Ef__mgU24cache0_2(L_8);
		G_B4_0 = G_B3_0;
		G_B4_1 = G_B3_1;
	}

IL_003a:
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRReferencePointExtensions_t125072412_il2cpp_TypeInfo_var);
		AttachReferencePointDelegate_t418922659 * L_9 = ((XRReferencePointExtensions_t125072412_StaticFields*)il2cpp_codegen_static_fields_for(XRReferencePointExtensions_t125072412_il2cpp_TypeInfo_var))->get_U3CU3Ef__mgU24cache0_2();
		AttachReferencePointDelegate_t418922659 * L_10 = RegistrationHelper_GetValueOrDefault_TisString_t_TisAttachReferencePointDelegate_t418922659_m850717648(NULL /*static, unused*/, G_B4_1, G_B4_0, L_9, /*hidden argument*/RegistrationHelper_GetValueOrDefault_TisString_t_TisAttachReferencePointDelegate_t418922659_m850717648_RuntimeMethod_var);
		((XRReferencePointExtensions_t125072412_StaticFields*)il2cpp_codegen_static_fields_for(XRReferencePointExtensions_t125072412_il2cpp_TypeInfo_var))->set_s_AttachReferencePointDelegate_0(L_10);
	}

IL_0049:
	{
		return;
	}
}
// System.Void UnityEngine.XR.ARExtensions.XRReferencePointExtensions::SetDefaultDelegates()
extern "C" IL2CPP_METHOD_ATTR void XRReferencePointExtensions_SetDefaultDelegates_m4188249370 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRReferencePointExtensions_SetDefaultDelegates_m4188249370_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRReferencePointExtensions_t125072412_il2cpp_TypeInfo_var);
		AttachReferencePointDelegate_t418922659 * L_0 = ((XRReferencePointExtensions_t125072412_StaticFields*)il2cpp_codegen_static_fields_for(XRReferencePointExtensions_t125072412_il2cpp_TypeInfo_var))->get_U3CU3Ef__mgU24cache1_3();
		if (L_0)
		{
			goto IL_0018;
		}
	}
	{
		intptr_t L_1 = (intptr_t)XRReferencePointExtensions_DefaultAttachReferencePoint_m4195628539_RuntimeMethod_var;
		AttachReferencePointDelegate_t418922659 * L_2 = (AttachReferencePointDelegate_t418922659 *)il2cpp_codegen_object_new(AttachReferencePointDelegate_t418922659_il2cpp_TypeInfo_var);
		AttachReferencePointDelegate__ctor_m3040356846(L_2, NULL, (intptr_t)L_1, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(XRReferencePointExtensions_t125072412_il2cpp_TypeInfo_var);
		((XRReferencePointExtensions_t125072412_StaticFields*)il2cpp_codegen_static_fields_for(XRReferencePointExtensions_t125072412_il2cpp_TypeInfo_var))->set_U3CU3Ef__mgU24cache1_3(L_2);
	}

IL_0018:
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRReferencePointExtensions_t125072412_il2cpp_TypeInfo_var);
		AttachReferencePointDelegate_t418922659 * L_3 = ((XRReferencePointExtensions_t125072412_StaticFields*)il2cpp_codegen_static_fields_for(XRReferencePointExtensions_t125072412_il2cpp_TypeInfo_var))->get_U3CU3Ef__mgU24cache1_3();
		((XRReferencePointExtensions_t125072412_StaticFields*)il2cpp_codegen_static_fields_for(XRReferencePointExtensions_t125072412_il2cpp_TypeInfo_var))->set_s_AttachReferencePointDelegate_0(L_3);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.XR.ARExtensions.XRReferencePointExtensions/AttachReferencePointDelegate::.ctor(System.Object,System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR void AttachReferencePointDelegate__ctor_m3040356846 (AttachReferencePointDelegate_t418922659 * __this, RuntimeObject * ___object0, intptr_t ___method1, const RuntimeMethod* method)
{
	__this->set_method_ptr_0(il2cpp_codegen_get_method_pointer((RuntimeMethod*)___method1));
	__this->set_method_3(___method1);
	__this->set_m_target_2(___object0);
}
// UnityEngine.Experimental.XR.TrackableId UnityEngine.XR.ARExtensions.XRReferencePointExtensions/AttachReferencePointDelegate::Invoke(UnityEngine.Experimental.XR.XRReferencePointSubsystem,UnityEngine.Experimental.XR.TrackableId,UnityEngine.Pose)
extern "C" IL2CPP_METHOD_ATTR TrackableId_t1251031970  AttachReferencePointDelegate_Invoke_m3134245136 (AttachReferencePointDelegate_t418922659 * __this, XRReferencePointSubsystem_t416875062 * ___referencePointSubsystem0, TrackableId_t1251031970  ___trackableId1, Pose_t545244865  ___pose2, const RuntimeMethod* method)
{
	TrackableId_t1251031970  result;
	memset(&result, 0, sizeof(result));
	if(__this->get_prev_9() != NULL)
	{
		AttachReferencePointDelegate_Invoke_m3134245136((AttachReferencePointDelegate_t418922659 *)__this->get_prev_9(), ___referencePointSubsystem0, ___trackableId1, ___pose2, method);
	}
	Il2CppMethodPointer targetMethodPointer = __this->get_method_ptr_0();
	RuntimeMethod* targetMethod = (RuntimeMethod*)(__this->get_method_3());
	RuntimeObject* targetThis = __this->get_m_target_2();
	il2cpp_codegen_raise_execution_engine_exception_if_method_is_not_found(targetMethod);
	bool ___methodIsStatic = MethodIsStatic(targetMethod);
	if (___methodIsStatic)
	{
		if (il2cpp_codegen_method_parameter_count(targetMethod) == 3)
		{
			// open
			{
				typedef TrackableId_t1251031970  (*FunctionPointerType) (RuntimeObject *, XRReferencePointSubsystem_t416875062 *, TrackableId_t1251031970 , Pose_t545244865 , const RuntimeMethod*);
				result = ((FunctionPointerType)targetMethodPointer)(NULL, ___referencePointSubsystem0, ___trackableId1, ___pose2, targetMethod);
			}
		}
		else
		{
			// closed
			{
				typedef TrackableId_t1251031970  (*FunctionPointerType) (RuntimeObject *, void*, XRReferencePointSubsystem_t416875062 *, TrackableId_t1251031970 , Pose_t545244865 , const RuntimeMethod*);
				result = ((FunctionPointerType)targetMethodPointer)(NULL, targetThis, ___referencePointSubsystem0, ___trackableId1, ___pose2, targetMethod);
			}
		}
	}
	else
	{
		if (il2cpp_codegen_method_parameter_count(targetMethod) == 3)
		{
			// closed
			if (il2cpp_codegen_method_is_virtual(targetMethod) && !il2cpp_codegen_object_is_of_sealed_type(targetThis) && il2cpp_codegen_delegate_has_invoker((Il2CppDelegate*)__this))
			{
				if (il2cpp_codegen_method_is_generic_instance(targetMethod))
				{
					if (il2cpp_codegen_method_is_interface_method(targetMethod))
						result = GenericInterfaceFuncInvoker3< TrackableId_t1251031970 , XRReferencePointSubsystem_t416875062 *, TrackableId_t1251031970 , Pose_t545244865  >::Invoke(targetMethod, targetThis, ___referencePointSubsystem0, ___trackableId1, ___pose2);
					else
						result = GenericVirtFuncInvoker3< TrackableId_t1251031970 , XRReferencePointSubsystem_t416875062 *, TrackableId_t1251031970 , Pose_t545244865  >::Invoke(targetMethod, targetThis, ___referencePointSubsystem0, ___trackableId1, ___pose2);
				}
				else
				{
					if (il2cpp_codegen_method_is_interface_method(targetMethod))
						result = InterfaceFuncInvoker3< TrackableId_t1251031970 , XRReferencePointSubsystem_t416875062 *, TrackableId_t1251031970 , Pose_t545244865  >::Invoke(il2cpp_codegen_method_get_slot(targetMethod), il2cpp_codegen_method_get_declaring_type(targetMethod), targetThis, ___referencePointSubsystem0, ___trackableId1, ___pose2);
					else
						result = VirtFuncInvoker3< TrackableId_t1251031970 , XRReferencePointSubsystem_t416875062 *, TrackableId_t1251031970 , Pose_t545244865  >::Invoke(il2cpp_codegen_method_get_slot(targetMethod), targetThis, ___referencePointSubsystem0, ___trackableId1, ___pose2);
				}
			}
			else
			{
				typedef TrackableId_t1251031970  (*FunctionPointerType) (void*, XRReferencePointSubsystem_t416875062 *, TrackableId_t1251031970 , Pose_t545244865 , const RuntimeMethod*);
				result = ((FunctionPointerType)targetMethodPointer)(targetThis, ___referencePointSubsystem0, ___trackableId1, ___pose2, targetMethod);
			}
		}
		else
		{
			// open
			if (il2cpp_codegen_method_is_virtual(targetMethod) && !il2cpp_codegen_object_is_of_sealed_type(targetThis) && il2cpp_codegen_delegate_has_invoker((Il2CppDelegate*)__this))
			{
				if (il2cpp_codegen_method_is_generic_instance(targetMethod))
				{
					if (il2cpp_codegen_method_is_interface_method(targetMethod))
						result = GenericInterfaceFuncInvoker2< TrackableId_t1251031970 , TrackableId_t1251031970 , Pose_t545244865  >::Invoke(targetMethod, ___referencePointSubsystem0, ___trackableId1, ___pose2);
					else
						result = GenericVirtFuncInvoker2< TrackableId_t1251031970 , TrackableId_t1251031970 , Pose_t545244865  >::Invoke(targetMethod, ___referencePointSubsystem0, ___trackableId1, ___pose2);
				}
				else
				{
					if (il2cpp_codegen_method_is_interface_method(targetMethod))
						result = InterfaceFuncInvoker2< TrackableId_t1251031970 , TrackableId_t1251031970 , Pose_t545244865  >::Invoke(il2cpp_codegen_method_get_slot(targetMethod), il2cpp_codegen_method_get_declaring_type(targetMethod), ___referencePointSubsystem0, ___trackableId1, ___pose2);
					else
						result = VirtFuncInvoker2< TrackableId_t1251031970 , TrackableId_t1251031970 , Pose_t545244865  >::Invoke(il2cpp_codegen_method_get_slot(targetMethod), ___referencePointSubsystem0, ___trackableId1, ___pose2);
				}
			}
			else
			{
				typedef TrackableId_t1251031970  (*FunctionPointerType) (XRReferencePointSubsystem_t416875062 *, TrackableId_t1251031970 , Pose_t545244865 , const RuntimeMethod*);
				result = ((FunctionPointerType)targetMethodPointer)(___referencePointSubsystem0, ___trackableId1, ___pose2, targetMethod);
			}
		}
	}
	return result;
}
// System.IAsyncResult UnityEngine.XR.ARExtensions.XRReferencePointExtensions/AttachReferencePointDelegate::BeginInvoke(UnityEngine.Experimental.XR.XRReferencePointSubsystem,UnityEngine.Experimental.XR.TrackableId,UnityEngine.Pose,System.AsyncCallback,System.Object)
extern "C" IL2CPP_METHOD_ATTR RuntimeObject* AttachReferencePointDelegate_BeginInvoke_m455971734 (AttachReferencePointDelegate_t418922659 * __this, XRReferencePointSubsystem_t416875062 * ___referencePointSubsystem0, TrackableId_t1251031970  ___trackableId1, Pose_t545244865  ___pose2, AsyncCallback_t3962456242 * ___callback3, RuntimeObject * ___object4, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AttachReferencePointDelegate_BeginInvoke_m455971734_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	void *__d_args[4] = {0};
	__d_args[0] = ___referencePointSubsystem0;
	__d_args[1] = Box(TrackableId_t1251031970_il2cpp_TypeInfo_var, &___trackableId1);
	__d_args[2] = Box(Pose_t545244865_il2cpp_TypeInfo_var, &___pose2);
	return (RuntimeObject*)il2cpp_codegen_delegate_begin_invoke((RuntimeDelegate*)__this, __d_args, (RuntimeDelegate*)___callback3, (RuntimeObject*)___object4);
}
// UnityEngine.Experimental.XR.TrackableId UnityEngine.XR.ARExtensions.XRReferencePointExtensions/AttachReferencePointDelegate::EndInvoke(System.IAsyncResult)
extern "C" IL2CPP_METHOD_ATTR TrackableId_t1251031970  AttachReferencePointDelegate_EndInvoke_m197713093 (AttachReferencePointDelegate_t418922659 * __this, RuntimeObject* ___result0, const RuntimeMethod* method)
{
	RuntimeObject *__result = il2cpp_codegen_delegate_end_invoke((Il2CppAsyncResult*) ___result0, 0);
	return *(TrackableId_t1251031970 *)UnBox ((RuntimeObject*)__result);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.XR.ARExtensions.XRSessionExtensions::.cctor()
extern "C" IL2CPP_METHOD_ATTR void XRSessionExtensions__cctor_m298900539 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRSessionExtensions__cctor_m298900539_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Dictionary_2_t757416466 * L_0 = (Dictionary_2_t757416466 *)il2cpp_codegen_object_new(Dictionary_2_t757416466_il2cpp_TypeInfo_var);
		Dictionary_2__ctor_m1921437841(L_0, /*hidden argument*/Dictionary_2__ctor_m1921437841_RuntimeMethod_var);
		((XRSessionExtensions_t411788579_StaticFields*)il2cpp_codegen_static_fields_for(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var))->set_s_InstallAsyncDelegates_2(L_0);
		Dictionary_2_t3245361703 * L_1 = (Dictionary_2_t3245361703 *)il2cpp_codegen_object_new(Dictionary_2_t3245361703_il2cpp_TypeInfo_var);
		Dictionary_2__ctor_m383910843(L_1, /*hidden argument*/Dictionary_2__ctor_m383910843_RuntimeMethod_var);
		((XRSessionExtensions_t411788579_StaticFields*)il2cpp_codegen_static_fields_for(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var))->set_s_GetAvailabilityAsyncDelegates_3(L_1);
		XRSessionExtensions_SetDefaultDelegates_m2570236516(NULL /*static, unused*/, /*hidden argument*/NULL);
		return;
	}
}
// System.Void UnityEngine.XR.ARExtensions.XRSessionExtensions::RegisterGetAvailabilityAsyncHandler(System.String,UnityEngine.XR.ARExtensions.XRSessionExtensions/AsyncDelegate`1<UnityEngine.XR.ARExtensions.SessionAvailability>)
extern "C" IL2CPP_METHOD_ATTR void XRSessionExtensions_RegisterGetAvailabilityAsyncHandler_m3177527582 (RuntimeObject * __this /* static, unused */, String_t* ___subsystemId0, AsyncDelegate_1_t3460105404 * ___handler1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRSessionExtensions_RegisterGetAvailabilityAsyncHandler_m3177527582_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var);
		Dictionary_2_t3245361703 * L_0 = ((XRSessionExtensions_t411788579_StaticFields*)il2cpp_codegen_static_fields_for(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var))->get_s_GetAvailabilityAsyncDelegates_3();
		String_t* L_1 = ___subsystemId0;
		AsyncDelegate_1_t3460105404 * L_2 = ___handler1;
		NullCheck(L_0);
		Dictionary_2_set_Item_m2124544062(L_0, L_1, L_2, /*hidden argument*/Dictionary_2_set_Item_m2124544062_RuntimeMethod_var);
		return;
	}
}
// UnityEngine.XR.ARExtensions.Promise`1<UnityEngine.XR.ARExtensions.SessionAvailability> UnityEngine.XR.ARExtensions.XRSessionExtensions::GetAvailabilityAsync(UnityEngine.Experimental.XR.XRSessionSubsystem)
extern "C" IL2CPP_METHOD_ATTR Promise_1_t3923167537 * XRSessionExtensions_GetAvailabilityAsync_m1573784747 (RuntimeObject * __this /* static, unused */, XRSessionSubsystem_t3616338244 * ___sessionSubsystem0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRSessionExtensions_GetAvailabilityAsync_m1573784747_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		XRSessionSubsystem_t3616338244 * L_0 = ___sessionSubsystem0;
		if (L_0)
		{
			goto IL_0011;
		}
	}
	{
		ArgumentNullException_t1615371798 * L_1 = (ArgumentNullException_t1615371798 *)il2cpp_codegen_object_new(ArgumentNullException_t1615371798_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m1170824041(L_1, _stringLiteral1345581681, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1, NULL, XRSessionExtensions_GetAvailabilityAsync_m1573784747_RuntimeMethod_var);
	}

IL_0011:
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var);
		AsyncDelegate_1_t3460105404 * L_2 = ((XRSessionExtensions_t411788579_StaticFields*)il2cpp_codegen_static_fields_for(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var))->get_s_GetAvailabilityAsyncDelegate_1();
		XRSessionSubsystem_t3616338244 * L_3 = ___sessionSubsystem0;
		NullCheck(L_2);
		Promise_1_t3923167537 * L_4 = AsyncDelegate_1_Invoke_m1924773735(L_2, L_3, /*hidden argument*/AsyncDelegate_1_Invoke_m1924773735_RuntimeMethod_var);
		return L_4;
	}
}
// UnityEngine.XR.ARExtensions.Promise`1<UnityEngine.XR.ARExtensions.SessionAvailability> UnityEngine.XR.ARExtensions.XRSessionExtensions::DefaultGetAvailabilityAsync(UnityEngine.Experimental.XR.XRSessionSubsystem)
extern "C" IL2CPP_METHOD_ATTR Promise_1_t3923167537 * XRSessionExtensions_DefaultGetAvailabilityAsync_m4160736096 (RuntimeObject * __this /* static, unused */, XRSessionSubsystem_t3616338244 * ___sessionSubsystem0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRSessionExtensions_DefaultGetAvailabilityAsync_m4160736096_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Promise_1_t3923167537 * L_0 = Promise_1_CreateResolvedPromise_m420313478(NULL /*static, unused*/, 6, /*hidden argument*/Promise_1_CreateResolvedPromise_m420313478_RuntimeMethod_var);
		return L_0;
	}
}
// UnityEngine.XR.ARExtensions.Promise`1<UnityEngine.XR.ARExtensions.SessionInstallationStatus> UnityEngine.XR.ARExtensions.XRSessionExtensions::InstallAsync(UnityEngine.Experimental.XR.XRSessionSubsystem)
extern "C" IL2CPP_METHOD_ATTR Promise_1_t1435222300 * XRSessionExtensions_InstallAsync_m658298074 (RuntimeObject * __this /* static, unused */, XRSessionSubsystem_t3616338244 * ___sessionSubsystem0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRSessionExtensions_InstallAsync_m658298074_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		XRSessionSubsystem_t3616338244 * L_0 = ___sessionSubsystem0;
		if (L_0)
		{
			goto IL_0011;
		}
	}
	{
		ArgumentNullException_t1615371798 * L_1 = (ArgumentNullException_t1615371798 *)il2cpp_codegen_object_new(ArgumentNullException_t1615371798_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m1170824041(L_1, _stringLiteral1345581681, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1, NULL, XRSessionExtensions_InstallAsync_m658298074_RuntimeMethod_var);
	}

IL_0011:
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var);
		AsyncDelegate_1_t972160167 * L_2 = ((XRSessionExtensions_t411788579_StaticFields*)il2cpp_codegen_static_fields_for(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var))->get_s_InstallAsyncDelegate_0();
		XRSessionSubsystem_t3616338244 * L_3 = ___sessionSubsystem0;
		NullCheck(L_2);
		Promise_1_t1435222300 * L_4 = AsyncDelegate_1_Invoke_m723727912(L_2, L_3, /*hidden argument*/AsyncDelegate_1_Invoke_m723727912_RuntimeMethod_var);
		return L_4;
	}
}
// UnityEngine.XR.ARExtensions.Promise`1<UnityEngine.XR.ARExtensions.SessionInstallationStatus> UnityEngine.XR.ARExtensions.XRSessionExtensions::DefaultInstallAsync(UnityEngine.Experimental.XR.XRSessionSubsystem)
extern "C" IL2CPP_METHOD_ATTR Promise_1_t1435222300 * XRSessionExtensions_DefaultInstallAsync_m325129405 (RuntimeObject * __this /* static, unused */, XRSessionSubsystem_t3616338244 * ___sessionSubsystem0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRSessionExtensions_DefaultInstallAsync_m325129405_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Promise_1_t1435222300 * L_0 = Promise_1_CreateResolvedPromise_m3838876404(NULL /*static, unused*/, 4, /*hidden argument*/Promise_1_CreateResolvedPromise_m3838876404_RuntimeMethod_var);
		return L_0;
	}
}
// System.Void UnityEngine.XR.ARExtensions.XRSessionExtensions::ActivateExtensions(UnityEngine.Experimental.XR.XRSessionSubsystem)
extern "C" IL2CPP_METHOD_ATTR void XRSessionExtensions_ActivateExtensions_m1327610782 (RuntimeObject * __this /* static, unused */, XRSessionSubsystem_t3616338244 * ___sessionSubsystem0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRSessionExtensions_ActivateExtensions_m1327610782_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	String_t* V_0 = NULL;
	String_t* G_B4_0 = NULL;
	Dictionary_2_t757416466 * G_B4_1 = NULL;
	String_t* G_B3_0 = NULL;
	Dictionary_2_t757416466 * G_B3_1 = NULL;
	String_t* G_B6_0 = NULL;
	Dictionary_2_t3245361703 * G_B6_1 = NULL;
	String_t* G_B5_0 = NULL;
	Dictionary_2_t3245361703 * G_B5_1 = NULL;
	{
		XRSessionSubsystem_t3616338244 * L_0 = ___sessionSubsystem0;
		if (L_0)
		{
			goto IL_0010;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var);
		XRSessionExtensions_SetDefaultDelegates_m2570236516(NULL /*static, unused*/, /*hidden argument*/NULL);
		goto IL_0076;
	}

IL_0010:
	{
		XRSessionSubsystem_t3616338244 * L_1 = ___sessionSubsystem0;
		NullCheck(L_1);
		XRSessionSubsystemDescriptor_t1188836047 * L_2 = Subsystem_1_get_SubsystemDescriptor_m1208900687(L_1, /*hidden argument*/Subsystem_1_get_SubsystemDescriptor_m1208900687_RuntimeMethod_var);
		NullCheck(L_2);
		String_t* L_3 = SubsystemDescriptorBase_get_id_m893539935(L_2, /*hidden argument*/NULL);
		V_0 = L_3;
		IL2CPP_RUNTIME_CLASS_INIT(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var);
		Dictionary_2_t757416466 * L_4 = ((XRSessionExtensions_t411788579_StaticFields*)il2cpp_codegen_static_fields_for(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var))->get_s_InstallAsyncDelegates_2();
		String_t* L_5 = V_0;
		AsyncDelegate_1_t972160167 * L_6 = ((XRSessionExtensions_t411788579_StaticFields*)il2cpp_codegen_static_fields_for(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var))->get_U3CU3Ef__mgU24cache0_4();
		G_B3_0 = L_5;
		G_B3_1 = L_4;
		if (L_6)
		{
			G_B4_0 = L_5;
			G_B4_1 = L_4;
			goto IL_003a;
		}
	}
	{
		intptr_t L_7 = (intptr_t)XRSessionExtensions_DefaultInstallAsync_m325129405_RuntimeMethod_var;
		AsyncDelegate_1_t972160167 * L_8 = (AsyncDelegate_1_t972160167 *)il2cpp_codegen_object_new(AsyncDelegate_1_t972160167_il2cpp_TypeInfo_var);
		AsyncDelegate_1__ctor_m2374002471(L_8, NULL, (intptr_t)L_7, /*hidden argument*/AsyncDelegate_1__ctor_m2374002471_RuntimeMethod_var);
		IL2CPP_RUNTIME_CLASS_INIT(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var);
		((XRSessionExtensions_t411788579_StaticFields*)il2cpp_codegen_static_fields_for(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var))->set_U3CU3Ef__mgU24cache0_4(L_8);
		G_B4_0 = G_B3_0;
		G_B4_1 = G_B3_1;
	}

IL_003a:
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var);
		AsyncDelegate_1_t972160167 * L_9 = ((XRSessionExtensions_t411788579_StaticFields*)il2cpp_codegen_static_fields_for(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var))->get_U3CU3Ef__mgU24cache0_4();
		AsyncDelegate_1_t972160167 * L_10 = RegistrationHelper_GetValueOrDefault_TisString_t_TisAsyncDelegate_1_t972160167_m3126187069(NULL /*static, unused*/, G_B4_1, G_B4_0, L_9, /*hidden argument*/RegistrationHelper_GetValueOrDefault_TisString_t_TisAsyncDelegate_1_t972160167_m3126187069_RuntimeMethod_var);
		((XRSessionExtensions_t411788579_StaticFields*)il2cpp_codegen_static_fields_for(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var))->set_s_InstallAsyncDelegate_0(L_10);
		Dictionary_2_t3245361703 * L_11 = ((XRSessionExtensions_t411788579_StaticFields*)il2cpp_codegen_static_fields_for(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var))->get_s_GetAvailabilityAsyncDelegates_3();
		String_t* L_12 = V_0;
		AsyncDelegate_1_t3460105404 * L_13 = ((XRSessionExtensions_t411788579_StaticFields*)il2cpp_codegen_static_fields_for(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var))->get_U3CU3Ef__mgU24cache1_5();
		G_B5_0 = L_12;
		G_B5_1 = L_11;
		if (L_13)
		{
			G_B6_0 = L_12;
			G_B6_1 = L_11;
			goto IL_0067;
		}
	}
	{
		intptr_t L_14 = (intptr_t)XRSessionExtensions_DefaultGetAvailabilityAsync_m4160736096_RuntimeMethod_var;
		AsyncDelegate_1_t3460105404 * L_15 = (AsyncDelegate_1_t3460105404 *)il2cpp_codegen_object_new(AsyncDelegate_1_t3460105404_il2cpp_TypeInfo_var);
		AsyncDelegate_1__ctor_m1054827699(L_15, NULL, (intptr_t)L_14, /*hidden argument*/AsyncDelegate_1__ctor_m1054827699_RuntimeMethod_var);
		IL2CPP_RUNTIME_CLASS_INIT(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var);
		((XRSessionExtensions_t411788579_StaticFields*)il2cpp_codegen_static_fields_for(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var))->set_U3CU3Ef__mgU24cache1_5(L_15);
		G_B6_0 = G_B5_0;
		G_B6_1 = G_B5_1;
	}

IL_0067:
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var);
		AsyncDelegate_1_t3460105404 * L_16 = ((XRSessionExtensions_t411788579_StaticFields*)il2cpp_codegen_static_fields_for(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var))->get_U3CU3Ef__mgU24cache1_5();
		AsyncDelegate_1_t3460105404 * L_17 = RegistrationHelper_GetValueOrDefault_TisString_t_TisAsyncDelegate_1_t3460105404_m3679850741(NULL /*static, unused*/, G_B6_1, G_B6_0, L_16, /*hidden argument*/RegistrationHelper_GetValueOrDefault_TisString_t_TisAsyncDelegate_1_t3460105404_m3679850741_RuntimeMethod_var);
		((XRSessionExtensions_t411788579_StaticFields*)il2cpp_codegen_static_fields_for(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var))->set_s_GetAvailabilityAsyncDelegate_1(L_17);
	}

IL_0076:
	{
		return;
	}
}
// System.Void UnityEngine.XR.ARExtensions.XRSessionExtensions::SetDefaultDelegates()
extern "C" IL2CPP_METHOD_ATTR void XRSessionExtensions_SetDefaultDelegates_m2570236516 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (XRSessionExtensions_SetDefaultDelegates_m2570236516_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var);
		AsyncDelegate_1_t972160167 * L_0 = ((XRSessionExtensions_t411788579_StaticFields*)il2cpp_codegen_static_fields_for(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var))->get_U3CU3Ef__mgU24cache2_6();
		if (L_0)
		{
			goto IL_0018;
		}
	}
	{
		intptr_t L_1 = (intptr_t)XRSessionExtensions_DefaultInstallAsync_m325129405_RuntimeMethod_var;
		AsyncDelegate_1_t972160167 * L_2 = (AsyncDelegate_1_t972160167 *)il2cpp_codegen_object_new(AsyncDelegate_1_t972160167_il2cpp_TypeInfo_var);
		AsyncDelegate_1__ctor_m2374002471(L_2, NULL, (intptr_t)L_1, /*hidden argument*/AsyncDelegate_1__ctor_m2374002471_RuntimeMethod_var);
		IL2CPP_RUNTIME_CLASS_INIT(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var);
		((XRSessionExtensions_t411788579_StaticFields*)il2cpp_codegen_static_fields_for(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var))->set_U3CU3Ef__mgU24cache2_6(L_2);
	}

IL_0018:
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var);
		AsyncDelegate_1_t972160167 * L_3 = ((XRSessionExtensions_t411788579_StaticFields*)il2cpp_codegen_static_fields_for(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var))->get_U3CU3Ef__mgU24cache2_6();
		((XRSessionExtensions_t411788579_StaticFields*)il2cpp_codegen_static_fields_for(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var))->set_s_InstallAsyncDelegate_0(L_3);
		AsyncDelegate_1_t3460105404 * L_4 = ((XRSessionExtensions_t411788579_StaticFields*)il2cpp_codegen_static_fields_for(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var))->get_U3CU3Ef__mgU24cache3_7();
		if (L_4)
		{
			goto IL_003a;
		}
	}
	{
		intptr_t L_5 = (intptr_t)XRSessionExtensions_DefaultGetAvailabilityAsync_m4160736096_RuntimeMethod_var;
		AsyncDelegate_1_t3460105404 * L_6 = (AsyncDelegate_1_t3460105404 *)il2cpp_codegen_object_new(AsyncDelegate_1_t3460105404_il2cpp_TypeInfo_var);
		AsyncDelegate_1__ctor_m1054827699(L_6, NULL, (intptr_t)L_5, /*hidden argument*/AsyncDelegate_1__ctor_m1054827699_RuntimeMethod_var);
		IL2CPP_RUNTIME_CLASS_INIT(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var);
		((XRSessionExtensions_t411788579_StaticFields*)il2cpp_codegen_static_fields_for(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var))->set_U3CU3Ef__mgU24cache3_7(L_6);
	}

IL_003a:
	{
		IL2CPP_RUNTIME_CLASS_INIT(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var);
		AsyncDelegate_1_t3460105404 * L_7 = ((XRSessionExtensions_t411788579_StaticFields*)il2cpp_codegen_static_fields_for(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var))->get_U3CU3Ef__mgU24cache3_7();
		((XRSessionExtensions_t411788579_StaticFields*)il2cpp_codegen_static_fields_for(XRSessionExtensions_t411788579_il2cpp_TypeInfo_var))->set_s_GetAvailabilityAsyncDelegate_1(L_7);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
